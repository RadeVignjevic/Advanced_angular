# Day 1 – Modern Angular Architecture and Reactive Primitives

## Instructor Guide (2 Hours)

---

## 📋 Agenda Overview

| Block | Topic | Duration |
|-------|-------|----------|
| 1 | Angular Evolution: From Modules to Standalone | 30 min |
| 2 | Standalone Components in Depth | 45 min |
| 3 | Practical Workshop: Module-to-Standalone Migration | 45 min |

---

## Prerequisites

- Node.js 18+ and npm installed
- Angular CLI installed (`npm install -g @angular/cli`)
- The demo project running: `cd angular-architecture-demo && npm install && ng serve`

Open `http://localhost:4200` — the sidebar navigation separates **🔴 NgModule-based (legacy)** and **🟢 Standalone (modern)** features so participants can see both patterns side by side.

---

---

# Block 1: Angular Evolution — From Modules to Standalone (30 min)

## 1.1 Historical Context (10 min)

### The NgModule Era (Angular 2–13)

Every Angular application was built around **NgModules**. A module was the fundamental unit of organization:

```
┌─────────────────────────────────────────┐
│  Feature Module (NgModule)              │
│                                         │
│  declarations: [ ComponentA,            │
│                   ComponentB,           │
│                   PipeX,                │
│                   DirectiveY ]          │
│                                         │
│  imports:      [ CommonModule,          │
│                   RouterModule,         │
│                   SharedModule ]        │
│                                         │
│  providers:    [ FeatureService ]       │
│                                         │
│  exports:      [ ComponentA ]           │
└─────────────────────────────────────────┘
```

**Pain points of the NgModule approach:**

1. **Boilerplate** — Every feature requires a module file that lists declarations, imports, providers, and exports
2. **Implicit dependencies** — A component doesn't declare what it needs; it inherits everything from its module
3. **CommonModule everywhere** — Every feature module must import `CommonModule` for `*ngFor`, `*ngIf`, pipes, etc.
4. **Indirection** — To understand what a component can use, you must trace through its module's imports
5. **Bundle complexity** — Tree-shaking is harder when modules group unrelated code together

> **📂 Demo file:** Open `src/app/features/products/products.module.ts` — this is a traditional NgModule feature.

```typescript
// products.module.ts — Traditional NgModule pattern
@NgModule({
  declarations: [          // Components belong to this module
    ProductListComponent,
    ProductDetailComponent
  ],
  imports: [
    CommonModule,          // Needed for *ngFor, *ngIf, pipes
    ProductsRoutingModule  // Routing wrapped in an NgModule
  ]
})
export class ProductsModule {}
```

**Ask participants:** *"How many files do you need to create a new feature with 2 components and routing?"*
Answer: At minimum 4 — the module, the routing module, and 2 component files.

---

### 1.2 The Standalone Revolution (Angular 14+) (10 min)

Angular 14 introduced **standalone components** as optional. Angular 15–16 made them stable. **Angular 19+ made standalone the default** — you now must explicitly set `standalone: false` if you want NgModule-based components.

**Key change:** Components declare their own dependencies.

```
┌─────────────────────────────────────────┐
│  Standalone Component                   │
│                                         │
│  @Component({                           │
│    imports: [ RouterLink, DatePipe ],   │  ← Self-contained
│    template: `...`,                     │
│  })                                     │
│  export class UserListComponent { }     │
│                                         │
│  // No NgModule needed!                 │
└─────────────────────────────────────────┘
```

> **📂 Demo file:** Open `src/app/features/users/components/user-list.component.ts` — a standalone component.

```typescript
// user-list.component.ts — Standalone pattern
@Component({
  selector: 'app-user-list',
  imports: [RouterLink, DatePipe],   // Component declares its own deps
  template: `...`
})
export class UserListComponent {
  private userService = inject(UserService);  // Modern DI
  users = signal<User[]>([]);                 // Signal-based state
}
```

**Side-by-side comparison to show in the IDE:**

| Aspect | NgModule (Products) | Standalone (Users) |
|--------|--------------------|--------------------|
| Dependencies | In module's `imports` | In component's `imports` |
| Declaration | In module's `declarations` | Self-contained |
| DI pattern | `constructor(private svc: Service)` | `inject(Service)` |
| State | Plain class properties | Signals |
| Routing file | `products-routing.module.ts` (NgModule) | `users.routes.ts` (plain array) |
| Module file | `products.module.ts` (required) | None needed |

---

### 1.3 Migration Considerations (10 min)

**When to migrate:**
- Starting a new project → **always use standalone** (it's the default since Angular 19)
- Existing project → migrate feature by feature, both patterns coexist
- Angular provides a migration schematic: `ng generate @angular/core:standalone`

**Coexistence:** NgModule and standalone components work together in the same application. Our demo project proves this — Products (NgModule) and Users (standalone) run side by side.

> **📂 Demo file:** Open `src/app/app.routes.ts` to show both lazy loading patterns coexisting:

```typescript
// NgModule-based lazy loading (LEGACY)
{
  path: 'products',
  loadChildren: () =>
    import('./features/products/products.module').then(m => m.ProductsModule)
},

// Standalone routes lazy loading (MODERN)
{
  path: 'users',
  loadChildren: () =>
    import('./features/users/users.routes').then(m => m.USER_ROUTES)
},
```

**Key takeaway:** Migration is incremental. You don't need to rewrite everything at once.

---

---

# Block 2: Standalone Components in Depth (45 min)

## 2.1 Application Bootstrap — No AppModule (10 min)

In the NgModule world, every app had an `AppModule` with `@NgModule({ bootstrap: [AppComponent] })`.

With standalone, the application bootstraps directly:

> **📂 Demo file:** Open `src/main.ts`

```typescript
// main.ts — Standalone bootstrap
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
```

And the configuration lives in a plain object:

> **📂 Demo file:** Open `src/app/app.config.ts`

```typescript
// app.config.ts — Replaces AppModule providers
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),                                    // Replaces RouterModule.forRoot()

    { provide: APP_CONFIG, useValue: DEFAULT_APP_CONFIG },    // InjectionToken
    { provide: LOGGER_CONFIG, useValue: DEVELOPMENT_LOGGER_CONFIG },
  ]
};
```

**What changed:**

| Before (NgModule) | After (Standalone) |
|--------------------|-------------------|
| `AppModule` class with `@NgModule` | `appConfig` plain object |
| `RouterModule.forRoot(routes)` | `provideRouter(routes)` |
| `HttpClientModule` | `provideHttpClient()` |
| `BrowserAnimationsModule` | `provideAnimations()` |

---

## 2.2 Provider Configuration Patterns (15 min)

This is one of the most important topics. Provider strategy changes significantly with standalone.

### Pattern 1: `providedIn: 'root'` (Tree-shakable Singleton)

The recommended default — service is a singleton, available everywhere, tree-shakable.

> **📂 Demo file:** Open `src/app/core/services/product.service.ts`

```typescript
@Injectable({ providedIn: 'root' })  // Tree-shakable singleton
export class ProductService {
  // Available everywhere, no need to add to any providers array
}
```

**When to use:** Most services. This is the modern default.

---

### Pattern 2: Module-Level Provider (Legacy)

The old pattern — service provided in NgModule's `providers` array.

> **📂 Demo file:** Open `src/app/core/services/customer.service.ts`

```typescript
@Injectable()  // NOT providedIn — must be provided manually
export class CustomerService { ... }
```

> **📂 Demo file:** Open `src/app/features/customers/customers.module.ts`

```typescript
@NgModule({
  providers: [
    CustomerService  // Service provided at module level
  ]
})
export class CustomersModule {}
```

**Problem:** The service is only available within this module's injector scope. Not tree-shakable.

---

### Pattern 3: Route-Level Providers (Modern Replacement for Module Providers)

The key standalone innovation for feature-scoped services:

> **📂 Demo file:** Open `src/app/features/settings/settings.routes.ts`

```typescript
export const SETTINGS_ROUTES: Routes = [
  {
    path: '',
    component: SettingsComponent,
    providers: [
      SettingsService  // Route-level provider — scoped to this route
    ]
  }
];
```

> **📂 Demo file:** Open `src/app/features/settings/settings.service.ts`

```typescript
@Injectable()  // NOT providedIn: 'root'
export class SettingsService {
  private settings = signal<Record<string, string>>({
    theme: 'light',
    language: 'en',
    pageSize: '10',
  });

  allSettings = computed(() => { ... });

  updateSetting(key: string, value: string): void {
    this.settings.update(current => ({ ...current, [key]: value }));
  }
}
```

**Live demo:** Navigate to Settings, change a value, navigate away, come back — the value resets. This is because the service instance is destroyed when leaving the route.

**When to use route-level providers:**
- Feature-scoped state that should reset on navigation
- Services that should NOT be singletons
- Encapsulating feature-specific logic

---

### Pattern 4: InjectionToken for Configuration

> **📂 Demo file:** Open `src/app/core/config/app.config.token.ts`

```typescript
export interface AppConfig {
  apiUrl: string;
  appTitle: string;
  enableAnalytics: boolean;
  maxItemsPerPage: number;
}

export const APP_CONFIG = new InjectionToken<AppConfig>('app.config');

export const DEFAULT_APP_CONFIG: AppConfig = {
  apiUrl: 'https://api.example.com',
  appTitle: 'Angular Architecture Demo',
  enableAnalytics: false,
  maxItemsPerPage: 10
};
```

Provided at the application level in `app.config.ts` and consumed via `inject()`:

```typescript
// In any standalone component
protected appConfig = inject(APP_CONFIG);

// In template
{{ appConfig.appTitle }}
```

> **📂 Demo file:** Open `src/app/features/dashboard/dashboard.component.ts` — see the Provider Configuration section on the Dashboard page.

---

## 2.3 Routing with Standalone Components (10 min)

### Legacy: Routing Module

```typescript
// products-routing.module.ts — NgModule routing wrapper
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductsRoutingModule {}
```

### Modern: Plain Routes Array

> **📂 Demo file:** Open `src/app/features/users/users.routes.ts`

```typescript
// users.routes.ts — Just export a Routes array
export const USER_ROUTES: Routes = [
  { path: '', component: UserListComponent },
  { path: ':id', component: UserDetailComponent }
];
```

**No NgModule wrapper.** No `RouterModule.forChild()`. Just data.

### Lazy Loading Comparison

> **📂 Demo file:** Open `src/app/app.routes.ts`

```typescript
// LEGACY: Lazy load an NgModule
{
  path: 'products',
  loadChildren: () =>
    import('./features/products/products.module').then(m => m.ProductsModule)
},

// MODERN: Lazy load a Routes array
{
  path: 'users',
  loadChildren: () =>
    import('./features/users/users.routes').then(m => m.USER_ROUTES)
},
```

**Build output comparison** (run `ng build` and look at the chunks):

```
Lazy chunk files    | Names            |  Raw size
chunk-...           | customers-module |   9.27 kB  ← NgModule bundle
chunk-...           | products-module  |   7.45 kB  ← NgModule bundle
chunk-...           | users-routes     |   6.50 kB  ← Standalone (smaller!)
chunk-...           | settings-routes  |  31.41 kB  ← Standalone (includes FormsModule)
```

---

## 2.4 Modern DI with `inject()` (10 min)

### Before: Constructor Injection

> **📂 Demo file:** Open `src/app/features/products/components/product-list.component.ts`

```typescript
export class ProductListComponent implements OnInit {
  products: Product[] = [];

  // Constructor-based DI (legacy pattern)
  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.products = products;
    });
  }
}
```

### After: `inject()` Function

> **📂 Demo file:** Open `src/app/features/dashboard/dashboard.component.ts`

```typescript
export class DashboardComponent implements OnInit {
  // Modern DI — no constructor needed
  private productService = inject(ProductService);
  private userService = inject(UserService);
  private logger = inject(LoggerService);
  protected appConfig = inject(APP_CONFIG);

  // Reactive state with signals
  products = signal<Product[]>([]);
  users = signal<User[]>([]);

  // Computed (derived) signals
  totalProducts = computed(() => this.products().length);
  inStockCount = computed(() => this.products().filter(p => p.inStock).length);
  totalUsers = computed(() => this.users().length);

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.products.set(products);  // Update signal
    });
  }
}
```

**Benefits of `inject()`:**
1. Works with `InjectionToken` directly (no `@Inject()` decorator needed)
2. Can be used in functions, not just classes
3. No constructor boilerplate
4. Better type inference
5. Works in inheritance without `super()` complexity

---

---

# Block 3: Practical Workshop — Module-to-Standalone Migration (45 min)

## Workshop Overview

Participants will migrate the **Customers feature** from NgModule-based to standalone architecture.

**Starting state:** `src/app/features/customers/` contains:
- `customers.module.ts` — NgModule with declarations and providers
- `customers-routing.module.ts` — Routing NgModule
- `components/customer-list.component.ts` — `standalone: false`, uses `*ngFor`, constructor DI
- `components/customer-detail.component.ts` — `standalone: false`, uses `*ngIf`, constructor DI
- `pipes/customer-full-name.pipe.ts` — `standalone: false`
- `directives/highlight-tier.directive.ts` — `standalone: false`
- `CustomerService` — `@Injectable()` with no `providedIn`

**Target state:** All standalone, no NgModules, modern patterns.

---

## Step-by-Step Migration Guide

### Step 1: Make the Pipe Standalone (5 min)

> **📂 File:** `src/app/features/customers/pipes/customer-full-name.pipe.ts`

**Before:**
```typescript
@Pipe({ name: 'customerFullName', standalone: false })
export class CustomerFullNamePipe implements PipeTransform { ... }
```

**After:**
```typescript
@Pipe({ name: 'customerFullName', standalone: true })
export class CustomerFullNamePipe implements PipeTransform { ... }
```

---

### Step 2: Make the Directive Standalone (5 min)

> **📂 File:** `src/app/features/customers/directives/highlight-tier.directive.ts`

**Before:**
```typescript
@Directive({ selector: '[appHighlightTier]', standalone: false })
export class HighlightTierDirective implements OnInit { ... }
```

**After:**
```typescript
@Directive({ selector: '[appHighlightTier]', standalone: true })
export class HighlightTierDirective implements OnInit { ... }
```

---

### Step 3: Migrate CustomerListComponent (10 min)

> **📂 File:** `src/app/features/customers/components/customer-list.component.ts`

**Changes needed:**
1. Remove `standalone: false` (or set to `true`)
2. Add `imports` array with required dependencies
3. Replace constructor DI with `inject()`

**Before:**
```typescript
@Component({
  standalone: false,
  selector: 'app-customer-list',
  template: `...`
})
export class CustomerListComponent implements OnInit {
  customers: Customer[] = [];

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    this.customerService.getCustomers().subscribe(customers => {
      this.customers = customers;
    });
  }
}
```

**After:**
```typescript
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  // standalone: true is the default in Angular 19+, so we just remove standalone: false
  selector: 'app-customer-list',
  imports: [CommonModule, RouterLink],  // Declare dependencies directly
  template: `...`
})
export class CustomerListComponent implements OnInit {
  private customerService = inject(CustomerService);  // Modern DI
  customers: Customer[] = [];

  ngOnInit(): void {
    this.customerService.getCustomers().subscribe(customers => {
      this.customers = customers;
    });
  }
}
```

---

### Step 4: Migrate CustomerDetailComponent (5 min)

> **📂 File:** `src/app/features/customers/components/customer-detail.component.ts`

Same pattern as Step 3:
1. Remove `standalone: false`
2. Add `imports: [CommonModule]`
3. Replace constructor DI with `inject()`

```typescript
@Component({
  selector: 'app-customer-detail',
  imports: [CommonModule],
  template: `...`
})
export class CustomerDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private customerService = inject(CustomerService);

  customer?: Customer;

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.customerService.getCustomerById(id).subscribe(customer => {
      this.customer = customer;
    });
  }

  goBack(): void {
    this.router.navigate(['/customers']);
  }
}
```

---

### Step 5: Update the Service (3 min)

> **📂 File:** `src/app/core/services/customer.service.ts`

**Option A — Make it tree-shakable (simplest):**
```typescript
@Injectable({ providedIn: 'root' })   // Add providedIn
export class CustomerService { ... }
```

**Option B — Use route-level providers (if you want scoped instances):**
Keep `@Injectable()` and provide it in the routes file (next step).

---

### Step 6: Create Standalone Routes File (5 min)

> **📂 Create new file:** `src/app/features/customers/customers.routes.ts`

```typescript
import { Routes } from '@angular/router';
import { CustomerListComponent } from './components/customer-list.component';
import { CustomerDetailComponent } from './components/customer-detail.component';

export const CUSTOMER_ROUTES: Routes = [
  { path: '', component: CustomerListComponent },
  { path: ':id', component: CustomerDetailComponent }
];
```

If using **Option B** (route-level provider), add providers:
```typescript
import { CustomerService } from '../../core/services/customer.service';

export const CUSTOMER_ROUTES: Routes = [
  {
    path: '',
    providers: [CustomerService],  // Route-level provider
    children: [
      { path: '', component: CustomerListComponent },
      { path: ':id', component: CustomerDetailComponent }
    ]
  }
];
```

---

### Step 7: Update App Routes (3 min)

> **📂 File:** `src/app/app.routes.ts`

**Before:**
```typescript
{
  path: 'customers',
  loadChildren: () =>
    import('./features/customers/customers.module').then(m => m.CustomersModule)
},
```

**After:**
```typescript
{
  path: 'customers',
  loadChildren: () =>
    import('./features/customers/customers.routes').then(m => m.CUSTOMER_ROUTES)
},
```

---

### Step 8: Delete the NgModule Files (2 min)

Delete these files — they're no longer needed:
- `src/app/features/customers/customers.module.ts`
- `src/app/features/customers/customers-routing.module.ts`

---

### Step 9: Verify (5 min)

Run `ng serve` and verify:
1. ✅ Navigate to Customers — list loads correctly
2. ✅ Click a customer — detail page works
3. ✅ Filter by tier — filtering works
4. ✅ Navigate away and back — no errors
5. ✅ Run `ng build` — no compilation errors

---

## Migration Checklist Summary

| # | Task | Status |
|---|------|--------|
| 1 | Make `CustomerFullNamePipe` standalone | ☐ |
| 2 | Make `HighlightTierDirective` standalone | ☐ |
| 3 | Migrate `CustomerListComponent` to standalone + `inject()` | ☐ |
| 4 | Migrate `CustomerDetailComponent` to standalone + `inject()` | ☐ |
| 5 | Update `CustomerService` to `providedIn: 'root'` | ☐ |
| 6 | Create `customers.routes.ts` with `CUSTOMER_ROUTES` | ☐ |
| 7 | Update lazy loading in `app.routes.ts` | ☐ |
| 8 | Delete `customers.module.ts` and `customers-routing.module.ts` | ☐ |
| 9 | Build & test | ☐ |

---

---

# Quick Reference

## Project Architecture Map

```
src/app/
├── core/
│   ├── config/
│   │   ├── app.config.token.ts         ← InjectionToken pattern
│   │   └── logger.config.token.ts      ← Environment-based config
│   ├── models/
│   │   ├── product.model.ts
│   │   ├── customer.model.ts
│   │   └── user.model.ts
│   └── services/
│       ├── product.service.ts          ← providedIn: 'root' (tree-shakable)
│       ├── customer.service.ts         ← @Injectable() only (module-provided)
│       ├── user.service.ts             ← providedIn: 'root'
│       ├── logger.service.ts           ← Uses InjectionToken
│       └── notification.service.ts     ← Uses APP_CONFIG token
│
├── features/
│   ├── products/                       ← 🔴 NgModule-based (LEGACY REFERENCE)
│   │   ├── products.module.ts
│   │   ├── products-routing.module.ts
│   │   └── components/
│   │
│   ├── customers/                      ← 🔴 NgModule-based (WORKSHOP TARGET)
│   │   ├── customers.module.ts
│   │   ├── customers-routing.module.ts
│   │   ├── components/
│   │   ├── pipes/
│   │   └── directives/
│   │
│   ├── dashboard/                      ← 🟢 Standalone (inject, signals, computed)
│   │   └── dashboard.component.ts
│   │
│   ├── users/                          ← 🟢 Standalone + routes file
│   │   ├── users.routes.ts
│   │   └── components/
│   │
│   └── settings/                       ← 🟢 Standalone + ROUTE-LEVEL PROVIDERS
│       ├── settings.routes.ts
│       ├── settings.service.ts
│       └── settings.component.ts
│
├── app.config.ts                       ← Application-level providers
├── app.routes.ts                       ← Both lazy loading patterns
└── main.ts                             ← bootstrapApplication()
```

## Key Concepts Cheat Sheet

| Concept | Legacy (NgModule) | Modern (Standalone) |
|---------|-------------------|---------------------|
| App bootstrap | `AppModule` + `platformBrowserDynamic().bootstrapModule()` | `bootstrapApplication(App, appConfig)` |
| Feature organization | NgModule with `declarations`, `imports`, `providers` | Self-contained components + routes file |
| Component dependencies | Inherited from module's `imports` | Declared in component's `imports` |
| Dependency injection | `constructor(private svc: SomeService)` | `private svc = inject(SomeService)` |
| Routing setup | `RouterModule.forChild(routes)` wrapped in NgModule | Plain `Routes` array exported from file |
| Lazy loading | `loadChildren: () => import('...module').then(m => m.Module)` | `loadChildren: () => import('...routes').then(m => m.ROUTES)` |
| Feature-scoped services | Module `providers` array | Route-level `providers` array |
| Global providers | `AppModule` providers | `appConfig.providers` |
| HTTP client | `HttpClientModule` in imports | `provideHttpClient()` in providers |
| Built-in directives/pipes | Import `CommonModule` in every module | Import `NgFor`, `DatePipe`, etc. individually |

---

## Talking Points & Common Questions

**Q: Do I have to migrate everything at once?**
A: No. NgModule and standalone coexist perfectly. Migrate feature by feature. Our demo project runs both patterns simultaneously.

**Q: Is `providedIn: 'root'` always the right choice?**
A: For most services, yes. Use route-level providers when you need scoped instances (like our `SettingsService` that resets when you navigate away).

**Q: What about SharedModule?**
A: With standalone, SharedModule is usually unnecessary. Components import what they need directly. If you have many shared utilities, you can create a barrel export file, but each component controls its own imports.

**Q: What does `standalone: false` mean in Angular 19+?**
A: Angular 19+ defaults all components/directives/pipes to `standalone: true`. To use the old NgModule pattern, you must explicitly opt out with `standalone: false`.

**Q: Can I use `inject()` in NgModule components?**
A: Yes! `inject()` works in any component, standalone or not. It's a DI mechanism, not tied to standalone.

---

## References

- [Angular Standalone Components Guide](https://angular.dev/guide/components/importing)
- [Angular Standalone Migration Schematic](https://angular.dev/reference/migrations/standalone)
- [Angular Routing with Standalone Components](https://angular.dev/guide/routing)
- [Angular Dependency Injection](https://angular.dev/guide/di)
- [Angular Signals](https://angular.dev/guide/signals)
