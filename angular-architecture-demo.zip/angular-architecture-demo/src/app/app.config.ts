import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { APP_CONFIG, DEFAULT_APP_CONFIG } from './core/config/app.config.token';
import { LOGGER_CONFIG, DEVELOPMENT_LOGGER_CONFIG } from './core/config/logger.config.token';

/**
 * Application Configuration - STANDALONE BOOTSTRAP PATTERN
 *
 * This replaces the traditional AppModule's providers array.
 * All application-wide providers are configured here and passed
 * to bootstrapApplication() in main.ts.
 *
 * KEY POINTS:
 * - provideRouter() replaces RouterModule.forRoot()
 * - InjectionTokens are provided here for app-wide availability
 * - No NgModule needed at the application level
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    // App-wide configuration via InjectionToken
    { provide: APP_CONFIG, useValue: DEFAULT_APP_CONFIG },

    // Logger configuration — swap with PRODUCTION_LOGGER_CONFIG for prod
    { provide: LOGGER_CONFIG, useValue: DEVELOPMENT_LOGGER_CONFIG },
  ]
};
