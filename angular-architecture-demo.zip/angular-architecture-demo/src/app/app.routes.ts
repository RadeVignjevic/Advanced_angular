import { Routes } from '@angular/router';
import { DashboardComponent } from './features/dashboard/dashboard.component';

/**
 * Application Routes
 *
 * This file demonstrates BOTH lazy loading patterns:
 *
 * 1. NgModule-based lazy loading (Legacy):
 *    loadChildren: () => import('...module').then(m => m.SomeModule)
 *    → Used for Products and Customers
 *
 * 2. Standalone routes lazy loading (Modern):
 *    loadChildren: () => import('...routes').then(m => m.SOME_ROUTES)
 *    → Used for Users and Settings
 *
 * The dashboard is eagerly loaded as the default route.
 */
export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    component: DashboardComponent
    // Eagerly loaded standalone component — no lazy loading needed for the landing page
  },

  // ─── NgModule-based lazy loading (LEGACY PATTERN) ───
  {
    path: 'products',
    loadChildren: () =>
      import('./features/products/products.module').then(m => m.ProductsModule)
    // Loads the entire NgModule, which contains its own routing
  },
  {
    path: 'customers',
    loadChildren: () =>
      import('./features/customers/customers.module').then(m => m.CustomersModule)
    // ⚠️ MIGRATION TARGET: Will be changed to load standalone routes
  },

  // ─── Standalone routes lazy loading (MODERN PATTERN) ───
  {
    path: 'users',
    loadChildren: () =>
      import('./features/users/users.routes').then(m => m.USER_ROUTES)
    // No NgModule — just loads a Routes array directly
  },
  {
    path: 'settings',
    loadChildren: () =>
      import('./features/settings/settings.routes').then(m => m.SETTINGS_ROUTES)
    // Includes route-level providers for SettingsService
  },

  // Wildcard route
  {
    path: '**',
    redirectTo: 'dashboard'
  }
];
