import { InjectionToken } from '@angular/core';

/**
 * Demonstrates using InjectionToken for configuration.
 * This is a modern Angular pattern for providing configuration
 * without coupling to concrete classes.
 */

export interface AppConfig {
  apiUrl: string;
  appTitle: string;
  enableAnalytics: boolean;
  maxItemsPerPage: number;
}

export const APP_CONFIG = new InjectionToken<AppConfig>('app.config');

export const DEFAULT_APP_CONFIG: AppConfig = {
  apiUrl: 'https://api.example.com',
  appTitle: 'Angular Architecture Demo',
  enableAnalytics: false,
  maxItemsPerPage: 10
};
