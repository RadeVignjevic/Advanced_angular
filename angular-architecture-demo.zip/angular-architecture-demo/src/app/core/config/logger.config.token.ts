import { InjectionToken } from '@angular/core';

/**
 * Logger configuration token - demonstrates environment-based
 * provider configuration that differs between NgModule and
 * standalone approaches.
 */

export interface LoggerConfig {
  level: 'debug' | 'info' | 'warn' | 'error';
  enableConsole: boolean;
  enableRemote: boolean;
}

export const LOGGER_CONFIG = new InjectionToken<LoggerConfig>('logger.config');

export const DEVELOPMENT_LOGGER_CONFIG: LoggerConfig = {
  level: 'debug',
  enableConsole: true,
  enableRemote: false
};

export const PRODUCTION_LOGGER_CONFIG: LoggerConfig = {
  level: 'error',
  enableConsole: false,
  enableRemote: true
};
