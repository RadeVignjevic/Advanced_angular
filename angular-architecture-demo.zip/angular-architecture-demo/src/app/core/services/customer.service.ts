import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { Customer } from '../models/customer.model';

/**
 * CustomerService - used in the NgModule-based Customers feature.
 * This is intentionally NOT providedIn: 'root' to demonstrate
 * how services were traditionally provided in NgModules.
 * During the migration workshop, participants will convert this
 * to use standalone provider patterns.
 */
@Injectable()
export class CustomerService {
  private customers: Customer[] = [
    { id: 1, firstName: 'Alice', lastName: 'Johnson', email: 'alice@example.com', phone: '555-0101', tier: 'platinum', totalOrders: 142 },
    { id: 2, firstName: 'Bob', lastName: 'Smith', email: 'bob@example.com', phone: '555-0102', tier: 'gold', totalOrders: 87 },
    { id: 3, firstName: 'Carol', lastName: 'Williams', email: 'carol@example.com', phone: '555-0103', tier: 'silver', totalOrders: 34 },
    { id: 4, firstName: 'David', lastName: 'Brown', email: 'david@example.com', phone: '555-0104', tier: 'bronze', totalOrders: 12 },
    { id: 5, firstName: 'Eva', lastName: 'Davis', email: 'eva@example.com', phone: '555-0105', tier: 'gold', totalOrders: 95 },
    { id: 6, firstName: 'Frank', lastName: 'Miller', email: 'frank@example.com', phone: '555-0106', tier: 'silver', totalOrders: 41 },
    { id: 7, firstName: 'Grace', lastName: 'Wilson', email: 'grace@example.com', phone: '555-0107', tier: 'platinum', totalOrders: 203 },
    { id: 8, firstName: 'Henry', lastName: 'Taylor', email: 'henry@example.com', phone: '555-0108', tier: 'bronze', totalOrders: 8 },
  ];

  getCustomers(): Observable<Customer[]> {
    return of(this.customers).pipe(delay(300));
  }

  getCustomerById(id: number): Observable<Customer | undefined> {
    return of(this.customers.find(c => c.id === id)).pipe(delay(200));
  }

  getCustomersByTier(tier: string): Observable<Customer[]> {
    return of(this.customers.filter(c => c.tier === tier)).pipe(delay(300));
  }
}
