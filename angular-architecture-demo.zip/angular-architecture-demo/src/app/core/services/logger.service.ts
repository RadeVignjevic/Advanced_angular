import { inject, Injectable } from '@angular/core';
import { LOGGER_CONFIG, LoggerConfig } from '../config/logger.config.token';

/**
 * LoggerService demonstrates provider configuration with InjectionToken.
 * The behavior changes based on the injected LoggerConfig,
 * which can be provided differently at root, route, or component level.
 */
@Injectable({ providedIn: 'root' })
export class LoggerService {
  private config = inject(LOGGER_CONFIG);

  debug(message: string, ...args: unknown[]): void {
    if (this.shouldLog('debug')) {
      console.debug(`[DEBUG] ${message}`, ...args);
    }
  }

  info(message: string, ...args: unknown[]): void {
    if (this.shouldLog('info')) {
      console.info(`[INFO] ${message}`, ...args);
    }
  }

  warn(message: string, ...args: unknown[]): void {
    if (this.shouldLog('warn')) {
      console.warn(`[WARN] ${message}`, ...args);
    }
  }

  error(message: string, ...args: unknown[]): void {
    if (this.shouldLog('error')) {
      console.error(`[ERROR] ${message}`, ...args);
    }
  }

  getConfig(): LoggerConfig {
    return this.config;
  }

  private shouldLog(level: string): boolean {
    const levels = ['debug', 'info', 'warn', 'error'];
    return levels.indexOf(level) >= levels.indexOf(this.config.level);
  }
}
