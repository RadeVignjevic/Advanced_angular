import { inject, Injectable } from '@angular/core';
import { APP_CONFIG } from '../config/app.config.token';
import { LoggerService } from './logger.service';

/**
 * NotificationService demonstrates component-level provider overrides.
 * When provided at a component level, it can behave differently
 * (e.g., different prefix or styling).
 */
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private config = inject(APP_CONFIG);
  private logger = inject(LoggerService);

  private notifications: { message: string; type: string; timestamp: Date }[] = [];

  success(message: string): void {
    this.addNotification(message, 'success');
    this.logger.info(`[${this.config.appTitle}] SUCCESS: ${message}`);
  }

  error(message: string): void {
    this.addNotification(message, 'error');
    this.logger.error(`[${this.config.appTitle}] ERROR: ${message}`);
  }

  info(message: string): void {
    this.addNotification(message, 'info');
    this.logger.info(`[${this.config.appTitle}] INFO: ${message}`);
  }

  getRecentNotifications() {
    return [...this.notifications].reverse().slice(0, 5);
  }

  private addNotification(message: string, type: string): void {
    this.notifications.push({ message, type, timestamp: new Date() });
  }
}
