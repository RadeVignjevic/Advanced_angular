import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { Product } from '../models/product.model';

/**
 * ProductService - uses providedIn: 'root' (tree-shakable).
 * This service works with both NgModule-based and standalone approaches.
 */
@Injectable({ providedIn: 'root' })
export class ProductService {
  private products: Product[] = [
    { id: 1, name: 'Laptop Pro X', price: 1299.99, category: 'Electronics', description: 'High-performance laptop with 16GB RAM', inStock: true },
    { id: 2, name: 'Wireless Mouse', price: 49.99, category: 'Electronics', description: 'Ergonomic wireless mouse with USB-C', inStock: true },
    { id: 3, name: 'Standing Desk', price: 599.99, category: 'Furniture', description: 'Adjustable height standing desk', inStock: false },
    { id: 4, name: 'Mechanical Keyboard', price: 159.99, category: 'Electronics', description: 'Cherry MX switches, RGB backlit', inStock: true },
    { id: 5, name: 'Monitor 27"', price: 449.99, category: 'Electronics', description: '4K UHD IPS display', inStock: true },
    { id: 6, name: 'Desk Chair', price: 399.99, category: 'Furniture', description: 'Ergonomic office chair with lumbar support', inStock: true },
    { id: 7, name: 'Webcam HD', price: 89.99, category: 'Electronics', description: '1080p webcam with built-in mic', inStock: false },
    { id: 8, name: 'USB-C Hub', price: 69.99, category: 'Accessories', description: '7-in-1 USB-C hub with HDMI', inStock: true },
  ];

  getProducts(): Observable<Product[]> {
    return of(this.products).pipe(delay(300));
  }

  getProductById(id: number): Observable<Product | undefined> {
    return of(this.products.find(p => p.id === id)).pipe(delay(200));
  }

  getProductsByCategory(category: string): Observable<Product[]> {
    return of(this.products.filter(p => p.category === category)).pipe(delay(300));
  }

  getCategories(): string[] {
    return [...new Set(this.products.map(p => p.category))];
  }
}
