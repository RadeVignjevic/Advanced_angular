import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../../../core/services/customer.service';
import { Customer } from '../../../core/models/customer.model';

/**
 * CustomerDetailComponent - MIGRATION TARGET
 *
 * MIGRATION STEPS:
 * 1. Add `standalone: true` to @Component
 * 2. Add `imports: [CommonModule]` to @Component
 * 3. Replace constructor DI with inject()
 * 4. Remove from CustomersModule declarations
 */
@Component({
  standalone: false,
  selector: 'app-customer-detail',
  template: `
    <div class="customer-detail" *ngIf="customer">
      <button class="back-btn" (click)="goBack()">← Back to Customers</button>
      <div class="detail-card">
        <h2>{{ customer.firstName }} {{ customer.lastName }}</h2>
        <span class="badge module-badge">NgModule Component</span>
        <div class="detail-grid">
          <div class="detail-row">
            <span class="label">Email:</span>
            <span class="value">{{ customer.email }}</span>
          </div>
          <div class="detail-row">
            <span class="label">Phone:</span>
            <span class="value">{{ customer.phone }}</span>
          </div>
          <div class="detail-row">
            <span class="label">Tier:</span>
            <span class="tier-badge" [attr.data-tier]="customer.tier">{{ customer.tier | titlecase }}</span>
          </div>
          <div class="detail-row">
            <span class="label">Total Orders:</span>
            <span class="value">{{ customer.totalOrders }}</span>
          </div>
        </div>
      </div>
    </div>
    <div *ngIf="!customer" class="loading">Loading customer...</div>
  `,
  styles: [`
    .customer-detail { padding: 1rem; }
    .back-btn { background: none; border: 2px solid #9b59b6; color: #9b59b6; padding: 0.5rem 1rem; border-radius: 8px; cursor: pointer; margin-bottom: 1rem; }
    .back-btn:hover { background: #9b59b6; color: white; }
    .detail-card { border: 1px solid #e0e0e0; border-radius: 12px; padding: 2rem; max-width: 600px; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; }
    .module-badge { background: #e74c3c; color: white; }
    .detail-grid { margin-top: 1.5rem; }
    .detail-row { display: flex; align-items: center; padding: 0.75rem 0; border-bottom: 1px solid #f0f0f0; }
    .label { font-weight: 600; width: 120px; color: #555; }
    .value { flex: 1; }
    .tier-badge { padding: 0.3rem 0.8rem; border-radius: 12px; font-weight: 600; font-size: 0.85rem; }
    .tier-badge[data-tier="platinum"] { background: #2c3e50; color: white; }
    .tier-badge[data-tier="gold"] { background: #f39c12; color: white; }
    .tier-badge[data-tier="silver"] { background: #95a5a6; color: white; }
    .tier-badge[data-tier="bronze"] { background: #e67e22; color: white; }
    .loading { text-align: center; padding: 2rem; color: #999; }
  `]
})
export class CustomerDetailComponent implements OnInit {
  customer?: Customer;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private customerService: CustomerService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.customerService.getCustomerById(id).subscribe(customer => {
      this.customer = customer;
    });
  }

  goBack(): void {
    this.router.navigate(['/customers']);
  }
}
