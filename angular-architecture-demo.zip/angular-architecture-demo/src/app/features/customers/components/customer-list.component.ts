import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../../core/services/customer.service';
import { Customer } from '../../../core/models/customer.model';

/**
 * CustomerListComponent - MIGRATION TARGET
 *
 * This component is part of the NgModule-based CustomersModule.
 * During the workshop, participants will migrate this to a standalone component.
 *
 * MIGRATION STEPS:
 * 1. Add `standalone: true` to @Component
 * 2. Add `imports: [CommonModule, RouterLink]` to @Component
 * 3. Replace constructor DI with inject()
 * 4. Remove from CustomersModule declarations
 */
@Component({
  standalone: false,
  selector: 'app-customer-list',
  template: `
    <div class="customer-list">
      <h2>Customers <span class="badge module-badge">NgModule-based</span></h2>
      <p class="architecture-note">
        🔧 <strong>Workshop Target:</strong> This feature uses the traditional NgModule architecture.
        Your task is to migrate it to standalone components.
      </p>

      <div class="tier-filters">
        <button
          *ngFor="let tier of tiers"
          [class.active]="selectedTier === tier"
          (click)="filterByTier(tier)"
          class="tier-btn"
          [attr.data-tier]="tier">
          {{ tier | titlecase }}
        </button>
        <button
          [class.active]="!selectedTier"
          (click)="clearFilter()"
          class="tier-btn">
          All
        </button>
      </div>

      <table class="customer-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Tier</th>
            <th>Orders</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let customer of filteredCustomers">
            <td>{{ customer.firstName }} {{ customer.lastName }}</td>
            <td>{{ customer.email }}</td>
            <td>{{ customer.phone }}</td>
            <td>
              <span class="tier-badge" [attr.data-tier]="customer.tier">
                {{ customer.tier | titlecase }}
              </span>
            </td>
            <td>{{ customer.totalOrders }}</td>
            <td>
              <a [routerLink]="['/customers', customer.id]" class="detail-link">Details →</a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .customer-list { padding: 1rem; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; vertical-align: middle; }
    .module-badge { background: #e74c3c; color: white; }
    .architecture-note { background: #f8d7da; border: 1px solid #f5c6cb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .tier-filters { display: flex; gap: 0.5rem; margin: 1rem 0; flex-wrap: wrap; }
    .tier-btn { padding: 0.4rem 1rem; border: 2px solid #9b59b6; border-radius: 20px; background: white; color: #9b59b6; cursor: pointer; transition: all 0.2s; }
    .tier-btn.active, .tier-btn:hover { background: #9b59b6; color: white; }
    .tier-btn[data-tier="platinum"] { border-color: #2c3e50; color: #2c3e50; }
    .tier-btn[data-tier="platinum"].active { background: #2c3e50; color: white; }
    .tier-btn[data-tier="gold"] { border-color: #f39c12; color: #f39c12; }
    .tier-btn[data-tier="gold"].active { background: #f39c12; color: white; }
    .customer-table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
    .customer-table th { background: #f8f9fa; padding: 0.75rem; text-align: left; border-bottom: 2px solid #dee2e6; font-weight: 600; }
    .customer-table td { padding: 0.75rem; border-bottom: 1px solid #e9ecef; }
    .customer-table tr:hover { background: #f8f9fa; }
    .tier-badge { padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.8rem; font-weight: 600; }
    .tier-badge[data-tier="platinum"] { background: #2c3e50; color: white; }
    .tier-badge[data-tier="gold"] { background: #f39c12; color: white; }
    .tier-badge[data-tier="silver"] { background: #95a5a6; color: white; }
    .tier-badge[data-tier="bronze"] { background: #e67e22; color: white; }
    .detail-link { color: #3498db; text-decoration: none; font-weight: 500; }
  `]
})
export class CustomerListComponent implements OnInit {
  customers: Customer[] = [];
  filteredCustomers: Customer[] = [];
  tiers = ['platinum', 'gold', 'silver', 'bronze'];
  selectedTier: string | null = null;

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    this.customerService.getCustomers().subscribe(customers => {
      this.customers = customers;
      this.filteredCustomers = customers;
    });
  }

  filterByTier(tier: string): void {
    this.selectedTier = tier;
    this.customerService.getCustomersByTier(tier).subscribe(customers => {
      this.filteredCustomers = customers;
    });
  }

  clearFilter(): void {
    this.selectedTier = null;
    this.filteredCustomers = this.customers;
  }
}
