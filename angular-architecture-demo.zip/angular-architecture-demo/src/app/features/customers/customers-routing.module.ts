import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerListComponent } from './components/customer-list.component';
import { CustomerDetailComponent } from './components/customer-detail.component';

const routes: Routes = [
  { path: '', component: CustomerListComponent },
  { path: ':id', component: CustomerDetailComponent }
];

/**
 * CustomersRoutingModule - MIGRATION TARGET
 *
 * In standalone architecture, this module is replaced by a simple
 * exported Routes array (e.g., customers.routes.ts).
 *
 * MIGRATION: Replace this entire file with:
 *   export const CUSTOMER_ROUTES: Routes = [
 *     { path: '', component: CustomerListComponent },
 *     { path: ':id', component: CustomerDetailComponent }
 *   ];
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomersRoutingModule {}
