import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersRoutingModule } from './customers-routing.module';
import { CustomerListComponent } from './components/customer-list.component';
import { CustomerDetailComponent } from './components/customer-detail.component';
import { CustomerFullNamePipe } from './pipes/customer-full-name.pipe';
import { HighlightTierDirective } from './directives/highlight-tier.directive';
import { CustomerService } from '../../core/services/customer.service';

/**
 * CustomersModule - ⚠️ WORKSHOP MIGRATION TARGET ⚠️
 *
 * This is the primary module participants will migrate to standalone
 * during the hands-on workshop exercise.
 *
 * CURRENT STRUCTURE (NgModule-based):
 * ────────────────────────────────────
 * ├── CustomersModule (this file)
 * │   ├── declarations: [CustomerListComponent, CustomerDetailComponent, CustomerFullNamePipe, HighlightTierDirective]
 * │   ├── imports: [CommonModule, CustomersRoutingModule]
 * │   └── providers: [CustomerService]  ← Service provided in module
 * ├── CustomersRoutingModule
 * │   └── RouterModule.forChild(routes)
 * └── Components use constructor-based DI
 *
 * TARGET STRUCTURE (Standalone):
 * ──────────────────────────────
 * ├── customers.routes.ts (just a Routes array)
 * ├── CustomerListComponent (standalone, imports: [...])
 * ├── CustomerDetailComponent (standalone, imports: [...])
 * ├── CustomerFullNamePipe (standalone: true)
 * ├── HighlightTierDirective (standalone: true)
 * └── CustomerService uses providedIn: 'root' or route-level providers
 *
 * MIGRATION CHECKLIST:
 * □ Make CustomerListComponent standalone
 * □ Make CustomerDetailComponent standalone
 * □ Make CustomerFullNamePipe standalone
 * □ Make HighlightTierDirective standalone
 * □ Create customers.routes.ts with Routes array
 * □ Move CustomerService to providedIn: 'root' or route providers
 * □ Update lazy loading in app.routes.ts
 * □ Delete this module file and CustomersRoutingModule
 */
@NgModule({
  declarations: [
    CustomerListComponent,
    CustomerDetailComponent,
    CustomerFullNamePipe,
    HighlightTierDirective
  ],
  imports: [
    CommonModule,
    CustomersRoutingModule
  ],
  providers: [
    // Service provided at module level (old pattern)
    // In standalone, this moves to providedIn: 'root' or route-level providers
    CustomerService
  ]
})
export class CustomersModule {}
