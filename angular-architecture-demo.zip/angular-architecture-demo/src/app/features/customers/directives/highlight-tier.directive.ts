import { Directive, ElementRef, Input, OnInit } from '@angular/core';

/**
 * HighlightTierDirective - MIGRATION TARGET
 *
 * This directive is declared in the CustomersModule.
 * During migration, it should become a standalone directive.
 *
 * MIGRATION STEPS:
 * 1. Add `standalone: true` to @Directive
 * 2. Import it directly in the component that uses it
 * 3. Remove from CustomersModule declarations
 */
@Directive({ selector: '[appHighlightTier]', standalone: false })
export class HighlightTierDirective implements OnInit {
  @Input() appHighlightTier: string = '';

  constructor(private el: ElementRef) {}

  ngOnInit(): void {
    const colors: Record<string, string> = {
      platinum: '#2c3e50',
      gold: '#f39c12',
      silver: '#95a5a6',
      bronze: '#e67e22'
    };

    const color = colors[this.appHighlightTier] || '#ccc';
    this.el.nativeElement.style.borderLeft = `4px solid ${color}`;
    this.el.nativeElement.style.paddingLeft = '8px';
  }
}
