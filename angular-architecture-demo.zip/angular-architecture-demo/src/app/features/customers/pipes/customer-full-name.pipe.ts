import { Pipe, PipeTransform } from '@angular/core';

/**
 * CustomerFullNamePipe - MIGRATION TARGET
 *
 * This pipe is declared in the CustomersModule.
 * During migration, it should become a standalone pipe.
 *
 * MIGRATION STEPS:
 * 1. Add `standalone: true` to @Pipe
 * 2. Import it directly in the component that uses it
 * 3. Remove from CustomersModule declarations
 */
@Pipe({ name: 'customerFullName', standalone: false })
export class CustomerFullNamePipe implements PipeTransform {
  transform(customer: { firstName: string; lastName: string }): string {
    return `${customer.lastName}, ${customer.firstName}`;
  }
}
