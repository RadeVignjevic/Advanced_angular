import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProductService } from '../../core/services/product.service';
import { UserService } from '../../core/services/user.service';
import { APP_CONFIG } from '../../core/config/app.config.token';
import { LoggerService } from '../../core/services/logger.service';
import { Product } from '../../core/models/product.model';
import { User } from '../../core/models/user.model';

/**
 * DashboardComponent - STANDALONE COMPONENT
 *
 * KEY POINTS FOR TRAINING:
 * ─────────────────────────
 * 1. `standalone: true` - no NgModule needed (Note: in Angular 19+, standalone is the default)
 * 2. `imports: [RouterLink]` - dependencies declared directly in the component
 * 3. `inject()` function - modern DI pattern (no constructor injection)
 * 4. Signals - reactive state management primitives
 * 5. Computed signals - derived reactive state
 *
 * Compare this with the NgModule-based ProductListComponent to see
 * the architectural differences.
 */
@Component({
  selector: 'app-dashboard',
  imports: [RouterLink],
  template: `
    <div class="dashboard">
      <h2>Dashboard <span class="badge standalone-badge">Standalone</span></h2>
      <p class="architecture-note">
        ✅ This feature uses <strong>standalone component architecture</strong>.
        No NgModule needed — imports are declared directly in the component.
      </p>

      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-number">{{ totalProducts() }}</div>
          <div class="stat-label">Products</div>
          <a routerLink="/products" class="stat-link">View All →</a>
        </div>
        <div class="stat-card">
          <div class="stat-number">{{ inStockCount() }}</div>
          <div class="stat-label">In Stock</div>
        </div>
        <div class="stat-card">
          <div class="stat-number">{{ totalUsers() }}</div>
          <div class="stat-label">Users</div>
          <a routerLink="/users" class="stat-link">View All →</a>
        </div>
        <div class="stat-card">
          <div class="stat-number">{{ appConfig.maxItemsPerPage }}</div>
          <div class="stat-label">Items/Page</div>
        </div>
      </div>

      <div class="info-section">
        <h3>Architecture Comparison</h3>
        <div class="comparison-grid">
          <div class="comparison-card legacy">
            <h4>🔴 NgModule-based (Legacy)</h4>
            <ul>
              <li>Components declared in NgModule</li>
              <li>CommonModule imported in every feature module</li>
              <li>Services provided in module providers array</li>
              <li>Routing via RouterModule.forChild()</li>
              <li>Constructor-based dependency injection</li>
              <li>Lazy loading via loadChildren → NgModule</li>
            </ul>
            <p class="example-link">See: <a routerLink="/products">Products</a> &amp; <a routerLink="/customers">Customers</a></p>
          </div>
          <div class="comparison-card modern">
            <h4>🟢 Standalone (Modern)</h4>
            <ul>
              <li>Components are self-contained</li>
              <li>Direct imports in component decorator</li>
              <li>Services use providedIn: 'root' or route providers</li>
              <li>Routing via simple Routes arrays</li>
              <li>inject() function for DI</li>
              <li>Lazy loading via loadChildren → Routes array</li>
            </ul>
            <p class="example-link">See: <a routerLink="/users">Users</a> &amp; <a routerLink="/settings">Settings</a></p>
          </div>
        </div>
      </div>

      <div class="info-section">
        <h3>Provider Configuration</h3>
        <div class="provider-info">
          <p><strong>App Title:</strong> {{ appConfig.appTitle }}</p>
          <p><strong>API URL:</strong> {{ appConfig.apiUrl }}</p>
          <p><strong>Analytics:</strong> {{ appConfig.enableAnalytics ? 'Enabled' : 'Disabled' }}</p>
          <p><strong>Logger Level:</strong> {{ loggerConfig }}</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { padding: 1rem; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; vertical-align: middle; }
    .standalone-badge { background: #2ecc71; color: white; }
    .architecture-note { background: #d4edda; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin: 1.5rem 0; }
    .stat-card { background: white; border: 1px solid #e0e0e0; border-radius: 12px; padding: 1.5rem; text-align: center; transition: box-shadow 0.2s; }
    .stat-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .stat-number { font-size: 2.5rem; font-weight: 700; color: #2c3e50; }
    .stat-label { color: #7f8c8d; font-size: 0.9rem; margin-top: 0.25rem; }
    .stat-link { display: block; margin-top: 0.5rem; color: #3498db; text-decoration: none; font-size: 0.85rem; }
    .info-section { margin-top: 2rem; }
    .comparison-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-top: 1rem; }
    .comparison-card { padding: 1.5rem; border-radius: 12px; }
    .comparison-card.legacy { background: #fef0f0; border: 2px solid #e74c3c; }
    .comparison-card.modern { background: #f0fef0; border: 2px solid #2ecc71; }
    .comparison-card h4 { margin-top: 0; }
    .comparison-card ul { padding-left: 1.2rem; }
    .comparison-card li { margin: 0.4rem 0; font-size: 0.9rem; }
    .example-link { font-size: 0.85rem; margin-top: 0.5rem; }
    .example-link a { color: #3498db; }
    .provider-info { background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 8px; padding: 1rem; }
    .provider-info p { margin: 0.4rem 0; font-size: 0.9rem; }
    @media (max-width: 768px) {
      .comparison-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class DashboardComponent implements OnInit {
  // Modern DI using inject() function
  private productService = inject(ProductService);
  private userService = inject(UserService);
  private logger = inject(LoggerService);
  protected appConfig = inject(APP_CONFIG);

  // Reactive state with signals
  products = signal<Product[]>([]);
  users = signal<User[]>([]);

  // Computed (derived) signals
  totalProducts = computed(() => this.products().length);
  inStockCount = computed(() => this.products().filter(p => p.inStock).length);
  totalUsers = computed(() => this.users().length);
  loggerConfig = '';

  ngOnInit(): void {
    this.logger.info('Dashboard initialized');

    this.productService.getProducts().subscribe(products => {
      this.products.set(products);
    });

    this.userService.getUsers().subscribe(users => {
      this.users.set(users);
    });

    this.loggerConfig = this.logger.getConfig().level;
  }
}
