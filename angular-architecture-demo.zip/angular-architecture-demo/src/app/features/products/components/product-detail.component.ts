import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../../core/services/product.service';
import { Product } from '../../../core/models/product.model';

/**
 * ProductDetailComponent - Part of the NgModule-based Products feature.
 * Uses constructor injection (legacy pattern).
 */
@Component({
  standalone: false,
  selector: 'app-product-detail',
  template: `
    <div class="product-detail" *ngIf="product">
      <button class="back-btn" (click)="goBack()">← Back to Products</button>
      <div class="detail-card">
        <h2>{{ product.name }}</h2>
        <span class="badge module-badge">NgModule Component</span>
        <div class="detail-grid">
          <div class="detail-row">
            <span class="label">Price:</span>
            <span class="value price">{{ product.price | currency }}</span>
          </div>
          <div class="detail-row">
            <span class="label">Category:</span>
            <span class="value">{{ product.category }}</span>
          </div>
          <div class="detail-row">
            <span class="label">Description:</span>
            <span class="value">{{ product.description }}</span>
          </div>
          <div class="detail-row">
            <span class="label">Availability:</span>
            <span class="value" [class.in-stock]="product.inStock" [class.out-of-stock]="!product.inStock">
              {{ product.inStock ? '✓ In Stock' : '✗ Out of Stock' }}
            </span>
          </div>
        </div>
      </div>
    </div>
    <div *ngIf="!product" class="loading">Loading product...</div>
  `,
  styles: [`
    .product-detail { padding: 1rem; }
    .back-btn { background: none; border: 2px solid #e74c3c; color: #e74c3c; padding: 0.5rem 1rem; border-radius: 8px; cursor: pointer; margin-bottom: 1rem; }
    .back-btn:hover { background: #e74c3c; color: white; }
    .detail-card { border: 1px solid #e0e0e0; border-radius: 12px; padding: 2rem; max-width: 600px; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; }
    .module-badge { background: #e74c3c; color: white; }
    .detail-grid { margin-top: 1.5rem; }
    .detail-row { display: flex; padding: 0.75rem 0; border-bottom: 1px solid #f0f0f0; }
    .label { font-weight: 600; width: 120px; color: #555; }
    .value { flex: 1; }
    .price { font-size: 1.2rem; font-weight: 700; color: #2ecc71; }
    .in-stock { color: #2ecc71; font-weight: 600; }
    .out-of-stock { color: #e74c3c; font-weight: 600; }
    .loading { text-align: center; padding: 2rem; color: #999; }
  `]
})
export class ProductDetailComponent implements OnInit {
  product?: Product;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.productService.getProductById(id).subscribe(product => {
      this.product = product;
    });
  }

  goBack(): void {
    this.router.navigate(['/products']);
  }
}
