import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../core/services/product.service';
import { Product } from '../../../core/models/product.model';

/**
 * ProductListComponent - Part of the NgModule-based Products feature.
 * This component does NOT use `imports` array (NgModule declares it).
 * It uses constructor-based DI (older pattern).
 */
@Component({
  standalone: false,
  selector: 'app-product-list',
  template: `
    <div class="product-list">
      <h2>Products <span class="badge module-badge">NgModule-based</span></h2>
      <p class="architecture-note">
        ℹ️ This feature uses the <strong>traditional NgModule architecture</strong>.
        Components are declared in ProductsModule and share the module's providers.
      </p>

      <div class="filters">
        <button
          *ngFor="let cat of categories"
          [class.active]="selectedCategory === cat"
          (click)="filterByCategory(cat)"
          class="filter-btn">
          {{ cat }}
        </button>
        <button
          [class.active]="!selectedCategory"
          (click)="clearFilter()"
          class="filter-btn">
          All
        </button>
      </div>

      <div class="product-grid">
        <div *ngFor="let product of filteredProducts" class="product-card" [class.out-of-stock]="!product.inStock">
          <h3>{{ product.name }}</h3>
          <p class="price">{{ product.price | currency }}</p>
          <p class="description">{{ product.description }}</p>
          <span class="category-tag">{{ product.category }}</span>
          <span class="stock-status" [class.in-stock]="product.inStock">
            {{ product.inStock ? '✓ In Stock' : '✗ Out of Stock' }}
          </span>
          <a [routerLink]="['/products', product.id]" class="detail-link">View Details →</a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .product-list { padding: 1rem; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; vertical-align: middle; }
    .module-badge { background: #e74c3c; color: white; }
    .architecture-note { background: #fff3cd; border: 1px solid #ffc107; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .filters { display: flex; gap: 0.5rem; margin: 1rem 0; flex-wrap: wrap; }
    .filter-btn { padding: 0.4rem 1rem; border: 2px solid #e74c3c; border-radius: 20px; background: white; color: #e74c3c; cursor: pointer; transition: all 0.2s; }
    .filter-btn.active, .filter-btn:hover { background: #e74c3c; color: white; }
    .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
    .product-card { border: 1px solid #e0e0e0; border-radius: 12px; padding: 1.25rem; transition: box-shadow 0.2s; }
    .product-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .product-card.out-of-stock { opacity: 0.6; }
    .price { font-size: 1.3rem; font-weight: 700; color: #2ecc71; margin: 0.5rem 0; }
    .description { color: #666; font-size: 0.9rem; }
    .category-tag { display: inline-block; background: #f0f0f0; padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.8rem; margin-right: 0.5rem; }
    .stock-status { font-size: 0.85rem; font-weight: 600; }
    .stock-status.in-stock { color: #2ecc71; }
    .stock-status:not(.in-stock) { color: #e74c3c; }
    .detail-link { display: block; margin-top: 0.75rem; color: #3498db; text-decoration: none; font-weight: 500; }
  `]
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  categories: string[] = [];
  selectedCategory: string | null = null;

  // Constructor-based DI (older pattern - compare with inject() in standalone)
  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.categories = this.productService.getCategories();
    this.productService.getProducts().subscribe(products => {
      this.products = products;
      this.filteredProducts = products;
    });
  }

  filterByCategory(category: string): void {
    this.selectedCategory = category;
    this.productService.getProductsByCategory(category).subscribe(products => {
      this.filteredProducts = products;
    });
  }

  clearFilter(): void {
    this.selectedCategory = null;
    this.filteredProducts = this.products;
  }
}
