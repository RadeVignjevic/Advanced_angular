import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductsRoutingModule } from './products-routing.module';
import { ProductListComponent } from './components/product-list.component';
import { ProductDetailComponent } from './components/product-detail.component';

/**
 * ProductsModule - Traditional NgModule-based feature module.
 *
 * KEY POINTS FOR TRAINING:
 * ─────────────────────────
 * 1. Components are DECLARED in the module (not standalone)
 * 2. CommonModule is imported for *ngFor, *ngIf, pipes, etc.
 * 3. RouterModule is imported via ProductsRoutingModule
 * 4. This module is lazy-loaded via loadChildren in app.routes.ts
 *
 * In standalone architecture, this entire module would be eliminated:
 * - Components would use `imports: [...]` directly
 * - Routes would be a simple `Routes` array exported from a file
 * - Lazy loading would use `loadChildren: () => import('./routes')`
 */
@NgModule({
  declarations: [
    ProductListComponent,
    ProductDetailComponent
  ],
  imports: [
    CommonModule,
    ProductsRoutingModule
  ]
})
export class ProductsModule {}
