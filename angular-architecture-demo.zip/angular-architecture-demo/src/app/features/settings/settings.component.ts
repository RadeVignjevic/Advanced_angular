import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SettingsService } from './settings.service';

/**
 * SettingsComponent - STANDALONE COMPONENT with ROUTE-LEVEL PROVIDERS
 *
 * KEY POINTS FOR TRAINING:
 * ─────────────────────────
 * 1. SettingsService is NOT providedIn: 'root'
 * 2. It's provided at the ROUTE level (see settings.routes.ts)
 * 3. The service instance is scoped to this route subtree
 * 4. When navigating away, the service instance is destroyed
 * 5. This replaces NgModule-level providers for feature-scoped services
 *
 * This pattern is useful for:
 * - Feature-scoped state that should reset on navigation
 * - Services that should not be singletons
 * - Encapsulating feature-specific logic
 */
@Component({
  selector: 'app-settings',
  imports: [FormsModule],
  //remove if you want to demonstrate route-level providers
  providers: [SettingsService],
  template: `
    <div class="settings">
      <h2>Settings <span class="badge standalone-badge">Standalone</span></h2>
      <p class="architecture-note">
        ✅ This demonstrates <strong>route-level providers</strong> with standalone components.
        The <code>SettingsService</code> is provided at the route level, not globally.
        It resets when you navigate away and come back.
      </p>

      <div class="settings-grid">
        @for (setting of settingsService.allSettings(); track setting.key) {
          <div class="setting-row">
            <label class="setting-label">{{ setting.key }}</label>
            @switch (setting.key) {
              @case ('theme') {
                <select
                  [ngModel]="setting.value"
                  (ngModelChange)="settingsService.updateSetting(setting.key, $event)"
                  class="setting-input">
                  <option value="light">Light</option>
                  <option value="dark">Dark</option>
                  <option value="system">System</option>
                </select>
              }
              @case ('language') {
                <select
                  [ngModel]="setting.value"
                  (ngModelChange)="settingsService.updateSetting(setting.key, $event)"
                  class="setting-input">
                  <option value="en">English</option>
                  <option value="de">Deutsch</option>
                  <option value="fr">Français</option>
                </select>
              }
              @case ('notifications') {
                <select
                  [ngModel]="setting.value"
                  (ngModelChange)="settingsService.updateSetting(setting.key, $event)"
                  class="setting-input">
                  <option value="enabled">Enabled</option>
                  <option value="disabled">Disabled</option>
                </select>
              }
              @default {
                <input
                  type="text"
                  [ngModel]="setting.value"
                  (ngModelChange)="settingsService.updateSetting(setting.key, $event)"
                  class="setting-input" />
              }
            }
          </div>
        }
      </div>

      <div class="provider-note">
        <h3>Route-Level Provider Demo</h3>
        <p>
          The <code>SettingsService</code> is provided in the route configuration:
        </p>
        <pre><code>{{ routeProviderExample }}</code></pre>
        <p>
          Navigate away and come back — the settings will <strong>reset</strong>
          because the service instance is destroyed with the route.
        </p>
      </div>
    </div>
  `,
  styles: [`
    .settings { padding: 1rem; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; vertical-align: middle; }
    .standalone-badge { background: #2ecc71; color: white; }
    .architecture-note { background: #d4edda; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .architecture-note code { background: #e8f5e9; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .settings-grid { display: grid; gap: 1rem; max-width: 500px; margin: 1.5rem 0; }
    .setting-row { display: flex; align-items: center; gap: 1rem; padding: 0.75rem; background: #f8f9fa; border-radius: 8px; }
    .setting-label { font-weight: 600; width: 140px; text-transform: capitalize; }
    .setting-input { flex: 1; padding: 0.5rem; border: 1px solid #dee2e6; border-radius: 6px; font-size: 0.9rem; }
    .provider-note { margin-top: 2rem; padding: 1.5rem; background: #f0f4f8; border-radius: 12px; border: 1px solid #d0d7de; }
    .provider-note code { background: #e1ecf4; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .provider-note pre { background: #2d2d2d; color: #f8f8f2; padding: 1rem; border-radius: 8px; overflow-x: auto; }
    .provider-note pre code { background: none; color: inherit; }
  `]
})
export class SettingsComponent {
  protected settingsService = inject(SettingsService);

  routeProviderExample = `// settings.routes.ts
export const SETTINGS_ROUTES: Routes = [
  {
    path: '',
    component: SettingsComponent,
    providers: [SettingsService]  // ← Route-level provider
  }
];`;
}
