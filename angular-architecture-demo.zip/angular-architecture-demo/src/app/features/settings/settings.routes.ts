import { Routes } from '@angular/router';
import { SettingsComponent } from './settings.component';
import { SettingsService } from './settings.service';

/**
 * Settings routes - STANDALONE ROUTING with ROUTE-LEVEL PROVIDERS
 *
 * This demonstrates how to provide services at the route level.
 * SettingsService is NOT providedIn: 'root', so it must be
 * provided here. The service instance lives only as long as
 * this route is active.
 *
 * This replaces the old pattern of providing services in NgModule.
 */
export const SETTINGS_ROUTES: Routes = [
  {
    path: '',
    component: SettingsComponent,
    // Route-level provider — service instance scoped to this route
    providers: [
      // Route-level provider — service instance scoped to this route
      SettingsService
    ]
  }
];
