import { Injectable, signal, computed } from '@angular/core';

/**
 * SettingsService - Provided at route level (not root).
 *
 * This demonstrates how standalone components can use
 * route-level providers for feature-scoped services.
 * The service instance is scoped to the settings route
 * and destroyed when navigating away.
 */
@Injectable()
export class SettingsService {
  private settings = signal<Record<string, string>>({
    theme: 'light',
    language: 'en',
    pageSize: '10',
    notifications: 'enabled',
    dateFormat: 'MM/dd/yyyy'
  });

  allSettings = computed(() => {
    const s = this.settings();
    return Object.entries(s).map(([key, value]) => ({ key, value }));
  });

  getSetting(key: string): string {
    return this.settings()[key] ?? '';
  }

  updateSetting(key: string, value: string): void {
    this.settings.update(current => ({ ...current, [key]: value }));
  }
}
