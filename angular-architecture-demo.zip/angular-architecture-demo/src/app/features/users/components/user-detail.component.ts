import { Component, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { UserService } from '../../../core/services/user.service';
import { User } from '../../../core/models/user.model';

/**
 * UserDetailComponent - STANDALONE COMPONENT
 *
 * Demonstrates inject() with ActivatedRoute and Router.
 */
@Component({
  selector: 'app-user-detail',
  imports: [DatePipe],
  template: `
    <div class="user-detail">
      <button class="back-btn" (click)="goBack()">← Back to Users</button>

      @if (user()) {
        <div class="detail-card">
          <div class="user-header">
            <img [src]="user()!.avatarUrl" [alt]="user()!.name" class="avatar" />
            <div>
              <h2>{{ user()!.name }}</h2>
              <span class="badge standalone-badge">Standalone Component</span>
            </div>
          </div>
          <div class="detail-grid">
            <div class="detail-row">
              <span class="label">Email:</span>
              <span class="value">{{ user()!.email }}</span>
            </div>
            <div class="detail-row">
              <span class="label">Role:</span>
              <span class="role-badge" [attr.data-role]="user()!.role">{{ user()!.role }}</span>
            </div>
            <div class="detail-row">
              <span class="label">Last Login:</span>
              <span class="value">{{ user()!.lastLogin | date:'full' }}</span>
            </div>
          </div>
        </div>
      } @else {
        <div class="loading">Loading user...</div>
      }
    </div>
  `,
  styles: [`
    .user-detail { padding: 1rem; }
    .back-btn { background: none; border: 2px solid #3498db; color: #3498db; padding: 0.5rem 1rem; border-radius: 8px; cursor: pointer; margin-bottom: 1rem; }
    .back-btn:hover { background: #3498db; color: white; }
    .detail-card { border: 1px solid #e0e0e0; border-radius: 12px; padding: 2rem; max-width: 600px; }
    .user-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; }
    .avatar { width: 80px; height: 80px; border-radius: 50%; border: 3px solid #3498db; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; }
    .standalone-badge { background: #2ecc71; color: white; }
    .detail-grid { margin-top: 1rem; }
    .detail-row { display: flex; align-items: center; padding: 0.75rem 0; border-bottom: 1px solid #f0f0f0; }
    .label { font-weight: 600; width: 120px; color: #555; }
    .value { flex: 1; }
    .role-badge { padding: 0.3rem 0.8rem; border-radius: 12px; font-weight: 600; font-size: 0.85rem; text-transform: uppercase; }
    .role-badge[data-role="admin"] { background: #e74c3c; color: white; }
    .role-badge[data-role="editor"] { background: #3498db; color: white; }
    .role-badge[data-role="viewer"] { background: #95a5a6; color: white; }
    .loading { text-align: center; padding: 2rem; color: #999; }
  `]
})
export class UserDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private userService = inject(UserService);

  user = signal<User | undefined>(undefined);

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.userService.getUserById(id).subscribe(user => {
      this.user.set(user);
    });
  }

  goBack(): void {
    this.router.navigate(['/users']);
  }
}
