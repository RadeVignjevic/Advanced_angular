import { Component, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DatePipe } from '@angular/common';
import { UserService } from '../../../core/services/user.service';
import { User } from '../../../core/models/user.model';

/**
 * UserListComponent - STANDALONE COMPONENT
 *
 * Demonstrates:
 * - Standalone component with direct imports
 * - inject() function for DI
 * - Signal-based state
 * - DatePipe imported directly (no CommonModule needed)
 */
@Component({
  selector: 'app-user-list',
  imports: [RouterLink, DatePipe],
  template: `
    <div class="user-list">
      <h2>Users <span class="badge standalone-badge">Standalone</span></h2>
      <p class="architecture-note">
        ✅ This standalone component imports <code>DatePipe</code> directly — no CommonModule needed.
        Uses <code>inject()</code> for DI and signals for state.
      </p>

      <div class="user-grid">
        @for (user of users(); track user.id) {
          <div class="user-card">
            <div class="user-avatar">
              <img [src]="user.avatarUrl" [alt]="user.name" />
            </div>
            <div class="user-info">
              <h3>{{ user.name }}</h3>
              <p class="email">{{ user.email }}</p>
              <span class="role-badge" [attr.data-role]="user.role">{{ user.role }}</span>
              <p class="last-login">Last login: {{ user.lastLogin | date:'mediumDate' }}</p>
            </div>
            <a [routerLink]="['/users', user.id]" class="detail-link">View Profile →</a>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .user-list { padding: 1rem; }
    .badge { font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 12px; vertical-align: middle; }
    .standalone-badge { background: #2ecc71; color: white; }
    .architecture-note { background: #d4edda; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .architecture-note code { background: #e8f5e9; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .user-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem; }
    .user-card { display: flex; flex-direction: column; border: 1px solid #e0e0e0; border-radius: 12px; padding: 1.25rem; transition: box-shadow 0.2s; }
    .user-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .user-avatar { text-align: center; }
    .user-avatar img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #e0e0e0; }
    .user-info { flex: 1; margin-top: 0.75rem; }
    .user-info h3 { margin: 0 0 0.25rem 0; }
    .email { color: #666; font-size: 0.9rem; margin: 0.25rem 0; }
    .role-badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; }
    .role-badge[data-role="admin"] { background: #e74c3c; color: white; }
    .role-badge[data-role="editor"] { background: #3498db; color: white; }
    .role-badge[data-role="viewer"] { background: #95a5a6; color: white; }
    .last-login { font-size: 0.8rem; color: #999; margin-top: 0.5rem; }
    .detail-link { display: block; margin-top: 0.75rem; color: #3498db; text-decoration: none; font-weight: 500; text-align: center; }
  `]
})
export class UserListComponent implements OnInit {
  private userService = inject(UserService);
  users = signal<User[]>([]);

  ngOnInit(): void {
    this.userService.getUsers().subscribe(users => {
      this.users.set(users);
    });
  }
}
