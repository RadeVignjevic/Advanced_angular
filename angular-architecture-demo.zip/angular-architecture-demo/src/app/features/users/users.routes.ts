import { Routes } from '@angular/router';
import { UserListComponent } from './components/user-list.component';
import { UserDetailComponent } from './components/user-detail.component';

/**
 * User routes - STANDALONE ROUTING PATTERN
 *
 * This is the modern approach to routing with standalone components:
 * - No NgModule needed (no RouterModule.forChild())
 * - Just a simple exported Routes array
 * - Lazy loaded via: loadChildren: () => import('./users.routes').then(m => m.USER_ROUTES)
 *
 * Compare this with products-routing.module.ts to see the difference.
 */
export const USER_ROUTES: Routes = [
  { path: '', component: UserListComponent },
  { path: ':id', component: UserDetailComponent }
];
