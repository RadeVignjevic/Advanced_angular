# Block 4 — Change Detection Mechanisms and Signal-Based Optimisation

## Instructor Guide — "For Dummies" Edition

**Duration:** 2 hours (120 min)
**Prerequisites:** Blocks 1-3 complete (Standalone + Monorepo + Signals)
**Angular Version:** 19.x
**Project:** `angular-change-detection-demo` (Nx monorepo, carried over from Block 3)

---

## How to Use This Guide

This guide tells you **exactly what to say, what to click, and what to draw on the whiteboard**. Every section follows this pattern:

1. **Whiteboard / Analogy** — draw or explain the concept in plain English first
2. **Show the Code** — scroll to the exact section in the running app
3. **Live Demo** — click buttons, watch the result, narrate what happens
4. **Student Checkpoint** — ask a question to verify understanding

> **Convention:** Text in "quotes like this" is **exactly what you say out loud** to the class.

---

## Schedule Overview

| # | Topic | Time | Route | What Students Learn |
|---|-------|------|-------|---------------------|
| 1 | Change Detection in Depth | 40 min | `/cd-in-depth` | How Angular knows when to re-render, Zone.js, OnPush, Zoneless |
| 2 | Signal-Driven Change Detection | 30 min | `/signal-driven-cd` | How signals make CD automatic, fine-grained, and fast |
| 3 | Identifying and Resolving CD Issues | 20 min | `/cd-issues` | The 5 most common CD bugs and how to fix each one |
| 4 | Workshop: CD Profiling | 30 min | `/cd-workshop` | Hands-on profiling with Angular DevTools and Chrome Performance |

All feature components are in `apps/demo-app/src/app/features/`.

---

## Before Class — Setup (5 min)

### Start the App

```bash
cd angular-change-detection-demo
npm install          # only the first time
npx nx serve demo-app
```

Open **http://localhost:4200**. You'll see the Block 4 dashboard with four clickable topic cards.

### What Students Need

- Chrome browser with **Angular DevTools** extension installed
- The app running on their machine (or watching your screen)
- Optionally: Chrome DevTools open (F12)

---

## Opening Talk (5 min)

### The Restaurant Analogy

> "Imagine you're a waiter in a restaurant with 50 tables. When the kitchen bell rings, you have two choices:
>
> **Choice A (Default CD):** You walk to EVERY table and ask 'Did your food arrive? Do you need anything?' — even tables that haven't ordered yet. This works, but it's exhausting.
>
> **Choice B (OnPush CD):** You carry a notepad. The kitchen writes down which table the food is for. You only visit THAT table.
>
> That's the difference between Default and OnPush change detection. And signals? Signals are like a buzzer system — the table buzzes YOU when they need something. No walking, no notepad, no wasted effort."

### Whiteboard — Draw This

```
┌──────────────────────────────────────────────────┐
│              HOW ANGULAR RE-RENDERS               │
│                                                   │
│  Something happens  ──►  Angular detects it       │
│  (click, timer,         (change detection)        │
│   HTTP response)                                  │
│                     ──►  Updates the DOM           │
│                         (re-renders components)    │
│                                                   │
│  TODAY'S QUESTION: How does Angular "detect it"?  │
│  Answer: Zone.js, OnPush, or Signals              │
└──────────────────────────────────────────────────┘
```

> "By the end of this block, you'll know exactly which components get checked, when they get checked, and how to make Angular check FEWER things."

---

## Topic 1: Change Detection in Depth (40 min)

**Navigate to:** `http://localhost:4200/cd-in-depth`
**File:** `apps/demo-app/src/app/features/cd-in-depth/cd-in-depth.component.ts`

---

### Section 1.1: Zone.js — How Angular Knows When to Check (10 min)

#### What to Say

> "Before we touch any code, let me explain what Zone.js actually is. When you write `setTimeout(() => { ... }, 500)` in a normal JavaScript app, the browser runs your callback after 500ms and that's it. Nobody else knows it happened.
>
> Zone.js REPLACES the original `setTimeout` with its own version. So when your callback runs, Zone.js says to Angular: 'Hey! Something async just finished! You might want to check your templates.'
>
> Angular then runs what's called `ApplicationRef.tick()` — which walks through EVERY component in your app, from the root down, and checks if any template bindings changed."

#### Whiteboard — Draw This

```
┌────────────────────────────────────────────────────┐
│                    ZONE.JS                          │
│                                                     │
│  Browser APIs that Zone.js monkey-patches:          │
│  ├── setTimeout / setInterval                       │
│  ├── addEventListener (click, keyup, etc.)          │
│  ├── fetch / XMLHttpRequest                         │
│  ├── Promise.then / .catch                          │
│  └── ~200 more APIs                                 │
│                                                     │
│  Any async callback completes                       │
│       │                                             │
│       ▼                                             │
│  Zone.js notifies Angular                           │
│       │                                             │
│       ▼                                             │
│  ApplicationRef.tick()                              │
│       │                                             │
│       ▼                                             │
│  CD runs from ROOT ──► checks ALL components        │
└────────────────────────────────────────────────────┘
```

#### Live Demo — The Three Buttons

Scroll to **Section 1** in the app ("Zone.js — How Angular Knows When to Check").

**Button 1: "Click (patched by Zone)"**

> "Watch the log box below. I'm going to click this button."

Click it. The log shows: `Click event — Zone.js notified Angular, CD ran from root`

> "A click event is a DOM event. Zone.js has monkey-patched `addEventListener`, so it sees this event and tells Angular to run CD. Simple."

**Button 2: "setTimeout (patched)"**

> "Now I'll click this one. It triggers a `setTimeout` with 500ms delay."

Click it. Wait half a second. The log updates.

> "Even though the code ran asynchronously, Zone.js patched `setTimeout`. So when the callback fires, Angular is notified. The UI updates."

**Button 3: "Run Outside Zone"**

> "Now the interesting one. This calls `ngZone.runOutsideAngular()`. That means whatever happens inside will NOT notify Angular."

Click it. Wait half a second. The log updates BUT only because the code **re-enters** the zone manually.

> "Look at the code — after running outside Zone, we call `ngZone.run()` to re-enter. Without that line, the UI would NEVER update. The log message says 'Ran outside Zone, then re-entered'. That re-enter step is crucial."

#### Show the Code

Point to the component's TypeScript in your editor:

```typescript
// Lines 227-237 in cd-in-depth.component.ts
triggerOutsideZone(): void {
  this.ngZone.runOutsideAngular(() => {
    setTimeout(() => {
      // This won't trigger CD!
      console.log('Ran outside Zone — no CD triggered.');
      this.ngZone.run(() => {
        this.cdLog.update(log => [...log,
          `Ran outside Zone, then re-entered — CD triggered manually`]);
      });
    }, 500);
  });
}
```

> "The pattern is: `runOutsideAngular` to escape, `ngZone.run()` to come back. But with signals, you won't need this at all — we'll see why in Topic 3."

#### Student Checkpoint

> "Quick question: if I do a `fetch()` call inside a component, does Angular know about it? Does it trigger CD?"

**Answer:** Yes — Zone.js patches `fetch`. When the response arrives, CD runs automatically.

---

### Section 1.2: Default vs OnPush Strategy (10 min)

#### What to Say

> "Angular gives you two modes for each component. Think of it like two types of security cameras:
>
> **Default** = the camera records 24/7, even when nothing is happening. It catches everything, but it wastes storage and electricity.
>
> **OnPush** = the camera is motion-activated. It only turns on when something ACTUALLY moves. Way more efficient."

#### Live Demo

Scroll to **Section 2** in the app ("Default vs OnPush Strategy").

Point to the two side-by-side cards:

> "On the left — Default strategy. This component gets checked on EVERY change detection cycle. EVERY click, EVERY timer, EVERY HTTP response in the app will cause Angular to check this component.
>
> On the right — OnPush strategy. This component only gets checked when one of four things happens..."

Count on your fingers:

> "One: an `@Input()` reference changes. Two: a DOM event fires INSIDE this component (like a button click). Three: an `AsyncPipe` emits a new value. Four: a signal that the template reads changes. That's it. Everything else is ignored."

**Click the "Trigger CD (Event)" button:**

> "Watch the counter. It increments because clicking is a DOM event inside this OnPush component. That's trigger number two."

Show the decorator in the component code:

```typescript
@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  // ...
})
```

> "This single line is the most impactful performance change you can make. One line."

#### Student Checkpoint

> "If a parent component uses Default strategy and a child uses OnPush, what happens when Angular runs CD?"

**Answer:** Angular checks the parent (Default = always checked). When it gets to the child (OnPush), it checks if the child has a reason to update. If not, the child AND its entire subtree are skipped.

---

### Section 1.3: Component Tree Traversal (10 min)

#### What to Say

> "Let's see this visually. Angular doesn't check components randomly — it walks a tree, from the root down."

#### Live Demo

Scroll to **Section 3** in the app ("Component Tree Traversal").

You'll see a tree diagram with boxes: AppComponent at top, then HeaderComponent, ContentComponent, SidebarComponent below, then ChildA, ChildB, ChildC at the bottom.

> "Look at the labels — some say 'Default', some say 'OnPush'. Watch what happens when I click 'Simulate CD Cycle'."

**Click "Simulate CD Cycle" multiple times.** Watch nodes turn green (checked) or stay grey (skipped).

> "See that? ContentComponent and ChildB always turn green because they use Default strategy — Angular always checks them. But HeaderComponent, SidebarComponent, ChildA, ChildC — they only light up when they have a reason. OnPush is the bouncer. No invitation, no entry."

**Click "Reset" to start over.**

> "In a real app with 200 components, imagine if 150 of them use OnPush. Angular skips checking 150 components on every click. That's a MASSIVE performance win."

#### Whiteboard — Draw This

```
                    AppComponent (Default)
                    ┌─── ALWAYS CHECKED ───┐
                    │                       │
          ┌─────────┤─────────┐             │
          │         │         │             │
     Header     Content   Sidebar          │
     (OnPush)   (Default) (OnPush)         │
     SKIPPED ✗  CHECKED ✓ SKIPPED ✗       │
          │         │         │             │
       ChildA    ChildB    ChildC          │
       (OnPush)  (Default) (OnPush)        │
       SKIPPED ✗ CHECKED ✓ SKIPPED ✗      │
                                            │
       With OnPush: 3 checked, 3 skipped    │
       Without OnPush: 6 checked, 0 skipped │
```

---

### Section 1.4: Zoneless Angular — Experimental (5 min)

#### What to Say

> "Here's the future: Angular without Zone.js entirely. No monkey-patching, no magic — just signals.
>
> Right now it's experimental, but it works. You add one provider to your app config, and Zone.js is removed."

Scroll to **Section 4** ("Zoneless Angular (Experimental)").

Point to the code block showing:

```typescript
provideExperimentalZonelessChangeDetection()
```

> "Instead of Zone.js watching 200+ browser APIs, Angular now relies ONLY on signals. When a signal changes, Angular knows that exact component is dirty. Nothing else is checked.
>
> The trade-off? ALL your state must be signals. If you use a plain `this.value = 'hello'`, Angular won't know it changed because there's no Zone.js watching assignments."

Point to the comparison grid:

> "Key numbers: Zone.js adds about 15KB to your bundle. Removing it makes your app smaller and removes a class of unpredictable behaviour."

---

### Section 1.5: markForCheck() vs detectChanges() (5 min)

#### What to Say

> "Before signals existed, OnPush components had a problem. If data changed outside of the four triggers — no input change, no event, no async pipe, no signal — the UI wouldn't update. Developers had two escape hatches."

Scroll to **Section 5** ("markForCheck() vs detectChanges()").

> "`markForCheck()` is the SAFE option. It says 'Hey Angular, when you run CD next, please check this component.' It's scheduled, it's orderly, it respects the lifecycle.
>
> `detectChanges()` is the EMERGENCY option. It says 'Check this component RIGHT NOW, synchronously.' It can cause errors like ExpressionChangedAfterItHasBeenChecked because it bypasses the normal cycle."

**Pause. Then say:**

> "But here's the punchline: **with signals, you almost never need either.** When you call `signal.set()` or `signal.update()`, Angular automatically calls `markForCheck()` for you. That's one less thing to remember."

#### Student Checkpoint

> "Pop quiz: if you're writing a brand new Angular 19 app with all signals and OnPush, how many times will you call `markForCheck()` in your code?"

**Answer:** Zero. Signals handle it automatically.

---

## Topic 2: Signal-Driven Change Detection (30 min)

**Navigate to:** `http://localhost:4200/signal-driven-cd`
**File:** `apps/demo-app/src/app/features/signal-driven-cd/signal-driven-cd.component.ts`

---

### Section 2.1: How Signals Mark Components Dirty (7 min)

#### What to Say

> "In Topic 1 we learned how Zone.js tells Angular to check EVERYTHING. Signals do the opposite — they tell Angular to check ONE specific component.
>
> Think of it like a doorbell system. Zone.js is like a fire alarm — the whole building evacuates. Signals are like a doorbell — only the person in that apartment answers."

#### Live Demo

Scroll to **Section 1** ("How Signals Mark Components Dirty"). You'll see a flow diagram:

```
signal()  ──►  Angular Framework  ──►  Change Detection  ──►  Re-render
               (markForCheck auto)     (scheduled next tick)
```

> "When I click this button, `count.set(count + 1)` runs. The signal notifies Angular. Angular marks this ONE component dirty. Next CD tick, it re-renders the template."

**Click the "count.set(count + 1)" button** several times.

> "Watch two things: the count goes up, AND the render count goes up. Every time the signal changes, Angular re-renders this component."

**Click "Reset".**

> "Notice the render count resets too. Zero waste — Angular only re-rendered when the signal actually changed."

#### Show the Code

```typescript
// The signal
count = signal(0);

// The button click handler
incrementCount(): void {
  this.count.update(v => v + 1);
}

// In template: {{ count() }}   ← reading the signal
// In template: {{ renderTracker() }}  ← tracks re-renders
```

> "There is NO `markForCheck()` call anywhere. The signal does it automatically."

---

### Section 2.2: Fine-Grained Reactivity (8 min)

#### What to Say

> "This is the most important demo in this entire block. It shows WHY signals are better than Zone.js for performance."

Scroll to **Section 2** ("Fine-Grained Reactivity — Only What Changed").

> "We have three fake components on screen. Component A reads `firstName()`. Component B reads `lastName()`. Component C reads `fullName()` which is a computed signal that combines both."

#### Live Demo

**Click "Change firstName":**

> "Look! Component A lit up green (RE-RENDERED) because it reads `firstName`. Component B stayed idle because `lastName` didn't change. Component C also updated because `fullName` is computed from `firstName`."

**Click "Change lastName":**

> "Now Component B lights up. Component A stays idle. Component C updates again because `fullName` depends on `lastName` too."

**Click "Reset" to clear the highlights.**

> "THIS is fine-grained reactivity. With Zone.js + Default strategy, ALL THREE components would be checked on EVERY interaction. With signals, Angular knows the exact dependency graph and only re-renders what's affected."

#### Whiteboard — Draw the Dependency Graph

```
   firstName ──────► Component A
       │
       ├─────► fullName (computed) ──► Component C
       │           ▲
   lastName ──────┘──────► Component B

   Change firstName → A and C update, B skipped
   Change lastName  → B and C update, A skipped
```

#### Show the Code

```typescript
firstName = signal('John');
lastName = signal('Doe');
fullName = computed(() => this.firstName() + ' ' + this.lastName());
lastUpdated = signal('');  // tracks which signal changed for the demo
```

> "Angular reads the template, sees `{{ firstName() }}`, and internally registers: 'this component depends on firstName'. When firstName changes, only components with that dependency get re-rendered."

---

### Section 2.3: Computed Memoisation (5 min)

#### What to Say

> "Computed signals have a superpower: they remember their last answer. If the inputs haven't changed, they return the cached value without recalculating."

Scroll to **Section 3** ("Computed Memoisation").

#### Live Demo

**Click "Change Input" three times.** Watch the recomputations counter go up.

> "Every time the input signal changes, the computed recalculates. That makes sense."

**Now click "Set SAME Value":**

> "I clicked it. Look — the recomputations counter did NOT increase! The signal said 'my value is already 8, you're setting it to 8 again, nothing changed.' The computed never even runs."

> "This is `Object.is()` equality. Same value = no notification = no recompute = no re-render. Free performance."

#### Show the Code

```typescript
memoInput = signal(5);
memoComputeCount = signal(0);

expensiveResult = computed(() => {
  this.memoComputeCount.update(c => c + 1);  // tracks recomputations
  return this.memoInput() * this.memoInput();
});

setSameValue(): void {
  this.memoInput.set(this.memoInput());  // same value — no recompute!
}
```

> "That `memoComputeCount.update()` inside the computed is how we track recomputations. In production you'd never do that, but for teaching it shows the memoisation perfectly."

---

### Section 2.4: Signal Equality Checks (5 min)

#### What to Say

> "There's a gotcha with signals and objects. By default, signals use `Object.is()` — which for objects means REFERENCE equality. A new object with the same content is still considered 'different'."

Scroll to **Section 4** ("Signal Equality Checks").

#### Live Demo

**Click "New Object Ref"** — the default updates counter increments.

> "I created a new object `{ name: 'A', value: 1 }` — same content as before, but it's a NEW JavaScript object. Default equality says 'new reference = changed!' So the update counter goes up."

**Click "Same Content, New Ref"** — default increments, but custom does NOT.

> "Look at the two counters. The default one went up again (new reference = changed). But the custom one stayed the same! Because we gave the signal a custom equality function."

#### Show the Code

```typescript
// Default: Object.is() — new reference always triggers
defaultObj = signal({ name: 'A', value: 1 });

// Custom: deep equality — same content = no update
customObj = signal(
  { name: 'A', value: 1 },
  { equal: (a, b) => a.name === b.name && a.value === b.value }
);
```

> "Rule of thumb: if your signal holds an object or array, and you frequently set it to the same content with a new reference, add a custom equality function. It prevents unnecessary re-renders."

---

### Section 2.5: Live Ticker Demo (5 min)

#### What to Say

> "Let me put it all together with a live example."

Scroll to **Section 5** ("Live Demo: Signal + OnPush Auto-Refresh").

> "Look at the timer counting up. That's `toSignal(interval(1000))` — an RxJS interval converted to a signal. Every second, the signal emits a new number.
>
> This component uses OnPush. In the old world, you'd need `AsyncPipe` or `markForCheck()` to make a timer update in an OnPush component. With signals? Nothing. It just works.
>
> The product count loaded once from the service and stays stable. No unnecessary re-renders."

#### Show the Code

```typescript
ticker = toSignal(interval(1000), { initialValue: 0 });
products = toSignal(this.productService.getProducts(), { initialValue: [] as Product[] });
productCount = computed(() => this.products().length);
```

> "Three lines. Automatic CD. OnPush compatible. No subscriptions to manage. No memory leaks. This is the Angular 19 way."

#### Student Checkpoint

> "Why doesn't the timer cause every component on the page to re-render?"

**Answer:** Because the signal is only read in THIS component's template. Other components don't read it, so Angular doesn't mark them dirty.

---

## Topic 3: Identifying and Resolving CD Issues (20 min)

**Navigate to:** `http://localhost:4200/cd-issues`
**File:** `apps/demo-app/src/app/features/cd-issues/cd-issues.component.ts`

---

### Opening — Set the Context

> "Now we're switching from 'how it works' to 'what goes wrong'. I'm going to show you the five most common change detection bugs. If you've worked in Angular for more than a month, you've probably hit at least three of these."

---

### Section 3.1: ExpressionChangedAfterItHasBeenChecked (5 min)

#### What to Say

> "This is the most infamous Angular error. Let me explain what it means.
>
> In development mode — NOT production — Angular runs change detection TWICE. The first pass updates bindings. The second pass VERIFIES that nothing changed since the first pass. If a value IS different, Angular throws this error because it means your template is unstable.
>
> The classic cause is a getter that returns a different value each time it's called."

#### Live Demo

Scroll to **Section 1** ("ExpressionChangedAfterItHasBeenChecked"). Read the code block:

```typescript
// ERROR scenario:
get currentTime() {
  return Date.now();  // Different on every check!
}
// Angular checks: 12345 -> verifies: 12346 -> ERROR!
```

> "`Date.now()` returns the current timestamp. First check sees 12345. Second check (milliseconds later) sees 12346. They don't match. BOOM — error."

Point to the fix:

```typescript
// FIX: Use a signal
currentTime = signal(Date.now());
constructor() {
  setInterval(() => this.currentTime.set(Date.now()), 1000);
}
```

> "With a signal, the value only changes when YOU change it — inside the `setInterval` callback. Between Angular's two checks, the signal value stays the same. No error."

#### Common Triggers — Read the List

> "Other things that cause this error:
> - Modifying state in `ngAfterViewInit` (after Angular already checked)
> - Parent modifying child inputs during its own CD check
> - Pipes that return new object references every time"

---

### Section 3.2: Getter Functions in Templates — The Hidden Trap (5 min)

#### What to Say

> "This is the NUMBER ONE hidden performance killer in Angular apps. I've seen this in every codebase I've audited."

Scroll to **Section 2** ("Getter Functions in Templates — Hidden Trap").

> "On the left: BAD pattern. A method called `getTotal()` in the template. On the right: GOOD pattern. A `computed()` signal called `total()`.
>
> The method runs on EVERY change detection cycle. If CD runs 50 times per second (mouse move, timers, etc.), that method runs 50 times per second. If it's calculating a total over 1000 items, that's 50,000 iterations per second. For nothing."

#### Live Demo

**Click "Trigger CD" on the BAD side** several times. Watch the call count go up.

> "See? Every click adds to the call count. And that's just clicks — in a real app, mouse moves, timers, and HTTP responses all trigger CD too."

**Click "Trigger CD" on the GOOD side.**

> "The computed version only recomputed when its dependency changed. When the signal feeding it didn't change, it returned the cached value. Zero extra work."

#### Show the Code

```typescript
// BAD — runs every CD cycle
getTotal() {
  return this.items.reduce((sum, i) => sum + i.price, 0);
}

// GOOD — runs only when items() signal changes
items = signal([...]);
total = computed(() =>
  this.items().reduce((sum, i) => sum + i.price, 0)
);
```

> "One rule: NEVER call a function in a template binding. Use a `computed()` signal instead. Always."

---

### Section 3.3: Object Mutation with OnPush (4 min)

#### What to Say

> "OnPush is efficient because it checks references, not values. But that means if you MUTATE an object — change a property without creating a new object — OnPush doesn't notice."

Scroll to **Section 3** ("Object Mutation — OnPush Pitfall").

#### Live Demo

**Click "Mutate (no update!)" on the BAD side:**

> "I clicked it. Look at the displayed name — it still says 'John'. But I CAN see in the code that `this.mutatedUser.name` was changed to 'Mutated!'.
>
> Why didn't the UI update? Because `this.mutatedUser` is still the SAME JavaScript object reference. OnPush compares references, sees the same reference, and says 'nothing changed, skip'."

**Click "Update (signal)" on the GOOD side:**

> "Now it works! The name changed to 'Jane'. Because signals use `update()` which creates a new object with the spread operator. New reference = OnPush sees a change."

#### Show the Code

```typescript
// BAD: same reference — OnPush doesn't notice
mutateObject(): void {
  this.mutatedUser.name = 'Mutated!';
  // reference didn't change → OnPush skips
}

// GOOD: new reference via signal.update()
immutableUpdate(): void {
  this.immutableUser.update(u => ({ ...u, name: next }));
  // new object → signal notifies → CD runs
}
```

> "The spread operator `{ ...u, name: next }` creates a new object. New object = new reference = OnPush is happy."

---

### Section 3.4: Third-Party Libraries Outside Zone (3 min)

#### What to Say

> "This one bites you when you use third-party libraries — charting libraries like Chart.js, mapping libraries like Leaflet, WebSocket clients, etc. Their callbacks often run outside Angular's Zone."

Scroll to **Section 4** ("Third-Party Libraries Running Outside Zone").

> "The symptom: you `console.log(this.data)` and see the correct value. But the UI shows the old value. You click somewhere, and suddenly the UI catches up. That's because Zone.js didn't intercept the library's callback."

#### Live Demo

**Click "Simulate Lib Callback (via signal)":**

> "Watch — it works! The value updates after 300ms. Even though the code runs OUTSIDE Zone (I wrapped it in `runOutsideAngular`), the signal still works because signals bypass Zone entirely."

#### Show the Code

```typescript
simulateExternalLib(): void {
  this.ngZone.runOutsideAngular(() => {
    setTimeout(() => {
      // Even though we're outside Zone, signals always work
      this.externalValue.set('Data received at ' + new Date().toLocaleTimeString());
    }, 300);
  });
}
```

> "This is fix #1 — the best fix. Use signals. They don't care about Zones. Fix #2 is `NgZone.run()` to re-enter the zone. Fix #3 is `detectChanges()` — but that's the nuclear option."

---

### Section 3.5: Excessive CD Cycles — Diagnostic Checklist (3 min)

#### What to Say

> "When your app feels sluggish, here's how to diagnose it. We're going to use this checklist in the workshop next."

Scroll to **Section 5** ("Excessive CD Cycles — Diagnosis").

Read through the 5-step checklist:

> "Step 1: Open Angular DevTools Profiler — see how many CD cycles run.
> Step 2: Check for Default strategy on parent components — they force CD on all children.
> Step 3: Search for function calls in templates — replace with computed().
> Step 4: Check for frequent async operations — timers, polling that trigger Zone CD.
> Step 5: Open browser Performance tab — look for long scripting blocks."

> "Let's actually DO all five steps now. That's our workshop."

---

## Topic 4: Workshop — Change Detection Profiling (30 min)

**Navigate to:** `http://localhost:4200/cd-workshop`
**File:** `apps/demo-app/src/app/features/cd-workshop/cd-workshop.component.ts`

---

### Phase 1: Angular DevTools Setup (5 min)

#### What to Say

> "Everyone open a Chrome tab, navigate to our app. Now press F12 to open Chrome DevTools. Look for a tab called 'Angular'. If you don't see it, you need to install the Angular DevTools extension from the Chrome Web Store."

Walk through the 5 steps shown on screen in Exercise 1:

> "Step 1: You've got Angular DevTools installed — good.
> Step 2: Open DevTools (F12).
> Step 3: Click the 'Angular' tab, then 'Profiler' inside it.
> Step 4: Click the red record button. Now interact with the app — click some buttons, scroll around. Then click stop.
> Step 5: You'll see bars. Each bar is one CD cycle. The taller the bar, the longer it took. Hover over a bar to see which components were checked."

**Wait for students to try it.** Walk around the room if in-person.

#### Common Issue

> "If you don't see the Angular tab, make sure you're on an Angular app (not a blank tab) and that you're in development mode, not production."

---

### Phase 2: Live Performance Profiling (10 min)

#### What to Say

> "Now let's profile real interactions. Look at the four cards in Exercise 2."

Scroll to **Exercise 2** ("Live Performance Test Area"). You'll see four cards:
- **Counter (Signal)** — value: 0, +1 button
- **Timer (interval via toSignal)** — counting up every second
- **Product Count** — static number
- **Filtered Count** — with "In Stock Only" / "Show All" toggle

#### Exercise — Walk Students Through

> "Start recording in the profiler. Now:"

**Step 1:** Click +1 on the counter three times.

> "Stop recording. Look at the profiler. You should see 3 CD cycles — one per click. Each one shows this component was checked. The parent components (if OnPush) were SKIPPED."

> "Start recording again."

**Step 2:** Just wait 5 seconds (let the timer tick).

> "Stop. You see about 5 CD cycles — one per second. That's the `interval(1000)` from `toSignal`. Each tick updates the signal, which marks this component dirty."

> "Record again."

**Step 3:** Click the "In Stock Only" filter button.

> "Stop. One CD cycle. The `showInStock` signal changed, which made `filteredProducts` (computed) and `filteredCount` (computed) recalculate. The product list in the DOM was updated via `@for` with `track`."

#### Show the Code

```typescript
counter = signal(0);
timer = toSignal(interval(1000), { initialValue: 0 });
showInStock = signal(false);

filteredProducts = computed(() => {
  const all = this.products();
  if (this.showInStock()) {
    return all.filter(p => p.inStock);
  }
  return all;
});

filteredCount = computed(() => this.filteredProducts().length);
```

> "Notice how `filteredProducts` chains off TWO signals: `products()` and `showInStock()`. Angular tracks BOTH dependencies. If either changes, the computed recalculates."

#### What to Observe Box

Read the observation box on screen to students:

> "Key observations:
> - Counter click → only this component shows in profiler
> - Timer ticks → CD cycle each second, automatic
> - Filter toggle → computed recalculates, but parent components are unaffected
> - OnPush parents are SKIPPED in the profiler"

---

### Phase 3: Before/After Optimisation (5 min)

#### What to Say

> "Now compare the two patterns side by side."

Scroll to **Exercise 3** ("Before/After Optimisation").

Left side (red border): Unoptimised
Right side (green border): Optimised

> "Read down the metrics table:
>
> Strategy: Default versus OnPush — OnPush skips unnecessary checks.
> Template calls: `getTotal()` method versus `computed()` signal — computed is memoised.
> State management: Mutable object versus Immutable signal — signals guarantee new references.
> CD per tick: Checks ALL children versus Only dirty components — massive performance difference."

#### Show the Before Code

```typescript
// BEFORE: No changeDetection specified = Default
// Method in template → runs every CD cycle
// *ngFor without track → bad
getTotal() {
  return this.products.reduce((s, p) => s + p.price, 0);
}
```

#### Show the After Code

```typescript
// AFTER: OnPush + computed + @for with track
changeDetection: OnPush,
products = toSignal(svc.getProducts(), { initialValue: [] });
total = computed(() =>
  this.products().reduce((s, p) => s + p.price, 0));
// @for (p of products(); track p.id) { ... }
```

> "Four simple changes. Each one independently improves performance. Together they transform an O(n) component into an O(1) component for CD."

---

### Phase 4: Browser Performance Tab (5 min)

#### What to Say

> "The Angular DevTools show you WHAT was checked. The browser Performance tab shows you HOW LONG it took."

Scroll to **Exercise 4** ("Browser Performance Tab").

Walk through the 5 steps on screen:

> "Step 1: Open Chrome DevTools → Performance tab (not the Angular tab this time).
> Step 2: Check 'Screenshots' and 'Web Vitals'.
> Step 3: Click Record, interact with the app for 5 seconds, then Stop.
> Step 4: In the flame chart, look for function calls named `ApplicationRef.tick` — that's Angular's CD function.
> Step 5: Click the 'Bottom-Up' tab and sort by 'Self Time'. The most expensive functions float to the top."

**If students are following along:**

> "You should see that each `ApplicationRef.tick` takes very little time — usually under 1ms. That's because everything is OnPush + signals. In an unoptimised app with Default strategy and method calls in templates, ticks can take 10-50ms on complex pages."

#### Profiling Target

Point to the product list at the bottom of this card:

> "This list renders products using `@for` with `track p.id`. The `track` expression is crucial — it tells Angular which DOM elements can be reused when the array changes. Without it, Angular would destroy and recreate every list element on every change."

---

### Phase 5: Optimisation Checklist (5 min)

#### What to Say

> "Let's wrap up the workshop with a checklist. I want you to go through this checklist mentally for YOUR current project at work. How many boxes can you check?"

Scroll to **Optimisation Checklist**. Read each item:

> "Checkbox 1: All components use `ChangeDetectionStrategy.OnPush` — this is the foundation.
>
> Checkbox 2: No method or getter calls in templates — use `computed()` instead.
>
> Checkbox 3: State managed via `signal()` with immutable updates — no mutations.
>
> Checkbox 4: Heavy lists use `@for` with `track` expression — for DOM reuse.
>
> Checkbox 5: No unnecessary `detectChanges()` calls — let signals handle it.
>
> Checkbox 6: Third-party callbacks wrapped with `signal.set()` or `NgZone.run()`.
>
> Checkbox 7: Custom equality functions on signals with object/array values — prevent false updates.
>
> Checkbox 8: Profiled with Angular DevTools — no unnecessary CD cycles remain."

> "If you can check all 8 boxes, your app is in the top 5% of Angular apps for CD performance."

---

## App Configuration — Teaching Notes

### app.config.ts

```typescript
export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(appRoutes),
    { provide: APP_CONFIG, useValue: DEFAULT_APP_CONFIG },
    { provide: LOGGER_CONFIG, useValue: DEV_LOGGER_CONFIG },
  ],
};
```

**Key teaching point about `eventCoalescing`:**

> "Notice `{ eventCoalescing: true }`. This tells Angular to BATCH multiple Zone.js notifications into a single CD cycle. Without it, if three events fire in the same microtask, Angular runs CD three times. With coalescing, it runs CD once. Free performance improvement."

### Routes — Lazy Loading

All Block 4 topics are lazy-loaded:

```typescript
{ path: 'cd-in-depth',
  loadChildren: () => import('./features/cd-in-depth/cd-in-depth.routes')
    .then(m => m.CD_IN_DEPTH_ROUTES) },
```

> "Each topic is loaded on demand. This means if a student never visits the workshop page, that code is never downloaded. This is standard Angular lazy loading — we covered it in Block 1."

---

## Project Structure

```
angular-change-detection-demo/
├── apps/demo-app/src/app/
│   ├── app.config.ts              # provideZoneChangeDetection with coalescing
│   ├── app.routes.ts              # All routes (Block 4 + 3 + 2 carried over)
│   ├── app.component.html         # Navigation sidebar
│   └── features/
│       ├── dashboard/             # Block 4 overview dashboard with topic cards
│       ├── cd-in-depth/           # Topic 1: Zone.js, Default vs OnPush, Zoneless
│       ├── signal-driven-cd/      # Topic 2: Signal CD, fine-grained, memoisation
│       ├── cd-issues/             # Topic 3: 5 common CD bugs + fixes
│       ├── cd-workshop/           # Topic 4: Profiling with DevTools + Performance
│       ├── signal-fundamentals/   # Block 3 (carried over)
│       ├── signals-vs-rxjs/       # Block 3 (carried over)
│       ├── signal-interop/        # Block 3 (carried over)
│       ├── rxjs-workshop/         # Block 3 (carried over)
│       ├── products/              # Block 2 (carried over)
│       ├── customers/             # Block 2 (carried over)
│       ├── users/                 # Block 2 (carried over)
│       └── settings/              # Block 2 (carried over)
├── libs/shared/
│   ├── ui/                        # UiButton, UiBadge, UiCard, UiDataTable, UiLayout
│   ├── data-access/               # Models, Services, Tokens
│   └── util/                      # Adapters, helpers, formatCurrency
└── INSTRUCTOR-GUIDE.md            # This file
```

---

## Wrap-Up Talk (5 min)

### Whiteboard — The Three Eras of Angular CD

```
┌─────────────────────────────────────────────────────────┐
│          ERA 1: Zone.js + Default (2016-2020)           │
│  • CD checks EVERYTHING on every async event            │
│  • Simple but wasteful                                  │
│  • Apps slow down as they grow                          │
├─────────────────────────────────────────────────────────┤
│          ERA 2: Zone.js + OnPush (2020-2024)            │
│  • CD only checks components with reasons               │
│  • Much faster, but needs discipline                    │
│  • Still relies on Zone.js for triggering               │
├─────────────────────────────────────────────────────────┤
│          ERA 3: Signals + Zoneless (2024+)              │
│  • No Zone.js at all                                    │
│  • Signals auto-mark exactly what changed               │
│  • ~15KB smaller, fully predictable                     │
│  • THE ANGULAR TEAM'S RECOMMENDED FUTURE                │
└─────────────────────────────────────────────────────────┘
```

### Key Takeaways — Say These Out Loud

> "Six things to remember from today:
>
> 1. **Zone.js** patches async APIs to trigger CD — but it's heavy and imprecise.
> 2. **OnPush** skips unnecessary checks — always use it with signals.
> 3. **Signals auto-mark components dirty** — no manual markForCheck() needed.
> 4. **computed() is memoised** — it replaces expensive template methods. NEVER call a function in a template.
> 5. **Zoneless Angular is the future** — fully signal-driven CD.
> 6. **Profile first, optimise second** — use Angular DevTools and the browser Performance tab."

---

## Common Student Questions

**Q: Should every component use OnPush?**
> "Yes. With signals, there are zero downsides. It only skips work that didn't need to happen."

**Q: Will Zone.js be removed from Angular?**
> "Eventually. Angular is moving toward zoneless as the default. Right now it's experimental but functional. Microsoft and Google's own Angular apps are already testing zoneless."

**Q: What about third-party libraries that use Zone.js internally?**
> "They continue to work. Zoneless mode only affects Angular's OWN CD trigger mechanism. Third-party code can still use NgZone.run() to re-enter Angular's zone."

**Q: Is detectChanges() ever appropriate?**
> "Rarely. Testing with `ComponentFixture.detectChanges()` is the main legitimate use. In production code, prefer signals. If you see `detectChanges()` in a PR review, it's usually a code smell."

**Q: How much performance improvement can I expect from OnPush + signals?**
> "Depends on tree size. Large apps with 100+ components see 60-80% fewer CD cycles. Small apps see less dramatic improvement but better architecture."

**Q: Does @for track replace trackBy?**
> "Yes. `@for (item of items; track item.id)` is the new syntax that replaces `*ngFor` with `trackBy` function. It's built into the new control flow syntax, and it's required — you can't forget it."

**Q: What happens if I mix Default and OnPush components?**
> "It works fine. Default components always get checked. OnPush components only get checked when their triggers fire. The tree traversal handles the mix. But ideally, everything should be OnPush."

**Q: Can signals cause memory leaks?**
> "No. Unlike observables, signals don't have subscriptions. Computed signals are garbage collected when the component is destroyed. Effects created in components are automatically cleaned up. This is one of the biggest wins over RxJS."

---

## Troubleshooting

### "Angular DevTools tab doesn't appear"
- Make sure you're on an Angular app URL (not about:blank or chrome://)
- The app must be in development mode (not a production build)
- Try refreshing the page after installing the extension

### "Storybook won't build"
- Use `npx nx storybook shared-ui` (not direct storybook CLI)
- Add `"compodoc": false` to storybook options if workspace path has spaces

### "Timer doesn't update in OnPush component"
- If using raw `setInterval`, you need `markForCheck()` or `signal.set()`
- If using `toSignal(interval(1000))`, it works automatically

### "Object mutation not reflected in UI"
- OnPush requires new references — use spread `{ ...obj, prop: newValue }`
- Signal's `update()` method is the cleanest way

---

## Reference Materials

- [Angular Change Detection Guide](https://angular.dev/guide/change-detection)
- [Angular DevTools Chrome Extension](https://chrome.google.com/webstore/detail/angular-devtools/)
- [Zoneless Angular (Experimental)](https://angular.dev/guide/experimental/zoneless)
- [Signal Equality (Angular docs)](https://angular.dev/guide/signals#equality-functions)

---

## Nx Commands Reference

```bash
npx nx serve demo-app          # Serve the demo app
npx nx build demo-app          # Build for production
npx nx lint demo-app           # Run linting
npx nx graph                   # Dependency graph
```
