# Block 2: Monorepo Architecture and Component Library Design

## Instructor Guide — 2-Hour Teaching Session

---

## Project Overview

This `angular-monorepo-demo` Nx workspace demonstrates enterprise-grade monorepo architecture.
All **Block 1 concepts** (standalone migration, signal inputs, inject(), etc.) are **already applied** — the codebase represents the "after" state.

**Tech stack:** Nx 20.3.0 · Angular 19 · TypeScript 5.6 · Jest · ESLint · Storybook 8.4 · Compodoc

---

## Session Schedule (2 Hours)

| Time       | Topic                                              | Duration |
|------------|-----------------------------------------------------|----------|
| 0:00–0:30  | **Topic 1:** Monorepo patterns with Nx              | 30 min   |
| 0:30–1:00  | **Topic 2:** Component library design                | 30 min   |
| 1:00–1:30  | **Topic 3:** Versioning and changelog management     | 30 min   |
| 1:30–1:45  | **Topic 4:** Documentation with Compodoc & Storybook | 15 min   |
| 1:45–2:00  | **Topic 5:** Third-party dependency management       | 15 min   |

---

## Topic 1: Monorepo Patterns with Nx (30 min)

### Learning Objectives
- Understand Nx workspace structure (apps/ vs libs/)
- Learn library categorization patterns (ui, data-access, util)
- Understand module boundary enforcement with ESLint rules
- Use Nx commands: build, affected, graph

### 1.1 Workspace Structure (10 min)

**Open these files to explain the workspace layout:**

```
angular-monorepo-demo/
├── apps/
│   └── demo-app/              ← Deployable application
├── libs/
│   └── shared/
│       ├── ui/                ← UI components (no business logic)
│       ├── data-access/       ← Services, models, tokens
│       └── util/              ← Framework-agnostic helpers
├── nx.json                    ← Nx configuration
├── tsconfig.base.json         ← Path aliases
└── eslint.config.cjs          ← Module boundary rules
```

**Key files to show:**

1. **`tsconfig.base.json`** — Show the path mappings:
   ```
   @angular-monorepo-demo/shared-ui    → libs/shared/ui/src/index.ts
   @angular-monorepo-demo/data-access  → libs/shared/data-access/src/index.ts
   @angular-monorepo-demo/util         → libs/shared/util/src/index.ts
   ```

2. **`nx.json`** — Explain `namedInputs`, `targetDefaults`, and caching:
   - `production` input excludes test files from build cache
   - `dependsOn: ["^build"]` ensures libs build before apps

3. **Each `project.json`** — Show tags:
   - `apps/demo-app/project.json` → `["scope:app", "type:app"]`
   - `libs/shared/ui/project.json` → `["scope:shared", "type:ui"]`
   - `libs/shared/data-access/project.json` → `["scope:shared", "type:data-access"]`
   - `libs/shared/util/project.json` → `["scope:shared", "type:util"]`

### 1.2 Library Categorization Pattern (10 min)

**Explain the three library types and their rules:**

| Library Type   | Purpose                      | Can Import              | Cannot Import         |
|---------------|------------------------------|-------------------------|----------------------|
| `type:ui`     | Presentational components     | `type:util`             | `type:data-access`   |
| `type:data-access` | Services, models, tokens | `type:util`             | `type:ui`            |
| `type:util`   | Pure helpers, adapters        | Nothing                 | Everything else       |
| `type:app`    | Deployable application        | All library types       | —                    |

**Why this matters:**
- UI components should never call HTTP services directly
- Data access logic should not render templates
- Utilities are "leaf nodes" — they depend on nothing

### 1.3 Module Boundary Enforcement (10 min)

**Open `eslint.config.cjs`** and walk through the `depConstraints`:

```javascript
depConstraints: [
  { sourceTag: 'type:app',         onlyDependOnLibsWithTags: ['type:ui', 'type:data-access', 'type:util'] },
  { sourceTag: 'type:ui',          onlyDependOnLibsWithTags: ['type:util'] },
  { sourceTag: 'type:data-access', onlyDependOnLibsWithTags: ['type:util'] },
  { sourceTag: 'type:util',        onlyDependOnLibsWithTags: [] },
]
```

**Live Demo — Break a boundary:**

1. Open `libs/shared/ui/src/lib/button/button.component.ts`
2. Add this import at the top:
   ```typescript
   import { ProductService } from '@angular-monorepo-demo/data-access';
   ```
3. Run: `npx nx lint shared-ui`
4. Show the ESLint error: *"A project tagged with 'type:ui' can only depend on libs tagged with 'type:util'"*
5. Remove the import — boundary restored!

**Live Demo — Dependency graph:**

```bash
npx nx graph
```

This opens a browser showing the visual dependency graph. Point out:
- demo-app depends on all 3 libraries
- shared-ui and data-access are independent siblings
- util has no outgoing dependencies

---

## Topic 2: Component Library Design (30 min)

### Learning Objectives
- Design component public APIs with signal inputs
- Use content projection (ng-content) with named slots
- Expose clean barrel exports via index.ts
- Type-safe component interfaces with TypeScript

### 2.1 Public API Design — The index.ts Barrel (10 min)

**Open `libs/shared/ui/src/index.ts`:**

Key principles to discuss:
1. **Only export what consumers need** — components, types, interfaces
2. **Group exports by feature** — Button, Badge, Card, DataTable, Layout
3. **Export types with `type` keyword** — `type ButtonVariant`, `type TableColumn`
4. **Internal helpers stay private** — if it's not in index.ts, it's not accessible

**Discuss: What happens if you don't control the public API?**
- Consumers import internal files → breaking changes on every refactor
- No clear contract between library and consumers
- Harder to version and document

### 2.2 Signal-Based Component Inputs (10 min)

**Open `libs/shared/ui/src/lib/button/button.component.ts`:**

```typescript
export class UiButtonComponent {
  variant = input<ButtonVariant>('primary');   // typed signal input with default
  size = input<ButtonSize>('md');              // constrained union type
  disabled = input<boolean>(false);            // primitive input
  clicked = output<void>();                    // typed output
}
```

**Key teaching points:**
- `input<T>()` replaces `@Input()` — signal-based, type-safe
- `output<T>()` replaces `@Output()` — cleaner API
- Union types (`ButtonVariant`) constrain allowed values
- Defaults are set in the function call, not in the decorator

**Compare with old style** (for reference — not in this codebase):
```typescript
// OLD: @Input() variant: string = 'primary';
// NEW: variant = input<ButtonVariant>('primary');
```

### 2.3 Content Projection Patterns (5 min)

**Open `libs/shared/ui/src/lib/card/card.component.ts`:**

```html
<div class="ui-card">
  @if (title()) {
    <div class="ui-card__header">
      <h3>{{ title() }}</h3>
      <ng-content select="[card-actions]" />     <!-- Named slot -->
    </div>
  }
  <div class="ui-card__body">
    <ng-content />                                <!-- Default slot -->
  </div>
  <div class="ui-card__footer">
    <ng-content select="[card-footer]" />          <!-- Named slot -->
  </div>
</div>
```

**Discuss patterns:**
- Default `<ng-content />` for main body content
- Named slots via `select="[card-actions]"` for structured composition
- Conditional rendering with `@if` — header only shown when title is set

### 2.4 Generic Data Components (5 min)

**Open `libs/shared/ui/src/lib/data-table/data-table.component.ts`:**

```typescript
export interface TableColumn<T = unknown> {
  key: string;
  header: string;
  sortable?: boolean;
  width?: string;
  transform?: (value: unknown, row: T) => string;   // Custom cell rendering
}
```

**Key points:**
- Column definitions are data-driven, not template-driven
- `transform` function allows custom formatting without template changes
- The table doesn't know about Products or Customers — it's generic
- Consumers pass `data` and `columns` — the table handles rendering

**Show usage in `apps/demo-app/src/app/features/products/components/product-list.component.ts`:**
- Product-specific columns with `formatCurrency` transform from `@angular-monorepo-demo/util`
- The UI library uses the util library (valid per boundary rules)

---

## Topic 3: Versioning and Changelog Management (30 min)

### Learning Objectives
- Understand semantic versioning for libraries
- Use conventional commits for automated changelogs
- Configure standard-version for release automation
- Manage per-library versions in a monorepo

### 3.1 Semantic Versioning (10 min)

**Open `libs/shared/ui/package.json`:**

```json
{
  "name": "@angular-monorepo-demo/shared-ui",
  "version": "1.0.0",
  "peerDependencies": {
    "@angular/common": ">=19.0.0",
    "@angular/core": ">=19.0.0"
  }
}
```

**Explain semver rules:**
- **MAJOR (2.0.0):** Breaking API changes (renamed input, removed component)
- **MINOR (1.1.0):** New features, backward-compatible (added component)
- **PATCH (1.0.1):** Bug fixes, no API change

**Discuss peerDependencies:**
- UI library declares `@angular/core` as a peer — it doesn't bundle Angular
- Consumers must provide compatible Angular version
- `>=19.0.0` means "any Angular 19+" will work

**Exercise brainstorm (5 min):**
Ask students: *"Which version bump would each of these require?"*
- Adding a new `outline` variant to UiButtonComponent → **Minor**
- Renaming `clicked` output to `buttonClick` → **Major**
- Fixing badge padding calculation → **Patch**
- Removing `UiLayoutComponent` from the public API → **Major**

### 3.2 Conventional Commits (10 min)

**Open `commitlint.config.js`:**

```
Format: type(scope): subject

Examples:
  feat(shared-ui): add dropdown component
  fix(data-access): handle null response in ProductService
  docs(util): update adapter pattern documentation
  refactor(demo-app): extract dashboard widgets
  BREAKING CHANGE: renamed UiButton variant prop to buttonVariant
```

**Show the configured scopes:**
```javascript
'scope-enum': [2, 'always', [
  'shared-ui', 'data-access', 'util', 'demo-app', 'workspace', 'ci', 'release'
]]
```

**Why conventional commits?**
- Automated changelog generation from git history
- Automated version bumps based on commit types
- Consistent team communication about changes
- `feat` → minor bump, `fix` → patch bump, `BREAKING CHANGE` → major bump

### 3.3 Standard-Version Configuration (10 min)

**Open `.versionrc.json`:**

Key configuration points:
1. **`types`** — Maps commit types to changelog sections:
   - `feat` → "Features", `fix` → "Bug Fixes", `perf` → "Performance"
   - `chore`, `test`, `style`, `build`, `ci` are hidden from changelog
2. **`bumpFiles`** — Bumps version in all library package.json files simultaneously
3. **`releaseCommitMessageFormat`** — Creates a standardized release commit

**Show the generated `CHANGELOG.md`:**

**Demonstrate the release workflow:**
```bash
# Dry run to see what would happen
npm run release:dry-run

# Actual release (bumps version, updates CHANGELOG, creates git tag)
npm run release

# Specific version bumps
npm run release:minor
npm run release:major
npm run release:patch
```

**Available npm scripts** (from `package.json`):
```json
"release": "standard-version",
"release:minor": "standard-version --release-as minor",
"release:major": "standard-version --release-as major",
"release:patch": "standard-version --release-as patch",
"release:dry-run": "standard-version --dry-run"
```

---

## Topic 4: Documentation with Compodoc & Storybook (15 min)

### Learning Objectives
- Generate API documentation from code comments
- Create interactive component playgrounds with Storybook
- Understand the complementary nature of the two tools

### 4.1 Compodoc — API Documentation (7 min)

**Configuration: `tsconfig.doc.json`**

Compodoc reads TypeScript source and JSDoc comments to generate HTML documentation.

**Run Compodoc:**
```bash
# Generate static docs
npm run docs

# Serve with live reload
npm run docs:serve
```

This generates documentation at `docs/` including:
- Component list with inputs/outputs
- Service API reference
- Interface/model definitions
- Dependency injection tokens
- Module hierarchy visualization

**Show how JSDoc comments drive documentation:**

Open `libs/shared/ui/src/lib/button/button.component.ts`:
```typescript
/**
 * UiButtonComponent — Standalone reusable button.
 *
 * PUBLIC API DESIGN:
 * - Uses Angular signal inputs (input()) for type-safe props
 * - Exposes typed variants and sizes
 * - Part of @angular-monorepo-demo/shared-ui public API
 */
```

**Best practice:** Every exported component, service, and interface should have JSDoc comments.

### 4.2 Storybook — Component Playground (8 min)

**Configuration:** `.storybook/main.ts`, `.storybook/preview.ts`

**Run Storybook:**
```bash
npm run storybook          # Dev server on port 6006
npm run storybook:build    # Static build to dist/storybook
```

**Open a story file — `libs/shared/ui/src/lib/button/button.stories.ts`:**

```typescript
const meta: Meta<UiButtonComponent> = {
  title: 'Shared UI/Button',
  component: UiButtonComponent,
  tags: ['autodocs'],           // Auto-generates docs page
  argTypes: {
    variant: {
      control: 'select',       // Dropdown in Storybook controls panel
      options: ['primary', 'secondary', 'danger', 'ghost'],
    },
  },
};
```

**Story structure:**
- Each export is a named story variant (Primary, Secondary, Danger, etc.)
- `tags: ['autodocs']` auto-generates a documentation page from the component
- `argTypes` creates interactive controls for props
- The `AllVariants` story shows all options at once for comparison

**Stories available in this project:**
| Component    | Stories                                          |
|-------------|--------------------------------------------------|
| Button      | Primary, Secondary, Danger, Ghost, Small, Large, Disabled, AllVariants |
| Badge       | Success, Warning, Danger, Info, Neutral, AllVariants |
| Card        | Default, Elevated, WithActions, NoTitle, CardGrid |
| DataTable   | Default, Empty, SimpleColumns                     |

**Compodoc vs Storybook — when to use which:**

| Concern              | Compodoc          | Storybook                |
|---------------------|-------------------|--------------------------|
| API reference       | ✅ Generated       | ❌ Manual stories         |
| Visual playground   | ❌ Static docs     | ✅ Interactive            |
| Non-devs can use    | ✅ Browse docs     | ✅ Play with components   |
| Design system       | Partial            | ✅ Full catalog           |
| Testing integration | ❌                 | ✅ Interaction tests      |

---

## Topic 5: Third-Party Dependency Management (15 min)

### Learning Objectives
- Isolate third-party dependencies behind adapters and wrappers
- Enable swapping implementations without impacting consumers
- Understand the Adapter and Wrapper patterns

### 5.1 The Adapter Pattern (7 min)

**Open `libs/shared/util/src/lib/adapters/date.adapter.ts`:**

```typescript
export class DateAdapter {
  format(date: Date, pattern: string): string { ... }
  parse(dateString: string): Date { ... }
  isValid(date: Date): boolean { ... }
  addDays(date: Date, days: number): Date { ... }
}
```

**Key insight:** The app calls `DateAdapter.format()`, not `dateFns.format()`.

**Why this matters:**
- If you need to swap `date-fns` for `luxon` or `dayjs`, change ONE file
- All consumers continue calling the same `DateAdapter` methods
- No scattered imports of the third-party library across the codebase

**Show `StorageAdapter` — `libs/shared/util/src/lib/adapters/storage.adapter.ts`:**
- Wraps `localStorage` / `sessionStorage`
- Adds typed `get<T>()` / `set<T>()` methods
- Factory functions: `createLocalStorageAdapter()`, `createSessionStorageAdapter()`
- Uses an `InjectionToken` for dependency injection

### 5.2 The Wrapper Pattern (5 min)

**Open `libs/shared/util/src/lib/wrappers/http.wrapper.ts`:**

```typescript
export class HttpWrapper {
  async get<T>(url: string): Promise<HttpResponse<T>> { ... }
  async post<T>(url: string, body: unknown): Promise<HttpResponse<T>> { ... }
}
```

**Adapter vs Wrapper — subtle difference:**
- **Adapter:** Changes the interface (makes a third-party API match YOUR API)
- **Wrapper:** Adds behavior around an existing interface (logging, error handling, caching)

**Discussion prompt:** *"Would you use an adapter for Angular's HttpClient? Why or why not?"*
- HttpClient is framework-provided and unlikely to change
- But an adapter makes sense for testing (mock the adapter, not HttpClient)
- Also useful for progressive migration or isomorphic code

### 5.3 Where Each Pattern Lives in the Architecture (3 min)

```
┌──────────────────────────────────────────────────┐
│  apps/demo-app         (type:app)                │
│    imports from shared libraries only             │
├──────────────────────────────────────────────────┤
│  libs/shared/ui        (type:ui)                 │
│    UiButtonComponent, UiCardComponent, etc.       │
│    → imports from util only                       │
├──────────────────────────────────────────────────┤
│  libs/shared/data-access (type:data-access)      │
│    ProductService, CustomerService, etc.          │
│    → imports from util only                       │
├──────────────────────────────────────────────────┤
│  libs/shared/util      (type:util)               │
│    DateAdapter, StorageAdapter, HttpWrapper        │
│    formatCurrency, generateId, deepClone          │
│    → imports NOTHING (leaf node)                  │
│    → wraps ALL third-party libs here              │
└──────────────────────────────────────────────────┘
```

**Rule:** Third-party dependencies should be wrapped/adapted in the `util` library.
This means only ONE library needs updating when a dependency changes.

---

## Quick-Reference: All npm Scripts

```bash
# Development
npx nx serve demo-app          # Start dev server
npx nx build demo-app          # Production build
npx nx graph                   # Visual dependency graph

# Quality
npx nx lint shared-ui          # Lint one library
npm run lint                   # Lint all projects
npm run test                   # Test all projects

# Affected (CI-optimized)
npm run build:affected         # Build only changed projects
npm run test:affected          # Test only changed projects
npm run lint:affected          # Lint only changed projects

# Documentation
npm run docs                   # Generate Compodoc HTML
npm run docs:serve             # Compodoc with live reload

# Storybook
npm run storybook              # Dev server on :6006
npm run storybook:build        # Static build

# Versioning
npm run release:dry-run        # Preview release
npm run release                # Auto bump + changelog + tag
npm run release:minor          # Force minor bump
npm run release:major          # Force major bump
npm run release:patch          # Force patch bump
```

---

## Project File Reference

### Workspace Configuration
| File                  | Purpose                                    |
|----------------------|---------------------------------------------|
| `nx.json`            | Nx workspace config, caching, target defaults |
| `tsconfig.base.json` | TypeScript paths for library imports         |
| `eslint.config.cjs`  | Module boundary rules and linting            |
| `package.json`       | Dependencies, npm scripts                    |
| `commitlint.config.js` | Conventional commit format rules           |
| `.versionrc.json`    | Standard-version release config              |
| `tsconfig.doc.json`  | Compodoc TypeScript config                   |

### Shared UI Library (`libs/shared/ui/`)
| File                                    | What It Demonstrates                        |
|----------------------------------------|----------------------------------------------|
| `src/index.ts`                         | Public API barrel, export design             |
| `src/lib/button/button.component.ts`   | Signal inputs, typed variants, output()      |
| `src/lib/button/button.stories.ts`     | Storybook: controls, variants, autodocs      |
| `src/lib/badge/badge.component.ts`     | Minimal public API surface                   |
| `src/lib/card/card.component.ts`       | Content projection, named slots, @if         |
| `src/lib/data-table/data-table.component.ts` | Generic component, TableColumn interface |
| `src/lib/layout/layout.component.ts`   | App shell with content projection            |
| `package.json`                          | Library versioning, peerDependencies         |
| `project.json`                          | Nx tags: scope:shared, type:ui               |

### Data Access Library (`libs/shared/data-access/`)
| File                                   | What It Demonstrates                         |
|---------------------------------------|-----------------------------------------------|
| `src/index.ts`                        | Service and model exports                     |
| `src/lib/models/index.ts`            | Product, Customer, User interfaces            |
| `src/lib/tokens/index.ts`            | InjectionTokens with defaults (APP_CONFIG)    |
| `src/lib/services/product.service.ts` | providedIn: 'root', signal-based state        |
| `src/lib/services/logger.service.ts`  | Configurable service via InjectionToken       |
| `package.json`                         | Library versioning with rxjs peer dep         |

### Util Library (`libs/shared/util/`)
| File                                    | What It Demonstrates                        |
|----------------------------------------|----------------------------------------------|
| `src/index.ts`                         | Adapter/wrapper/helper exports               |
| `src/lib/adapters/date.adapter.ts`    | Adapter pattern — isolate date library       |
| `src/lib/adapters/storage.adapter.ts`  | Adapter pattern — typed storage abstraction  |
| `src/lib/wrappers/http.wrapper.ts`    | Wrapper pattern — fetch with error handling  |
| `src/lib/helpers/index.ts`            | Pure utility functions                        |

### Demo Application (`apps/demo-app/`)
| File                                            | What It Demonstrates                    |
|------------------------------------------------|------------------------------------------|
| `src/app/app.config.ts`                        | Provider configuration with tokens       |
| `src/app/app.routes.ts`                        | Lazy-loaded standalone routes            |
| `src/app/features/dashboard/dashboard.component.ts` | Cross-library imports (ui + data-access) |
| `src/app/features/products/components/product-list.component.ts` | DataTable + formatCurrency usage |
| `src/app/features/settings/settings.service.ts` | Route-level providers pattern           |

---

## Workshop Exercises (Optional)

### Exercise 1: Add a New UI Component (15 min)
**Goal:** Students create a `UiAlertComponent` in the shared-ui library.

1. Create `libs/shared/ui/src/lib/alert/alert.component.ts`
2. Add signal inputs: `type` (success/warning/error/info), `dismissible` (boolean)
3. Add `dismissed` output
4. Export from `libs/shared/ui/src/index.ts`
5. Use it in the dashboard component
6. Create a Storybook story

### Exercise 2: Break a Module Boundary (5 min)
**Goal:** Understand boundary enforcement hands-on.

1. In `libs/shared/ui/src/lib/button/button.component.ts`, add:
   ```typescript
   import { ProductService } from '@angular-monorepo-demo/data-access';
   ```
2. Run `npx nx lint shared-ui` — observe the error
3. Discuss: *Why is this import not allowed? What's the correct architecture?*
4. Remove the import

### Exercise 3: Simulate a Release (10 min)
**Goal:** Practice the release workflow.

1. Make a change and create a conventional commit:
   ```bash
   git add .
   git commit -m "feat(shared-ui): add alert component"
   ```
2. Run `npm run release:dry-run` to preview
3. Look at the CHANGELOG.md to see the generated entry
4. Discuss: *What version would this be?* (Answer: 1.1.0 — minor, because `feat`)

---

## Key Concepts Cheat Sheet

| Term                     | Definition                                                        |
|--------------------------|-------------------------------------------------------------------|
| **Monorepo**             | Single repository containing multiple projects (apps + libs)      |
| **Library boundary**     | ESLint rule preventing unauthorized cross-library imports          |
| **Barrel export**        | index.ts file that defines a library's public API                 |
| **Signal input**         | `input<T>()` — type-safe reactive component property               |
| **Content projection**   | `<ng-content>` — inserting external content into a component       |
| **Conventional commit**  | Standardized commit format: `type(scope): subject`                 |
| **Semantic versioning**  | MAJOR.MINOR.PATCH version scheme based on change type              |
| **Adapter pattern**      | Abstraction that translates a third-party API to your own          |
| **Wrapper pattern**      | Abstraction that adds behavior around an existing API              |
| **Affected command**     | Nx command that only runs tasks for changed projects               |

---

## Troubleshooting

| Issue                              | Solution                                           |
|-----------------------------------|----------------------------------------------------|
| `nx graph` won't open browser     | Run on port: `npx nx graph --port=4211`            |
| ESLint boundary errors            | Check project.json tags match depConstraints        |
| Storybook build fails             | Ensure `.storybook/tsconfig.json` includes stories  |
| Compodoc empty output             | Check `tsconfig.doc.json` include paths             |
| `npm run release` fails           | Initialize git first: `git init && git add -A && git commit -m "chore: initial commit"` |
