import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProductService, UserService, APP_CONFIG } from '@angular-monorepo-demo/data-access';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';
import { Product, User } from '@angular-monorepo-demo/data-access';

@Component({
  selector: 'app-dashboard',
  imports: [RouterLink, UiCardComponent, UiBadgeComponent],
  template: `
    <div class="dashboard">
      <h2>Dashboard <ui-badge variant="info">Monorepo App</ui-badge></h2>
      <p class="note">
        ✅ This app uses <strong>standalone architecture</strong> (Block 1 complete)
        and consumes components from <code>&#64;angular-monorepo-demo/shared-ui</code>.
      </p>

      <div class="stats-grid">
        <ui-card title="Products" [elevated]="true">
          <div class="stat-number">{{ totalProducts() }}</div>
          <a routerLink="/products" card-footer>View All →</a>
        </ui-card>
        <ui-card title="In Stock" [elevated]="true">
          <div class="stat-number">{{ inStockCount() }}</div>
        </ui-card>
        <ui-card title="Users" [elevated]="true">
          <div class="stat-number">{{ totalUsers() }}</div>
          <a routerLink="/users" card-footer>View All →</a>
        </ui-card>
        <ui-card title="Config" [elevated]="true">
          <div class="stat-number">{{ appConfig.maxItemsPerPage }}</div>
          <span card-footer>Items/Page</span>
        </ui-card>
      </div>

      <ui-card title="Monorepo Library Architecture" [elevated]="true">
        <div class="arch-grid">
          <div class="arch-card">
            <h4>📦 shared/ui</h4>
            <p>Button, Badge, Card, DataTable, Layout</p>
            <ui-badge variant="success">Standalone Components</ui-badge>
          </div>
          <div class="arch-card">
            <h4>📊 shared/data-access</h4>
            <p>Models, Services, InjectionTokens</p>
            <ui-badge variant="info">Tree-shakable Services</ui-badge>
          </div>
          <div class="arch-card">
            <h4>🔧 shared/util</h4>
            <p>DateAdapter, StorageAdapter, HttpWrapper</p>
            <ui-badge variant="warning">Third-Party Isolation</ui-badge>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .dashboard { padding: 0.5rem; }
    .note { background: #d4edda; border: 1px solid #c3e6cb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8f5e9; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin: 1.5rem 0; }
    .stat-number { font-size: 2.5rem; font-weight: 700; color: #2c3e50; text-align: center; }
    .arch-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; }
    .arch-card { padding: 1rem; background: #f8f9fa; border-radius: 8px; }
    .arch-card h4 { margin: 0 0 0.5rem 0; }
    .arch-card p { margin: 0.3rem 0; font-size: 0.85rem; color: #666; }
  `]
})
export class DashboardComponent implements OnInit {
  private productService = inject(ProductService);
  private userService = inject(UserService);
  protected appConfig = inject(APP_CONFIG);

  products = signal<Product[]>([]);
  users = signal<User[]>([]);
  totalProducts = computed(() => this.products().length);
  inStockCount = computed(() => this.products().filter(p => p.inStock).length);
  totalUsers = computed(() => this.users().length);

  ngOnInit(): void {
    this.productService.getProducts().subscribe(p => this.products.set(p));
    this.userService.getUsers().subscribe(u => this.users.set(u));
  }
}
