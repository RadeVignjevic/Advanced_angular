# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-01-01

### Features

- **shared-ui:** add UiButtonComponent with variant/size/disabled signal inputs
- **shared-ui:** add UiBadgeComponent with variant signal input
- **shared-ui:** add UiCardComponent with content projection slots
- **shared-ui:** add UiDataTableComponent with generic column configuration
- **shared-ui:** add UiLayoutComponent with sidebar content projection
- **data-access:** add Product, Customer, User models
- **data-access:** add APP_CONFIG and LOGGER_CONFIG injection tokens
- **data-access:** add ProductService, CustomerService, UserService
- **data-access:** add LoggerService with configurable log levels
- **util:** add DateAdapter for date formatting abstraction
- **util:** add StorageAdapter for typed localStorage/sessionStorage access
- **util:** add HttpWrapper for fetch API abstraction
- **util:** add formatCurrency, generateId, deepClone, debounce helpers
- **demo-app:** add dashboard with summary cards
- **demo-app:** add product list with data table
- **demo-app:** add customer list with status badges
- **demo-app:** add user management with cards
- **demo-app:** add settings with route-level providers
- **workspace:** configure Nx module boundary rules
