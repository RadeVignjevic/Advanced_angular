# Block 5 — State Management with NgRx Signal Store

## Instructor Guide — "For Dummies" Edition

> **Total time:** 2 hours 30 minutes | **Demo project:** `angular-ngrx-signal-store-demo` | **Angular 19 + NgRx Signals**

---

## Schedule Overview

| # | Topic | Route | Duration | Type |
|---|-------|-------|----------|------|
| 1 | State Management Patterns | `/state-overview` | 20 min | Lecture + visuals |
| 2 | NgRx Signal Store Core API | `/signal-store-api` | 40 min | Code + live demo |
| 3 | Signal Store Design Patterns | `/store-patterns` | 30 min | Code + live demo |
| 4 | Debugging & Observability | `/store-debugging` | 20 min | Code + live demo |
| 5 | Workshop: CRUD Feature Store | `/store-workshop` | 40 min | Guided workshop |

---

## Before-Class Setup

### 1. Install & Build (do this 30 min before class)

```bash
cd angular-ngrx-signal-store-demo
npm install
npx nx serve demo-app
```

### 2. Check Every Route

Open `http://localhost:4200` and click through each route in this order:

1. `/state-overview` — static cards, no interactivity to verify
2. `/signal-store-api` — click Increment 3×, type a todo, toggle a filter
3. `/store-patterns` — type in Search, click In Stock Only, click Add Product
4. `/store-debugging` — open DevTools Console, click "Log Snapshot", click "Add" with a new item
5. `/store-workshop` — wait for products to load, try Search, Edit, Delete, Create

### 3. Prepare Your Environment

- **Browser:** Chrome with DevTools docked to the right
- **Console tab** open (you'll need it for Topics 2 and 4)
- **Editor:** Have `signal-store-api.component.ts` open as a reference
- **Whiteboard or draw.io:** Ready for diagrams
- **Font size:** At least 18px in both editor and browser

### 4. Files You'll Reference

| File | What's in it |
|------|-------------|
| `features/state-overview/state-overview.component.ts` | All overview slides |
| `features/signal-store-api/signal-store-api.component.ts` | Counter + Todo stores |
| `features/store-patterns/store-patterns.component.ts` | Filter, Entity, Custom Feature stores |
| `features/store-debugging/store-debugging.component.ts` | withDevtools + DebugDemoStore |
| `features/store-workshop/store-workshop.component.ts` | Full CRUD store with rxMethod |

---

## Opening Talk (3 min)

> "Before we dive in, let me paint a picture. Imagine you're running a **restaurant**. When it's just you and two cooks, you keep track of everything in your head — what's in the fridge, what's on order, what table needs what. That's like a small Angular app with a few signals and services."
>
> "Now imagine the restaurant grows. You've got 20 cooks, a bar, a pastry section, three floors. Suddenly 'keeping it in your head' doesn't work. You need an **inventory system** — a single source of truth that everyone reads from and writes to through a defined process. That's what state management is."
>
> "Today we're going to build that inventory system for Angular apps using **NgRx Signal Store**. It's the newest, cleanest way to do it, and it's built entirely on top of Angular Signals — the same signals we already know."

---

## Topic 1 — State Management Patterns (20 min)

**Route:** Navigate to `http://localhost:4200/state-overview`

### Section 1: Why Formalised State Management?

**What to say:**

> "Look at these two columns on screen. The left side is what happens in apps without structure — state is sprinkled across dozens of components, you pass data down five levels of `@Input()`, and when a bug shows up you have no idea which component changed what."
>
> "The right side is what happens with a state management system — one place to look, predictable updates, easy debugging. That's where we're headed."

**Point at each bullet on screen** as you read it. Let students absorb the contrast.

### Section 2: Categories of State

**What to say:**

> "Not all state is created equal. There are three buckets."

**Whiteboard diagram:**

```
┌──────────────────────────────────────────────────────┐
│                   STATE CATEGORIES                    │
├──────────────┬──────────────────┬─────────────────────┤
│  COMPONENT   │    SHARED        │     GLOBAL          │
│  (local)     │  (feature)       │   (app-wide)        │
├──────────────┼──────────────────┼─────────────────────┤
│ signal()     │ Service+signal() │ Signal Store         │
│ form toggle  │ filter bar       │ auth, user prefs     │
│ counter      │ selected item    │ entity collections   │
│ modal open   │ sort order       │ feature flags        │
└──────────────┴──────────────────┴─────────────────────┘
```

> "Component state — it lives and dies with one component. A local counter, a toggle, a form field. Just use `signal()`. Done."
>
> "Shared state — two or three sibling components need the same data. A service with a signal works fine here. Maybe a parent passes it down."
>
> "Global state — the whole app cares about it. Auth tokens, user preferences, your product catalogue. This is where Signal Store shines."

**Point at the three cards on screen.** Each one has a code snippet showing the appropriate tool.

### Section 3: Evolution of Angular State Management

> "Let me give you the history in 30 seconds."

**Point at the timeline on screen:**

> "Step 1: Services with `BehaviorSubject`. Works, but gets messy at scale."
>
> "Step 2: NgRx Store — the full Redux pattern. Actions, reducers, effects, selectors. Very powerful, very verbose. Hundreds of lines for a simple CRUD."
>
> "Step 3: NgRx Component Store. Lighter, component-scoped. Better, but still RxJS-centric."
>
> "Step 4: **NgRx Signal Store**. Signal-based, functional API, composable features. This is the modern recommended approach, and it's what we're learning today."

### Section 4: When to Use What?

> "This decision table is your cheat sheet. Screenshot it."

**Point at the decision table.** Read each row aloud:

> "Local UI state? Just `signal()`. Shared filter between siblings? Service with a signal. Feature with CRUD and loading states? Signal Store. Entity collections? Signal Store with `withEntities`. Complex cross-feature workflows with time-travel debugging? That's still full NgRx Store with Redux."

### Section 5: NgRx Signal Store at a Glance

> "Here's the preview of what we'll learn over the next two hours. These are the building blocks."

**Point at each pill on screen** as you name it:

> "`signalStore()` creates the store. `withState()` defines the shape. `withComputed()` adds derived state. `withMethods()` adds actions. `withHooks()` adds lifecycle. `withEntities()` adds entity management. `patchState()` is how you update state."
>
> "Every single one of these is a **function you compose together**. No classes, no decorators, no boilerplate. Let's see how."

### Student Checkpoint — Topic 1

1. **Q:** "If you have a form toggle that only one component cares about, what do you use?"
   **A:** `signal()` — it's component-local state.

2. **Q:** "Your product list and product filter sidebar need to share a search term. Service + signal, or Signal Store?"
   **A:** Either works. Service + signal is fine for 2-3 components. Signal Store if the feature is growing.

3. **Q:** "Name one advantage of Signal Store over the full Redux NgRx Store."
   **A:** Far less boilerplate — no separate action files, reducer files, or effect files.

---

## Topic 2 — NgRx Signal Store Core API (40 min)

**Route:** Navigate to `http://localhost:4200/signal-store-api`

### Opening

> "Alright, let's build stores. Everything on this page is **live** — the counter and todo list are powered by real Signal Stores defined right in the component file."

### Section 1: signalStore() + withState()

**What to say:**

> "Creating a store is one function call. Watch."

**Show the code on screen (Section 1 card):**

```typescript
import { signalStore, withState } from '@ngrx/signals';

export const CounterStore = signalStore(
  withState({
    count: 0,
    label: 'My Counter',
  })
);
// Each state property becomes a signal:
// store.count()  -> Signal<number>
// store.label()  -> Signal<string>
```

> "That's it. `signalStore()` returns an **injectable service**. `withState()` defines the initial state shape. Every property in that object automatically becomes a signal. So `store.count()` returns a `Signal<number>`, just like `signal(0)` would — except it's managed by the store."

**Whiteboard diagram:**

```
signalStore(                  ← creates injectable service
  withState({                 ← defines initial state
    count: 0,                 → store.count()  : Signal<number>
    label: 'Demo Counter'     → store.label()  : Signal<string>
  })
)
```

### Section 2: withComputed() — Derived State

**What to say:**

> "Now let's derive values from state. This is `withComputed()`."

**Show the code on screen (Section 2 card):**

```typescript
withComputed(({ count }) => ({
  doubled: computed(() => count() * 2),
  isPositive: computed(() => count() > 0),
}))
// Access: store.doubled(), store.isPositive()
```

> "The function receives the store's signals — here we destructure `count`. We return an object of `computed()` signals. They memorise their result and only re-evaluate when `count()` changes."

**Live Demo — Click these buttons while talking:**

1. **Click "Increment" 3 times.** Point at count (3), doubled (6), isPositive (true).

   > "See that? Count is 3, doubled auto-updated to 6, isPositive is true. I didn't tell it to update — it's reactive."

2. **Click "Reset".** Point at count (0), doubled (0), isPositive (false).

   > "Reset to zero — doubled goes to zero, isPositive flips to false. All automatic."

3. **Click "Decrement" twice.** Count goes to -2, isPositive shows false.

   > "Negative now. `isPositive` correctly shows false. These computeds are the equivalent of selectors in Redux — but with zero boilerplate."

### Section 3: withMethods() + patchState()

**What to say:**

> "Computed gives us derived values. `withMethods()` gives us **actions** — ways to change state."

**Show the code on screen (Section 3 card):**

```typescript
withMethods((store) => ({
  increment() {
    patchState(store, { count: store.count() + 1 });
  },
  setLabel(label: string) {
    patchState(store, { label });
  },
}))
```

> "`withMethods()` receives the entire store. Each method calls `patchState()` to update state. `patchState` does an **immutable merge** — it creates a brand new state object. You never mutate directly."

**Live Demo:**

1. **Click 'setLabel("Updated!")' button.** Point at label changing.

   > "The label switched. That's `patchState(store, { label: 'Updated!' })` under the hood."

2. **Click 'Reset Label' button.** Label resets to 'Demo Counter'.

### Section 4: withHooks() — Lifecycle

**What to say:**

> "Stores have lifecycle hooks, just like components."

**Show the code:**

```typescript
withHooks({
  onInit(store) {
    console.log('Store initialised:', getState(store));
  },
  onDestroy(store) {
    console.log('Store destroyed:', getState(store));
  }
})
```

> "`onInit` fires when the store is first created — perfect for loading initial data. `onDestroy` fires when the injector is destroyed — cleanup subscriptions here."

**Live Demo:**

1. **Open the browser Console** (Ctrl+Shift+J / Cmd+Option+J).
2. **Point at the `[DemoCounterStore] Initialised with state:` log.**

   > "See this line? That came from `onInit`. The store logged its initial state when this page loaded. If you navigate away from this page and come back, you'll see a destroy log followed by a new init log — because this store is component-scoped."

### Section 5: patchState() Patterns

**What to say:**

> "`patchState()` is more flexible than you might think. It accepts three forms."

**Show the code on screen (Section 5 card). Point at each pattern:**

> "**Partial object:** `patchState(store, { count: 5 })` — just merge in the changes."
>
> "**Updater function:** `patchState(store, state => ({ count: state.count + 1 }))` — when you need the current state to compute the next."
>
> "**Multiple updaters:** `patchState(store, setLoading(), addEntity(product))` — chain multiple operations in one call. We'll see this in the workshop."

### Section 6: Live Todo Store

**What to say:**

> "Let's see a real-world-ish store. This is a todo app backed by a Signal Store."

**Show the code (scroll up in the component file to the `DemoTodoStore`):**

```typescript
const DemoTodoStore = signalStore(
  withState({
    todos: [] as TodoItem[],
    filter: 'all' as 'all' | 'active' | 'done',
    nextId: 1,
  }),
  withComputed(({ todos, filter }) => ({
    filteredTodos: computed(() => {
      const all = todos();
      switch (filter()) {
        case 'active': return all.filter(t => !t.done);
        case 'done':   return all.filter(t => t.done);
        default:       return all;
      }
    }),
    totalCount:  computed(() => todos().length),
    doneCount:   computed(() => todos().filter(t => t.done).length),
    activeCount: computed(() => todos().filter(t => !t.done).length),
  })),
  withMethods((store) => ({
    addTodo(text: string) {
      patchState(store, {
        todos: [...store.todos(), { id: store.nextId(), text, done: false }],
        nextId: store.nextId() + 1,
      });
    },
    toggleTodo(id: number) {
      patchState(store, {
        todos: store.todos().map(t => t.id === id ? { ...t, done: !t.done } : t),
      });
    },
    removeTodo(id: number) {
      patchState(store, {
        todos: store.todos().filter(t => t.id !== id),
      });
    },
    setFilter(filter: 'all' | 'active' | 'done') {
      patchState(store, { filter });
    },
  }))
);
```

> "State: an array of todos, a filter string, and a nextId counter. Computed: filtered list plus three counts. Methods: add, toggle, remove, set filter. That's a complete feature store in about 40 lines."

**Live Demo — walk through each action:**

1. **Type "Buy groceries" in the input and press Enter.** Point at Total: 1, Active: 1.
2. **Type "Finish Angular course" and press Enter.** Total: 2, Active: 2.
3. **Click the checkbox on "Buy groceries".** Done: 1. The text gets a strike-through.
4. **Click the "Done" filter button.** Only "Buy groceries" shows.
5. **Click "Active".** Only "Finish Angular course" shows.
6. **Click "All".** Both show again.
7. **Click the "x" button on "Buy groceries".** It's removed. Total: 1, Done: 0.

> "All state transitions go through `patchState()`. There's no direct mutation anywhere. The template just reads signals — it updates automatically."

### Student Checkpoint — Topic 2

1. **Q:** "What function creates the store service?" **A:** `signalStore()`
2. **Q:** "How do you read a state property in the template?" **A:** `store.count()` — call it like a signal.
3. **Q:** "What's the difference between `withComputed` and `withMethods`?" **A:** `withComputed` creates read-only derived signals. `withMethods` creates functions that can change state via `patchState`.
4. **Q:** "When does `onInit` fire?" **A:** When the store is first injected (created by the injector).

---

## Topic 3 — Signal Store Design Patterns (30 min)

**Route:** Navigate to `http://localhost:4200/store-patterns`

### Opening

> "The counter and todo demos were great for learning the API. Now let's see how you'd actually structure stores in a real app. Three patterns: feature stores, entity collections, and custom reusable features."

### Pattern 1: Feature Store (Component-Scoped)

**What to say:**

> "A feature store manages state for **one feature area** — a product filter, a checkout flow, a form wizard. You provide it at the component level, so each instance of the component gets its own store."

**Show the code on screen:**

```typescript
const ProductFilterStore = signalStore(
  withState<FilterState>({
    searchTerm: '',
    selectedCategory: null,
    showInStockOnly: false,
  }),
  withMethods((store) => ({
    setSearch(searchTerm: string) { patchState(store, { searchTerm }); },
    setCategory(selectedCategory: string | null) { patchState(store, { selectedCategory }); },
    toggleInStock() { patchState(store, { showInStockOnly: !store.showInStockOnly() }); },
    resetFilters() { patchState(store, { searchTerm: '', selectedCategory: null, showInStockOnly: false }); },
  }))
);
```

> "The key line is in the component decorator: `providers: [ProductFilterStore]`. That makes it **component-scoped**. When this component is destroyed, the store is destroyed. Navigate away and back — you get a fresh store."

**Live Demo:**

1. **Type "angular" in the search input.** Point at the state display: `searchTerm: "angular"`.
2. **Click "In Stock Only".** `inStockOnly: true`.
3. **Click "Reset".** All values go back to defaults.

   > "Watch the state display at the bottom — it updates in real time. That's the beauty of signals powering the store."

### Pattern 2: Entity Collections (withEntities)

**What to say:**

> "When you're managing a list of things — products, users, orders — you want `withEntities`. It gives you a normalised entity collection out of the box."

**Show the code on screen:**

```typescript
const productConfig = entityConfig({
  entity: type<Product>(),
  selectId: (product) => product.id,
});

const ProductEntityStore = signalStore(
  withEntities(productConfig),
  withComputed(({ entities }) => ({
    totalCount: computed(() => entities().length),
    inStockCount: computed(() => entities().filter(p => p.inStock).length),
    categories: computed(() => [...new Set(entities().map(p => p.category))]),
  })),
  // ...methods using setAllEntities, addEntity, removeEntity, updateEntity
);
```

> "`withEntities` gives you three things for free: `entities()` (the array), `ids()` (just the IDs), and `entityMap()` (a lookup dictionary). You manipulate them with helper functions: `setAllEntities`, `addEntity`, `removeEntity`, `updateEntity`."

**Whiteboard diagram:**

```
withEntities(productConfig)
     │
     ├── entities()    → Signal<Product[]>   (the list)
     ├── ids()         → Signal<number[]>    (just IDs)
     └── entityMap()   → Signal<Record<number, Product>>  (lookup)

Mutation helpers:
  setAllEntities(products)           → replace all
  addEntity(product)                 → add one
  removeEntity(id)                   → remove by ID
  updateEntity({ id, changes })      → partial update
```

**Live Demo:**

1. **Point at the stats bar:** Total, In Stock, Categories.
2. **Click "Toggle" on "RxJS Poster".** Its badge switches from "Out" to "In Stock". In Stock count increases.
3. **Click "Remove" on "Signal Mug".** It disappears. Total drops by 1.
4. **Click "Add Product".** A random product appears at the bottom.

   > "All of this — add, remove, toggle — is powered by entity helper functions passed to `patchState`. No manual array manipulation."

### Pattern 3: Custom Store Features (Reusable)

**What to say:**

> "This is where Signal Store gets really powerful. You can create **reusable plugins** with `signalStoreFeature()`."

**Show the code on screen:**

```typescript
function withLoadingState() {
  return signalStoreFeature(
    withState({ isLoading: false, error: null as string | null }),
    withComputed(({ isLoading, error }) => ({
      hasError: computed(() => error() !== null),
    })),
    withMethods((store) => ({
      setLoading() { patchState(store, { isLoading: true, error: null }); },
      setLoaded()  { patchState(store, { isLoading: false }); },
      setError(error: string) { patchState(store, { isLoading: false, error }); },
    }))
  );
}
```

> "This is a function that returns a `signalStoreFeature`. It adds `isLoading`, `error`, and `hasError` to **any** store you plug it into. You write it once, use it everywhere."
>
> "Imagine building a whole library of these: `withPagination()`, `withUndoRedo()`, `withLogger()`. Each one is a tested, composable building block."

### Pattern 4: Store Composition

> "The real power is stacking these features. Look at this composed store."

**Point at the composition code on screen:**

> "Line by line: base state, then entity collection, then loading state, then computed values that read from entities AND search term, then methods, then hooks. Order matters — later features can access state from earlier ones. It's like building with Lego blocks."

### Pattern 5: providedIn Options

> "Two choices for scope. Component-scoped: put it in `providers`. Root-scoped: add `{ providedIn: 'root' }` as the first argument. Component-scoped stores are destroyed with the component. Root-scoped stores live forever — use them for auth, user preferences, global settings."

### Student Checkpoint — Topic 3

1. **Q:** "How do you make a store component-scoped?" **A:** Add it to the component's `providers` array.
2. **Q:** "What does `withEntities` give you for free?" **A:** `entities()`, `ids()`, `entityMap()` signals plus helper functions for mutations.
3. **Q:** "What's the purpose of `signalStoreFeature()`?" **A:** Create reusable store plugins (loading state, pagination, etc.) that can be composed into any store.
4. **Q:** "Can a later `with*()` feature access state from an earlier one?" **A:** Yes — order matters, and later features can read from earlier state.

---

## Topic 4 — Debugging & Observability (20 min)

**Route:** Navigate to `http://localhost:4200/store-debugging`

### Opening

> "Debugging reactive state is hard. You can't just set a breakpoint and inspect a variable — state changes flow through signals. NgRx gives us two tools: `getState()` for snapshots and `watchState()` for real-time tracing."

### Section 1: getState() — Snapshots

**What to say:**

> "`getState()` gives you a **plain JavaScript object** — a snapshot of the store at this exact moment. It's not reactive, it's not a signal. It's just data. Perfect for logging, error reporting, or serialization."

**Live Demo:**

1. **Open the browser Console** (Ctrl+Shift+J).
2. **Click "Log Snapshot to Console".**
3. **Point at the console output:** You'll see `{ items: ['Alpha', 'Beta', 'Gamma'], selectedIndex: 0, lastAction: 'initialized' }`.
4. **Point at the rendered JSON** on the page — same data, formatted.

   > "Same data on screen and in the console. This is `getState(store)` — a plain object, perfect for error reporters like Sentry."

### Section 2: watchState() — Real-Time Tracing

**What to say:**

> "`watchState()` is the big one. It sets up a reactive effect that fires on **every single state change**. Think of it as `console.log` on steroids for your store."

**Show the code on screen:**

```typescript
watchState(store, (state) => {
  console.log('State changed:', state);
});
```

> "Every time any property in the store changes, this callback runs. It runs inside Angular's effect system, so it's cleaned up automatically."

### Section 3: Custom withDevtools Feature

**What to say:**

> "Rather than adding `watchState` manually to every store, wrap it in a reusable feature."

**Show the code on screen:**

```typescript
function withDevtools(storeName: string) {
  return signalStoreFeature(
    withHooks({
      onInit(store) {
        console.log(`[${storeName}] Store initialized`, getState(store));
        watchState(store, (state) => {
          console.log(`[${storeName}] State changed:`, state);
        });
      },
      onDestroy(store) {
        console.log(`[${storeName}] Store destroyed`);
      }
    })
  );
}
```

> "Now you can add `withDevtools('MyStore')` to any store and get automatic init, destroy, and change logging. In production, guard it with `isDevMode()`."

### Section 4: Live Demo — Watch the Console

**This is the most interactive section. Keep the Console open and visible.**

**Live Demo:**

1. **Point at the current state display:** Items: Alpha, Beta, Gamma. Selected: Alpha (index 0).
2. **Type "Delta" in the input and click "Add".** Watch the console — you'll see `[DebugDemoStore] 🔄 State changed: { items: ['Alpha', 'Beta', 'Gamma', 'Delta'], ... lastAction: 'added "Delta"' }`.

   > "See the console? Every action triggers a state change log with the store name in brackets. That `lastAction` field tells you exactly what happened."

3. **Click on "Beta" in the list** (it highlights). Console shows `lastAction: 'selected index 1'`.
4. **Click the × button on "Gamma".** Console shows `lastAction: 'removed index 2'`.

   > "Every single change is logged. In a real app you'd guard this with `isDevMode()` so it doesn't run in production."

### Section 5: Best Practices

**Point at the Do/Don't list on screen. Read each one:**

> "**Do:** Use `watchState` only during development — guard with `isDevMode()`."
> "**Do:** Name your stores with `withDevtools('StoreName')` so you can filter in the console."
> "**Do:** Use `getState()` in error handlers to capture state snapshots."
> "**Don't:** Leave `watchState` in production — it runs on every change and hurts performance."
> "**Don't:** Mutate state from inside `watchState` — you'll create infinite loops."

**Show the isDevMode guard code:**

```typescript
if (isDevMode()) {
  watchState(store, (state) =>
    console.log(`[${name}]`, state)
  );
}
```

### Student Checkpoint — Topic 4

1. **Q:** "What does `getState()` return?" **A:** A plain JavaScript object — a snapshot, not a signal.
2. **Q:** "What happens if you mutate state inside `watchState`?" **A:** Infinite loop — `watchState` detects the change and fires again, which triggers another change, etc.
3. **Q:** "How do you prevent `watchState` logging from running in production?" **A:** Wrap it in `if (isDevMode()) { ... }`.

---

## Topic 5 — Workshop: CRUD Feature Store (40 min)

**Route:** Navigate to `http://localhost:4200/store-workshop`

### Opening (5 min)

> "Alright, this is where it all comes together. We're building a **product management system** — full CRUD with search, filtering, inline editing, loading states, and async data fetching. This is what a real feature store looks like."

**Show the architecture code on screen and walk through it:**

```
ProductCrudStore = signalStore(
  withEntities(productConfig)         ← entity collection
  withLoadingState()                   ← reusable loading/error feature
  withState({ searchTerm, selectedCategory, editingProduct, nextId })
  withComputed({ filteredProducts, totalCount, categories, inStockCount, outOfStockCount })
  withMethods({
    loadProducts (rxMethod),           ← async via RxJS pipeline
    createProduct, updateProduct, deleteProduct, toggleStock,
    setSearch, setCategory,
    startEditing, cancelEditing, saveEditing, updateEditField
  })
  withHooks({ onInit → loadProducts() })
)
```

**Whiteboard diagram:**

```
┌──────────────────────────────────────────────────┐
│              ProductCrudStore                      │
├──────────────────────────────────────────────────┤
│ ENTITIES    │ products[] (withEntities)            │
│ LOADING     │ isLoading, error (withLoadingState)  │
│ UI STATE    │ searchTerm, selectedCategory,        │
│             │ editingProduct, nextId               │
├──────────────────────────────────────────────────┤
│ COMPUTED    │ filteredProducts, totalCount,         │
│             │ categories, inStockCount,             │
│             │ outOfStockCount                       │
├──────────────────────────────────────────────────┤
│ METHODS     │ loadProducts (rxMethod → HTTP)        │
│             │ CRUD: create, update, delete           │
│             │ Filters: setSearch, setCategory         │
│             │ Editing: start, cancel, save, updateField│
├──────────────────────────────────────────────────┤
│ HOOKS       │ onInit → loadProducts()                │
└──────────────────────────────────────────────────┘
```

### Guided Walkthrough (15 min)

#### Step 1: Observe the Dashboard

> "When this page loaded, `onInit` fired and called `loadProducts()`. That triggered an `rxMethod` which called `ProductService.getProducts()` — an Observable that returned product data. The store set loading state, loaded the entities, then cleared loading state."

**Point at the stats bar:** Total, In Stock, Out of Stock, Showing.

#### Step 2: Search & Filter

1. **Type "angular" in the search box.** The "Showing" count drops — only matching products appear.

   > "That's `filteredProducts` computed signal at work. It reads `searchTerm()` and `entities()` and filters reactively."

2. **Pick a category from the dropdown.** The list filters further.
3. **Clear the search.** Full list returns.

#### Step 3: Inline Editing

1. **Click "Edit" on any product.** The row switches to edit mode with input fields.

   > "That's `startEditing(product)` — it copies the product into `editingProduct` state. The template checks `isEditing(product.id)` to toggle view/edit mode."

2. **Change the name, then click "Save".** The product is updated.

   > "`saveEditing()` calls `updateEntity` with the changes, then clears `editingProduct`."

3. **Click "Edit" again, then "Cancel".** The edit mode closes without changes.

#### Step 4: Create a Product

1. **Scroll down to the Create Product form.**
2. **Fill in: Name="Nx Workshop", Price=49.99, Category="Books", Description="Learn Nx".**
3. **Click "Add Product".** It appears in the list. Total count increases.

   > "That's `createProduct()` — it uses `addEntity()` and increments `nextId`."

#### Step 5: Delete & Toggle

1. **Click "Delete" on a product.** It's removed. Counts update.
2. **Click "Toggle Stock" on a product.** Its badge switches between In Stock / Out of Stock.

#### Step 6: rxMethod Deep Dive

**Show the rxMethod code on screen:**

```typescript
loadProducts: rxMethod<void>(
  pipe(
    tap(() => store.setLoading()),
    switchMap(() =>
      productService.getProducts().pipe(
        tap((products) => {
          patchState(store, setAllEntities(products));
          store.setLoaded();
        })
      )
    )
  )
),
```

> "`rxMethod` bridges the Observable world into Signal Store. It creates a method that, when called, triggers an RxJS pipeline. Here: set loading → call the service → store the results → clear loading. The `switchMap` means if you call `loadProducts()` twice quickly, the first call is cancelled. This is the same pattern you'd use for HTTP calls, WebSocket streams, or any async operation."

### Student Exercises (20 min)

> "Now it's your turn. Here are four exercises, ordered by difficulty. Try at least the first two."

**Point at the exercise card on screen and read each task:**

> "**Exercise 1 (Easy):** Add a `sortBy` state field and a `sortProducts()` method. The `filteredProducts` computed should read `sortBy` and sort results by name or price."
>
> "**Exercise 2 (Medium):** Create a `withPagination()` custom feature. Add `page`, `pageSize`, `totalPages` computed, and `nextPage()` / `prevPage()` methods. Apply it to `filteredProducts`."
>
> "**Exercise 3 (Medium):** Create a `ProductDetailStore` that loads a single product by ID using `rxMethod<number>`. Show it in a detail view."
>
> "**Exercise 4 (Hard):** Build a `withUndoRedo()` feature that keeps a history of entity states and allows undo/redo operations."

**Walk around the room and help students. Common issues:**

- Students forget to import `rxMethod` from `@ngrx/signals/rxjs-interop`
- Students try to mutate the array directly instead of using spread / `patchState`
- Pagination: remind them `totalPages = Math.ceil(total / pageSize)`

### Student Checkpoint — Topic 5

1. **Q:** "What does `rxMethod` do?" **A:** Creates a store method that triggers an RxJS pipeline — bridges Observable async into Signal Store.
2. **Q:** "Why does the store use `switchMap` in `loadProducts`?" **A:** To cancel any in-flight request if `loadProducts` is called again before the first one finishes.
3. **Q:** "How does inline editing work without mutating the entity directly?" **A:** The product is copied into `editingProduct` state. Edits modify `editingProduct`. On save, `updateEntity` applies the changes immutably.

---

## Wrap-Up Talk (5 min)

> "Let me give you the five things to remember from this block."
>
> "**One:** `signalStore()` creates an injectable, signal-based store. State properties become signals automatically."
>
> "**Two:** The API is composable — `withState`, `withComputed`, `withMethods`, `withHooks`, `withEntities`. Stack them like Lego."
>
> "**Three:** Custom features with `signalStoreFeature()` let you build reusable plugins — loading state, pagination, logging."
>
> "**Four:** `patchState()` is always immutable. Partial objects, updater functions, or entity helpers."
>
> "**Five:** Debug with `getState()` for snapshots and `watchState()` for tracing — but guard with `isDevMode()` in production."
>
> "If your app has three components sharing a filter, a service with signals is fine. If your app has CRUD features with loading states and entity collections, Signal Store is the right tool. You don't need Redux-level complexity for 90% of apps."

---

## Common Student Questions

**Q1: "Do I still need NgRx Store (Redux) if I use Signal Store?"**

> Not for most apps. Signal Store covers feature-level state management well. You'd only reach for full NgRx Store if you need time-travel debugging, action logging across the entire app, or complex cross-feature side effects with `@ngrx/effects`. Signal Store handles 90% of use cases with 10% of the boilerplate.

**Q2: "Can I use Signal Store with RxJS Observables?"**

> Yes — that's what `rxMethod` is for. It creates a method that runs an RxJS pipeline. You can also use `toObservable()` from `@angular/core/rxjs-interop` to convert a store's signal into an Observable for interop with existing RxJS code.

**Q3: "How does Signal Store compare to NGXS or Akita?"**

> Same problem space, different API. Signal Store is signal-native (no Observable wrappers), functional (no classes), and officially maintained by the NgRx team. If you're starting a new Angular 17+ project, Signal Store is the recommended choice.

**Q4: "What happens to my store state when the user navigates away?"**

> If the store is component-scoped (in `providers`), it's destroyed. When the user navigates back, a new instance is created with default state. If the store is root-scoped (`providedIn: 'root'`), it persists for the app's lifetime. Choose based on your needs.

**Q5: "Can I test Signal Store in unit tests?"**

> Yes. Since `signalStore()` creates an injectable service, you use `TestBed` to provide and inject it. Call methods, then assert on signal values. No special testing utilities needed — just `store.count()` returns the current value.

**Q6: "What's the performance of `withEntities` compared to managing arrays manually?"**

> `withEntities` uses a normalised structure internally (entity map + ID array), so lookups are O(1). For lists up to a few thousand items, there's no meaningful performance difference from a plain array. For very large datasets, the entity map lookup is faster than array `find()`.

**Q7: "Can I have multiple stores interact with each other?"**

> Yes. Inject one store into another store's `withMethods` using `inject()`. For example, `ProductStore` could inject `AuthStore` to check permissions before deleting a product. Keep the dependency direction clear — avoid circular dependencies.

**Q8: "Is Signal Store tree-shakeable?"**

> Yes. Because it's functional (no classes with large method tables), the build system can tree-shake unused features. If you don't import `withEntities`, it's not in your bundle.

---

## Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| `NullInjectorError: No provider for DemoCounterStore` | Store not in `providers` array | Add to component `providers: [DemoCounterStore]` or use `{ providedIn: 'root' }` |
| Console shows no `watchState` output | Not navigated to the debugging page | Navigate to `/store-debugging` — the store with `withDevtools` is scoped to that component |
| `rxMethod` call doesn't trigger HTTP | Service not injected | Ensure `productService = inject(ProductService)` is in `withMethods` second arg |
| Products don't load on workshop page | `ProductService` not provided | Check that `ProductService` is `providedIn: 'root'` or in the app providers |
| Entity type error with `updateEntity` | Wrong changes shape | Use `{ id, changes: { name: 'New' } }` or `{ id, changes: (p) => ({ ...p, name: 'New' }) }` |
| `patchState` doesn't update UI | Mutating instead of replacing | Always spread: `[...store.items(), newItem]`, never `store.items().push(newItem)` |
| Store state resets on navigation | Component-scoped store destroyed | Expected behaviour for `providers: [Store]`. Use `{ providedIn: 'root' }` for persistence |

---

## Project Structure

```
angular-ngrx-signal-store-demo/
├── apps/
│   └── demo-app/
│       └── src/
│           └── app/
│               ├── app.routes.ts          ← all routes defined here
│               ├── app.component.ts       ← main layout + navigation
│               └── features/
│                   ├── state-overview/     ← Topic 1 (lecture slides)
│                   ├── signal-store-api/   ← Topic 2 (counter + todo stores)
│                   ├── store-patterns/     ← Topic 3 (filter, entity, custom)
│                   ├── store-debugging/    ← Topic 4 (devtools, watchState)
│                   └── store-workshop/     ← Topic 5 (full CRUD)
├── libs/
│   └── shared/
│       ├── ui/            ← UiCardComponent, UiButtonComponent, UiBadgeComponent
│       └── data-access/   ← Product model, ProductService
├── package.json
├── nx.json
└── tsconfig.base.json
```

---

## Nx Commands Reference

```bash
# Serve the demo app (default port 4200)
npx nx serve demo-app

# Build for production
npx nx build demo-app

# Run tests
npx nx test demo-app

# Lint
npx nx lint demo-app

# See the dependency graph
npx nx graph

# Run all tests across the monorepo
npx nx run-many --target=test --all

# Serve with a specific port
npx nx serve demo-app --port=4201
```
