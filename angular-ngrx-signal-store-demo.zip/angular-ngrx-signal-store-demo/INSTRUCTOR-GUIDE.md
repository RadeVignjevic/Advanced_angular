# Block 5 — State Management with NgRx Signal Store

## Instructor Guide — "For Dummies" Edition

**Duration:** 2 h 30 min  
**Prerequisites:** Blocks 2–4 complete (Architecture, Signals, Change Detection)  
**Key Dependency:** `@ngrx/signals@19.2.1`  
**Project:** `angular-ngrx-signal-store-demo`

---

## How to Use This Guide

This guide tells you **exactly what to say, what to click, and what to draw on the whiteboard**. Every section follows this pattern:

1. **Whiteboard / Analogy** — draw or explain the concept in plain English first
2. **Show the Code** — scroll to the exact section in the running app
3. **Live Demo** — click buttons, watch the result, narrate what happens
4. **Student Checkpoint** — ask a question to verify understanding

> **Convention:** Text in "quotes like this" is **exactly what you say out loud** to the class.

---

## Schedule Overview

| # | Topic | Time | Route | What Students Learn |
|---|-------|------|-------|---------------------|
| 1 | State Management Patterns | 20 min | `/state-overview` | Why state management exists, categories, when to use what |
| 2 | NgRx Signal Store Core API | 40 min | `/signal-store-api` | signalStore, withState, withComputed, withMethods, patchState |
| 3 | Signal Store Design Patterns | 30 min | `/store-patterns` | Feature stores, withEntities, custom features, composition |
| 4 | Debugging & Observability | 20 min | `/store-debugging` | getState, watchState, custom devtools feature |
| 5 | Workshop: CRUD Feature Store | 40 min | `/store-workshop` | Full CRUD store with rxMethod, entities, loading state |

---

## Before Class — Setup (5 min)

```bash
cd angular-ngrx-signal-store-demo
npm install
npx nx serve demo-app
```

Open **http://localhost:4200**. The dashboard shows Block 5 topic cards plus all previous blocks.

---

## Opening Talk (5 min)

### The Restaurant Inventory Analogy

> "Imagine you run a restaurant chain with 20 locations. Every location needs to know: what's in the fridge, what customers ordered, and which staff are on shift.
>
> **Without state management**, each location keeps its own sticky notes. When headquarters asks 'how many steaks do we have across all locations?' — nobody knows. The data is scattered.
>
> **With state management**, you install a central inventory system. Each location reads from and writes to one system. Headquarters has one source of truth.
>
> NgRx Signal Store IS that central inventory system — but for your Angular app's data."

### Whiteboard — Draw This

```
┌─────────────────────────────────────────────────┐
│           WITHOUT STATE MANAGEMENT              │
│                                                  │
│  Component A          Component B               │
│  ┌──────────┐         ┌──────────┐             │
│  │ products  │←prop→  │ products  │  ← COPIES! │
│  │ isLoading │        │ isLoading │             │
│  └──────────┘         └──────────┘             │
│  ↑ Which is correct? Who updates whom?          │
├─────────────────────────────────────────────────┤
│           WITH SIGNAL STORE                     │
│                                                  │
│           ┌──────────────┐                      │
│           │ ProductStore  │ ← SINGLE TRUTH      │
│           │ entities()    │                      │
│           │ isLoading()   │                      │
│           └──────┬───────┘                      │
│                  │                               │
│           ┌──────┼──────┐                       │
│           ▼      ▼      ▼                       │
│         Comp A  Comp B  Comp C  ← ALL READ IT  │
└─────────────────────────────────────────────────┘
```

---

## Topic 1: State Management Patterns (20 min)

**Navigate to:** `http://localhost:4200/state-overview`

### Section 1.1: Why State Management? (4 min)

> "Look at the two cards on screen. Left side — what happens WITHOUT structure. Right side — what happens WITH state management."

Point to the "Without Structure" card:

> "State scattered across components. Prop drilling through deep trees. Duplicate data. Race conditions. Sound familiar? Raise your hand if your current project has at least two of these problems."

Point to the "With State Management" card:

> "Single source of truth. Components inject what they need. Predictable transitions. Easy to test. This is what we're building today."

### Section 1.2: Categories of State (5 min)

Scroll to **Section 2** ("Categories of State"). Three cards with icons.

> "Not all state is the same. There are three categories. Think of them as proximity levels:
>
> **Component State (blue):** Local to ONE component. A toggle, a counter, a form field value. Use a plain `signal()`. That's it. Don't overthink it.
>
> **Shared State (yellow):** Two or three sibling components need the same data. A selected item, a search filter. An injectable service with signals is enough.
>
> **Global / App State (red):** The whole app needs this data. Auth, user profile, a product catalog. THIS is where Signal Store shines."

### Section 1.3: Evolution Timeline (4 min)

Scroll to **Section 3** ("Evolution of Angular State Management").

> "Angular state management has evolved through four generations:"

Point to each timeline step:

> "Generation 1: Services with BehaviorSubject. Simple, no dependencies. Works for small apps. Breaks down at scale because there's no structure.
>
> Generation 2: NgRx Store — the Redux pattern. Actions, reducers, effects, selectors. Very powerful, but SO much boilerplate. A simple counter needs 4 files.
>
> Generation 3: NgRx Component Store. Lighter weight, component-scoped. Less boilerplate than Redux. But still RxJS-based.
>
> Generation 4: NgRx Signal Store. Where we are today. Signal-based, functional API, composable features. Zero boilerplate. Let me show you."

### Section 1.4: Decision Framework (4 min)

Scroll to **Section 4** ("When to Use What?").

Read the table rows:

> "Form toggle? Just use `signal()`. Shared filter between siblings? Service with signals. Feature with CRUD and loading states? Signal Store. Entity collections? Signal Store with `withEntities`. Complex cross-feature workflows with time-travel debugging? Stick with full NgRx Store."

### Section 1.5: Signal Store Preview (3 min)

Scroll to **Section 5**. Show the code preview and feature pills.

> "This is the entire API. Seven building blocks. You compose them together like LEGO bricks. No classes, no decorators, no boilerplate — just functions."

#### Student Checkpoint

> "If I have a simple form toggle (open/closed), should I create a Signal Store for it?"

**Answer:** No. Use a plain `signal(false)`. Signal Store is for shared or complex state.

---

## Topic 2: NgRx Signal Store Core API (40 min)

**Navigate to:** `http://localhost:4200/signal-store-api`

### Section 2.1: signalStore() + withState() (5 min)

> "Let's build our first store. `signalStore()` creates an injectable service. `withState()` defines the data shape."

Scroll to **Section 1** and read the code:

```typescript
export const CounterStore = signalStore(
  withState({ count: 0, label: 'My Counter' })
);
// store.count() → Signal<number>
// store.label() → Signal<string>
```

> "Each property in `withState` becomes a signal automatically. You read it with `store.count()` — just like any signal. No `.value`, no `.getValue()`, no `.pipe()`. Just call it like a function."

### Section 2.2: withComputed() — Derived State (8 min)

Scroll to **Section 2** ("withComputed() — Derived State").

> "Remember `computed()` from Block 3? Same thing, but inside a store."

Show the live demo values: count, doubled, isPositive.

**Click "Increment" three times:**

> "Watch: count goes to 3, doubled goes to 6, isPositive says true. All automatic. The computed signals recalculate when count changes — memoised, just like standalone computed signals."

**Click "Decrement" four times (count goes to -1):**

> "Now isPositive is false. No manual wiring. No subscription. The dependency graph handles it."

**Click "Reset":**

> "Back to zero. `patchState(store, { count: 0 })` — that's all reset does."

#### Show the Code

```typescript
withComputed(({ count }) => ({
  doubled: computed(() => count() * 2),
  isPositive: computed(() => count() > 0),
}))
```

> "The function receives the store's existing signals as an argument. You return an object of computed signals. They're added to the store just like state properties."

### Section 2.3: withMethods() + patchState() (7 min)

Scroll to **Section 3** ("withMethods() + patchState()").

> "`withMethods()` adds the actions that can change state. Every state change goes through `patchState()`."

Show the label demo:

**Click "setLabel('Updated!')":**

> "The label changed to 'Updated!'. Under the hood: `patchState(store, { label: 'Updated!' })`. It merges this partial state into the current state — immutably. A new state object is created."

> "This is important: `patchState` is ALWAYS immutable. You can never accidentally mutate the store's state."

### Section 2.4: withHooks() (3 min)

Scroll to **Section 4** ("withHooks()").

> "Stores have lifecycle hooks, just like components. `onInit` runs when the store is first injected. `onDestroy` runs when its injector is destroyed."

> "Open your browser console right now. You should see: '[DemoCounterStore] Initialised with state: { count: 0, label: Demo Counter }'. That's from the `onInit` hook."

### Section 2.5: patchState() Patterns (5 min)

Scroll to **Section 5** ("patchState() Patterns").

> "Three ways to call patchState:
>
> One: a plain object — `patchState(store, { count: 5 })`.
> Two: an updater function — `patchState(store, state => ({ count: state.count + 1 }))`.
> Three: multiple updaters — `patchState(store, setLoading(), addEntity(product))`.
>
> The third form is the most powerful — you compose multiple changes in one call."

### Section 2.6: Live Todo Store Demo (12 min)

Scroll to **Section 6** ("Live Demo: Todo Store").

> "Now let's see a real use case. This is a fully functional todo app — powered entirely by a Signal Store."

**Step 1: Add todos:**

> "Type 'Learn signals' and press Enter."

Type and press Enter. The todo appears.

> "Type 'Build a store' and press Enter."

Another todo appears. Point to the stats: Total: 2, Active: 2, Done: 0.

**Step 2: Toggle a todo:**

> "Click the checkbox on 'Learn signals'."

It gets strikethrough. Stats update: Total: 2, Active: 1, Done: 1.

**Step 3: Filter:**

> "Click the 'Done' filter button."

Only "Learn signals" shows. Click "Active" — only "Build a store" shows. Click "All" — both show.

> "The filter is a state property. `filteredTodos` is a computed signal that reads both `todos()` and `filter()`. When either changes, the list updates."

**Step 4: Remove:**

> "Click the 'x' button on any todo."

Stats update instantly.

#### Show the Code

```typescript
const DemoTodoStore = signalStore(
  withState({
    todos: [] as TodoItem[],
    filter: 'all' as 'all' | 'active' | 'done',
    nextId: 1,
  }),
  withComputed(({ todos, filter }) => ({
    filteredTodos: computed(() => {
      const all = todos();
      switch (filter()) {
        case 'active': return all.filter(t => !t.done);
        case 'done': return all.filter(t => t.done);
        default: return all;
      }
    }),
    totalCount: computed(() => todos().length),
    doneCount: computed(() => todos().filter(t => t.done).length),
    activeCount: computed(() => todos().filter(t => !t.done).length),
  })),
  withMethods((store) => ({
    addTodo(text: string) {
      patchState(store, {
        todos: [...store.todos(), { id: store.nextId(), text, done: false }],
        nextId: store.nextId() + 1,
      });
    },
    toggleTodo(id: number) {
      patchState(store, {
        todos: store.todos().map(t => t.id === id ? { ...t, done: !t.done } : t),
      });
    },
    // ...
  }))
);
```

> "This entire todo app — with filtering, counting, CRUD — is about 40 lines of code. In NgRx Redux style, this would be 4 files and 200+ lines."

#### Student Checkpoint

> "In the todo store, `filteredTodos` is a computed signal. What two signals does it depend on?"

**Answer:** `todos()` and `filter()`. If either changes, `filteredTodos` recalculates.

---

## Topic 3: Signal Store Design Patterns (30 min)

**Navigate to:** `http://localhost:4200/store-patterns`

### Section 3.1: Feature Store — Scoped (7 min)

Scroll to **Pattern 1** ("Feature Store (Scoped)").

> "In the real world, not every store should be a global singleton. A search filter for your products page? That belongs ONLY to the products feature. When you navigate away, it should be destroyed."

**Live Demo:**

Type "angular" in the search box. Toggle "In Stock Only". Watch the state display update in real time:

```
searchTerm: "angular"  category: null  inStockOnly: true
```

> "This store is provided at the COMPONENT level — `providers: [ProductFilterStore]` in the component decorator. One instance per component tree. When the component is destroyed, the store is destroyed."

**Click "Reset":**

> "All filters cleared. The store methods (`setSearch`, `toggleInStock`, `resetFilters`) are the only way to change state."

#### Student Checkpoint

> "What happens to a component-scoped store when the user navigates to a different route?"

**Answer:** The store is destroyed (garbage collected) along with the component. Next time the user navigates back, a fresh store is created.

### Section 3.2: Entity Collections — withEntities (10 min)

> "This is the MOST IMPORTANT pattern in this topic. Almost every real app has entity collections — products, users, orders, etc."

Scroll to **Pattern 2** ("Entity Collections").

Point to the stats bar: Total, In Stock, Categories.

> "`withEntities()` gives you three things for FREE: `entities()` — the array, `ids()` — just the IDs, and `entityMap()` — a dictionary by ID. You also get helper functions for CRUD."

**Live Demo:**

**Click "Toggle" on a product:**

> "The stock status flipped. Under the hood: `patchState(store, updateEntity({ id, changes: ... }))`. The entity helpers handle finding and updating the right item."

**Click "Remove" on a product:**

> "Gone. `patchState(store, removeEntity(id))`. The stats update automatically because they're computed from `entities()`."

**Click "Add Product":**

> "A new random product appears. `patchState(store, addEntity(product))`. The entity collection grows."

#### Whiteboard — Entity Store Structure

```
┌─────────────────────────────────────────┐
│         withEntities(config)             │
│                                          │
│  Gives you:                              │
│  ├── entities()    → Product[]           │
│  ├── ids()         → number[]            │
│  └── entityMap()   → Record<id, Product> │
│                                          │
│  Helper functions:                       │
│  ├── setAllEntities(products)            │
│  ├── addEntity(product)                  │
│  ├── updateEntity({ id, changes })       │
│  ├── removeEntity(id)                    │
│  └── upsertEntity(product)              │
│                                          │
│  Config:                                 │
│  entityConfig({ entity: type<Product>(), │
│    selectId: (p) => p.id })              │
└─────────────────────────────────────────┘
```

### Section 3.3: Custom Store Features (5 min)

Scroll to **Pattern 3** ("Custom Store Features").

> "What if multiple stores all need loading and error state? Do you copy-paste `isLoading`, `error`, `setLoading()`, `setLoaded()`, `setError()` into every store? No. You create a reusable FEATURE."

Show the `withLoadingState()` code:

```typescript
function withLoadingState() {
  return signalStoreFeature(
    withState({ isLoading: false, error: null as string | null }),
    withComputed(({ isLoading, error }) => ({
      hasError: computed(() => error() !== null),
    })),
    withMethods((store) => ({
      setLoading() { patchState(store, { isLoading: true, error: null }); },
      setLoaded()  { patchState(store, { isLoading: false }); },
      setError(msg: string) { patchState(store, { isLoading: false, error: msg }); },
    }))
  );
}

// Usage: signalStore(withState(...), withLoadingState(), ...)
```

> "Now ANY store can add `withLoadingState()` and instantly get loading/error handling. Same pattern for pagination, undo/redo, logging."

### Section 3.4: Composition (3 min)

Scroll to **Pattern 4** ("Composing Multiple Features").

> "Here's the magic — you stack features like LEGO bricks. Order matters: later features can access state from earlier features."

```typescript
signalStore(
  withState({ searchTerm: '' }),        // 1. base state
  withEntities(productConfig),          // 2. entities
  withLoadingState(),                   // 3. loading
  withComputed(...),                    // 4. derived (accesses entities + searchTerm)
  withMethods(...),                     // 5. methods (calls setLoading)
  withHooks(...)                        // 6. lifecycle
);
```

### Section 3.5: providedIn Options (5 min)

Scroll to **Pattern 5** ("Store Scope").

> "Two scoping strategies:
>
> **Component-scoped:** `providers: [MyStore]` in the component. One instance per component tree. Destroyed with the component. Use for feature-specific state.
>
> **Root-scoped:** `signalStore({ providedIn: 'root' }, ...)`. One instance for the entire app. Lives forever. Use for auth, user preferences, global settings."

---

## Topic 4: Debugging & Observability (20 min)

**Navigate to:** `http://localhost:4200/store-debugging`

> "Before we build the full workshop store, let me show you how to debug Signal Stores."

### Section 4.1: getState() — Snapshots (5 min)

Scroll to **Section 1** ("getState() — Snapshot Inspection").

> "`getState(store)` returns a plain JavaScript object — a snapshot of the entire store. No signals, no reactivity, just data."

**Click "Log Snapshot to Console":**

> "Open your browser console. You'll see the full state object: items, selectedIndex, lastAction. This is perfect for error reporting — send the state snapshot to your error tracking service."

### Section 4.2: watchState() — Real-time Tracing (5 min)

> "`watchState(store, callback)` is like a spy camera on your store. Every time ANY state property changes, your callback runs."

### Section 4.3: Custom withDevtools (3 min)

> "We wrap both getState and watchState into a reusable feature called `withDevtools`. Add it to any store and you get automatic console logging."

### Section 4.4: Live Demo (5 min)

Scroll to **Section 4** ("Live Demo — Watch the Console").

> "Open your console. Now watch what happens."

**Click on "Alpha" in the list:**

> "Console shows: `[DebugDemoStore] State changed:` with the full state including `selectedIndex: 0` and `lastAction: 'selected index 0'`."

**Type "Delta" in the input and click "Add":**

> "Console shows the state change with items now having 4 elements."

**Click the "x" button on any item:**

> "Console shows the removal. Every action is traced."

### Section 4.5: Best Practices (2 min)

> "Two critical rules:
>
> Rule 1: Guard with `isDevMode()`. NEVER leave watchState in production — it fires on every change.
>
> Rule 2: NEVER mutate state from inside `watchState`. That creates an infinite loop — the mutation triggers watchState, which triggers a mutation, which triggers watchState..."

#### Student Checkpoint

> "You're using `withDevtools('ProductStore')` in production and users report the app is slow. What's happening?"

**Answer:** `watchState` fires on every state change, adding console.log overhead. Wrap it in `isDevMode()` so it only runs in development.

---

## Topic 5: Workshop — CRUD Feature Store (40 min)

**Navigate to:** `http://localhost:4200/store-workshop`

### The Architecture (5 min)

Scroll to **Store Architecture** card.

> "This is the real deal — a fully composed store that handles products with CRUD, filtering, loading states, and async data loading."

#### Whiteboard — Draw the Store Layers

```
┌──────────────────────────────────────────────┐
│            ProductCrudStore                    │
│                                               │
│  Layer 1: withEntities(productConfig)         │
│           → entities(), ids(), entityMap()     │
│                                               │
│  Layer 2: withLoadingState()                  │
│           → isLoading(), error(), setLoading() │
│                                               │
│  Layer 3: withState(...)                      │
│           → searchTerm(), selectedCategory()   │
│                                               │
│  Layer 4: withComputed(...)                   │
│           → filteredProducts(), totalCount()   │
│                                               │
│  Layer 5: withMethods(...)                    │
│           → loadProducts(), createProduct()    │
│           → deleteProduct(), toggleStock()     │
│                                               │
│  Layer 6: withHooks({ onInit: loadProducts }) │
│           → auto-loads data on creation        │
└──────────────────────────────────────────────┘
```

### CRUD Operations (20 min)

#### READ — Auto-loading

> "When this component mounts, the store's `onInit` hook fires and calls `loadProducts()`. That's `rxMethod` — it triggers an RxJS pipeline that calls ProductService.getProducts(), gets the response, and populates the entity collection."

Point to the stats bar:

> "Total, In Stock, Out of Stock, Showing — all computed from the entity collection. Automatic."

#### CREATE — Adding Products

> "Fill in the form at the bottom: Name, Price, Category, Description. Click 'Add Product'."

Fill in and click. The product appears in the list.

> "`createProduct()` calls `patchState(store, addEntity(product))`. One line. The entity collection grows, all computed signals update, the stats bar refreshes. No manual wiring."

#### UPDATE — Inline Editing

> "Click 'Edit' on any product."

Click Edit. An inline form appears.

> "Change the name or price, then click 'Save'. The store calls `updateEntity({ id, changes })` and the UI updates."

Click Save.

#### DELETE — Removing Products

> "Click 'Delete' on any product."

Click Delete. Product disappears, stats update.

#### Search & Filter

> "Type in the search box. Select a different category."

Type a term. The list filters in real time.

> "`filteredProducts` is a computed signal that reads `entities()`, `searchTerm()`, and `selectedCategory()`. Any change triggers a recalculation."

### rxMethod Deep Dive (10 min)

Scroll to **Key Pattern: rxMethod for Async**.

> "This is the bridge between RxJS and Signal Store. `rxMethod` creates a method that runs an RxJS pipeline when called."

```typescript
loadProducts: rxMethod<void>(
  pipe(
    tap(() => store.setLoading()),          // 1. show loading
    switchMap(() =>
      productService.getProducts().pipe(    // 2. HTTP call
        tap((products) => {
          patchState(store,                 // 3. update entities
            setAllEntities(products)
          );
          store.setLoaded();                // 4. hide loading
        })
      )
    )
  )
)
```

> "Think of rxMethod as: 'when I call this method, kick off this RxJS pipeline'. Import from `@ngrx/signals/rxjs-interop`. Use it for any async operation — HTTP calls, WebSocket subscriptions, etc."

### Student Exercises (5 min)

> "If time allows, try these exercises:
> 1. Add sorting by name or price
> 2. Add pagination with `withPagination()` custom feature
> 3. Create a product detail store that loads one product by ID
> 4. Add undo/redo capability"

---

## Wrap-Up Talk (5 min)

### Key Takeaways — Say These Out Loud

> "Five things to remember from today:
>
> 1. **Signal Store is functional and composable** — `withState`, `withComputed`, `withMethods`, `withHooks` stack like LEGO.
> 2. **patchState() is always immutable** — you can never accidentally mutate state.
> 3. **withEntities() handles entity collections** — the most important pattern for real apps.
> 4. **Custom features are reusable** — `withLoadingState()`, `withPagination()`, `withDevtools()` — build once, use everywhere.
> 5. **rxMethod bridges RxJS into stores** — for async operations like HTTP calls."

---

## Common Student Questions

**Q: How does Signal Store compare to NgRx Store (Redux)?**
> "Signal Store is simpler — no actions, no reducers, no effect files. For most apps, it's enough. Use full NgRx Store only when you need time-travel debugging, action logging, or complex cross-feature coordination."

**Q: Can I use Signal Store with existing RxJS services?**
> "Yes. Use `rxMethod` to call Observable-returning services. Or use `toSignal()` to bridge at the consumption point. They coexist perfectly."

**Q: How do I test a Signal Store?**
> "Inject it in a test, call methods, read signal values. No TestBed required for basic unit tests: `const store = new MyStore(); store.increment(); expect(store.count()).toBe(1);`"

**Q: Can I have multiple stores in one component?**
> "Yes. Provide multiple stores in the `providers` array and inject them separately. Each store manages its own slice of state."

**Q: Are Signal Stores tree-shakeable?**
> "Yes. If a store is `providedIn: 'root'` and no component injects it, it's removed from the bundle."

**Q: What if I need to coordinate between two stores?**
> "One store can inject another. Or use a higher-level service that injects both stores and orchestrates. For very complex cross-store workflows, consider full NgRx Store."

**Q: Signal Store or plain services with signals?**
> "For 1-2 signals: plain service. For 3+ signals with computed values, loading states, and methods: Signal Store. The structured API prevents spaghetti."

---

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| `NullInjectorError: No provider for MyStore` | Store not provided | Add to `providers: [MyStore]` or use `{ providedIn: 'root' }` |
| `patchState is not a function` | Wrong import | Import from `@ngrx/signals`, not `@ngrx/store` |
| `withEntities type error` | Missing entityConfig | Use `entityConfig({ entity: type<Product>(), selectId: ... })` |
| `rxMethod does nothing` | Forgot to call the method | `withHooks({ onInit: (store) => store.loadProducts() })` |
| Console shows `[Store] initialized` repeatedly | Store re-created on every navigation | Use `{ providedIn: 'root' }` for singletons |

---

## Project Structure

```
angular-ngrx-signal-store-demo/
├── apps/demo-app/src/app/
│   ├── app.config.ts
│   ├── app.routes.ts
│   └── features/
│       ├── dashboard/              # Block 5 overview
│       ├── state-overview/         # Topic 1: Why state management
│       ├── signal-store-api/       # Topic 2: Core API (counter + todo demos)
│       ├── store-patterns/         # Topic 3: Entities, features, composition
│       ├── store-debugging/        # Topic 4: getState, watchState, devtools
│       └── store-workshop/         # Topic 5: Full CRUD workshop
├── libs/shared/
│   ├── ui/                         # UiButton, UiBadge, UiCard
│   ├── data-access/                # ProductService, Models, Tokens
│   └── util/                       # Adapters, helpers
└── INSTRUCTOR-GUIDE.md
```

---

## Key Imports Reference

```typescript
// Core Signal Store
import { signalStore, withState, withComputed, withMethods,
         withHooks, patchState, getState, watchState,
         signalStoreFeature, type } from '@ngrx/signals';

// Entity Management
import { withEntities, setAllEntities, addEntity,
         removeEntity, updateEntity, entityConfig } from '@ngrx/signals/entities';

// RxJS Interop
import { rxMethod } from '@ngrx/signals/rxjs-interop';
```

---

## Nx Commands

```bash
npx nx serve demo-app          # Serve the demo app
npx nx build demo-app          # Build for production
npx nx lint demo-app           # Run linting
npx nx graph                   # Dependency graph
```
