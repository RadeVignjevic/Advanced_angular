import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { appRoutes } from './app.routes';
import { APP_CONFIG, DEFAULT_APP_CONFIG, LOGGER_CONFIG, DEV_LOGGER_CONFIG } from '@angular-monorepo-demo/data-access';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(appRoutes),
    { provide: APP_CONFIG, useValue: DEFAULT_APP_CONFIG },
    { provide: LOGGER_CONFIG, useValue: DEV_LOGGER_CONFIG },
  ],
};
