import { Component, signal, computed, ChangeDetectionStrategy, NgZone, inject, OnInit, OnDestroy } from '@angular/core';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Change Detection in Depth — Topic 1 (40 min)
 *
 * TEACHING POINTS:
 * 1. Zone.js — How Angular knows when to check
 * 2. Default vs OnPush change detection strategies
 * 3. Zoneless mode (experimental) — provideExperimentalZonelessChangeDetection
 * 4. How the component tree is traversed
 * 5. markForCheck() vs detectChanges()
 */
@Component({
  selector: 'app-cd-in-depth',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="cd-page">
      <h2>Change Detection in Depth <ui-badge variant="info">Block 4 — Topic 1</ui-badge></h2>

      <p class="note">
        Angular's change detection (CD) decides <strong>when and how</strong> to re-render components.
        Understanding CD is key to building performant apps.
      </p>

      <!-- 1. Zone.js Explained -->
      <ui-card title="1. Zone.js — How Angular Knows When to Check" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeZoneJs }}</pre>

          <div class="explanation">
            <p><strong>Zone.js monkey-patches</strong> browser APIs: setTimeout, addEventListener,
            Promise.then, XHR, fetch, etc.</p>
            <p>When any async operation completes, Zone.js notifies Angular, which triggers
            CD from the root component <strong>down the entire tree</strong>.</p>
          </div>

          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="triggerClick()">Click (patched by Zone)</ui-button>
            <ui-button variant="secondary" size="sm" (clicked)="triggerTimeout()">setTimeout (patched)</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="triggerOutsideZone()">Run Outside Zone</ui-button>
          </div>

          <div class="log-box">
            <p><strong>CD Trigger Log:</strong></p>
            @for (entry of cdLog(); track $index) {
              <div class="log-entry">{{ entry }}</div>
            }
            @empty {
              <div class="log-entry muted">Click a button to trigger change detection...</div>
            }
          </div>
        </div>
      </ui-card>

      <!-- 2. Default vs OnPush -->
      <ui-card title="2. Default vs OnPush Strategy" [elevated]="true">
        <div class="demo-section">
          <div class="strategy-grid">
            <div class="strategy-card default-card">
              <h4>ChangeDetectionStrategy.Default</h4>
              <pre class="code-block">{{ codeDefault }}</pre>
              <ul>
                <li>Checks component on <strong>every</strong> CD cycle</li>
                <li>Walks entire subtree regardless of changes</li>
                <li>Safe but expensive for large trees</li>
                <li>No action needed — this is the default</li>
              </ul>
              <ui-badge variant="warning">Easy but Slow</ui-badge>
            </div>
            <div class="strategy-card onpush-card">
              <h4>ChangeDetectionStrategy.OnPush</h4>
              <pre class="code-block">{{ codeOnPush }}</pre>
              <ul>
                <li>Skips component unless:</li>
                <li>- Input reference changes</li>
                <li>- Event fires within the component</li>
                <li>- Async pipe emits</li>
                <li>- Signal read in template changes</li>
                <li>- markForCheck() called manually</li>
              </ul>
              <ui-badge variant="success">Fast &amp; Recommended</ui-badge>
            </div>
          </div>

          <div class="demo-row">
            <span class="value-display">
              CD checks on this component: <strong>{{ checkCount() }}</strong>
            </span>
            <ui-button variant="primary" size="sm" (clicked)="incrementCounter()">Trigger CD (Event)</ui-button>
          </div>
          <p class="explanation-inline">
            This component uses <code>OnPush</code>. The counter only updates because
            clicking the button fires an event <strong>inside</strong> this component.
          </p>
        </div>
      </ui-card>

      <!-- 3. The Component Tree Traversal -->
      <ui-card title="3. Component Tree Traversal" [elevated]="true">
        <div class="demo-section">
          <div class="tree-viz">
            <div class="tree-node root">
              <span>AppComponent</span>
              <span class="strategy-tag">Default</span>
            </div>
            <div class="tree-level">
              <div class="tree-node" [class.checked]="treeCheckState() >= 1">
                <span>HeaderComponent</span>
                <span class="strategy-tag onpush">OnPush</span>
              </div>
              <div class="tree-node checked">
                <span>ContentComponent</span>
                <span class="strategy-tag">Default</span>
              </div>
              <div class="tree-node" [class.checked]="treeCheckState() >= 1">
                <span>SidebarComponent</span>
                <span class="strategy-tag onpush">OnPush</span>
              </div>
            </div>
            <div class="tree-level sub">
              <div class="tree-node" [class.checked]="treeCheckState() >= 2">
                <span>ChildA</span>
                <span class="strategy-tag onpush">OnPush</span>
              </div>
              <div class="tree-node checked">
                <span>ChildB</span>
                <span class="strategy-tag">Default</span>
              </div>
              <div class="tree-node" [class.checked]="treeCheckState() === 3">
                <span>ChildC</span>
                <span class="strategy-tag onpush">OnPush</span>
              </div>
            </div>
          </div>
          <div class="tree-legend">
            <span class="legend-item"><span class="dot checked-dot"></span> Checked</span>
            <span class="legend-item"><span class="dot skipped-dot"></span> Skipped (OnPush)</span>
          </div>
          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="cycleTreeState()">Simulate CD Cycle</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="resetTree()">Reset</ui-button>
          </div>
          <p class="explanation-inline">
            <strong>Default</strong> components are always checked. <strong>OnPush</strong>
            components are skipped unless they have a reason to update (input change, event, signal, etc).
          </p>
        </div>
      </ui-card>

      <!-- 4. Zoneless Mode -->
      <ui-card title="4. Zoneless Angular (Experimental)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeZoneless }}</pre>
          <div class="comparison-grid">
            <div class="compare-col">
              <h4>With Zone.js (Traditional)</h4>
              <ul>
                <li>Zone.js patches ~200+ browser APIs</li>
                <li>CD triggered on every async task</li>
                <li>Adds ~15KB to bundle</li>
                <li>Can cause unnecessary CD cycles</li>
                <li>Hard to debug what triggered CD</li>
              </ul>
            </div>
            <div class="compare-col highlight">
              <h4>Zoneless (Signal-Based)</h4>
              <ul>
                <li>No Zone.js patching</li>
                <li>CD triggered only by signal changes</li>
                <li>Smaller bundle (-15KB)</li>
                <li>Predictable, traceable reactivity</li>
                <li>Requires signals for all state</li>
              </ul>
            </div>
          </div>
          <p class="explanation-inline">
            <strong>Zoneless</strong> is the future of Angular. Once all your components use
            signals, Zone.js becomes unnecessary. Use
            <code>provideExperimentalZonelessChangeDetection()</code> in your app config.
          </p>
        </div>
      </ui-card>

      <!-- 5. markForCheck vs detectChanges -->
      <ui-card title="5. markForCheck() vs detectChanges()" [elevated]="true">
        <div class="demo-section">
          <div class="strategy-grid">
            <div class="strategy-card">
              <h4>markForCheck()</h4>
              <pre class="code-block">{{ codeMarkForCheck }}</pre>
              <ul>
                <li>Marks component dirty from current to root</li>
                <li>CD runs on next tick (scheduled)</li>
                <li>Safe — respects Angular lifecycle</li>
                <li>Used when OnPush component needs refresh</li>
              </ul>
              <ui-badge variant="success">Recommended</ui-badge>
            </div>
            <div class="strategy-card">
              <h4>detectChanges()</h4>
              <pre class="code-block">{{ codeDetectChanges }}</pre>
              <ul>
                <li>Triggers CD immediately on this subtree</li>
                <li>Synchronous — can cause issues</li>
                <li>Does NOT propagate to parent</li>
                <li>Use sparingly — often a code smell</li>
              </ul>
              <ui-badge variant="danger">Use With Caution</ui-badge>
            </div>
          </div>
          <p class="explanation-inline">
            With <strong>signals</strong>, you rarely need either — signals auto-notify Angular
            that a component needs re-checking.
          </p>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .cd-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 1rem 0; flex-wrap: wrap; }
    .value-display { font-size: 1.1rem; }
    .explanation p, .explanation-inline { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation-inline code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .log-box { background: #f5f5f5; border: 1px solid #ddd; border-radius: 8px; padding: 0.75rem; margin-top: 0.75rem; max-height: 150px; overflow-y: auto; }
    .log-entry { font-family: monospace; font-size: 0.82rem; padding: 0.2rem 0; }
    .log-entry.muted { color: #999; }
    .strategy-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin: 0.75rem 0; }
    .strategy-card { background: #f8f9fa; border: 2px solid #e9ecef; border-radius: 12px; padding: 1.25rem; }
    .strategy-card h4 { margin: 0 0 0.5rem; color: #2c3e50; font-size: 0.95rem; }
    .strategy-card ul { margin: 0.5rem 0; padding-left: 1.25rem; font-size: 0.85rem; color: #555; }
    .strategy-card li { margin: 0.25rem 0; }
    .default-card { border-color: #ffca28; }
    .onpush-card { border-color: #66bb6a; }
    .tree-viz { display: flex; flex-direction: column; align-items: center; gap: 0.5rem; margin: 1rem 0; }
    .tree-level { display: flex; gap: 1.5rem; justify-content: center; }
    .tree-level.sub { gap: 2rem; }
    .tree-node { background: #e0e0e0; border: 2px solid #bdbdbd; border-radius: 8px; padding: 0.5rem 1rem; text-align: center; min-width: 120px; transition: all 0.3s; }
    .tree-node span { display: block; font-size: 0.82rem; }
    .tree-node.root { background: #bbdefb; border-color: #42a5f5; }
    .tree-node.checked { background: #c8e6c9; border-color: #66bb6a; }
    .strategy-tag { font-size: 0.7rem; color: #888; margin-top: 0.15rem; }
    .strategy-tag.onpush { color: #2e7d32; font-weight: 600; }
    .tree-legend { display: flex; gap: 1.5rem; justify-content: center; margin: 0.5rem 0; }
    .legend-item { display: flex; align-items: center; gap: 0.4rem; font-size: 0.82rem; }
    .dot { width: 12px; height: 12px; border-radius: 50%; }
    .checked-dot { background: #c8e6c9; border: 2px solid #66bb6a; }
    .skipped-dot { background: #e0e0e0; border: 2px solid #bdbdbd; }
    .comparison-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 0.75rem 0; }
    .compare-col { background: #f8f9fa; border-radius: 8px; padding: 1rem; }
    .compare-col.highlight { background: #e8f5e9; border: 2px solid #66bb6a; }
    .compare-col h4 { margin: 0 0 0.5rem; font-size: 0.95rem; }
    .compare-col ul { margin: 0; padding-left: 1.25rem; font-size: 0.85rem; color: #555; }
    .compare-col li { margin: 0.25rem 0; }
  `]
})
export class CdInDepthComponent {
  private ngZone = inject(NgZone);

  // ═══════════ CODE EXAMPLES (as strings to avoid template parsing issues) ═══════════
  codeZoneJs = `// Zone.js intercepts ALL async APIs:
// setTimeout, addEventListener, fetch, Promise.then, XHR...

// When any async callback completes:
// 1. Zone.js notifies Angular
// 2. Angular calls ApplicationRef.tick()
// 3. tick() runs CD from root down the tree

// This is why Angular "just works" with async code!
zone.onMicrotaskEmpty.subscribe(() => {
  ngZone.run(() => applicationRef.tick());
});`;

  codeDefault = `@Component({
  // Default — no strategy specified
  // Angular checks this on EVERY CD cycle
  template: \`<div>{{ value }}</div>\`
})
export class DefaultComponent {
  value = 'always checked';
}`;

  codeOnPush = `@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: \`<div>{{ value() }}</div>\`
})
export class OnPushComponent {
  value = signal('only checked when needed');
  // Checked when: input changes, event fires,
  // signal updates, async pipe emits
}`;

  codeZoneless = `// app.config.ts — Zoneless setup
import { provideExperimentalZonelessChangeDetection }
  from '@angular/core';

export const appConfig = {
  providers: [
    provideExperimentalZonelessChangeDetection(),
    provideRouter(routes),
    provideHttpClient()
  ]
};
// No Zone.js import in polyfills!
// CD only runs when signals change.`;

  codeMarkForCheck = `// OnPush component with manual trigger
constructor(private cdr: ChangeDetectorRef) {}

ngOnInit() {
  someExternalLib.onChange(() => {
    this.data = newData;
    this.cdr.markForCheck(); // schedule CD
  });
}`;

  codeDetectChanges = `// Forces immediate CD on this subtree
constructor(private cdr: ChangeDetectorRef) {}

updateNow() {
  this.data = newData;
  this.cdr.detectChanges(); // sync, immediate
  // Careful: can cause ExpressionChangedError
}`;

  // ═══════════ DEMO STATE ═══════════
  cdLog = signal<string[]>([]);
  checkCount = signal(0);
  treeCheckState = signal(0);

  triggerClick(): void {
    this.cdLog.update(log => [...log, `[${new Date().toLocaleTimeString()}] Click event — Zone.js notified Angular, CD ran from root`]);
  }

  triggerTimeout(): void {
    setTimeout(() => {
      this.cdLog.update(log => [...log, `[${new Date().toLocaleTimeString()}] setTimeout completed — Zone.js triggered CD`]);
    }, 500);
  }

  triggerOutsideZone(): void {
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        // This won't trigger CD!
        console.log('Ran outside Zone — no CD triggered. Check console.');
        this.ngZone.run(() => {
          this.cdLog.update(log => [...log, `[${new Date().toLocaleTimeString()}] Ran outside Zone, then re-entered — CD triggered manually`]);
        });
      }, 500);
    });
  }

  incrementCounter(): void {
    this.checkCount.update(v => v + 1);
  }

  cycleTreeState(): void {
    this.treeCheckState.update(v => v >= 3 ? 0 : v + 1);
  }

  resetTree(): void {
    this.treeCheckState.set(0);
  }
}
