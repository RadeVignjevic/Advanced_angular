import { Route } from '@angular/router';
import { CdInDepthComponent } from './cd-in-depth.component';

export const CD_IN_DEPTH_ROUTES: Route[] = [
  { path: '', component: CdInDepthComponent }
];
