import { Component, signal, computed, ChangeDetectionStrategy, ChangeDetectorRef, inject, NgZone } from '@angular/core';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Identifying and Resolving Change Detection Issues — Topic 3 (20 min)
 *
 * TEACHING POINTS:
 * 1. ExpressionChangedAfterItHasBeenChecked error
 * 2. Excessive CD cycles — detecting and fixing
 * 3. Getter functions in templates (hidden performance trap)
 * 4. Object mutation vs immutable update (OnPush pitfall)
 * 5. Running outside Angular zone (third-party libraries)
 */
@Component({
  selector: 'app-cd-issues',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="cd-issues-page">
      <h2>Identifying &amp; Resolving CD Issues <ui-badge variant="info">Block 4 — Topic 3</ui-badge></h2>

      <p class="note">
        These are the most common change detection problems in Angular apps.
        Learn to identify, diagnose, and fix them.
      </p>

      <!-- Issue 1: ExpressionChangedAfterItHasBeenChecked -->
      <ui-card title="1. ExpressionChangedAfterItHasBeenChecked" [elevated]="true">
        <div class="demo-section">
          <div class="issue-header">
            <ui-badge variant="danger">Common Error</ui-badge>
            <ui-badge variant="warning">Dev Mode Only</ui-badge>
          </div>

          <pre class="code-block">{{ codeExprChanged }}</pre>

          <div class="diagnosis-box">
            <h4>What causes it?</h4>
            <p>A binding value changes <strong>between</strong> the CD check and the verification pass.
            Angular runs CD twice in dev mode to detect this.</p>

            <h4>Common triggers:</h4>
            <ul>
              <li>Modifying state in <code>ngAfterViewInit</code></li>
              <li>Calling methods that return new values on each call (e.g., <code>Date.now()</code>)</li>
              <li>Parent modifying child inputs during its own CD check</li>
              <li>Pipes that return new object references</li>
            </ul>

            <h4>Fixes:</h4>
            <ul>
              <li>Use <code>signal()</code> — signals defer updates properly</li>
              <li>Move state changes to <code>ngOnInit</code> (before view check)</li>
              <li>Use <code>setTimeout()</code> (defers to next CD cycle)</li>
              <li>As last resort: <code>detectChanges()</code> after the change</li>
            </ul>
          </div>
        </div>
      </ui-card>

      <!-- Issue 2: Getter Functions in Templates -->
      <ui-card title="2. Getter Functions in Templates — Hidden Trap" [elevated]="true">
        <div class="demo-section">
          <div class="comparison-grid">
            <div class="compare-col bad">
              <h4>BAD: Getter/Method in Template</h4>
              <pre class="code-block">{{ codeGetterBad }}</pre>
              <div class="impact-box">
                <p>Method called: <strong>{{ getterCallCount() }} times</strong></p>
                <ui-button variant="primary" size="sm" (clicked)="triggerCdForGetter()">Trigger CD</ui-button>
              </div>
              <ul>
                <li>Called on EVERY CD cycle</li>
                <li>No caching — recomputes each time</li>
                <li>10 items in list = 10 calls per cycle</li>
                <li>Often invisible in profiling</li>
              </ul>
              <ui-badge variant="danger">Performance Killer</ui-badge>
            </div>
            <div class="compare-col good">
              <h4>GOOD: computed() Signal</h4>
              <pre class="code-block">{{ codeGetterGood }}</pre>
              <div class="impact-box">
                <p>Recomputed: <strong>{{ computedCallCount() }} times</strong></p>
                <ui-button variant="primary" size="sm" (clicked)="triggerCdForComputed()">Trigger CD</ui-button>
              </div>
              <ul>
                <li>Recomputes ONLY when deps change</li>
                <li>Memoised — returns cached value</li>
                <li>Angular skips if value unchanged</li>
                <li>Explicit dependency tracking</li>
              </ul>
              <ui-badge variant="success">Efficient</ui-badge>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Issue 3: Object Mutation with OnPush -->
      <ui-card title="3. Object Mutation — OnPush Pitfall" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeMutation }}</pre>

          <div class="comparison-grid">
            <div class="compare-col bad">
              <h4>BAD: Mutating Object</h4>
              <div class="mutation-demo">
                <p>user.name = <strong>{{ mutatedUser.name }}</strong></p>
                <ui-button variant="ghost" size="sm" (clicked)="mutateObject()">Mutate (no update!)</ui-button>
              </div>
              <p class="issue-note">OnPush ignores mutations — same reference means no CD.</p>
            </div>
            <div class="compare-col good">
              <h4>GOOD: Immutable Update (Signal)</h4>
              <div class="mutation-demo">
                <p>user().name = <strong>{{ immutableUser().name }}</strong></p>
                <ui-button variant="primary" size="sm" (clicked)="immutableUpdate()">Update (signal)</ui-button>
              </div>
              <p class="issue-note">New reference via signal.update() triggers CD correctly.</p>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Issue 4: Third-Party Libraries Outside Zone -->
      <ui-card title="4. Third-Party Libraries Running Outside Zone" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeOutsideZone }}</pre>

          <div class="diagnosis-box">
            <h4>Symptoms:</h4>
            <ul>
              <li>Data updates in console but UI does not reflect changes</li>
              <li>UI updates only after clicking or interacting with something</li>
              <li>Third-party chart/map library callbacks do not trigger CD</li>
            </ul>

            <h4>Diagnosis:</h4>
            <p>The library runs callbacks outside Angular's Zone. Zone.js never gets notified.</p>

            <h4>Fixes (ranked best to worst):</h4>
            <ol>
              <li><strong>Use signals</strong> — signals always trigger CD regardless of Zone</li>
              <li><code>NgZone.run()</code> — re-enter Zone manually</li>
              <li><code>ChangeDetectorRef.detectChanges()</code> — force immediate CD</li>
            </ol>
          </div>

          <div class="demo-row">
            <span>External value: <strong>{{ externalValue() }}</strong></span>
            <ui-button variant="primary" size="sm" (clicked)="simulateExternalLib()">Simulate Lib Callback (via signal)</ui-button>
          </div>
        </div>
      </ui-card>

      <!-- Issue 5: Excessive CD Cycles -->
      <ui-card title="5. Excessive CD Cycles — Diagnosis" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeExcessiveCd }}</pre>

          <div class="checklist">
            <h4>Diagnostic Checklist:</h4>
            <div class="check-item">
              <span class="check-icon">1</span>
              <div>
                <strong>Open Angular DevTools</strong> — Profiler tab shows CD cycles
              </div>
            </div>
            <div class="check-item">
              <span class="check-icon">2</span>
              <div>
                <strong>Check for Default strategy</strong> on parent components —
                they force CD on all children
              </div>
            </div>
            <div class="check-item">
              <span class="check-icon">3</span>
              <div>
                <strong>Search for function calls in templates</strong> —
                replace with computed() or pipe
              </div>
            </div>
            <div class="check-item">
              <span class="check-icon">4</span>
              <div>
                <strong>Check for frequent async operations</strong> —
                timers, websockets, polling that trigger Zone CD
              </div>
            </div>
            <div class="check-item">
              <span class="check-icon">5</span>
              <div>
                <strong>Profile with browser Performance tab</strong> —
                look for long "CD" scripting blocks
              </div>
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .cd-issues-page { padding: 0.5rem; }
    .note { background: #fff3e0; border: 1px solid #ffe0b2; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 1rem 0; flex-wrap: wrap; }
    .issue-header { display: flex; gap: 0.5rem; margin-bottom: 0.5rem; }
    .explanation-inline { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation-inline code, .diagnosis-box code, .issue-note code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .diagnosis-box { background: #fafafa; border: 1px solid #e0e0e0; border-radius: 8px; padding: 1rem; margin: 0.75rem 0; }
    .diagnosis-box h4 { margin: 0.75rem 0 0.25rem; font-size: 0.9rem; color: #2c3e50; }
    .diagnosis-box h4:first-child { margin-top: 0; }
    .diagnosis-box ul, .diagnosis-box ol { padding-left: 1.25rem; font-size: 0.85rem; color: #555; margin: 0.25rem 0; }
    .diagnosis-box li { margin: 0.2rem 0; }
    .diagnosis-box p { font-size: 0.85rem; color: #555; margin: 0.25rem 0; }
    .comparison-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 0.75rem 0; }
    .compare-col { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 1rem; }
    .compare-col.bad { border-color: #ef5350; background: #ffebee; }
    .compare-col.good { border-color: #66bb6a; background: #e8f5e9; }
    .compare-col h4 { margin: 0 0 0.5rem; font-size: 0.9rem; }
    .compare-col ul { padding-left: 1.25rem; font-size: 0.82rem; color: #555; margin: 0.5rem 0; }
    .compare-col li { margin: 0.2rem 0; }
    .impact-box { margin: 0.5rem 0; font-size: 0.9rem; }
    .mutation-demo { margin: 0.5rem 0; font-size: 0.9rem; }
    .issue-note { font-size: 0.82rem; color: #777; margin-top: 0.5rem; }
    .checklist { margin: 0.75rem 0; }
    .checklist h4 { margin: 0 0 0.75rem; }
    .check-item { display: flex; gap: 0.75rem; align-items: flex-start; margin: 0.5rem 0; padding: 0.5rem; background: #f5f5f5; border-radius: 8px; }
    .check-icon { background: #42a5f5; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: 600; flex-shrink: 0; }
    .check-item div { font-size: 0.85rem; color: #555; }
    .check-item strong { color: #2c3e50; }
  `]
})
export class CdIssuesComponent {
  private ngZone = inject(NgZone);

  // ═══════════ CODE EXAMPLES ═══════════
  codeExprChanged = `// ERROR: ExpressionChangedAfterItHasBeenChecked
@Component({
  template: \`<div>{{ currentTime }}</div>\`
})
export class BadComponent {
  get currentTime() {
    return Date.now(); // Different on every check!
  }
  // Angular checks: 12345 -> verifies: 12346 -> ERROR
}

// FIX: Use a signal
export class FixedComponent {
  currentTime = signal(Date.now());
  constructor() {
    setInterval(() => this.currentTime.set(Date.now()), 1000);
  }
}`;

  codeGetterBad = `// BAD: method call in template
@Component({
  template: \`
    <div>{{ getTotal() }}</div>
  \`
})
export class BadComp {
  getTotal() {
    // Runs on EVERY CD cycle!
    return this.items.reduce(
      (sum, i) => sum + i.price, 0
    );
  }
}`;

  codeGetterGood = `// GOOD: computed signal
@Component({
  template: \`
    <div>{{ total() }}</div>
  \`
})
export class GoodComp {
  items = signal([...]);
  total = computed(() =>
    this.items().reduce(
      (sum, i) => sum + i.price, 0
    )
  );
  // Only recomputes when items change!
}`;

  codeMutation = `// OnPush ignores mutations — must use new reference

// BAD: mutating an object — OnPush won't detect this
this.user.name = 'New Name';
// Same reference -> OnPush skips component

// GOOD: new reference via signal
this.user.update(u => ({ ...u, name: 'New Name' }));
// New reference -> signal notifies -> CD runs`;

  codeOutsideZone = `// Third-party library running outside Zone.js
declare const externalLib: any;

// BAD: callback runs outside Zone — no CD
externalLib.onData((data) => {
  this.data = data; // UI won't update!
});

// FIX 1: Use signal (best)
externalLib.onData((data) => {
  this.dataSignal.set(data); // signals always trigger CD
});

// FIX 2: Re-enter Zone
externalLib.onData((data) => {
  this.ngZone.run(() => { this.data = data; });
});`;

  codeExcessiveCd = `// Symptom: app feels sluggish, high scripting time

// Diagnosis with Angular DevTools:
// 1. Open Chrome DevTools -> Angular tab -> Profiler
// 2. Record a user interaction
// 3. Look for components checked unnecessarily
// 4. Each bar = one CD cycle, height = time spent

// Common fix: switch parent to OnPush
// This prevents cascading checks to all children`;

  // ═══════════ DEMO STATE ═══════════
  getterCallCount = signal(0);
  computedCallCount = signal(0);
  mutatedUser = { name: 'John', age: 30 };
  immutableUser = signal({ name: 'John', age: 30 });
  externalValue = signal('(waiting for callback)');

  triggerCdForGetter(): void {
    this.getterCallCount.update(v => v + 1);
  }

  triggerCdForComputed(): void {
    this.computedCallCount.update(v => v + 1);
  }

  mutateObject(): void {
    // This won't update the UI in OnPush!
    this.mutatedUser.name = 'Mutated! (but UI unchanged in OnPush)';
    // The template still shows 'John' because reference didn't change
  }

  immutableUpdate(): void {
    const names = ['John', 'Jane', 'Alex', 'Maria'];
    const current = this.immutableUser().name;
    const next = names[(names.indexOf(current) + 1) % names.length];
    this.immutableUser.update(u => ({ ...u, name: next }));
  }

  simulateExternalLib(): void {
    // Simulate a third-party callback — signal always triggers CD
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        // Even though we're outside Zone, signals always work
        this.externalValue.set('Data received at ' + new Date().toLocaleTimeString());
      }, 300);
    });
  }
}
