import { Route } from '@angular/router';
import { CdIssuesComponent } from './cd-issues.component';

export const CD_ISSUES_ROUTES: Route[] = [
  { path: '', component: CdIssuesComponent }
];
