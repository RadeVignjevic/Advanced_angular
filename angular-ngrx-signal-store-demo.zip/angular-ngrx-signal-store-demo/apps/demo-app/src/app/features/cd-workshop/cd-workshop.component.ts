import { Component, signal, computed, effect, ChangeDetectionStrategy, inject, OnInit, OnDestroy } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { interval, map, Subject, takeUntil } from 'rxjs';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';
import { ProductService, Product } from '@angular-monorepo-demo/data-access';
import { formatCurrency } from '@angular-monorepo-demo/util';

/**
 * Practical Workshop: Change Detection Profiling — Topic 4 (30 min)
 *
 * TEACHING POINTS:
 * 1. Using Angular DevTools Profiler
 * 2. Browser Performance tab for CD analysis
 * 3. How to identify Default vs OnPush impact
 * 4. Measuring improvement after optimisation
 * 5. Building a "performance-aware" component
 */
@Component({
  selector: 'app-cd-workshop',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="workshop-page">
      <h2>Workshop: Change Detection Profiling <ui-badge variant="info">Block 4 — Topic 4</ui-badge></h2>

      <p class="note">
        Hands-on exercise: use Angular DevTools and browser profiling to diagnose and fix
        change detection performance issues.
      </p>

      <!-- Exercise 1: Profiling Setup -->
      <ui-card title="Exercise 1: Angular DevTools Setup" [elevated]="true">
        <div class="demo-section">
          <div class="steps">
            <div class="step">
              <span class="step-num">1</span>
              <div>
                <strong>Install Angular DevTools</strong>
                <p>Chrome Web Store &gt; "Angular DevTools" &gt; Install extension</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">2</span>
              <div>
                <strong>Open Chrome DevTools (F12)</strong>
                <p>Navigate to the "Angular" tab (appears only on Angular apps)</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">3</span>
              <div>
                <strong>Switch to Profiler</strong>
                <p>Click "Profiler" in the Angular DevTools panel</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">4</span>
              <div>
                <strong>Record a session</strong>
                <p>Click the record button, interact with the app, then stop recording</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">5</span>
              <div>
                <strong>Analyse results</strong>
                <p>Each bar = one CD cycle. Bar height = time. Hover for component details.</p>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Exercise 2: Performance Test Area -->
      <ui-card title="Exercise 2: Live Performance Test Area" [elevated]="true">
        <div class="demo-section">
          <p class="exercise-prompt">
            <strong>Task:</strong> Profile this section with Angular DevTools while interacting.
            Notice how many CD cycles are triggered and which components re-render.
          </p>

          <div class="perf-grid">
            <div class="perf-card">
              <h4>Counter (Signal)</h4>
              <div class="perf-value">{{ counter() }}</div>
              <ui-button variant="primary" size="sm" (clicked)="incrementCounter()">+1</ui-button>
              <p class="perf-note">CD scope: only this component</p>
            </div>
            <div class="perf-card">
              <h4>Timer (interval via toSignal)</h4>
              <div class="perf-value">{{ timer() }}s</div>
              <p class="perf-note">CD triggers every second via signal</p>
            </div>
            <div class="perf-card">
              <h4>Product Count</h4>
              <div class="perf-value">{{ productCount() }}</div>
              <p class="perf-note">Loaded once, computed, no re-render after</p>
            </div>
            <div class="perf-card">
              <h4>Filtered Count</h4>
              <div class="perf-value">{{ filteredCount() }}</div>
              <ui-button variant="secondary" size="sm" (clicked)="toggleFilter()">
                {{ showInStock() ? 'Show All' : 'In Stock Only' }}
              </ui-button>
              <p class="perf-note">Computed recalculates on filter toggle</p>
            </div>
          </div>

          <div class="observation-box">
            <h4>What to Observe in Angular DevTools:</h4>
            <ul>
              <li>Click "+1" — only the counter component should show in the profiler bar</li>
              <li>Timer ticks — the profiler shows a CD cycle each second</li>
              <li>Toggle filter — the computed recalculates, but only relevant bindings update</li>
              <li>Parent components with OnPush are <strong>skipped</strong> if no signals they read changed</li>
            </ul>
          </div>
        </div>
      </ui-card>

      <!-- Exercise 3: Before/After Optimisation -->
      <ui-card title="Exercise 3: Before/After Optimisation" [elevated]="true">
        <div class="demo-section">
          <div class="comparison-grid">
            <div class="compare-col before">
              <h4>BEFORE: Unoptimised Pattern</h4>
              <pre class="code-block">{{ codeBefore }}</pre>
              <div class="metrics-box">
                <div class="metric">
                  <span class="metric-label">Strategy</span>
                  <span class="metric-value bad">Default</span>
                </div>
                <div class="metric">
                  <span class="metric-label">Template calls</span>
                  <span class="metric-value bad">Method getTotal()</span>
                </div>
                <div class="metric">
                  <span class="metric-label">State mgmt</span>
                  <span class="metric-value bad">Mutable object</span>
                </div>
                <div class="metric">
                  <span class="metric-label">CD per tick</span>
                  <span class="metric-value bad">Checks ALL children</span>
                </div>
              </div>
            </div>
            <div class="compare-col after">
              <h4>AFTER: Optimised Pattern</h4>
              <pre class="code-block">{{ codeAfter }}</pre>
              <div class="metrics-box">
                <div class="metric">
                  <span class="metric-label">Strategy</span>
                  <span class="metric-value good">OnPush</span>
                </div>
                <div class="metric">
                  <span class="metric-label">Template calls</span>
                  <span class="metric-value good">computed() signal</span>
                </div>
                <div class="metric">
                  <span class="metric-label">State mgmt</span>
                  <span class="metric-value good">Immutable signal</span>
                </div>
                <div class="metric">
                  <span class="metric-label">CD per tick</span>
                  <span class="metric-value good">Only dirty components</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Exercise 4: Browser Performance Tab -->
      <ui-card title="Exercise 4: Browser Performance Tab" [elevated]="true">
        <div class="demo-section">
          <div class="steps">
            <div class="step">
              <span class="step-num">1</span>
              <div>
                <strong>Open Chrome DevTools &gt; Performance tab</strong>
                <p>Enable "Screenshots" and "Web Vitals" checkboxes</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">2</span>
              <div>
                <strong>Click Record, then interact with the app for 5 seconds</strong>
                <p>Click buttons, scroll, filter products — generate activity</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">3</span>
              <div>
                <strong>Stop recording and examine the flame chart</strong>
                <p>Look for "ApplicationRef.tick" in the Scripting section — this is CD</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">4</span>
              <div>
                <strong>Check "Bottom-Up" tab for hotspots</strong>
                <p>Sort by "Self Time" to find the most expensive operations</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">5</span>
              <div>
                <strong>Compare before and after optimisation</strong>
                <p>After switching to OnPush + signals, tick time should decrease significantly</p>
              </div>
            </div>
          </div>

          <div class="profiling-target">
            <h4>Profiling Target — Heavy List Rendering</h4>
            <p>{{ products().length }} products loaded | Filtered: {{ filteredProducts().length }} | Total value: {{ totalValue() }}</p>
            <div class="product-list">
              @for (p of filteredProducts(); track p.id) {
                <div class="product-row" [class.out-of-stock]="!p.inStock">
                  <span>{{ p.name }}</span>
                  <span>{{ formatPrice(p.price) }}</span>
                  <ui-badge [variant]="p.inStock ? 'success' : 'danger'">
                    {{ p.inStock ? 'In Stock' : 'Out' }}
                  </ui-badge>
                </div>
              }
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Summary Checklist -->
      <ui-card title="Optimisation Checklist" [elevated]="true">
        <div class="demo-section">
          <div class="checklist">
            <label class="check-item">
              <input type="checkbox" />
              <span>All components use <code>ChangeDetectionStrategy.OnPush</code></span>
            </label>
            <label class="check-item">
              <input type="checkbox" />
              <span>No method/getter calls in templates — use <code>computed()</code> instead</span>
            </label>
            <label class="check-item">
              <input type="checkbox" />
              <span>State managed via <code>signal()</code> — immutable updates only</span>
            </label>
            <label class="check-item">
              <input type="checkbox" />
              <span>Heavy lists use <code>&#64;for</code> with <code>track</code> expression</span>
            </label>
            <label class="check-item">
              <input type="checkbox" />
              <span>No unnecessary <code>detectChanges()</code> calls</span>
            </label>
            <label class="check-item">
              <input type="checkbox" />
              <span>Third-party callbacks wrapped with <code>signal.set()</code> or <code>NgZone.run()</code></span>
            </label>
            <label class="check-item">
              <input type="checkbox" />
              <span>Custom equality functions on signals with object/array values</span>
            </label>
            <label class="check-item">
              <input type="checkbox" />
              <span>Profiled with Angular DevTools — no unnecessary CD cycles remain</span>
            </label>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .workshop-page { padding: 0.5rem; }
    .note { background: #e8f5e9; border: 1px solid #c8e6c9; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .exercise-prompt { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; font-size: 0.9rem; }
    .steps { display: flex; flex-direction: column; gap: 0.5rem; margin: 0.5rem 0; }
    .step { display: flex; gap: 0.75rem; align-items: flex-start; padding: 0.75rem; background: #f5f5f5; border-radius: 8px; }
    .step-num { background: #42a5f5; color: white; min-width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 0.85rem; flex-shrink: 0; }
    .step p { margin: 0.25rem 0 0; font-size: 0.82rem; color: #777; }
    .step strong { color: #2c3e50; }
    .perf-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin: 1rem 0; }
    .perf-card { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 1rem; text-align: center; }
    .perf-card h4 { margin: 0 0 0.5rem; font-size: 0.88rem; color: #2c3e50; }
    .perf-value { font-size: 2rem; font-weight: 700; color: #1565c0; margin: 0.25rem 0; }
    .perf-note { font-size: 0.75rem; color: #999; margin-top: 0.5rem; }
    .observation-box { background: #fff8e1; border: 1px solid #ffe082; border-radius: 8px; padding: 1rem; margin-top: 1rem; }
    .observation-box h4 { margin: 0 0 0.5rem; font-size: 0.9rem; }
    .observation-box ul { padding-left: 1.25rem; font-size: 0.85rem; color: #555; }
    .observation-box li { margin: 0.3rem 0; }
    .comparison-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .compare-col { border: 2px solid #e0e0e0; border-radius: 12px; padding: 1rem; }
    .compare-col.before { border-color: #ef5350; background: #ffebee; }
    .compare-col.after { border-color: #66bb6a; background: #e8f5e9; }
    .compare-col h4 { margin: 0 0 0.5rem; font-size: 0.9rem; }
    .metrics-box { margin-top: 0.5rem; }
    .metric { display: flex; justify-content: space-between; padding: 0.4rem 0; border-bottom: 1px solid rgba(0,0,0,0.08); font-size: 0.85rem; }
    .metric-label { color: #777; }
    .metric-value { font-weight: 600; }
    .metric-value.bad { color: #d32f2f; }
    .metric-value.good { color: #2e7d32; }
    .profiling-target { background: #f5f5f5; border-radius: 8px; padding: 1rem; margin-top: 1rem; }
    .profiling-target h4 { margin: 0 0 0.5rem; font-size: 0.9rem; }
    .profiling-target p { font-size: 0.85rem; color: #555; margin-bottom: 0.5rem; }
    .product-list { max-height: 200px; overflow-y: auto; }
    .product-row { display: flex; justify-content: space-between; align-items: center; padding: 0.4rem 0.5rem; border-bottom: 1px solid #e0e0e0; font-size: 0.85rem; }
    .product-row.out-of-stock { opacity: 0.5; }
    .checklist { display: flex; flex-direction: column; gap: 0.5rem; }
    .check-item { display: flex; align-items: center; gap: 0.5rem; padding: 0.5rem; background: #f5f5f5; border-radius: 8px; cursor: pointer; font-size: 0.88rem; }
    .check-item:hover { background: #e8f5e9; }
    .check-item code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.82rem; }
    .check-item input[type="checkbox"] { width: 18px; height: 18px; accent-color: #42a5f5; }
  `]
})
export class CdWorkshopComponent {
  private productService = inject(ProductService);

  // ═══════════ CODE EXAMPLES ═══════════
  codeBefore = `// BEFORE: Unoptimised
@Component({
  // No changeDetection specified = Default
  template: \`
    <div>Total: {{ getTotal() }}</div>
    <div *ngFor="let p of products">
      {{ p.name }} - {{ p.price }}
    </div>
  \`
})
export class ListComponent {
  products: Product[] = [];
  getTotal() { // runs EVERY CD cycle!
    return this.products.reduce(
      (s, p) => s + p.price, 0);
  }
}`;

  codeAfter = `// AFTER: Optimised
@Component({
  changeDetection: OnPush,
  template: \`
    <div>Total: {{ total() }}</div>
    @for (p of products(); track p.id) {
      {{ p.name }} - {{ p.price }}
    }
  \`
})
export class ListComponent {
  products = toSignal(svc.getProducts(),
    { initialValue: [] });
  total = computed(() =>
    this.products().reduce(
      (s, p) => s + p.price, 0));
}`;

  // ═══════════ DEMO STATE ═══════════
  counter = signal(0);
  timer = toSignal(interval(1000), { initialValue: 0 });
  showInStock = signal(false);

  private allProducts = toSignal(this.productService.getProducts(), { initialValue: [] as Product[] });

  products = computed(() => this.allProducts());
  productCount = computed(() => this.products().length);

  filteredProducts = computed(() => {
    const all = this.products();
    if (this.showInStock()) {
      return all.filter(p => p.inStock);
    }
    return all;
  });

  filteredCount = computed(() => this.filteredProducts().length);
  totalValue = computed(() => formatCurrency(this.filteredProducts().reduce((sum, p) => sum + p.price, 0)));

  incrementCounter(): void {
    this.counter.update(v => v + 1);
  }

  toggleFilter(): void {
    this.showInStock.update(v => !v);
  }

  formatPrice(price: number): string {
    return formatCurrency(price);
  }
}
