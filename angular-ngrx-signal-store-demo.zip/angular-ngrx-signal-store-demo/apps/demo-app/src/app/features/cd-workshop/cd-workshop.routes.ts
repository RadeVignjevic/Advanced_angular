import { Route } from '@angular/router';
import { CdWorkshopComponent } from './cd-workshop.component';

export const CD_WORKSHOP_ROUTES: Route[] = [
  { path: '', component: CdWorkshopComponent }
];
