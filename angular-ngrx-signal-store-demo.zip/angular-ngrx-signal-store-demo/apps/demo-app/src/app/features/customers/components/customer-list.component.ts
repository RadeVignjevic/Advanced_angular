import { Component, inject, signal, OnInit } from '@angular/core';
import { CustomerService, Customer } from '@angular-monorepo-demo/data-access';
import { UiDataTableComponent, UiBadgeComponent, TableColumn } from '@angular-monorepo-demo/shared-ui';

@Component({
  selector: 'app-customer-list',
  imports: [UiDataTableComponent, UiBadgeComponent],
  template: `
    <h2>Customers <ui-badge variant="success">Standalone (Migrated)</ui-badge></h2>
    <p class="note">This feature was migrated from NgModule to standalone in Block 1.</p>
    <ui-data-table [data]="customers()" [columns]="columns" />
  `,
  styles: [`.note { background: #d4edda; border: 1px solid #c3e6cb; padding: 0.5rem; border-radius: 6px; font-size: 0.85rem; margin-bottom: 1rem; }`]
})
export class CustomerListComponent implements OnInit {
  private customerService = inject(CustomerService);
  customers = signal<Customer[]>([]);

  columns: TableColumn[] = [
    { key: 'firstName', header: 'First Name' },
    { key: 'lastName', header: 'Last Name' },
    { key: 'email', header: 'Email' },
    { key: 'tier', header: 'Tier', transform: (v) => (v as string).toUpperCase() },
    { key: 'totalOrders', header: 'Orders' }
  ];

  ngOnInit(): void {
    this.customerService.getCustomers().subscribe(c => this.customers.set(c));
  }
}
