import { Routes } from '@angular/router';
import { CustomerListComponent } from './components/customer-list.component';

export const CUSTOMER_ROUTES: Routes = [
  { path: '', component: CustomerListComponent }
];
