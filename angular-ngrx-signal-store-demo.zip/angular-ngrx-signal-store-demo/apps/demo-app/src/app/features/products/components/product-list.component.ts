import { Component, inject, signal, OnInit } from '@angular/core';
import { ProductService, Product } from '@angular-monorepo-demo/data-access';
import { UiDataTableComponent, UiButtonComponent, UiBadgeComponent, TableColumn } from '@angular-monorepo-demo/shared-ui';
import { formatCurrency } from '@angular-monorepo-demo/util';

@Component({
  selector: 'app-product-list',
  imports: [UiDataTableComponent, UiButtonComponent, UiBadgeComponent],
  template: `
    <h2>Products <ui-badge variant="success">Standalone</ui-badge></h2>
    <div class="filters">
      @for (cat of categories; track cat) {
        <ui-button
          [variant]="selectedCategory === cat ? 'primary' : 'ghost'"
          size="sm"
          (clicked)="filter(cat)">{{ cat }}</ui-button>
      }
      <ui-button variant="secondary" size="sm" (clicked)="clearFilter()">All</ui-button>
    </div>
    <ui-data-table [data]="filteredProducts()" [columns]="columns" (rowClicked)="onRowClick($event)" />
  `,
  styles: [`.filters { display: flex; gap: 0.5rem; margin: 1rem 0; flex-wrap: wrap; }`]
})
export class ProductListComponent implements OnInit {
  private productService = inject(ProductService);

  products = signal<Product[]>([]);
  filteredProducts = signal<Product[]>([]);
  categories: string[] = [];
  selectedCategory: string | null = null;

  columns: TableColumn[] = [
    { key: 'name', header: 'Name' },
    { key: 'price', header: 'Price', transform: (v) => formatCurrency(v as number) },
    { key: 'category', header: 'Category' },
    { key: 'inStock', header: 'Status', transform: (v) => v ? '✓ In Stock' : '✗ Out of Stock' }
  ];

  ngOnInit(): void {
    this.categories = this.productService.getCategories();
    this.productService.getProducts().subscribe(p => {
      this.products.set(p);
      this.filteredProducts.set(p);
    });
  }

  filter(cat: string): void {
    this.selectedCategory = cat;
    this.filteredProducts.set(this.products().filter(p => p.category === cat));
  }

  clearFilter(): void {
    this.selectedCategory = null;
    this.filteredProducts.set(this.products());
  }

  onRowClick(row: Product): void {
    console.log('Product clicked:', row);
  }
}
