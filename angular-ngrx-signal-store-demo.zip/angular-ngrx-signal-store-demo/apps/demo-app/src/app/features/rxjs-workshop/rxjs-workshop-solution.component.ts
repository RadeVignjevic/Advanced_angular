import { Component, inject, signal, computed } from '@angular/core';
import { toSignal, toObservable } from '@angular/core/rxjs-interop';
import { debounceTime, distinctUntilChanged, switchMap, of, delay, map } from 'rxjs';
import { RouterLink } from '@angular/router';
import { ProductService, Product } from '@angular-monorepo-demo/data-access';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent, UiDataTableComponent, TableColumn } from '@angular-monorepo-demo/shared-ui';
import { formatCurrency } from '@angular-monorepo-demo/util';

/**
 * ╔═══════════════════════════════════════════════════════════════╗
 * ║  WORKSHOP SOLUTION: Signal-Based Product Dashboard            ║
 * ║                                                               ║
 * ║  This is the AFTER state — refactored from RxJS to Signals.   ║
 * ║  Compare with rxjs-workshop.component.ts to see the diff.     ║
 * ╚═══════════════════════════════════════════════════════════════╝
 *
 * WHAT CHANGED:
 * ✅ BehaviorSubjects → signal()
 * ✅ combineLatest+map → computed()
 * ✅ AsyncPipe removed — signals used directly
 * ✅ takeUntil/destroy$ removed — signals auto-cleanup
 * ✅ ngOnInit subscription → toSignal()
 * ✅ Debounced search → toObservable() + pipeline + toSignal()
 */
@Component({
  selector: 'app-rxjs-workshop-solution',
  imports: [RouterLink, UiCardComponent, UiBadgeComponent, UiButtonComponent, UiDataTableComponent],
  template: `
    <div class="workshop-page">
      <h2>Workshop Solution: Signal Dashboard <ui-badge variant="success">AFTER — Signals!</ui-badge></h2>

      <p class="success-note">
        ✅ <strong>REFACTORED:</strong> This component uses Angular Signals instead of RxJS BehaviorSubjects.
        Compare with the <a routerLink="/workshop">Before (RxJS)</a> version.
      </p>

      <!-- Diff Summary -->
      <ui-card title="📊 Refactoring Summary" [elevated]="true">
        <div class="diff-grid">
          <div class="diff-item removed">
            <h4>Removed</h4>
            <ul>
              <li><code>BehaviorSubject</code> × 5</li>
              <li><code>combineLatest</code></li>
              <li><code>AsyncPipe</code></li>
              <li><code>takeUntil / destroy$</code></li>
              <li><code>ngOnInit</code> / <code>ngOnDestroy</code></li>
              <li><code>Subject</code> import</li>
            </ul>
          </div>
          <div class="diff-item added">
            <h4>Added</h4>
            <ul>
              <li><code>signal()</code> × 4</li>
              <li><code>computed()</code> × 5</li>
              <li><code>toSignal()</code> × 1</li>
              <li><code>toObservable()</code> × 1</li>
            </ul>
          </div>
          <div class="diff-item metric">
            <h4>Impact</h4>
            <ul>
              <li>~40% less code</li>
              <li>No manual cleanup</li>
              <li>No async pipe</li>
              <li>Synchronous reads</li>
            </ul>
          </div>
        </div>
      </ui-card>

      <!-- Stats — direct signal() reads, no | async -->
      <div class="stats-row">
        <ui-card title="Total Products" [elevated]="true">
          <div class="stat-value">{{ totalCount() }}</div>
        </ui-card>
        <ui-card title="Filtered" [elevated]="true">
          <div class="stat-value">{{ filteredCount() }}</div>
        </ui-card>
        <ui-card title="In Stock" [elevated]="true">
          <div class="stat-value">{{ inStockCount() }}</div>
        </ui-card>
        <ui-card title="Total Value" [elevated]="true">
          <div class="stat-value">{{ totalValue() }}</div>
        </ui-card>
      </div>

      <!-- Filters — signal.set() instead of subject.next() -->
      <ui-card title="Filters" [elevated]="true">
        <div class="filter-row">
          <div class="filter-group">
            <label>Search:</label>
            <input
              [value]="searchTerm()"
              (input)="searchTerm.set(getInputValue($event))"
              placeholder="Search by name..."
              class="filter-input"
            />
          </div>
          <div class="filter-group">
            <label>Category:</label>
            <div class="category-buttons">
              @for (cat of categories(); track cat) {
                <ui-button
                  [variant]="selectedCategory() === cat ? 'primary' : 'ghost'"
                  size="sm"
                  (clicked)="selectedCategory.set(cat)">{{ cat }}</ui-button>
              }
              <ui-button variant="secondary" size="sm" (clicked)="selectedCategory.set(null)">All</ui-button>
            </div>
          </div>
          <div class="filter-group">
            <label>Stock:</label>
            <ui-button
              [variant]="showInStockOnly() ? 'primary' : 'ghost'"
              size="sm"
              (clicked)="toggleInStock()">In Stock Only</ui-button>
          </div>
        </div>
      </ui-card>

      <!-- Data Table — filteredProducts() instead of (filteredProducts$ | async) -->
      <ui-card title="Products" [elevated]="true">
        <ui-data-table
          [data]="filteredProducts()"
          [columns]="columns"
          (rowClicked)="selectedProduct.set($event)" />
      </ui-card>

      <!-- Selected Product -->
      @if (selectedProduct(); as product) {
        <ui-card title="Selected Product" [elevated]="true">
          <div class="product-detail">
            <h3>{{ product.name }}</h3>
            <p>{{ product.description }}</p>
            <ui-badge [variant]="product.inStock ? 'success' : 'danger'">
              {{ product.inStock ? 'In Stock' : 'Out of Stock' }}
            </ui-badge>
            <span class="price">{{ formatPrice(product.price) }}</span>
          </div>
        </ui-card>
      }
    </div>
  `,
  styles: [`
    .workshop-page { padding: 0.5rem; }
    .success-note { background: #d4edda; border: 2px solid #c3e6cb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .success-note a { color: #007bff; text-decoration: underline; }
    .diff-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; }
    .diff-item { padding: 0.75rem; border-radius: 8px; }
    .diff-item h4 { margin: 0 0 0.5rem 0; }
    .diff-item ul { margin: 0; padding-left: 1.2rem; font-size: 0.85rem; }
    .diff-item li { margin: 0.2rem 0; }
    .diff-item code { background: rgba(0,0,0,0.08); padding: 0.1rem 0.3rem; border-radius: 3px; font-size: 0.8rem; }
    .diff-item.removed { background: #f8d7da; border: 1px solid #f5c6cb; }
    .diff-item.added { background: #d4edda; border: 1px solid #c3e6cb; }
    .diff-item.metric { background: #d1ecf1; border: 1px solid #bee5eb; }
    .stats-row { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem; margin: 1rem 0; }
    .stat-value { font-size: 2rem; font-weight: 700; color: #2c3e50; text-align: center; }
    .filter-row { display: flex; flex-direction: column; gap: 1rem; }
    .filter-group { display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap; }
    .filter-group label { font-weight: 600; min-width: 80px; font-size: 0.9rem; }
    .filter-input { padding: 0.4rem 0.75rem; border: 1px solid #ddd; border-radius: 4px; min-width: 200px; }
    .category-buttons { display: flex; gap: 0.4rem; flex-wrap: wrap; }
    .product-detail { display: flex; flex-direction: column; gap: 0.5rem; }
    .product-detail h3 { margin: 0; }
    .product-detail p { margin: 0; color: #666; }
    .price { font-size: 1.2rem; font-weight: 700; color: #27ae60; }
  `]
})
export class RxjsWorkshopSolutionComponent {
  private productService = inject(ProductService);

  // ═══════════ STATE — signal() replaces BehaviorSubject ═══════════

  // ✅ toSignal() replaces manual subscription + ngOnInit
  private products = toSignal(this.productService.getProducts(), { initialValue: [] as Product[] });

  // ✅ signal() replaces BehaviorSubject
  searchTerm = signal('');
  selectedCategory = signal<string | null>(null);
  showInStockOnly = signal(false);
  selectedProduct = signal<Product | null>(null);

  // ═══════════ DERIVED STATE — computed() replaces combineLatest ═══════════

  // ✅ computed() replaces combineLatest([products$, searchTerm$, category$, inStock$]).pipe(map(...))
  filteredProducts = computed(() => {
    let filtered = this.products();
    const search = this.searchTerm().toLowerCase();
    const category = this.selectedCategory();
    const inStockOnly = this.showInStockOnly();

    if (search) {
      filtered = filtered.filter(p => p.name.toLowerCase().includes(search));
    }
    if (category) {
      filtered = filtered.filter(p => p.category === category);
    }
    if (inStockOnly) {
      filtered = filtered.filter(p => p.inStock);
    }
    return filtered;
  });

  // ✅ computed() replaces .pipe(map(...))
  categories = computed(() => [...new Set(this.products().map(p => p.category))]);
  totalCount = computed(() => this.products().length);
  filteredCount = computed(() => this.filteredProducts().length);
  inStockCount = computed(() => this.products().filter(p => p.inStock).length);
  totalValue = computed(() => formatCurrency(this.products().reduce((sum, p) => sum + p.price, 0)));

  // ═══════════ TABLE CONFIG (unchanged) ═══════════
  columns: TableColumn[] = [
    { key: 'name', header: 'Name' },
    { key: 'price', header: 'Price', transform: (v) => formatCurrency(v as number) },
    { key: 'category', header: 'Category' },
    { key: 'inStock', header: 'Status', transform: (v) => v ? '✓ In Stock' : '✗ Out' }
  ];

  toggleInStock(): void {
    this.showInStockOnly.update(v => !v);
  }

  getInputValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  formatPrice(price: number): string {
    return formatCurrency(price);
  }

  // ✅ No ngOnInit, no ngOnDestroy, no destroy$, no takeUntil!
}
