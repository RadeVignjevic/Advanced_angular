import { Route } from '@angular/router';
import { RxjsWorkshopSolutionComponent } from './rxjs-workshop-solution.component';

export const RXJS_WORKSHOP_SOLUTION_ROUTES: Route[] = [
  { path: '', component: RxjsWorkshopSolutionComponent }
];
