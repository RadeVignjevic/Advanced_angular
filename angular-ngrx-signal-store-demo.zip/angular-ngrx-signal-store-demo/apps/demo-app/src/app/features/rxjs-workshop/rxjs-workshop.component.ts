import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subject, Observable, combineLatest, map, takeUntil, debounceTime, distinctUntilChanged, startWith } from 'rxjs';
import { AsyncPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductService, Product } from '@angular-monorepo-demo/data-access';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent, UiDataTableComponent, TableColumn } from '@angular-monorepo-demo/shared-ui';
import { formatCurrency } from '@angular-monorepo-demo/util';

/**
 * ╔═══════════════════════════════════════════════════════════════╗
 * ║  WORKSHOP EXERCISE: RxJS → Signals Refactoring               ║
 * ║                                                               ║
 * ║  This is the BEFORE state — heavy RxJS implementation.        ║
 * ║  Students should refactor this to use Signals.                ║
 * ║                                                               ║
 * ║  See rxjs-workshop-solution.component.ts for the answer.      ║
 * ╚═══════════════════════════════════════════════════════════════╝
 *
 * REFACTORING TARGETS:
 * 1. Replace BehaviorSubjects with signal()
 * 2. Replace combineLatest+map with computed()
 * 3. Replace manual subscriptions with toSignal() or direct signal reads
 * 4. Remove takeUntil/destroy$ pattern (signals auto-cleanup)
 * 5. Remove AsyncPipe (use signal() directly in template)
 */
@Component({
  selector: 'app-rxjs-workshop',
  imports: [AsyncPipe, RouterLink, UiCardComponent, UiBadgeComponent, UiButtonComponent, UiDataTableComponent],
  template: `
    <div class="workshop-page">
      <h2>Workshop: RxJS Product Dashboard <ui-badge variant="danger">BEFORE — Refactor Me!</ui-badge></h2>

      <p class="warning-note">
        ⚠️ <strong>EXERCISE:</strong> This component uses RxJS BehaviorSubjects, combineLatest,
        and manual subscriptions. Refactor it to use Angular Signals!
        See the <a routerLink="/workshop-solution">Solution</a> when done.
      </p>

      <!-- Stats -->
      <div class="stats-row">
        <ui-card title="Total Products" [elevated]="true">
          <div class="stat-value">{{ totalCount$ | async }}</div>
        </ui-card>
        <ui-card title="Filtered" [elevated]="true">
          <div class="stat-value">{{ filteredCount$ | async }}</div>
        </ui-card>
        <ui-card title="In Stock" [elevated]="true">
          <div class="stat-value">{{ inStockCount$ | async }}</div>
        </ui-card>
        <ui-card title="Total Value" [elevated]="true">
          <div class="stat-value">{{ totalValue$ | async }}</div>
        </ui-card>
      </div>

      <!-- Filters -->
      <ui-card title="Filters" [elevated]="true">
        <div class="filter-row">
          <div class="filter-group">
            <label>Search:</label>
            <input
              [value]="(searchTerm$ | async) ?? ''"
              (input)="onSearchInput($event)"
              placeholder="Search by name..."
              class="filter-input"
            />
          </div>
          <div class="filter-group">
            <label>Category:</label>
            <div class="category-buttons">
              @for (cat of categories; track cat) {
                <ui-button
                  [variant]="(selectedCategory$ | async) === cat ? 'primary' : 'ghost'"
                  size="sm"
                  (clicked)="selectCategory(cat)">{{ cat }}</ui-button>
              }
              <ui-button variant="secondary" size="sm" (clicked)="clearCategory()">All</ui-button>
            </div>
          </div>
          <div class="filter-group">
            <label>Stock:</label>
            <ui-button
              [variant]="(showInStockOnly$ | async) ? 'primary' : 'ghost'"
              size="sm"
              (clicked)="toggleInStock()">In Stock Only</ui-button>
          </div>
        </div>
      </ui-card>

      <!-- Data Table -->
      <ui-card title="Products" [elevated]="true">
        <ui-data-table
          [data]="(filteredProducts$ | async) ?? []"
          [columns]="columns"
          (rowClicked)="onRowClick($event)" />
      </ui-card>

      <!-- Selected Product Detail -->
      @if (selectedProduct$ | async; as product) {
        <ui-card title="Selected Product" [elevated]="true">
          <div class="product-detail">
            <h3>{{ product.name }}</h3>
            <p>{{ product.description }}</p>
            <ui-badge [variant]="product.inStock ? 'success' : 'danger'">
              {{ product.inStock ? 'In Stock' : 'Out of Stock' }}
            </ui-badge>
            <span class="price">{{ formatPrice(product.price) }}</span>
          </div>
        </ui-card>
      }

      <!-- Refactoring Checklist -->
      <ui-card title="📝 Refactoring Checklist" [elevated]="true">
        <div class="checklist">
          <label><input type="checkbox" /> Replace <code>BehaviorSubject</code>s with <code>signal()</code></label>
          <label><input type="checkbox" /> Replace <code>combineLatest + map</code> with <code>computed()</code></label>
          <label><input type="checkbox" /> Remove <code>AsyncPipe</code> — use <code>signal()</code> in template</label>
          <label><input type="checkbox" /> Remove <code>takeUntil / destroy$</code> pattern</label>
          <label><input type="checkbox" /> Replace <code>ngOnInit</code> subscription with <code>toSignal()</code></label>
          <label><input type="checkbox" /> Use <code>toObservable()</code> for the debounced search pipeline</label>
          <label><input type="checkbox" /> Compare with solution to verify</label>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .workshop-page { padding: 0.5rem; }
    .warning-note { background: #f8d7da; border: 2px solid #f5c6cb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .warning-note a { color: #007bff; text-decoration: underline; }
    .stats-row { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem; margin: 1rem 0; }
    .stat-value { font-size: 2rem; font-weight: 700; color: #2c3e50; text-align: center; }
    .filter-row { display: flex; flex-direction: column; gap: 1rem; }
    .filter-group { display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap; }
    .filter-group label { font-weight: 600; min-width: 80px; font-size: 0.9rem; }
    .filter-input { padding: 0.4rem 0.75rem; border: 1px solid #ddd; border-radius: 4px; min-width: 200px; }
    .category-buttons { display: flex; gap: 0.4rem; flex-wrap: wrap; }
    .product-detail { display: flex; flex-direction: column; gap: 0.5rem; }
    .product-detail h3 { margin: 0; }
    .product-detail p { margin: 0; color: #666; }
    .price { font-size: 1.2rem; font-weight: 700; color: #27ae60; }
    .checklist { display: flex; flex-direction: column; gap: 0.75rem; }
    .checklist label { display: flex; align-items: center; gap: 0.5rem; font-size: 0.9rem; cursor: pointer; }
    .checklist code { background: #e9ecef; padding: 0.1rem 0.3rem; border-radius: 3px; font-size: 0.8rem; }
  `]
})
export class RxjsWorkshopComponent implements OnInit, OnDestroy {
  private productService = inject(ProductService);
  private destroy$ = new Subject<void>();

  // ── ALL STATE AS BEHAVIORSUBJECTS (refactor target!) ──
  private products$ = new BehaviorSubject<Product[]>([]);
  searchTerm$ = new BehaviorSubject<string>('');
  selectedCategory$ = new BehaviorSubject<string | null>(null);
  showInStockOnly$ = new BehaviorSubject<boolean>(false);
  selectedProduct$ = new BehaviorSubject<Product | null>(null);

  categories: string[] = [];

  // ── DERIVED STATE VIA COMBINELATEST (refactor to computed!) ──
  filteredProducts$: Observable<Product[]> = combineLatest([
    this.products$,
    this.searchTerm$.pipe(debounceTime(200), distinctUntilChanged()),
    this.selectedCategory$,
    this.showInStockOnly$
  ]).pipe(
    map(([products, search, category, inStockOnly]) => {
      let filtered = products;
      if (search) {
        filtered = filtered.filter(p =>
          p.name.toLowerCase().includes(search.toLowerCase())
        );
      }
      if (category) {
        filtered = filtered.filter(p => p.category === category);
      }
      if (inStockOnly) {
        filtered = filtered.filter(p => p.inStock);
      }
      return filtered;
    })
  );

  totalCount$ = this.products$.pipe(map(p => p.length));
  filteredCount$ = this.filteredProducts$.pipe(map(p => p.length));
  inStockCount$ = this.products$.pipe(map(p => p.filter(x => x.inStock).length));
  totalValue$ = this.products$.pipe(
    map(p => formatCurrency(p.reduce((sum, x) => sum + x.price, 0)))
  );

  columns: TableColumn[] = [
    { key: 'name', header: 'Name' },
    { key: 'price', header: 'Price', transform: (v) => formatCurrency(v as number) },
    { key: 'category', header: 'Category' },
    { key: 'inStock', header: 'Status', transform: (v) => v ? '✓ In Stock' : '✗ Out' }
  ];

  ngOnInit(): void {
    this.productService.getProducts()
      .pipe(takeUntil(this.destroy$))
      .subscribe(products => {
        this.products$.next(products);
        this.categories = [...new Set(products.map(p => p.category))];
      });
  }

  onSearchInput(event: Event): void {
    this.searchTerm$.next((event.target as HTMLInputElement).value);
  }

  selectCategory(category: string): void {
    this.selectedCategory$.next(category);
  }

  clearCategory(): void {
    this.selectedCategory$.next(null);
  }

  toggleInStock(): void {
    this.showInStockOnly$.next(!this.showInStockOnly$.value);
  }

  onRowClick(product: Product): void {
    this.selectedProduct$.next(product);
  }

  formatPrice(price: number): string {
    return formatCurrency(price);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
