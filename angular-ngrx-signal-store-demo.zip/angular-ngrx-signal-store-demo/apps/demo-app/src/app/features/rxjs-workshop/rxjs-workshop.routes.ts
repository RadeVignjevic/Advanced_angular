import { Route } from '@angular/router';
import { RxjsWorkshopComponent } from './rxjs-workshop.component';

export const RXJS_WORKSHOP_ROUTES: Route[] = [
  { path: '', component: RxjsWorkshopComponent }
];
