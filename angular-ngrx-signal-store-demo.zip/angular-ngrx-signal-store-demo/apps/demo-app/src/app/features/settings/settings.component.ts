import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';
import { SettingsService } from './settings.service';

@Component({
  selector: 'app-settings',
  imports: [FormsModule, UiCardComponent, UiBadgeComponent],
  template: `
    <h2>Settings <ui-badge variant="info">Route-Level Providers</ui-badge></h2>
    <p class="note">SettingsService is provided at the route level — it resets when you navigate away.</p>

    <ui-card title="Application Settings" [elevated]="true">
      <div class="settings-grid">
        @for (s of settingsService.allSettings(); track s.key) {
          <div class="setting-row">
            <label>{{ s.key }}</label>
            <input [ngModel]="s.value" (ngModelChange)="settingsService.updateSetting(s.key, $event)" />
          </div>
        }
      </div>
    </ui-card>
  `,
  styles: [`
    .note { background: #d1ecf1; border: 1px solid #bee5eb; padding: 0.5rem; border-radius: 6px; font-size: 0.85rem; margin-bottom: 1rem; }
    .settings-grid { display: grid; gap: 0.75rem; }
    .setting-row { display: flex; align-items: center; gap: 1rem; }
    .setting-row label { font-weight: 600; width: 140px; text-transform: capitalize; }
    .setting-row input { flex: 1; padding: 0.4rem; border: 1px solid #dee2e6; border-radius: 6px; }
  `]
})
export class SettingsComponent {
  protected settingsService = inject(SettingsService);
}
