import { Routes } from '@angular/router';
import { SettingsComponent } from './settings.component';
import { SettingsService } from './settings.service';

export const SETTINGS_ROUTES: Routes = [
  {
    path: '',
    component: SettingsComponent,
    providers: [SettingsService] // Route-level provider
  }
];
