import { Injectable, signal, computed } from '@angular/core';

@Injectable()
export class SettingsService {
  private settings = signal<Record<string, string>>({
    theme: 'light', language: 'en', pageSize: '10',
    notifications: 'enabled', dateFormat: 'MM/dd/yyyy'
  });

  allSettings = computed(() =>
    Object.entries(this.settings()).map(([key, value]) => ({ key, value }))
  );

  updateSetting(key: string, value: string): void {
    this.settings.update(s => ({ ...s, [key]: value }));
  }
}
