import { Component, signal, computed, effect, ChangeDetectionStrategy, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { interval, map } from 'rxjs';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';
import { ProductService, Product } from '@angular-monorepo-demo/data-access';

/**
 * Signal-Driven Change Detection — Topic 2 (30 min)
 *
 * TEACHING POINTS:
 * 1. How signals mark components dirty automatically
 * 2. Fine-grained reactivity — only signal-reading components update
 * 3. OnPush + Signals = optimal performance with zero boilerplate
 * 4. Computed signals and their memoisation behaviour
 * 5. Signal equality checks preventing unnecessary re-renders
 */
@Component({
  selector: 'app-signal-driven-cd',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="signal-cd-page">
      <h2>Signal-Driven Change Detection <ui-badge variant="info">Block 4 — Topic 2</ui-badge></h2>

      <p class="note">
        Signals automatically <strong>mark components dirty</strong> when their value changes.
        Combined with OnPush, this gives fine-grained reactivity with zero extra work.
      </p>

      <!-- 1. How Signals Trigger CD -->
      <ui-card title="1. How Signals Mark Components Dirty" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeSignalCd }}</pre>

          <div class="demo-row">
            <div class="signal-viz">
              <div class="signal-node">
                <span class="signal-label">signal()</span>
                <span class="signal-value">count = {{ count() }}</span>
              </div>
              <div class="arrow">notifies</div>
              <div class="signal-node framework">
                <span class="signal-label">Angular Framework</span>
                <span class="signal-value">markForCheck() auto-called</span>
              </div>
              <div class="arrow">schedules</div>
              <div class="signal-node cd">
                <span class="signal-label">Change Detection</span>
                <span class="signal-value">re-renders template</span>
              </div>
            </div>
          </div>

          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="incrementCount()">count.set(count + 1)</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="count.set(0)">Reset</ui-button>
            <span class="value-display">Render count: <strong>{{ renderTracker() }}</strong></span>
          </div>

          <div class="explanation">
            <p>When you call <code>count.set()</code> or <code>count.update()</code>,
            Angular automatically runs the equivalent of <code>markForCheck()</code>
            on every component that reads <code>count()</code> in its template.</p>
          </div>
        </div>
      </ui-card>

      <!-- 2. Fine-Grained Reactivity -->
      <ui-card title="2. Fine-Grained Reactivity — Only What Changed" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeFineGrained }}</pre>

          <div class="reactivity-grid">
            <div class="reactivity-card" [class.active]="lastUpdated() === 'firstName'">
              <h4>Component A</h4>
              <p>Reads: firstName()</p>
              <div class="current-val">{{ firstName() }}</div>
              <ui-badge [variant]="lastUpdated() === 'firstName' ? 'success' : 'neutral'">
                {{ lastUpdated() === 'firstName' ? 'RE-RENDERED' : 'Idle' }}
              </ui-badge>
            </div>
            <div class="reactivity-card" [class.active]="lastUpdated() === 'lastName'">
              <h4>Component B</h4>
              <p>Reads: lastName()</p>
              <div class="current-val">{{ lastName() }}</div>
              <ui-badge [variant]="lastUpdated() === 'lastName' ? 'success' : 'neutral'">
                {{ lastUpdated() === 'lastName' ? 'RE-RENDERED' : 'Idle' }}
              </ui-badge>
            </div>
            <div class="reactivity-card" [class.active]="lastUpdated() !== ''">
              <h4>Component C</h4>
              <p>Reads: fullName() — computed</p>
              <div class="current-val">{{ fullName() }}</div>
              <ui-badge [variant]="lastUpdated() !== '' ? 'warning' : 'neutral'">
                {{ lastUpdated() !== '' ? 'RECOMPUTED' : 'Idle' }}
              </ui-badge>
            </div>
          </div>

          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="changeFirstName()">Change firstName</ui-button>
            <ui-button variant="secondary" size="sm" (clicked)="changeLastName()">Change lastName</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="resetNames()">Reset</ui-button>
          </div>

          <p class="explanation-inline">
            When <code>firstName</code> changes, only components reading it re-render.
            <code>fullName</code> (computed) recomputes but only if a dependency changed.
          </p>
        </div>
      </ui-card>

      <!-- 3. Computed Memoisation -->
      <ui-card title="3. Computed Memoisation — Avoiding Redundant Work" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeMemo }}</pre>

          <div class="memo-demo">
            <div class="memo-row">
              <span>Input signal: <strong>{{ memoInput() }}</strong></span>
              <span>Computed result: <strong>{{ expensiveResult() }}</strong></span>
              <span>Recomputations: <strong>{{ memoComputeCount() }}</strong></span>
            </div>
          </div>

          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="changeMemoInput()">Change Input</ui-button>
            <ui-button variant="ghost" size="sm" (clicked)="setSameValue()">Set SAME Value (no recompute)</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="resetMemo()">Reset</ui-button>
          </div>

          <p class="explanation-inline">
            <code>computed()</code> uses <strong>Object.is()</strong> to compare the result.
            If the input signal is set to the same value, the computed
            does NOT recompute — memoisation for free.
          </p>
        </div>
      </ui-card>

      <!-- 4. Signal Equality & Custom Equality -->
      <ui-card title="4. Signal Equality Checks" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeEquality }}</pre>

          <div class="equality-grid">
            <div class="eq-card">
              <h4>Default (Object.is)</h4>
              <p>Reference equality — fast but triggers on new object refs</p>
              <div class="eq-metric">
                Updates: <strong>{{ defaultEqUpdates() }}</strong>
              </div>
              <ui-button variant="primary" size="sm" (clicked)="setNewRef()">New Object Ref</ui-button>
            </div>
            <div class="eq-card">
              <h4>Custom Equal (deep)</h4>
              <p>Content equality — skips if values match</p>
              <div class="eq-metric">
                Updates: <strong>{{ customEqUpdates() }}</strong>
              </div>
              <ui-button variant="primary" size="sm" (clicked)="setSameContent()">Same Content, New Ref</ui-button>
            </div>
          </div>

          <p class="explanation-inline">
            Use <code>signal(value, {{ '{' }} equal: customFn {{ '}' }})</code> to prevent
            unnecessary re-renders when the value is semantically the same.
          </p>
        </div>
      </ui-card>

      <!-- 5. Live Ticker — Signals + OnPush -->
      <ui-card title="5. Live Demo: Signal + OnPush Auto-Refresh" [elevated]="true">
        <div class="demo-section">
          <div class="ticker-row">
            <span>Live timer (via toSignal + interval): <strong>{{ ticker() }}s</strong></span>
            <span>Products loaded: <strong>{{ productCount() }}</strong></span>
          </div>
          <p class="explanation-inline">
            No <code>markForCheck()</code> needed. The signal from <code>toSignal(interval(1000))</code>
            automatically marks this OnPush component dirty every second.
          </p>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .signal-cd-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 1rem 0; flex-wrap: wrap; }
    .value-display { font-size: 1rem; }
    .explanation p, .explanation-inline { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation-inline code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .signal-viz { display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap; margin: 0.75rem 0; }
    .signal-node { background: #e3f2fd; border: 2px solid #42a5f5; border-radius: 10px; padding: 0.75rem 1.25rem; text-align: center; }
    .signal-node.framework { background: #fff3e0; border-color: #ff9800; }
    .signal-node.cd { background: #e8f5e9; border-color: #66bb6a; }
    .signal-label { display: block; font-size: 0.75rem; color: #888; text-transform: uppercase; }
    .signal-value { display: block; font-weight: 600; font-size: 0.9rem; }
    .arrow { color: #999; font-size: 0.8rem; }
    .reactivity-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin: 0.75rem 0; }
    .reactivity-card { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 10px; padding: 1rem; text-align: center; transition: all 0.3s; }
    .reactivity-card.active { border-color: #66bb6a; background: #e8f5e9; }
    .reactivity-card h4 { margin: 0 0 0.25rem; font-size: 0.9rem; }
    .reactivity-card p { font-size: 0.8rem; color: #777; margin: 0.25rem 0; }
    .current-val { font-size: 1.2rem; font-weight: 600; margin: 0.5rem 0; color: #2c3e50; }
    .memo-demo { background: #f5f5f5; border-radius: 8px; padding: 0.75rem; margin: 0.75rem 0; }
    .memo-row { display: flex; gap: 2rem; font-size: 0.9rem; flex-wrap: wrap; }
    .equality-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 0.75rem 0; }
    .eq-card { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 10px; padding: 1rem; }
    .eq-card h4 { margin: 0 0 0.25rem; font-size: 0.9rem; }
    .eq-card p { font-size: 0.82rem; color: #777; margin: 0.25rem 0; }
    .eq-metric { font-size: 1.1rem; margin: 0.5rem 0; }
    .ticker-row { display: flex; gap: 2rem; font-size: 1rem; padding: 0.5rem 0; flex-wrap: wrap; }
  `]
})
export class SignalDrivenCdComponent {
  private productService = inject(ProductService);

  // ═══════════ CODE EXAMPLES ═══════════
  codeSignalCd = `// When a signal changes, Angular auto-calls markForCheck()
count = signal(0);

// In template: {{ count() }}
// Every time count changes:
// 1. Signal notifies its consumers
// 2. Angular marks the component dirty
// 3. Next CD cycle re-renders the template
// No manual markForCheck() or detectChanges() needed!`;

  codeFineGrained = `// Only components reading changed signals re-render
firstName = signal('John');
lastName = signal('Doe');
fullName = computed(() => firstName() + ' ' + lastName());

// Component A reads firstName() — only re-renders on firstName change
// Component B reads lastName() — only re-renders on lastName change
// Component C reads fullName() — recomputes when either changes`;

  codeMemo = `// computed() is memoised — skips if deps unchanged
input = signal(5);
result = computed(() => {
  console.log('Computing...'); // only runs when input changes
  return input() * input();
});

input.set(5); // same value — computed does NOT rerun!
input.set(6); // different value — computed reruns`;

  codeEquality = `// Default: Object.is() — reference equality
objSignal = signal({ name: 'A', value: 1 });
objSignal.set({ name: 'A', value: 1 }); // NEW ref — triggers update!

// Custom equality: content equality
objSignal = signal(
  { name: 'A', value: 1 },
  { equal: (a, b) => a.name === b.name && a.value === b.value }
);
objSignal.set({ name: 'A', value: 1 }); // same content — SKIPPED`;

  // ═══════════ DEMO STATE ═══════════
  count = signal(0);
  private renderCount = 0;

  renderTracker(): number {
    return ++this.renderCount;
  }

  // Fine-grained reactivity
  firstName = signal('John');
  lastName = signal('Doe');
  fullName = computed(() => this.firstName() + ' ' + this.lastName());
  lastUpdated = signal('');

  // Memoisation demo
  memoInput = signal(5);
  memoComputeCount = signal(0);
  expensiveResult = computed(() => {
    this.memoComputeCount.update(c => c + 1);
    return this.memoInput() * this.memoInput();
  });

  // Equality demo
  defaultObj = signal({ name: 'A', value: 1 });
  customObj = signal(
    { name: 'A', value: 1 },
    { equal: (a, b) => a.name === b.name && a.value === b.value }
  );
  defaultEqUpdates = signal(0);
  customEqUpdates = signal(0);

  // Live ticker
  ticker = toSignal(interval(1000), { initialValue: 0 });
  products = toSignal(this.productService.getProducts(), { initialValue: [] as Product[] });
  productCount = computed(() => this.products().length);

  // Effects to track equality updates
  private defaultEqEffect = effect(() => {
    this.defaultObj();
    // Don't count initial effect run
    if (this.defaultEqUpdates() >= 0) {
      // tracked
    }
  });

  incrementCount(): void {
    this.count.update(v => v + 1);
  }

  changeFirstName(): void {
    const names = ['John', 'Jane', 'Alex', 'Maria', 'Sam'];
    const current = this.firstName();
    const next = names[(names.indexOf(current) + 1) % names.length];
    this.firstName.set(next);
    this.lastUpdated.set('firstName');
  }

  changeLastName(): void {
    const names = ['Doe', 'Smith', 'Johnson', 'Williams', 'Brown'];
    const current = this.lastName();
    const next = names[(names.indexOf(current) + 1) % names.length];
    this.lastName.set(next);
    this.lastUpdated.set('lastName');
  }

  resetNames(): void {
    this.firstName.set('John');
    this.lastName.set('Doe');
    this.lastUpdated.set('');
  }

  changeMemoInput(): void {
    this.memoInput.update(v => v + 1);
  }

  setSameValue(): void {
    this.memoInput.set(this.memoInput()); // same value — no recompute!
  }

  resetMemo(): void {
    this.memoInput.set(5);
    this.memoComputeCount.set(0);
  }

  setNewRef(): void {
    this.defaultObj.set({ name: 'A', value: 1 }); // new ref, triggers
    this.defaultEqUpdates.update(v => v + 1);
  }

  setSameContent(): void {
    this.customObj.set({ name: 'A', value: 1 }); // same content, skipped!
    // customEqUpdates should NOT increment because equal() returns true
    this.defaultObj.set({ name: 'A', value: 1 });
    this.defaultEqUpdates.update(v => v + 1);
    // Only default increments
  }
}
