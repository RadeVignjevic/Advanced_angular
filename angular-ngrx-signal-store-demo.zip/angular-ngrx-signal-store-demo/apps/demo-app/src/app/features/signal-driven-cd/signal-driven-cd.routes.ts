import { Route } from '@angular/router';
import { SignalDrivenCdComponent } from './signal-driven-cd.component';

export const SIGNAL_DRIVEN_CD_ROUTES: Route[] = [
  { path: '', component: SignalDrivenCdComponent }
];
