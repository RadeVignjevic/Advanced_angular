import { Component, signal, computed, effect, untracked, OnDestroy } from '@angular/core';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Signal Fundamentals Demo — Topic 1 (30 min)
 *
 * TEACHING POINTS:
 * 1. signal() — writable reactive primitive
 * 2. computed() — derived read-only signal
 * 3. effect() — side-effect runner that auto-tracks dependencies
 * 4. update() vs set() — mutation patterns
 * 5. untracked() — reading without subscribing
 */
@Component({
  selector: 'app-signal-fundamentals',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  template: `
    <div class="signals-page">
      <h2>Signal Fundamentals <ui-badge variant="info">Block 3 — Topic 1</ui-badge></h2>

      <p class="note">
        Signals are <strong>synchronous reactive primitives</strong> — they hold a value
        and notify consumers when it changes. Unlike Observables, they always have a current value.
      </p>

      <!-- 1. signal() — Writable Signal -->
      <ui-card title="1. signal() — Writable Reactive Value" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeWritableSignal }}</pre>
          <div class="demo-row">
            <span class="value-display">Count: <strong>{{ count() }}</strong></span>
            <div class="btn-group">
              <ui-button variant="primary" size="sm" (clicked)="incrementByOne()">set(count + 1)</ui-button>
              <ui-button variant="secondary" size="sm" (clicked)="incrementByFive()">update(v + 5)</ui-button>
              <ui-button variant="danger" size="sm" (clicked)="count.set(0)">set(0) — Reset</ui-button>
            </div>
          </div>
          <div class="explanation">
            <p><strong>set()</strong> — replaces the value entirely</p>
            <p><strong>update()</strong> — derives new value from current (like setState callback in React)</p>
          </div>
        </div>
      </ui-card>

      <!-- 2. computed() — Derived Signal -->
      <ui-card title="2. computed() — Derived Read-Only Signal" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeComputedSignal }}</pre>
          <div class="computed-grid">
            <div class="computed-item">
              <span class="label">count()</span>
              <span class="value">{{ count() }}</span>
            </div>
            <div class="computed-item arrow">-></div>
            <div class="computed-item">
              <span class="label">doubled()</span>
              <span class="value">{{ doubled() }}</span>
            </div>
            <div class="computed-item arrow">-></div>
            <div class="computed-item">
              <span class="label">quadrupled()</span>
              <span class="value">{{ quadrupled() }}</span>
            </div>
          </div>
          <div class="computed-grid" style="margin-top: 0.75rem;">
            <div class="computed-item">
              <span class="label">label()</span>
              <ui-badge [variant]="labelVariant()">{{ label() }}</ui-badge>
            </div>
          </div>
          <div class="explanation">
            <p>Computed signals are <strong>lazy</strong> — they only recompute when read AND a dependency changed.</p>
            <p>They form a <strong>dependency graph</strong>: quadrupled depends on doubled which depends on count.</p>
          </div>
        </div>
      </ui-card>

      <!-- 3. Signals with Objects/Arrays -->
      <ui-card title="3. Signals with Objects and Arrays" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeObjectSignal }}</pre>
          <div class="demo-row">
            <div>
              <p><strong>Items:</strong> {{ items().join(', ') }} ({{ itemCount() }} items)</p>
              <p><strong>User:</strong> {{ user().name }}, age {{ user().age }}</p>
            </div>
            <div class="btn-group">
              <ui-button variant="primary" size="sm" (clicked)="addItem()">Add Item</ui-button>
              <ui-button variant="secondary" size="sm" (clicked)="incrementAge()">Increment Age</ui-button>
              <ui-button variant="ghost" size="sm" (clicked)="resetCollections()">Reset</ui-button>
            </div>
          </div>
          <div class="explanation">
            <p>Immutability matters! Always spread to create new references:</p>
            <pre class="code-block">{{ codeImmutableUpdate }}</pre>
            <p>The signal uses reference equality by default — mutating an array won't trigger updates.</p>
          </div>
        </div>
      </ui-card>

      <!-- 4. effect() — Side Effects -->
      <ui-card title="4. effect() — Reactive Side Effects" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeEffect }}</pre>
          <div class="demo-row">
            <span>Effect log (check console): <strong>{{ effectLog().length }}</strong> entries</span>
            <ui-button variant="primary" size="sm" (clicked)="incrementByOne()">Trigger Effect</ui-button>
          </div>
          <div class="log-output">
            @for (entry of effectLog(); track $index) {
              <div class="log-entry">{{ entry }}</div>
            } @empty {
              <div class="log-entry dim">Click "Trigger Effect" to see effect() in action</div>
            }
          </div>
          <div class="explanation">
            <p><strong>effect()</strong> auto-tracks signal reads inside its callback.</p>
            <p><strong>untracked()</strong> reads a signal without creating a dependency.</p>
            <p>Effects run at least once, then re-run when tracked signals change.</p>
          </div>
        </div>
      </ui-card>

      <!-- 5. Mental Model Summary -->
      <ui-card title="5. Signal Mental Model" [elevated]="true">
        <div class="mental-model">
          <div class="model-row">
            <div class="model-item signal-box">
              <h4>signal()</h4>
              <p>Writable container</p>
              <span class="model-code">set(), update()</span>
            </div>
            <div class="model-arrow">feeds -></div>
            <div class="model-item computed-box">
              <h4>computed()</h4>
              <p>Derived value (lazy, cached)</p>
              <span class="model-code">read-only</span>
            </div>
            <div class="model-arrow">triggers -></div>
            <div class="model-item effect-box">
              <h4>effect()</h4>
              <p>Side effects (logging, API calls)</p>
              <span class="model-code">auto-cleanup</span>
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .signals-page { padding: 0.5rem; }
    .note { background: #d1ecf1; border: 1px solid #bee5eb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; justify-content: space-between; align-items: center; margin: 0.75rem 0; flex-wrap: wrap; gap: 0.75rem; }
    .btn-group { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    .value-display { font-size: 1.2rem; }
    .code-block { background: #2d2d2d; color: #f8f8f2; padding: 0.75rem; border-radius: 6px; font-size: 0.85rem; overflow-x: auto; margin-bottom: 0.75rem; font-family: monospace; }
    .computed-grid { display: flex; align-items: center; gap: 1rem; flex-wrap: wrap; }
    .computed-item { text-align: center; }
    .computed-item .label { display: block; font-size: 0.75rem; color: #666; margin-bottom: 0.25rem; }
    .computed-item .value { display: block; font-size: 1.5rem; font-weight: 700; color: #2c3e50; }
    .computed-item.arrow { font-size: 1.5rem; color: #999; }
    .explanation { background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px; padding: 0.75rem; margin-top: 0.75rem; font-size: 0.85rem; }
    .explanation p { margin: 0.3rem 0; }
    .log-output { background: #1e1e1e; color: #00ff00; padding: 0.75rem; border-radius: 6px; max-height: 150px; overflow-y: auto; margin: 0.5rem 0; font-family: monospace; font-size: 0.8rem; }
    .log-entry { padding: 0.15rem 0; }
    .log-entry.dim { color: #666; }
    .mental-model { padding: 1rem 0; }
    .model-row { display: flex; align-items: center; justify-content: center; gap: 1rem; flex-wrap: wrap; }
    .model-item { text-align: center; padding: 1rem; border-radius: 8px; min-width: 150px; }
    .model-item h4 { margin: 0 0 0.3rem 0; }
    .model-item p { margin: 0.2rem 0; font-size: 0.8rem; color: #666; }
    .model-code { font-size: 0.75rem; background: rgba(0,0,0,0.1); padding: 0.15rem 0.4rem; border-radius: 4px; }
    .model-item.signal-box { background: #d4edda; border: 2px solid #28a745; }
    .model-item.computed-box { background: #d1ecf1; border: 2px solid #17a2b8; }
    .model-item.effect-box { background: #fff3cd; border: 2px solid #ffc107; }
    .model-arrow { font-size: 1.2rem; color: #999; font-weight: bold; }
  `]
})
export class SignalFundamentalsComponent implements OnDestroy {
  // ── Code examples as properties (avoids template parsing issues) ──
  codeWritableSignal = 'count = signal(0);';

  codeComputedSignal = `doubled = computed(() => count() * 2);
quadrupled = computed(() => doubled() * 2);
label = computed(() => count() === 0 ? 'Zero' : count() > 10 ? 'High' : 'Low');`;

  codeObjectSignal = `items = signal<string[]>(['Angular', 'Signals']);
user = signal({ name: 'Alice', age: 30 });`;

  codeImmutableUpdate = `items.update(list => [...list, 'New Item'])`;

  codeEffect = `effect(() => {
  console.log('Count changed to:', count());
  // Auto-tracks: re-runs whenever count() changes
});`;

  // ── 1. Writable Signal ──
  count = signal(0);

  // ── 2. Computed Signals (dependency chain) ──
  doubled = computed(() => this.count() * 2);
  quadrupled = computed(() => this.doubled() * 2);
  label = computed(() => {
    const c = this.count();
    return c === 0 ? 'Zero' : c > 10 ? 'High' : 'Low';
  });
  labelVariant = computed(() => {
    const l = this.label();
    return l === 'Zero' ? 'neutral' as const : l === 'High' ? 'danger' as const : 'info' as const;
  });

  // ── 3. Object/Array Signals ──
  items = signal<string[]>(['Angular', 'Signals']);
  user = signal({ name: 'Alice', age: 30 });
  itemCount = computed(() => this.items().length);

  // ── 4. Effect with log ──
  effectLog = signal<string[]>([]);
  private effectRef = effect(() => {
    const current = this.count();
    untracked(() => {
      this.effectLog.update(log => [
        ...log,
        `[${new Date().toLocaleTimeString()}] count changed to ${current}`
      ]);
    });
  });

  incrementByOne(): void {
    this.count.set(this.count() + 1);
  }

  incrementByFive(): void {
    this.count.update(v => v + 5);
  }

  addItem(): void {
    const newItem = `Item ${this.items().length + 1}`;
    this.items.update(list => [...list, newItem]);
  }

  incrementAge(): void {
    this.user.update(u => ({ ...u, age: u.age + 1 }));
  }

  resetCollections(): void {
    this.items.set(['Angular', 'Signals']);
    this.user.set({ name: 'Alice', age: 30 });
  }

  ngOnDestroy(): void {
    this.effectRef.destroy();
  }
}
