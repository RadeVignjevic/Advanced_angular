import { Route } from '@angular/router';
import { SignalFundamentalsComponent } from './signal-fundamentals.component';

export const SIGNAL_FUNDAMENTALS_ROUTES: Route[] = [
  { path: '', component: SignalFundamentalsComponent }
];
