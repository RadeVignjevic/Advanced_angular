import { Component, signal, computed, inject } from '@angular/core';
import { toSignal, toObservable } from '@angular/core/rxjs-interop';
import { Observable, interval, map, switchMap, of, delay, debounceTime, distinctUntilChanged, tap } from 'rxjs';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';
import { ProductService, Product } from '@angular-monorepo-demo/data-access';

/**
 * Signal / RxJS Interoperability — Topic 3 (20 min)
 *
 * TEACHING POINTS:
 * 1. toSignal() — Convert Observable to Signal
 * 2. toObservable() — Convert Signal to Observable
 * 3. initialValue option and requireSync
 * 4. Practical patterns: signal input -> observable pipeline -> signal result
 */
@Component({
  selector: 'app-signal-interop',
  imports: [UiCardComponent, UiBadgeComponent],
  template: `
    <div class="interop-page">
      <h2>Signal / RxJS Interop <ui-badge variant="info">Block 3 — Topic 3</ui-badge></h2>

      <p class="note">
        <strong>toSignal()</strong> converts an Observable into a Signal.
        <strong>toObservable()</strong> converts a Signal into an Observable.
        These bridges let you use the best tool for each job.
      </p>

      <!-- 1. toSignal() -->
      <ui-card title="1. toSignal() — Observable to Signal" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeToSignal }}</pre>

          <div class="result-box">
            <p><strong>Products loaded via toSignal():</strong> {{ products().length }} products</p>
            <div class="product-tags">
              @for (p of products(); track p.id) {
                <ui-badge [variant]="p.inStock ? 'success' : 'danger'">{{ p.name }}</ui-badge>
              }
            </div>
          </div>

          <div class="explanation">
            <p><strong>initialValue</strong> is required because the Observable may not have emitted yet.
            The signal needs a value at all times.</p>
            <p>Alternative: toSignal(obs$, {{ '{' }} requireSync: true {{ '}' }}) — only for
            Observables that emit synchronously (like BehaviorSubject or of()).</p>
          </div>
        </div>
      </ui-card>

      <!-- 2. toSignal() with timer -->
      <ui-card title="2. toSignal() — Live Stream Example" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeTimerSignal }}</pre>
          <div class="timer-display">
            <div class="timer-item">
              <span class="timer-label">Raw tick</span>
              <span class="timer-value">{{ tick() }}</span>
            </div>
            <div class="timer-item">
              <span class="timer-label">Formatted (computed)</span>
              <span class="timer-value">{{ formattedTick() }}</span>
            </div>
            <div class="timer-item">
              <span class="timer-label">Is even? (computed)</span>
              <ui-badge [variant]="isEvenTick() ? 'success' : 'warning'">
                {{ isEvenTick() ? 'Yes' : 'No' }}
              </ui-badge>
            </div>
          </div>
          <div class="explanation">
            <p>The interval Observable is bridged once via toSignal(). Then we derive
            multiple computed() signals — no extra subscriptions needed!</p>
          </div>
        </div>
      </ui-card>

      <!-- 3. toObservable() -->
      <ui-card title="3. toObservable() — Signal to Observable" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeToObservable }}</pre>

          <div class="search-demo">
            <input
              [value]="searchQuery()"
              (input)="searchQuery.set(getInputValue($event))"
              placeholder="Type to search products (debounced via Observable)..."
              class="search-input"
            />
            <div class="search-info">
              <span>Signal value: "{{ searchQuery() }}"</span>
              <span>|</span>
              <span>Debounced results: {{ searchResults().length }}</span>
              @if (isSearching()) {
                <ui-badge variant="warning">Searching...</ui-badge>
              }
            </div>
            <div class="search-results">
              @for (p of searchResults(); track p.id) {
                <div class="result-item">
                  <strong>{{ p.name }}</strong>
                  <span>{{ p.category }} — \${{ p.price }}</span>
                </div>
              } @empty {
                @if (searchQuery()) {
                  <div class="result-empty">No products match "{{ searchQuery() }}"</div>
                } @else {
                  <div class="result-empty">Type to search...</div>
                }
              }
            </div>
          </div>

          <div class="explanation">
            <p><strong>This is the recommended pattern:</strong></p>
            <p>Signal (input) -> toObservable() -> RxJS pipeline (debounce, switchMap) -> toSignal() (output)</p>
            <p>You get signal simplicity in the template AND RxJS power for the async logic.</p>
          </div>
        </div>
      </ui-card>

      <!-- 4. Pattern Summary -->
      <ui-card title="4. Bridge Pattern Summary" [elevated]="true">
        <div class="pattern-flow">
          <div class="flow-step signal-step">
            <h4>Signal (Input)</h4>
            <p>User action sets a signal</p>
          </div>
          <div class="flow-arrow">-> toObservable() -></div>
          <div class="flow-step rxjs-step">
            <h4>Observable (Pipeline)</h4>
            <p>RxJS operators process the stream</p>
          </div>
          <div class="flow-arrow">-> toSignal() -></div>
          <div class="flow-step signal-step">
            <h4>Signal (Output)</h4>
            <p>Template reads the result</p>
          </div>
        </div>

        <div class="api-summary">
          <table class="api-table">
            <thead>
              <tr><th>Function</th><th>Direction</th><th>Key Options</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>toSignal(obs$)</td>
                <td>Observable -> Signal</td>
                <td>initialValue, requireSync, manualCleanup</td>
              </tr>
              <tr>
                <td>toObservable(sig)</td>
                <td>Signal -> Observable</td>
                <td>Emits on signal change (uses effect() internally)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .interop-page { padding: 0.5rem; }
    .note { background: #d1ecf1; border: 1px solid #bee5eb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .demo-section { padding: 0.5rem 0; }
    .code-block { background: #2d2d2d; color: #f8f8f2; padding: 0.75rem; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; margin-bottom: 0.75rem; font-family: monospace; }
    .result-box { background: #f8f9fa; padding: 0.75rem; border-radius: 6px; margin: 0.5rem 0; }
    .product-tags { display: flex; flex-wrap: wrap; gap: 0.4rem; margin-top: 0.5rem; }
    .explanation { background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px; padding: 0.75rem; margin-top: 0.75rem; font-size: 0.85rem; }
    .explanation p { margin: 0.3rem 0; }
    .timer-display { display: flex; gap: 2rem; align-items: center; justify-content: center; padding: 1rem; background: #f8f9fa; border-radius: 6px; flex-wrap: wrap; }
    .timer-item { text-align: center; }
    .timer-label { display: block; font-size: 0.75rem; color: #666; margin-bottom: 0.25rem; }
    .timer-value { display: block; font-size: 2rem; font-weight: 700; color: #2c3e50; }
    .search-demo { padding: 0.5rem 0; }
    .search-input { width: 100%; padding: 0.6rem; border: 2px solid #17a2b8; border-radius: 6px; font-size: 0.95rem; margin-bottom: 0.5rem; }
    .search-info { display: flex; gap: 0.75rem; font-size: 0.8rem; color: #666; align-items: center; margin-bottom: 0.5rem; flex-wrap: wrap; }
    .search-results { background: #f8f9fa; border-radius: 6px; max-height: 200px; overflow-y: auto; }
    .result-item { display: flex; justify-content: space-between; padding: 0.5rem 0.75rem; border-bottom: 1px solid #e9ecef; }
    .result-item span { color: #666; font-size: 0.85rem; }
    .result-empty { padding: 1rem; text-align: center; color: #999; font-style: italic; }
    .pattern-flow { display: flex; align-items: center; justify-content: center; gap: 0.75rem; padding: 1.5rem 0; flex-wrap: wrap; }
    .flow-step { text-align: center; padding: 1rem; border-radius: 8px; min-width: 180px; }
    .flow-step h4 { margin: 0 0 0.3rem 0; }
    .flow-step p { margin: 0.2rem 0; font-size: 0.8rem; color: #666; }
    .signal-step { background: #d4edda; border: 2px solid #28a745; }
    .rxjs-step { background: #d1ecf1; border: 2px solid #17a2b8; }
    .flow-arrow { font-weight: bold; color: #999; white-space: nowrap; }
    .api-summary { margin-top: 1rem; }
    .api-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
    .api-table th { background: #f8f9fa; padding: 0.6rem; text-align: left; border-bottom: 2px solid #dee2e6; }
    .api-table td { padding: 0.5rem 0.6rem; border-bottom: 1px solid #e9ecef; }
  `]
})
export class SignalInteropComponent {
  private productService = inject(ProductService);

  // ── Code examples as component properties ──
  codeToSignal = `// Convert an Observable to a Signal (injection context)
products$ = this.productService.getProducts();
products = toSignal(this.products$, { initialValue: [] as Product[] });

// Now use in template without | async:
// {{ products().length }}`;

  codeTimerSignal = `// Convert interval Observable to signal — auto-updates!
tick$ = interval(1000);
tick = toSignal(this.tick$, { initialValue: 0 });
formatted = computed(() => {
  const t = this.tick();
  const min = Math.floor(t / 60);
  const sec = t % 60;
  return min + ':' + sec.toString().padStart(2, '0');
});`;

  codeToObservable = `// Signal for user input
searchQuery = signal('');

// Convert to Observable for debounce pipeline
searchQuery$ = toObservable(this.searchQuery);
results$ = this.searchQuery$.pipe(
  debounceTime(300),
  distinctUntilChanged(),
  switchMap(query => this.searchProducts(query))
);

// Convert results back to signal for template
searchResults = toSignal(this.results$, { initialValue: [] });`;

  // ── 1. toSignal() basic — Observable -> Signal ──
  private products$ = this.productService.getProducts();
  products = toSignal(this.products$, { initialValue: [] as Product[] });

  // ── 2. toSignal() with interval stream ──
  private tick$ = interval(1000);
  tick = toSignal(this.tick$, { initialValue: 0 });
  formattedTick = computed(() => {
    const t = this.tick();
    const min = Math.floor(t / 60);
    const sec = t % 60;
    return `${min}:${sec.toString().padStart(2, '0')}`;
  });
  isEvenTick = computed(() => this.tick() % 2 === 0);

  // ── 3. toObservable() — Signal -> Observable -> toSignal() ──
  searchQuery = signal('');
  isSearching = signal(false);

  private searchQuery$ = toObservable(this.searchQuery);
  private searchResults$ = this.searchQuery$.pipe(
    debounceTime(300),
    distinctUntilChanged(),
    tap(() => this.isSearching.set(true)),
    switchMap(query => this.searchProducts(query)),
    tap(() => this.isSearching.set(false))
  );
  searchResults = toSignal(this.searchResults$, { initialValue: [] as Product[] });

  getInputValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  private searchProducts(query: string): Observable<Product[]> {
    if (!query.trim()) {
      return of([]);
    }
    return this.productService.getProducts().pipe(
      delay(200),
      map(products => products.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.category.toLowerCase().includes(query.toLowerCase())
      ))
    );
  }
}
