import { Route } from '@angular/router';
import { SignalInteropComponent } from './signal-interop.component';

export const SIGNAL_INTEROP_ROUTES: Route[] = [
  { path: '', component: SignalInteropComponent }
];
