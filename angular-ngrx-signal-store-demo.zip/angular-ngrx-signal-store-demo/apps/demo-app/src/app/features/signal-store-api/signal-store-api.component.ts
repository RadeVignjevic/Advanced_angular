import { Component, ChangeDetectionStrategy, inject, computed, signal } from '@angular/core';
import { signalStore, withState, withComputed, withMethods, withHooks, patchState, getState } from '@ngrx/signals';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

// ═══════════ LIVE DEMO STORE ═══════════
// A self-contained counter store used for live demos on this page
const DemoCounterStore = signalStore(
  withState({ count: 0, label: 'Demo Counter' }),
  withComputed(({ count }) => ({
    doubled: computed(() => count() * 2),
    isPositive: computed(() => count() > 0),
  })),
  withMethods((store) => ({
    increment() { patchState(store, { count: store.count() + 1 }); },
    decrement() { patchState(store, { count: store.count() - 1 }); },
    reset() { patchState(store, { count: 0 }); },
    setLabel(label: string) { patchState(store, { label }); },
  })),
  withHooks({
    onInit(store) {
      console.log('[DemoCounterStore] Initialised with state:', getState(store));
    },
    onDestroy(store) {
      console.log('[DemoCounterStore] Destroyed. Final state:', getState(store));
    }
  })
);

// ═══════════ TODO STORE (more complex demo) ═══════════
interface TodoItem {
  id: number;
  text: string;
  done: boolean;
}

const DemoTodoStore = signalStore(
  withState({
    todos: [] as TodoItem[],
    filter: 'all' as 'all' | 'active' | 'done',
    nextId: 1,
    error: null as string | null,
  }),
  withComputed(({ todos, filter }) => ({
    filteredTodos: computed(() => {
      const all = todos();
      switch (filter()) {
        case 'active': return all.filter(t => !t.done);
        case 'done': return all.filter(t => t.done);
        default: return all;
      }
    }),
    totalCount: computed(() => todos().length),
    doneCount: computed(() => todos().filter(t => t.done).length),
    activeCount: computed(() => todos().filter(t => !t.done).length),
  })),
  withMethods((store) => ({
    addTodo(text: string) {
      patchState(store, {
        todos: [...store.todos(), { id: store.nextId(), text, done: false }],
        nextId: store.nextId() + 1,
      });
    },
    toggleTodo(id: number) {
      patchState(store, {
        todos: store.todos().map(t => t.id === id ? { ...t, done: !t.done } : t),
      });
    },
    removeTodo(id: number) {
      patchState(store, {
        todos: store.todos().filter(t => t.id !== id),
      });
    },
    setFilter(filter: 'all' | 'active' | 'done') {
      patchState(store, { filter });
    },
  })),
  withHooks({
    onInit(store) {
      try {
        const sampleTodos = [
          { id: 1, text: 'Learn Signal Store', done: false },
          { id: 2, text: 'Build a Todo App', done: false },
          { id: 3, text: 'Master withHooks', done: false },
        ];
        patchState(store, {
          todos: sampleTodos,
          nextId: 4,
          error: null,
        });
        console.log('[DemoTodoStore] Initialised with state:', getState(store));
      } catch (error) {
        console.error('[DemoTodoStore] Init error:', error);
        patchState(store, {
          todos: [],
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    },
    onDestroy(store) {
      console.log('[DemoTodoStore] Destroyed. Final state:', getState(store));
    }
  })
);

// ═══════════ PRODUCT STORE (standard NgRx withState pattern) ═══════════
interface Product {
  id: number;
  name: string;
  price: number;
}

type LoadingState = 'idle' | 'loading' | 'loaded' | 'error';

// Simulated API call
function fetchProducts(): Promise<Product[]> {
  return new Promise((resolve) =>
    setTimeout(() => resolve([
      { id: 1, name: 'Laptop', price: 999 },
      { id: 2, name: 'Keyboard', price: 79 },
      { id: 3, name: 'Mouse', price: 29 },
      { id: 4, name: 'Monitor', price: 499 },
      { id: 5, name: 'Headphones', price: 149 },
    ]), 800)
  );
}

const ProductStore = signalStore(
  { providedIn: 'root' },
  withState({
    products: [] as Product[],
    searchTerm: '',
    loadingState: 'idle' as LoadingState,
    error: null as string | null,
  }),
  withComputed(({ products, searchTerm, loadingState }) => ({
    filtered: computed(() => {
      const term = searchTerm().toLowerCase();
      return products().filter(p =>
        p.name.toLowerCase().includes(term)
      );
    }),
    isLoading: computed(() => loadingState() === 'loading'),
    isLoaded: computed(() => loadingState() === 'loaded'),
    hasError: computed(() => loadingState() === 'error'),
    totalCount: computed(() => products().length),
  })),
  withMethods((store) => ({
    setSearchTerm(searchTerm: string) {
      patchState(store, { searchTerm });
    },
    async loadProducts() {
      patchState(store, { loadingState: 'loading', error: null });
      try {
        const products = await fetchProducts();
        patchState(store, { products, loadingState: 'loaded' });
      } catch (e) {
        patchState(store, {
          loadingState: 'error',
          error: e instanceof Error ? e.message : 'Failed to load',
        });
      }
    },
  })),
  withHooks({
    onInit(store) {
      store.loadProducts();
      console.log('[ProductStore] Initialised, loading products...');
    },
    onDestroy(store) {
      console.log('[ProductStore] Destroyed. Final state:', getState(store));
    },
  })
);

/**
 * NgRx Signal Store: Core API — Topic 2 (40 min)
 */
@Component({
  selector: 'app-signal-store-api',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DemoCounterStore, DemoTodoStore],
  template: `
    <div class="api-page">
      <h2>NgRx Signal Store: Core API <ui-badge variant="info">Block 5 — Topic 2</ui-badge></h2>

      <p class="note">
        The Signal Store uses a <strong>functional, composable API</strong>.
        Each <code>with*()</code> function adds a layer of functionality.
      </p>

      <!-- 1. signalStore() + withState() -->
      <ui-card title="1. signalStore() + withState() — Creating a Store" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeWithState }}</pre>
          <div class="explanation">
            <p><code>signalStore()</code> creates an injectable service.</p>
            <p><code>withState()</code> defines the initial state shape. Each property becomes a signal.</p>
            <p>Access state via <code>store.count()</code> — just like a regular signal!</p>
          </div>
        </div>
      </ui-card>

      <!-- 2. withComputed() -->
      <ui-card title="2. withComputed() — Derived State" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeWithComputed }}</pre>
          <div class="demo-row">
            <span>count: <strong>{{ counterStore.count() }}</strong></span>
            <span>doubled: <strong>{{ counterStore.doubled() }}</strong></span>
            <span>isPositive: <strong>{{ counterStore.isPositive() }}</strong></span>
          </div>
          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="counterStore.increment()">Increment</ui-button>
            <ui-button variant="secondary" size="sm" (clicked)="counterStore.decrement()">Decrement</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="counterStore.reset()">Reset</ui-button>
          </div>
          <p class="explanation-inline">
            <code>withComputed()</code> receives the store's signals as an argument.
            Return an object of computed signals — they auto-update when dependencies change.
          </p>
        </div>
      </ui-card>

      <!-- 3. withMethods() + patchState() -->
      <ui-card title="3. withMethods() + patchState() — State Mutations" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeWithMethods }}</pre>
          <div class="explanation">
            <p><code>withMethods()</code> adds methods to the store. Methods can call <code>patchState()</code>
            to update the state immutably.</p>
            <p><code>patchState(store, partialState)</code> merges the partial state into the current state.
            It is always <strong>immutable</strong> — a new state object is created.</p>
          </div>
          <div class="demo-row">
            <span>Label: <strong>{{ counterStore.label() }}</strong></span>
          </div>
          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="counterStore.setLabel('Updated!')">setLabel('Updated!')</ui-button>
            <ui-button variant="secondary" size="sm" (clicked)="counterStore.setLabel('Demo Counter')">Reset Label</ui-button>
          </div>
        </div>
      </ui-card>

      <!-- 4. withHooks() -->
      <ui-card title="4. withHooks() — Lifecycle Hooks" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeWithHooks }}</pre>
          <div class="explanation">
            <p><code>onInit</code> runs when the store is first injected (created).</p>
            <p><code>onDestroy</code> runs when the store's injector is destroyed.</p>
            <p>Check your <strong>browser console</strong> — you'll see the init log from this page's store.</p>
          </div>
        </div>
      </ui-card>

      <!-- 5. patchState() patterns -->
      <ui-card title="5. patchState() Patterns" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codePatchState }}</pre>
          <div class="explanation">
            <p><code>patchState()</code> accepts:</p>
            <ul>
              <li>A partial state object: <code>patchState(store, {{ '{' }} count: 5 {{ '}' }})</code></li>
              <li>An updater function: <code>patchState(store, state =&gt; ({{ '{' }} count: state.count + 1 {{ '}' }}))</code></li>
              <li>Multiple updaters: <code>patchState(store, updater1, updater2)</code></li>
            </ul>
          </div>
        </div>
      </ui-card>

      <!-- 6. Live Todo Store Demo -->
      <ui-card title="6. Live Demo: Todo Store" [elevated]="true">
        <div class="demo-section">
          <div class="todo-stats">
            <span>Total: <strong>{{ todoStore.totalCount() }}</strong></span>
            <span>Active: <strong>{{ todoStore.activeCount() }}</strong></span>
            <span>Done: <strong>{{ todoStore.doneCount() }}</strong></span>
          </div>

          <div class="todo-filters">
            <ui-button [variant]="todoStore.filter() === 'all' ? 'primary' : 'ghost'" size="sm"
              (clicked)="todoStore.setFilter('all')">All</ui-button>
            <ui-button [variant]="todoStore.filter() === 'active' ? 'primary' : 'ghost'" size="sm"
              (clicked)="todoStore.setFilter('active')">Active</ui-button>
            <ui-button [variant]="todoStore.filter() === 'done' ? 'primary' : 'ghost'" size="sm"
              (clicked)="todoStore.setFilter('done')">Done</ui-button>
          </div>

          <div class="todo-input">
            <input type="text" placeholder="Add a todo..." #todoInput
              (keyup.enter)="addTodo(todoInput)" />
            <ui-button variant="primary" size="sm" (clicked)="addTodo(todoInput)">Add</ui-button>
          </div>

          <div class="todo-list">
            @for (todo of todoStore.filteredTodos(); track todo.id) {
              <div class="todo-item" [class.done]="todo.done">
                <label>
                  <input type="checkbox" [checked]="todo.done" (change)="todoStore.toggleTodo(todo.id)" />
                  <span>{{ todo.text }}</span>
                </label>
                <ui-button variant="danger" size="sm" (clicked)="todoStore.removeTodo(todo.id)">x</ui-button>
              </div>
            } @empty {
              <p class="empty-msg">No todos yet. Add one above!</p>
            }
          </div>

          <p class="explanation-inline">
            This fully functional todo app is powered by a Signal Store with
            <code>withState</code>, <code>withComputed</code>, and <code>withMethods</code>.
          </p>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .api-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.75rem 0; flex-wrap: wrap; font-size: 1rem; }
    .explanation p, .explanation-inline { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation ul { padding-left: 1.25rem; font-size: 0.85rem; color: #555; }
    .explanation li { margin: 0.2rem 0; }
    .explanation-inline code, .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .todo-stats { display: flex; gap: 1.5rem; font-size: 0.95rem; margin-bottom: 0.75rem; }
    .todo-filters { display: flex; gap: 0.5rem; margin-bottom: 0.75rem; }
    .todo-input { display: flex; gap: 0.5rem; margin-bottom: 0.75rem; }
    .todo-input input { flex: 1; padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; }
    .todo-input input:focus { outline: none; border-color: #42a5f5; }
    .todo-list { max-height: 200px; overflow-y: auto; }
    .todo-item { display: flex; justify-content: space-between; align-items: center; padding: 0.4rem 0.5rem; border-bottom: 1px solid #eee; }
    .todo-item label { display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-size: 0.9rem; }
    .todo-item.done span { text-decoration: line-through; color: #999; }
    .todo-item input[type="checkbox"] { accent-color: #42a5f5; }
    .empty-msg { color: #999; font-size: 0.85rem; text-align: center; padding: 1rem; }
  `]
})
export class SignalStoreApiComponent {
  protected counterStore = inject(DemoCounterStore);
  protected todoStore = inject(DemoTodoStore);

  // ═══════════ CODE EXAMPLES ═══════════
  codeWithState = `import { signalStore, withState } from '@ngrx/signals';

export const CounterStore = signalStore(
  withState({
    count: 0,
    label: 'My Counter',
  })
);
// Each state property becomes a signal:
// store.count()  -> Signal<number>
// store.label()  -> Signal<string>`;

  codeWithComputed = `withComputed(({ count }) => ({
  doubled: computed(() => count() * 2),
  isPositive: computed(() => count() > 0),
}))
// Access: store.doubled(), store.isPositive()
// Auto-updates when count() changes (memoised)`;

  codeWithMethods = `withMethods((store) => ({
  increment() {
    patchState(store, { count: store.count() + 1 });
  },
  setLabel(label: string) {
    patchState(store, { label });
  },
}))
// Call: store.increment(), store.setLabel('New')`;

  codeWithHooks = `withHooks({
  onInit(store) {
    console.log('Store initialised:', getState(store));
    // Load data, start subscriptions, etc.
  },
  onDestroy(store) {
    console.log('Store destroyed:', getState(store));
    // Cleanup
  }
})`;

  codePatchState = `// Partial state object
patchState(store, { count: 5 });

// Updater function
patchState(store, (state) => ({
  count: state.count + 1,
}));

// Multiple updaters
patchState(store, setLoading(), addEntity(product));

// getState() — snapshot of entire state
const snapshot = getState(store);
console.log(snapshot); // { count: 5, label: '...' }`;

  addTodo(input: HTMLInputElement): void {
    const text = input.value.trim();
    if (text) {
      this.todoStore.addTodo(text);
      input.value = '';
    }
  }
}
