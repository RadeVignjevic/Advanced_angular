import { Route } from '@angular/router';
import { SignalStoreApiComponent } from './signal-store-api.component';

export const SIGNAL_STORE_API_ROUTES: Route[] = [
  { path: '', component: SignalStoreApiComponent }
];
