import { Component, signal, computed, inject, OnInit, OnDestroy } from '@angular/core';
import { Subject, BehaviorSubject, map, takeUntil, combineLatest, startWith } from 'rxjs';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';
import { ProductService, Product } from '@angular-monorepo-demo/data-access';

/**
 * Signals vs RxJS Comparison — Topic 2 (30 min)
 *
 * TEACHING POINTS:
 * 1. When to use Signals vs Observables
 * 2. Synchronous (signals) vs asynchronous (observables) reactivity
 * 3. Signals for UI state, Observables for events/streams
 * 4. Side-by-side comparison patterns
 */
@Component({
  selector: 'app-signals-vs-rxjs',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  template: `
    <div class="comparison-page">
      <h2>Signals vs RxJS <ui-badge variant="info">Block 3 — Topic 2</ui-badge></h2>

      <p class="note">
        Signals and RxJS Observables are <strong>complementary</strong>, not competing.
        Each excels in different scenarios.
      </p>

      <!-- Decision Framework -->
      <ui-card title="Decision Framework: Signal or Observable?" [elevated]="true">
        <div class="decision-grid">
          <div class="decision-col signal-col">
            <h4>Use Signals When:</h4>
            <ul>
              <li>You need synchronous current value</li>
              <li>Managing component UI state</li>
              <li>Deriving values via computed()</li>
              <li>Simple state that always has a value</li>
              <li>No complex async operations needed</li>
            </ul>
            <div class="example-tag">
              <ui-badge variant="success">Counter, form field, toggle, filtered list</ui-badge>
            </div>
          </div>
          <div class="decision-col rxjs-col">
            <h4>Use Observables When:</h4>
            <ul>
              <li>Working with async streams (HTTP, WebSocket)</li>
              <li>Needing operators (debounce, switchMap, retry)</li>
              <li>Event composition (merge, race, combineLatest)</li>
              <li>Values that may not exist yet (loading states)</li>
              <li>Complex pipelines with error handling</li>
            </ul>
            <div class="example-tag">
              <ui-badge variant="info">HTTP responses, search typeahead, WebSocket</ui-badge>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Pattern 1: Counter -->
      <ui-card title="Pattern 1: Simple Counter — Signal Wins" [elevated]="true">
        <div class="comparison-row">
          <div class="comparison-side signal-side">
            <h4><ui-badge variant="success">Signal</ui-badge> Approach</h4>
            <pre class="code-block">{{ codeSignalCounter }}</pre>
            <div class="demo-box">
              <span>Count: <strong>{{ signalCount() }}</strong> | Doubled: <strong>{{ signalDoubled() }}</strong></span>
              <ui-button variant="primary" size="sm" (clicked)="incrementSignal()">+1</ui-button>
            </div>
          </div>
          <div class="comparison-side rxjs-side">
            <h4><ui-badge variant="info">RxJS</ui-badge> Approach</h4>
            <pre class="code-block">{{ codeRxjsCounter }}</pre>
            <div class="demo-box">
              <span>Count: <strong>{{ rxjsCountValue() }}</strong> | Doubled: <strong>{{ rxjsDoubledValue() }}</strong></span>
              <ui-button variant="secondary" size="sm" (clicked)="incrementRxjs()">+1</ui-button>
            </div>
          </div>
        </div>
        <div class="verdict">
          <strong>Verdict:</strong> Signal is cleaner for synchronous component state.
          No need for async pipe or subscription management.
        </div>
      </ui-card>

      <!-- Pattern 2: Derived/Filtered Data -->
      <ui-card title="Pattern 2: Derived Data — Both Work Well" [elevated]="true">
        <div class="comparison-row">
          <div class="comparison-side signal-side">
            <h4><ui-badge variant="success">Signal</ui-badge> Computed Chain</h4>
            <pre class="code-block">{{ codeSignalFilter }}</pre>
            <div class="demo-box">
              <input
                [value]="searchTerm()"
                (input)="searchTerm.set(asInputValue($event))"
                placeholder="Search products (signal)..."
                class="search-input"
              />
              <span class="result-count">{{ filteredProducts().length }} results</span>
            </div>
          </div>
          <div class="comparison-side rxjs-side">
            <h4><ui-badge variant="info">RxJS</ui-badge> combineLatest</h4>
            <pre class="code-block">{{ codeRxjsFilter }}</pre>
            <div class="demo-box">
              <input
                (input)="searchSubject.next(asInputValue($event))"
                placeholder="Search products (rxjs)..."
                class="search-input"
              />
              <span class="result-count">{{ rxjsFilteredCount() }} results</span>
            </div>
          </div>
        </div>
        <div class="verdict">
          <strong>Verdict:</strong> Both approaches work. Signals are simpler for local filtering.
          RxJS shines when the source is already an Observable (HTTP response).
        </div>
      </ui-card>

      <!-- Pattern 3: Async Data -->
      <ui-card title="Pattern 3: Async Data Loading — Observables Shine" [elevated]="true">
        <div class="async-note">
          <p>When data comes from an API (HttpClient), observables are natural.
          Use toSignal() to bridge into signal world (covered in Topic 3).</p>
          <pre class="code-block">{{ codeAsyncBridge }}</pre>
        </div>
        <div class="verdict">
          <strong>Best Practice:</strong> Use Observables for the async pipeline,
          toSignal() to convert for the template. Best of both worlds.
        </div>
      </ui-card>

      <!-- Summary Table -->
      <ui-card title="Comparison Cheat Sheet" [elevated]="true">
        <table class="comparison-table">
          <thead>
            <tr><th>Aspect</th><th>Signals</th><th>RxJS Observables</th></tr>
          </thead>
          <tbody>
            <tr>
              <td>Value availability</td>
              <td><ui-badge variant="success">Always has value</ui-badge></td>
              <td><ui-badge variant="info">May not have emitted</ui-badge></td>
            </tr>
            <tr>
              <td>Synchronous read</td>
              <td><ui-badge variant="success">signal()</ui-badge></td>
              <td><ui-badge variant="danger">Not possible</ui-badge></td>
            </tr>
            <tr>
              <td>Operators</td>
              <td><ui-badge variant="warning">computed() only</ui-badge></td>
              <td><ui-badge variant="success">200+ operators</ui-badge></td>
            </tr>
            <tr>
              <td>Async support</td>
              <td><ui-badge variant="warning">Via toSignal()</ui-badge></td>
              <td><ui-badge variant="success">Native</ui-badge></td>
            </tr>
            <tr>
              <td>Cleanup</td>
              <td><ui-badge variant="success">Auto (DI context)</ui-badge></td>
              <td><ui-badge variant="warning">Manual unsubscribe</ui-badge></td>
            </tr>
            <tr>
              <td>Change detection</td>
              <td><ui-badge variant="success">Granular (zoneless)</ui-badge></td>
              <td><ui-badge variant="info">Zone-based / OnPush</ui-badge></td>
            </tr>
          </tbody>
        </table>
      </ui-card>
    </div>
  `,
  styles: [`
    .comparison-page { padding: 0.5rem; }
    .note { background: #d1ecf1; border: 1px solid #bee5eb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .decision-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    .decision-col { padding: 1rem; border-radius: 8px; }
    .decision-col ul { margin: 0.5rem 0; padding-left: 1.2rem; font-size: 0.9rem; }
    .decision-col li { margin: 0.3rem 0; }
    .signal-col { background: #d4edda; border: 2px solid #28a745; }
    .rxjs-col { background: #d1ecf1; border: 2px solid #17a2b8; }
    .example-tag { margin-top: 0.75rem; }
    .comparison-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 0.5rem 0; }
    .comparison-side { padding: 0.75rem; border-radius: 8px; }
    .signal-side { background: #f0faf3; border: 1px solid #c3e6cb; }
    .rxjs-side { background: #e8f4fd; border: 1px solid #b8daff; }
    .comparison-side h4 { margin: 0 0 0.5rem 0; font-size: 0.95rem; }
    .code-block { background: #2d2d2d; color: #f8f8f2; padding: 0.75rem; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; margin-bottom: 0.5rem; font-family: monospace; }
    .demo-box { display: flex; align-items: center; justify-content: space-between; padding: 0.5rem; background: white; border-radius: 6px; gap: 0.5rem; flex-wrap: wrap; }
    .search-input { padding: 0.4rem 0.75rem; border: 1px solid #ddd; border-radius: 4px; flex: 1; min-width: 120px; }
    .result-count { font-size: 0.85rem; color: #666; white-space: nowrap; }
    .verdict { background: #fff3cd; border: 1px solid #ffc107; padding: 0.75rem; border-radius: 6px; margin-top: 0.75rem; font-size: 0.85rem; }
    .async-note { padding: 0.5rem 0; }
    .async-note p { margin: 0 0 0.75rem 0; font-size: 0.9rem; }
    .comparison-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
    .comparison-table th { background: #f8f9fa; padding: 0.6rem; text-align: left; border-bottom: 2px solid #dee2e6; }
    .comparison-table td { padding: 0.5rem 0.6rem; border-bottom: 1px solid #e9ecef; }
  `]
})
export class SignalsVsRxjsComponent implements OnInit, OnDestroy {
  private productService = inject(ProductService);
  private destroy$ = new Subject<void>();

  // ── Code example strings (avoids template parsing issues with < > =>) ──
  codeSignalCounter = `// 3 lines — clean and clear
count = signal(0);
doubled = computed(() => count() * 2);
// Template: {{ count() }}`;

  codeRxjsCounter = `// Verbose for simple state
count$ = new BehaviorSubject(0);
doubled$ = count$.pipe(map(v => v * 2));
// Template: {{ count$ | async }}`;

  codeSignalFilter = `products = signal<Product[]>([]);
searchTerm = signal('');
filtered = computed(() =>
  products().filter(p =>
    p.name.toLowerCase().includes(
      searchTerm().toLowerCase()
    ))
);`;

  codeRxjsFilter = `products$ = this.svc.getProducts();
searchTerm$ = new Subject<string>();
filtered$ = combineLatest([
  products$,
  searchTerm$.pipe(startWith(''))
]).pipe(
  map(([p, term]) => p.filter(...))
);`;

  codeAsyncBridge = `// Observable is natural for HTTP
products$ = this.http.get<Product[]>('/api/products').pipe(
  retry(3),
  catchError(err => {
    this.errorSignal.set(err.message);
    return EMPTY;
  })
);

// Bridge to signal for template simplicity
products = toSignal(this.products$, { initialValue: [] });`;

  // ── Pattern 1: Counter ──
  signalCount = signal(0);
  signalDoubled = computed(() => this.signalCount() * 2);

  private rxjsCount$ = new BehaviorSubject(0);
  rxjsCountValue = signal(0);
  rxjsDoubledValue = signal(0);

  // ── Pattern 2: Filtered data ──
  products = signal<Product[]>([]);
  searchTerm = signal('');
  filteredProducts = computed(() => {
    const term = this.searchTerm().toLowerCase();
    return term ? this.products().filter(p => p.name.toLowerCase().includes(term)) : this.products();
  });

  searchSubject = new Subject<string>();
  rxjsFilteredCount = signal(0);

  ngOnInit(): void {
    this.productService.getProducts().subscribe(p => this.products.set(p));

    this.rxjsCount$.pipe(takeUntil(this.destroy$)).subscribe(v => this.rxjsCountValue.set(v));
    this.rxjsCount$.pipe(
      map(v => v * 2),
      takeUntil(this.destroy$)
    ).subscribe(v => this.rxjsDoubledValue.set(v));

    combineLatest([
      this.productService.getProducts(),
      this.searchSubject.pipe(startWith(''))
    ]).pipe(
      map(([products, term]) =>
        term ? products.filter(p => p.name.toLowerCase().includes(term.toLowerCase())) : products
      ),
      takeUntil(this.destroy$)
    ).subscribe(filtered => this.rxjsFilteredCount.set(filtered.length));
  }

  incrementSignal(): void {
    this.signalCount.update(v => v + 1);
  }

  incrementRxjs(): void {
    this.rxjsCount$.next(this.rxjsCount$.value + 1);
  }

  asInputValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
