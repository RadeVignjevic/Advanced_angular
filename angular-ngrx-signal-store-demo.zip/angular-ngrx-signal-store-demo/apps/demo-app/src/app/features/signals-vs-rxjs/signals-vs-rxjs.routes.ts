import { Route } from '@angular/router';
import { SignalsVsRxjsComponent } from './signals-vs-rxjs.component';

export const SIGNALS_VS_RXJS_ROUTES: Route[] = [
  { path: '', component: SignalsVsRxjsComponent }
];
