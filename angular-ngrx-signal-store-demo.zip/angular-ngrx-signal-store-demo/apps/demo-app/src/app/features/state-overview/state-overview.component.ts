import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * State Management Patterns: An Overview — Topic 1 (20 min)
 *
 * TEACHING POINTS:
 * 1. Why formalised state management matters
 * 2. Component state vs shared state vs global state
 * 3. Available solutions: Services, BehaviorSubject, NgRx Store, NgRx Signal Store
 * 4. When to introduce a state management library
 * 5. NgRx Signal Store as the modern recommended approach
 */
@Component({
  selector: 'app-state-overview',
  imports: [UiCardComponent, UiBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="overview-page">
      <h2>State Management Patterns <ui-badge variant="info">Block 5 — Topic 1</ui-badge></h2>

      <p class="note">
        As apps grow, managing shared state across components becomes the <strong>primary source
        of complexity</strong>. Formalised state management provides structure and predictability.
      </p>

      <!-- 1. Why State Management? -->
      <ui-card title="1. Why Formalised State Management?" [elevated]="true">
        <div class="demo-section">
          <div class="problem-grid">
            <div class="problem-card">
              <h4>Without Structure</h4>
              <ul>
                <li>State scattered across components</li>
                <li>Prop drilling through deep trees</li>
                <li>Duplicate data in multiple places</li>
                <li>Hard to track what changed and why</li>
                <li>Race conditions with async operations</li>
                <li>Testing requires complex setup</li>
              </ul>
              <ui-badge variant="danger">Spaghetti State</ui-badge>
            </div>
            <div class="problem-card good">
              <h4>With State Management</h4>
              <ul>
                <li>Single source of truth</li>
                <li>Components inject what they need</li>
                <li>Predictable state transitions</li>
                <li>Easy to debug and trace changes</li>
                <li>Consistent async patterns</li>
                <li>State is testable in isolation</li>
              </ul>
              <ui-badge variant="success">Structured State</ui-badge>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- 2. State Categories -->
      <ui-card title="2. Categories of State" [elevated]="true">
        <div class="demo-section">
          <div class="state-grid">
            <div class="state-card">
              <div class="state-icon">🔵</div>
              <h4>Component State</h4>
              <p>Local to one component. Form values, toggles, counters.</p>
              <pre class="code-block">{{ codeComponentState }}</pre>
              <ui-badge variant="info">signal() is enough</ui-badge>
            </div>
            <div class="state-card">
              <div class="state-icon">🟡</div>
              <h4>Shared State</h4>
              <p>Shared between sibling or related components. Selected item, filters.</p>
              <pre class="code-block">{{ codeSharedState }}</pre>
              <ui-badge variant="warning">Service or Signal Store</ui-badge>
            </div>
            <div class="state-card">
              <div class="state-icon">🔴</div>
              <h4>Global / App State</h4>
              <p>App-wide state. Auth, user prefs, feature flags, entities.</p>
              <pre class="code-block">{{ codeGlobalState }}</pre>
              <ui-badge variant="danger">Signal Store recommended</ui-badge>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- 3. Evolution of Solutions -->
      <ui-card title="3. Evolution of Angular State Management" [elevated]="true">
        <div class="demo-section">
          <div class="timeline">
            <div class="timeline-item">
              <div class="timeline-marker">1</div>
              <div class="timeline-content">
                <h4>Services + BehaviorSubject</h4>
                <p>Simple, no dependencies. Fine for small apps. Breaks down at scale.</p>
                <ui-badge variant="info">Angular 2+</ui-badge>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-marker">2</div>
              <div class="timeline-content">
                <h4>NgRx Store (Redux pattern)</h4>
                <p>Actions, reducers, effects, selectors. Very powerful but verbose.</p>
                <ui-badge variant="warning">Angular 4+</ui-badge>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-marker">3</div>
              <div class="timeline-content">
                <h4>NgRx Component Store</h4>
                <p>Lightweight, component-scoped. Less boilerplate than full NgRx.</p>
                <ui-badge variant="info">Angular 12+</ui-badge>
              </div>
            </div>
            <div class="timeline-item active">
              <div class="timeline-marker">4</div>
              <div class="timeline-content">
                <h4>NgRx Signal Store</h4>
                <p>Signal-based, functional API, composable features. The modern recommended approach.</p>
                <ui-badge variant="success">Angular 17+ (Current)</ui-badge>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- 4. Decision Framework -->
      <ui-card title="4. When to Use What?" [elevated]="true">
        <div class="demo-section">
          <table class="decision-table">
            <thead>
              <tr>
                <th>Scenario</th>
                <th>Solution</th>
                <th>Why</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Form toggle, counter, local UI</td>
                <td><ui-badge variant="info">signal()</ui-badge></td>
                <td>Component-local, no sharing needed</td>
              </tr>
              <tr>
                <td>Shared filter across 2-3 siblings</td>
                <td><ui-badge variant="info">Service + signal()</ui-badge></td>
                <td>Simple injection, no library needed</td>
              </tr>
              <tr>
                <td>Feature with CRUD + async loading</td>
                <td><ui-badge variant="success">Signal Store</ui-badge></td>
                <td>Structured state, loading/error handling</td>
              </tr>
              <tr>
                <td>Entity collections (products, users)</td>
                <td><ui-badge variant="success">Signal Store + withEntities</ui-badge></td>
                <td>Built-in entity management</td>
              </tr>
              <tr>
                <td>Complex cross-feature workflows</td>
                <td><ui-badge variant="warning">NgRx Store (Redux)</ui-badge></td>
                <td>Actions, effects, time-travel debugging</td>
              </tr>
            </tbody>
          </table>
        </div>
      </ui-card>

      <!-- 5. Signal Store Preview -->
      <ui-card title="5. NgRx Signal Store at a Glance" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeSignalStorePreview }}</pre>
          <div class="feature-pills">
            <span class="pill">signalStore()</span>
            <span class="pill">withState()</span>
            <span class="pill">withComputed()</span>
            <span class="pill">withMethods()</span>
            <span class="pill">withHooks()</span>
            <span class="pill">withEntities()</span>
            <span class="pill">patchState()</span>
          </div>
          <p class="explanation-inline">
            Signal Store uses a <strong>functional, composable API</strong>. Each <code>with*()</code>
            function adds a feature to the store. No classes, no decorators, no boilerplate.
          </p>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .overview-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .explanation-inline { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation-inline code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .problem-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .problem-card { background: #ffebee; border: 2px solid #ef9a9a; border-radius: 12px; padding: 1.25rem; }
    .problem-card.good { background: #e8f5e9; border-color: #a5d6a7; }
    .problem-card h4 { margin: 0 0 0.5rem; }
    .problem-card ul { padding-left: 1.25rem; font-size: 0.85rem; color: #555; margin: 0.5rem 0; }
    .problem-card li { margin: 0.25rem 0; }
    .state-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; }
    .state-card { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 1rem; text-align: center; }
    .state-icon { font-size: 2rem; margin-bottom: 0.25rem; }
    .state-card h4 { margin: 0.25rem 0; font-size: 0.95rem; }
    .state-card p { font-size: 0.82rem; color: #666; margin: 0.25rem 0; }
    .timeline { display: flex; flex-direction: column; gap: 0.5rem; }
    .timeline-item { display: flex; gap: 1rem; padding: 0.75rem; background: #f5f5f5; border-radius: 8px; align-items: flex-start; }
    .timeline-item.active { background: #e8f5e9; border: 2px solid #66bb6a; }
    .timeline-marker { background: #42a5f5; color: white; min-width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 0.85rem; flex-shrink: 0; }
    .timeline-item.active .timeline-marker { background: #2e7d32; }
    .timeline-content h4 { margin: 0 0 0.2rem; font-size: 0.9rem; }
    .timeline-content p { font-size: 0.82rem; color: #666; margin: 0.2rem 0 0.4rem; }
    .decision-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
    .decision-table th { background: #f5f5f5; padding: 0.6rem; text-align: left; border-bottom: 2px solid #ddd; }
    .decision-table td { padding: 0.6rem; border-bottom: 1px solid #eee; }
    .feature-pills { display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 0.75rem 0; }
    .pill { background: #e3f2fd; color: #1565c0; padding: 0.35rem 0.75rem; border-radius: 20px; font-size: 0.82rem; font-weight: 500; }
  `]
})
export class StateOverviewComponent {
  codeComponentState = `// Component state — signal() is enough
count = signal(0);
isOpen = signal(false);
formValue = signal('');`;

  codeSharedState = `// Shared state — injectable service
@Injectable({ providedIn: 'root' })
export class FilterService {
  searchTerm = signal('');
  category = signal<string | null>(null);
}`;

  codeGlobalState = `// Global state — Signal Store
export const AuthStore = signalStore(
  { providedIn: 'root' },
  withState({ user: null, token: null }),
  withComputed(/* ... */),
  withMethods(/* ... */)
);`;

  codeSignalStorePreview = `import { signalStore, withState, withComputed, withMethods, patchState } from '@ngrx/signals';

export const CounterStore = signalStore(
  withState({ count: 0 }),
  withComputed(({ count }) => ({
    doubled: computed(() => count() * 2),
  })),
  withMethods(({ count, ...store }) => ({
    increment() { patchState(store, { count: count() + 1 }); },
    reset()     { patchState(store, { count: 0 }); },
  }))
);

// Usage in component:
// store = inject(CounterStore);
// template: {{ store.count() }} / {{ store.doubled() }}`;
}
