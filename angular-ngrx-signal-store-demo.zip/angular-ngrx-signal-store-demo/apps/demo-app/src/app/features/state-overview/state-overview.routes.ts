import { Route } from '@angular/router';
import { StateOverviewComponent } from './state-overview.component';

export const STATE_OVERVIEW_ROUTES: Route[] = [
  { path: '', component: StateOverviewComponent }
];
