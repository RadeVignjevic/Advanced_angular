import { Component, ChangeDetectionStrategy, inject, computed, signal, OnDestroy, effect } from '@angular/core';
import { signalStore, withState, withComputed, withMethods, withHooks, patchState, getState, watchState, signalStoreFeature } from '@ngrx/signals';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

// ═══════════ Custom Logging Feature ═══════════
function withDevtools(storeName: string) {
  return signalStoreFeature(
    withHooks({
      onInit(store) {
        console.log(`[${storeName}] 🟢 Store initialized`, getState(store));
        const watcher = watchState(store, (state) => {
          console.log(`[${storeName}] 🔄 State changed:`, state);
        });
      },
      onDestroy(store) {
        console.log(`[${storeName}] 🔴 Store destroyed`);
      }
    })
  );
}

// ═══════════ Demo Store for debugging ═══════════
interface DebugDemoState {
  items: string[];
  selectedIndex: number;
  lastAction: string;
}

const DebugDemoStore = signalStore(
  withState<DebugDemoState>({
    items: ['Alpha', 'Beta', 'Gamma'],
    selectedIndex: 0,
    lastAction: 'initialized',
  }),
  withComputed(({ items, selectedIndex }) => ({
    selectedItem: computed(() => items()[selectedIndex()] ?? 'none'),
    count: computed(() => items().length),
  })),
  withMethods((store) => ({
    addItem(item: string) {
      patchState(store, {
        items: [...store.items(), item],
        lastAction: `added "${item}"`,
      });
    },
    removeItem(index: number) {
      const items = store.items().filter((_, i) => i !== index);
      patchState(store, {
        items,
        selectedIndex: Math.min(store.selectedIndex(), items.length - 1),
        lastAction: `removed index ${index}`,
      });
    },
    selectItem(index: number) {
      patchState(store, { selectedIndex: index, lastAction: `selected index ${index}` });
    },
  })),
  withDevtools('DebugDemoStore')
);

/**
 * Debugging & Observability — Topic 4 (20 min)
 */
@Component({
  selector: 'app-store-debugging',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DebugDemoStore],
  template: `
    <div class="debugging-page">
      <h2>Debugging &amp; Observability <ui-badge variant="info">Block 5 — Topic 4</ui-badge></h2>

      <p class="note">
        Debugging reactive state can be challenging. NgRx Signal Store provides
        <strong>getState()</strong> and <strong>watchState()</strong> to help
        inspect and trace state changes at runtime.
      </p>

      <!-- getState() -->
      <ui-card title="1. getState() — Snapshot Inspection" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeGetState }}</pre>

          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="logSnapshot()">
              Log Snapshot to Console
            </ui-button>
            <span class="inline-info">Open DevTools console to see output</span>
          </div>

          <div class="state-snapshot">
            <h4>Current State (rendered from getState):</h4>
            <pre class="snapshot-pre">{{ currentSnapshot() }}</pre>
          </div>

          <div class="explanation">
            <p><code>getState(store)</code> returns a plain JS object (snapshot) of the current state.
            Useful for logging, serialization, or sending state to error-tracking services.</p>
          </div>
        </div>
      </ui-card>

      <!-- watchState() -->
      <ui-card title="2. watchState() — Real-time State Tracing" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeWatchState }}</pre>

          <div class="explanation">
            <p><code>watchState(store, callback)</code> runs the callback on <strong>every state change</strong>
            inside a reactive effect. Great for development-time logging, analytics, or syncing to
            external systems.</p>
          </div>
        </div>
      </ui-card>

      <!-- Custom withDevtools -->
      <ui-card title="3. Custom withDevtools Feature" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeWithDevtools }}</pre>

          <div class="explanation">
            <p>Wrap <code>watchState</code> + <code>getState</code> inside a reusable
            <code>signalStoreFeature</code> to add consistent logging to any store.</p>
          </div>
        </div>
      </ui-card>

      <!-- Live Demo -->
      <ui-card title="4. Live Demo — Watch the Console" [elevated]="true">
        <div class="demo-section">
          <div class="live-store-state">
            <div class="state-row">
              <span class="label">Items:</span>
              <span>{{ debugStore.items().join(', ') }}</span>
            </div>
            <div class="state-row">
              <span class="label">Selected:</span>
              <span>{{ debugStore.selectedItem() }} (index {{ debugStore.selectedIndex() }})</span>
            </div>
            <div class="state-row">
              <span class="label">Last action:</span>
              <span>{{ debugStore.lastAction() }}</span>
            </div>
          </div>

          <div class="demo-row">
            <input type="text" placeholder="New item..." class="demo-input"
              #newItemInput (keyup.enter)="addItem(newItemInput)" />
            <ui-button variant="primary" size="sm" (clicked)="addItem(newItemInput)">Add</ui-button>
          </div>

          <div class="items-list">
            @for (item of debugStore.items(); track $index) {
              <div class="item-row" [class.selected]="$index === debugStore.selectedIndex()">
                <span (click)="debugStore.selectItem($index)" class="item-name">{{ item }}</span>
                <ui-button variant="danger" size="sm" (clicked)="debugStore.removeItem($index)">×</ui-button>
              </div>
            }
          </div>

          <p class="console-hint">
            Open browser DevTools → Console tab. Every action above triggers a
            <code>watchState</code> log from the <code>withDevtools</code> feature.
          </p>
        </div>
      </ui-card>

      <!-- Best Practices -->
      <ui-card title="5. Debugging Best Practices" [elevated]="true">
        <div class="demo-section">
          <div class="best-practices">
            <div class="practice">
              <ui-badge variant="success">Do</ui-badge>
              <span>Use <code>watchState</code> only during development — guard with <code>isDevMode()</code></span>
            </div>
            <div class="practice">
              <ui-badge variant="success">Do</ui-badge>
              <span>Name your stores via <code>withDevtools('StoreName')</code> for easy filtering</span>
            </div>
            <div class="practice">
              <ui-badge variant="success">Do</ui-badge>
              <span>Use <code>getState()</code> in error handlers to capture state snapshots</span>
            </div>
            <div class="practice">
              <ui-badge variant="danger">Don't</ui-badge>
              <span>Leave <code>watchState</code> in production — it runs on every change</span>
            </div>
            <div class="practice">
              <ui-badge variant="danger">Don't</ui-badge>
              <span>Mutate state from inside <code>watchState</code> — causes infinite loops</span>
            </div>
          </div>

          <pre class="code-block">{{ codeIsDevMode }}</pre>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .debugging-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.75rem 0; flex-wrap: wrap; }
    .demo-input { padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; min-width: 200px; }
    .demo-input:focus { outline: none; border-color: #42a5f5; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .inline-info { font-size: 0.82rem; color: #888; }
    .state-snapshot { background: #f5f5f5; border-radius: 8px; padding: 0.75rem; margin: 0.75rem 0; }
    .state-snapshot h4 { margin: 0 0 0.5rem; font-size: 0.85rem; }
    .snapshot-pre { background: #263238; color: #a5d6a7; padding: 0.75rem; border-radius: 6px; font-family: monospace; font-size: 0.82rem; margin: 0; }
    .live-store-state { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 0.75rem; margin-bottom: 0.75rem; }
    .state-row { display: flex; gap: 0.5rem; padding: 0.25rem 0; font-size: 0.88rem; }
    .state-row .label { font-weight: 600; min-width: 100px; color: #333; }
    .items-list { border: 1px solid #e0e0e0; border-radius: 8px; max-height: 200px; overflow-y: auto; }
    .item-row { display: flex; align-items: center; justify-content: space-between; padding: 0.4rem 0.75rem; border-bottom: 1px solid #eee; font-size: 0.88rem; }
    .item-row:last-child { border-bottom: none; }
    .item-row.selected { background: #e3f2fd; }
    .item-name { cursor: pointer; flex: 1; }
    .item-name:hover { color: #1976d2; }
    .console-hint { font-size: 0.82rem; color: #666; background: #fff8e1; padding: 0.5rem 0.75rem; border-radius: 8px; margin-top: 0.75rem; }
    .console-hint code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .best-practices { display: flex; flex-direction: column; gap: 0.5rem; margin: 0.5rem 0; }
    .practice { display: flex; align-items: center; gap: 0.75rem; font-size: 0.88rem; }
    .practice code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.82rem; }
  `]
})
export class StoreDebuggingComponent {
  protected debugStore = inject(DebugDemoStore);

  currentSnapshot = computed(() => JSON.stringify(getState(this.debugStore), null, 2));

  codeGetState = `import { getState } from '@ngrx/signals';

// Get a plain object snapshot of the store
const snapshot = getState(this.myStore);
console.log('Current state:', snapshot);

// Useful in error handlers:
handleError(error: Error) {
  errorReporter.report(error, {
    storeState: getState(this.myStore),
  });
}`;

  codeWatchState = `import { watchState } from '@ngrx/signals';

// Watch all state changes (runs inside an effect)
const watcher = watchState(this.myStore, (state) => {
  console.log('State changed:', state);
});

// In onInit hook:
withHooks({
  onInit(store) {
    watchState(store, (state) => {
      console.log('[MyStore] State:', state);
    });
  }
})`;

  codeWithDevtools = `// Reusable debugging feature
function withDevtools(storeName: string) {
  return signalStoreFeature(
    withHooks({
      onInit(store) {
        console.log(\`[\${storeName}] Store initialized\`, getState(store));
        watchState(store, (state) => {
          console.log(\`[\${storeName}] State changed:\`, state);
        });
      },
      onDestroy(store) {
        console.log(\`[\${storeName}] Store destroyed\`);
      }
    })
  );
}

// Add to any store:
const MyStore = signalStore(
  withState({ ... }),
  withDevtools('MyStore')  // <-- automatic logging
);`;

  codeIsDevMode = `import { isDevMode } from '@angular/core';

function withDevtools(name: string) {
  return signalStoreFeature(
    withHooks({
      onInit(store) {
        if (isDevMode()) {
          watchState(store, (state) =>
            console.log(\`[\${name}]\`, state)
          );
        }
      }
    })
  );
}`;

  logSnapshot(): void {
    const snapshot = getState(this.debugStore);
    console.log('[DebugDemoStore] Snapshot:', snapshot);
  }

  addItem(input: HTMLInputElement): void {
    const value = input.value.trim();
    if (value) {
      this.debugStore.addItem(value);
      input.value = '';
    }
  }
}
