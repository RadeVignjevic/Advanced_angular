import { Route } from '@angular/router';
import { StoreDebuggingComponent } from './store-debugging.component';

export const STORE_DEBUGGING_ROUTES: Route[] = [
  { path: '', component: StoreDebuggingComponent }
];
