import { Component, ChangeDetectionStrategy, inject, computed, signal } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { signalStore, withState, withComputed, withMethods, withHooks, patchState, signalStoreFeature, type } from '@ngrx/signals';
import { withEntities, setAllEntities, addEntity, removeEntity, updateEntity, entityConfig } from '@ngrx/signals/entities';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';
import { Product } from '@angular-monorepo-demo/data-access';

// ═══════════ PATTERN 1: Feature Store (scoped to a feature) ═══════════
interface FilterState {
  searchTerm: string;
  selectedCategory: string | null;
  showInStockOnly: boolean;
}

const ProductFilterStore = signalStore(
  withState<FilterState>({
    searchTerm: '',
    selectedCategory: null,
    showInStockOnly: false,
  }),
  withMethods((store) => ({
    setSearch(searchTerm: string) { patchState(store, { searchTerm }); },
    setCategory(selectedCategory: string | null) { patchState(store, { selectedCategory }); },
    toggleInStock() { patchState(store, { showInStockOnly: !store.showInStockOnly() }); },
    resetFilters() { patchState(store, { searchTerm: '', selectedCategory: null, showInStockOnly: false }); },
  }))
);

// ═══════════ PATTERN 2: Entity Collection Store ═══════════
const productConfig = entityConfig({
  entity: type<Product>(),
  selectId: (product) => product.id,
});

const ProductEntityStore = signalStore(
  withEntities(productConfig),
  withComputed(({ entities }) => ({
    totalCount: computed(() => entities().length),
    inStockCount: computed(() => entities().filter(p => p.inStock).length),
    categories: computed(() => [...new Set(entities().map(p => p.category))]),
  })),
  withMethods((store) => ({
    loadProducts(products: Product[]) {
      patchState(store, setAllEntities(products));
       console.log('entities():', store.entities());
      console.log('ids():', store.ids());
      console.log('entityMap():', store.entityMap());
    },
    addProduct(product: Product) {
      patchState(store, addEntity(product));
       console.log(' addProduct — entities:', store.entities());
      console.log(' addProduct — ids:', store.ids());
     console.log(' addProduct — entityMap:', store.entityMap());
    },
    removeProduct(id: number) {
      console.log(' remove — entityMap:', store.entityMap());
      patchState(store, removeEntity(id));
      console.log(' remove — entityMap:', store.entityMap());
    },
    toggleStock(id: number) {
      patchState(store, updateEntity(
        { id, changes: (p: Product) => ({ ...p, inStock: !p.inStock }) }
      ));
    },
  })),
  withHooks({
    onInit(store) {
      // Seed with demo data
      store.loadProducts([
        { id: 1, name: 'Angular Book', price: 39.99, category: 'Books', description: 'Learn Angular', inStock: true },
        { id: 2, name: 'TypeScript Guide', price: 29.99, category: 'Books', description: 'Master TS', inStock: true },
        { id: 3, name: 'RxJS Poster', price: 14.99, category: 'Merch', description: 'Wall art', inStock: false },
        { id: 4, name: 'Signal Mug', price: 12.99, category: 'Merch', description: 'Coffee mug', inStock: true },
      ]);
    }
  })
);

// ═══════════ PATTERN 3: Custom Store Feature (reusable) ═══════════
// A reusable "loading" feature that can be added to any store
function withLoadingState() {
  return signalStoreFeature(
    withState({ isLoading: false, error: null as string | null }),
    withComputed(({ isLoading, error }) => ({
      hasError: computed(() => error() !== null),
    })),
    withMethods((store) => ({
      setLoading() { patchState(store, { isLoading: true, error: null }); },
      setLoaded() { patchState(store, { isLoading: false }); },
      setError(error: string) { patchState(store, { isLoading: false, error }); },
    }))
  );
}

/**
 * Signal Store Design Patterns — Topic 3 (30 min)
 */
@Component({
  selector: 'app-store-patterns',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent, DecimalPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [ProductFilterStore, ProductEntityStore],
  template: `
    <div class="patterns-page">
      <h2>Signal Store Design Patterns <ui-badge variant="info">Block 5 — Topic 3</ui-badge></h2>

      <p class="note">
        Real apps need more than a counter. These patterns show how to structure stores
        for <strong>feature modules, entity collections, and reusable store features</strong>.
      </p>

      <!-- Pattern 1: Feature Store -->
      <ui-card title="Pattern 1: Feature Store (Scoped)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeFeatureStore }}</pre>

          <div class="demo-row">
            <input type="text" placeholder="Search..." [value]="filterStore.searchTerm()"
              (input)="filterStore.setSearch(getInputValue($event))" class="demo-input" />
            <ui-button [variant]="filterStore.showInStockOnly() ? 'primary' : 'ghost'" size="sm"
              (clicked)="filterStore.toggleInStock()">In Stock Only</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="filterStore.resetFilters()">Reset</ui-button>
          </div>

          <div class="state-display">
            <span>searchTerm: "{{ filterStore.searchTerm() }}"</span>
            <span>category: {{ filterStore.selectedCategory() ?? 'null' }}</span>
            <span>inStockOnly: {{ filterStore.showInStockOnly() }}</span>
          </div>

          <div class="explanation">
            <p>Feature stores are <strong>component-scoped</strong> — provided in the component's
            <code>providers</code> array. One instance per component tree. Destroyed with the component.</p>
          </div>
        </div>
      </ui-card>

      <!-- Pattern 2: Entity Collection -->
      <ui-card title="Pattern 2: Entity Collections (withEntities)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeEntityStore }}</pre>

          <div class="entity-stats">
            <span>Total: <strong>{{ entityStore.totalCount() }}</strong></span>
            <span>In Stock: <strong>{{ entityStore.inStockCount() }}</strong></span>
            <span>Categories: <strong>{{ entityStore.categories().join(', ') }}</strong></span>
          </div>

          <div class="entity-list">
            @for (product of entityStore.entities(); track product.id) {
              <div class="entity-row">
                <span class="entity-name">{{ product.name }}</span>
                <span class="entity-price">{{ product.price | number:'1.2-2' }}</span>
                <ui-badge [variant]="product.inStock ? 'success' : 'danger'">
                  {{ product.inStock ? 'In Stock' : 'Out' }}
                </ui-badge>
                <ui-button variant="ghost" size="sm" (clicked)="entityStore.toggleStock(product.id)">Toggle</ui-button>
                <ui-button variant="danger" size="sm" (clicked)="entityStore.removeProduct(product.id)">Remove</ui-button>
              </div>
            }
          </div>

          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="addDemoProduct()">Add Product</ui-button>
          </div>

          <div class="explanation">
            <p><code>withEntities()</code> provides: <code>entities()</code>, <code>ids()</code>,
            <code>entityMap()</code>. Use <code>setAllEntities</code>, <code>addEntity</code>,
            <code>updateEntity</code>, <code>removeEntity</code> to mutate.</p>
          </div>
        </div>
      </ui-card>

      <!-- Pattern 3: Custom Store Feature -->
      <ui-card title="Pattern 3: Custom Store Features (Reusable)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeCustomFeature }}</pre>

          <div class="explanation">
            <p><code>signalStoreFeature()</code> lets you create <strong>reusable store plugins</strong>.
            Common examples:</p>
            <ul>
              <li><strong>withLoadingState()</strong> — isLoading, error, setLoading(), setLoaded(), setError()</li>
              <li><strong>withPagination()</strong> — page, pageSize, totalPages, nextPage()</li>
              <li><strong>withUndoRedo()</strong> — undo(), redo(), history of state changes</li>
              <li><strong>withLogger()</strong> — logs all state changes to console</li>
            </ul>
            <p>Compose into any store: <code>signalStore(withState(...), withLoadingState(), ...)</code></p>
          </div>
        </div>
      </ui-card>

      <!-- Pattern 4: Store Composition -->
      <ui-card title="Pattern 4: Composing Multiple Features" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeComposition }}</pre>

          <div class="explanation">
            <p>Signal stores are <strong>composable by design</strong>. Stack features to build
            complex stores from simple, tested building blocks.</p>
            <p>Order matters: later features can access state from earlier features.</p>
          </div>
        </div>
      </ui-card>

      <!-- Pattern 5: providedIn options -->
      <ui-card title="Pattern 5: Store Scope (providedIn)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeProvidedIn }}</pre>

          <div class="scope-grid">
            <div class="scope-card">
              <h4>Component-scoped</h4>
              <p>Add to <code>providers: [MyStore]</code></p>
              <p>One instance per component. Destroyed with component.</p>
              <ui-badge variant="info">Feature stores</ui-badge>
            </div>
            <div class="scope-card">
              <h4>Root-scoped (singleton)</h4>
              <p>Use <code>{{ '{' }} providedIn: 'root' {{ '}' }}</code></p>
              <p>One instance for entire app. Lives forever.</p>
              <ui-badge variant="success">Auth, user prefs, global state</ui-badge>
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .patterns-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.75rem 0; flex-wrap: wrap; }
    .demo-input { padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; min-width: 200px; }
    .demo-input:focus { outline: none; border-color: #42a5f5; }
    .state-display { display: flex; gap: 1.5rem; font-family: monospace; font-size: 0.82rem; background: #f5f5f5; padding: 0.5rem 0.75rem; border-radius: 8px; margin: 0.5rem 0; flex-wrap: wrap; }
    .explanation p, .explanation-inline { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation ul { padding-left: 1.25rem; font-size: 0.85rem; color: #555; }
    .explanation li { margin: 0.3rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .entity-stats { display: flex; gap: 1.5rem; font-size: 0.95rem; margin-bottom: 0.5rem; }
    .entity-list { max-height: 200px; overflow-y: auto; border: 1px solid #e0e0e0; border-radius: 8px; }
    .entity-row { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 0.75rem; border-bottom: 1px solid #eee; font-size: 0.85rem; }
    .entity-row:last-child { border-bottom: none; }
    .entity-name { flex: 1; font-weight: 500; }
    .entity-price { color: #666; }
    .scope-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 0.75rem 0; }
    .scope-card { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 1rem; }
    .scope-card h4 { margin: 0 0 0.25rem; font-size: 0.9rem; }
    .scope-card p { font-size: 0.82rem; color: #666; margin: 0.2rem 0; }
    .scope-card code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.78rem; }
  `]
})
export class StorePatternsComponent {
  protected filterStore = inject(ProductFilterStore);
  protected entityStore = inject(ProductEntityStore);

  private nextProductId = 10;

  codeFeatureStore = `// Feature store — scoped to a component
const ProductFilterStore = signalStore(
  withState({
    searchTerm: '',
    selectedCategory: null as string | null,
    showInStockOnly: false,
  }),
  withMethods((store) => ({
    setSearch(term: string) { patchState(store, { searchTerm: term }); },
    toggleInStock()  { patchState(store, { showInStockOnly: !store.showInStockOnly() }); },
    resetFilters()   { patchState(store, { searchTerm: '', selectedCategory: null, showInStockOnly: false }); },
  }))
);

// Provide in component — one instance per component tree
@Component({
  providers: [ProductFilterStore],  // <-- scoped!
})`;

  codeEntityStore = `import { withEntities, setAllEntities, addEntity, removeEntity, updateEntity, entityConfig }
  from '@ngrx/signals/entities';

const productConfig = entityConfig({
  entity: type<Product>(),
  selectId: (product) => product.id,
});

const ProductEntityStore = signalStore(
  withEntities(productConfig),
  withComputed(({ entities }) => ({
    totalCount: computed(() => entities().length),
    inStockCount: computed(() => entities().filter(p => p.inStock).length),
  })),
  withMethods((store) => ({
    loadProducts(products: Product[]) {
      patchState(store, setAllEntities(products, productConfig));
    },
    addProduct(product: Product) {
      patchState(store, addEntity(product, productConfig));
    },
    removeProduct(id: number) {
      patchState(store, removeEntity(id, productConfig));
    },
  }))
);`;

  codeCustomFeature = `// Reusable store feature — add to any store
function withLoadingState() {
  return signalStoreFeature(
    withState({ isLoading: false, error: null as string | null }),
    withComputed(({ isLoading, error }) => ({
      hasError: computed(() => error() !== null),
    })),
    withMethods((store) => ({
      setLoading() { patchState(store, { isLoading: true, error: null }); },
      setLoaded()  { patchState(store, { isLoading: false }); },
      setError(msg: string) { patchState(store, { isLoading: false, error: msg }); },
    }))
  );
}

// Usage:
const MyStore = signalStore(
  withState({ data: [] }),
  withLoadingState(),  // <-- plug it in!
  // store.isLoading(), store.setLoading(), store.setError('...')
);`;

  codeComposition = `// Compose multiple features into one store
const ProductStore = signalStore(
  { providedIn: 'root' },
  withState({ searchTerm: '' }),         // 1. base state
  withEntities(productConfig),           // 2. entity collection
  withLoadingState(),                     // 3. loading/error
  withComputed(({ entities, searchTerm }) => ({
    filtered: computed(() => {
      const term = searchTerm().toLowerCase();
      return entities().filter(p =>
        p.name.toLowerCase().includes(term)
      );
    }),
  })),                                    // 4. derived state
  withMethods((store) => ({
    async loadProducts() {
      store.setLoading();
      try {
        const products = await fetchProducts();
        patchState(store, setAllEntities(products, productConfig));
        store.setLoaded();
      } catch (e) {
        store.setError('Failed to load');
      }
    },
  })),                                    // 5. async methods
  withHooks({ onInit: (store) => store.loadProducts() })
);`;

  codeProvidedIn = `// Component-scoped (default)
const FeatureStore = signalStore(
  withState({ ... })
);
// Provide: providers: [FeatureStore]

// Root-scoped (singleton)
const GlobalStore = signalStore(
  { providedIn: 'root' },
  withState({ ... })
);
// No providers needed — auto-injected`;

  getInputValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  addDemoProduct(): void {
    this.entityStore.addProduct({
      id: this.nextProductId++,
      name: `Product #${this.nextProductId - 1}`,
      price: Math.round(Math.random() * 50 * 100) / 100,
      category: ['Books', 'Merch', 'Tools'][Math.floor(Math.random() * 3)],
      description: 'Demo product',
      inStock: Math.random() > 0.3,
    });
  }
}
