import { Route } from '@angular/router';
import { StorePatternsComponent } from './store-patterns.component';

export const STORE_PATTERNS_ROUTES: Route[] = [
  { path: '', component: StorePatternsComponent }
];
