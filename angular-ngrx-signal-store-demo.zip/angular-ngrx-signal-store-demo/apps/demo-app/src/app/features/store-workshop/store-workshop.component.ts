import { Component, ChangeDetectionStrategy, inject, computed, signal } from '@angular/core';
import { signalStore, withState, withComputed, withMethods, withHooks, patchState, getState, signalStoreFeature } from '@ngrx/signals';
import { withEntities, setAllEntities, addEntity, removeEntity, updateEntity, entityConfig } from '@ngrx/signals/entities';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';
import { Product, ProductService } from '@angular-monorepo-demo/data-access';
import { rxMethod } from '@ngrx/signals/rxjs-interop';
import { pipe, switchMap, tap } from 'rxjs';

// ═══════════ Reusable Features ═══════════
function withLoadingState() {
  return signalStoreFeature(
    withState({ isLoading: false, error: null as string | null }),
    withComputed(({ isLoading, error }) => ({
      hasError: computed(() => error() !== null),
    })),
    withMethods((store) => ({
      setLoading() { patchState(store, { isLoading: true, error: null }); },
      setLoaded() { patchState(store, { isLoading: false }); },
      setError(error: string) { patchState(store, { isLoading: false, error }); },
    }))
  );
}

// ═══════════ Product CRUD Store ═══════════
const productConfig = entityConfig({
  entity: type<Product>(),
  selectId: (product: Product) => product.id,
});

// Needed for type<> helper
import { type } from '@ngrx/signals';

const ProductCrudStore = signalStore(
  withEntities(productConfig),
  withLoadingState(),
  withState({
    searchTerm: '',
    selectedCategory: 'all',
    editingProduct: null as Product | null,
    nextId: 100,
  }),
  withComputed(({ entities, searchTerm, selectedCategory }) => ({
    filteredProducts: computed(() => {
      let result = entities();
      const term = searchTerm().toLowerCase();
      if (term) {
        result = result.filter(p => p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term));
      }
      const cat = selectedCategory();
      if (cat !== 'all') {
        result = result.filter(p => p.category === cat);
      }
      return result;
    }),
    totalCount: computed(() => entities().length),
    categories: computed(() => ['all', ...new Set(entities().map(p => p.category))]),
    inStockCount: computed(() => entities().filter(p => p.inStock).length),
    outOfStockCount: computed(() => entities().filter(p => !p.inStock).length),
  })),
  withMethods((store, productService = inject(ProductService)) => ({
    // READ
    loadProducts: rxMethod<void>(
      pipe(
        tap(() => store.setLoading()),
        switchMap(() => productService.getProducts().pipe(
          tap((products) => {
            patchState(store, setAllEntities(products));
            store.setLoaded();
          })
        ))
      )
    ),
    // CREATE
    createProduct(data: Omit<Product, 'id'>) {
      const id = store.nextId();
      const product: Product = { ...data, id };
      patchState(store, addEntity(product), { nextId: id + 1 });
    },
    // UPDATE
    updateProduct(id: number, changes: Partial<Product>) {
      patchState(store, updateEntity({ id, changes }));
    },
    // DELETE
    deleteProduct(id: number) {
      patchState(store, removeEntity(id));
    },
    // TOGGLE STOCK
    toggleStock(id: number) {
      patchState(store, updateEntity(
        { id, changes: (p: Product) => ({ ...p, inStock: !p.inStock }) }
      ));
    },
    // FILTERING
    setSearch(searchTerm: string) { patchState(store, { searchTerm }); },
    setCategory(selectedCategory: string) { patchState(store, { selectedCategory }); },
    // EDITING
    startEditing(product: Product) { patchState(store, { editingProduct: { ...product } }); },
    cancelEditing() { patchState(store, { editingProduct: null }); },
    saveEditing() {
      const p = store.editingProduct();
      if (p) {
        patchState(store, updateEntity({ id: p.id, changes: p }), { editingProduct: null });
      }
    },
    updateEditField(field: string, value: string | number | boolean) {
      const current = store.editingProduct();
      if (current) {
        patchState(store, { editingProduct: { ...current, [field]: value } });
      }
    },
  })),
  withHooks({
    onInit(store) {
      store.loadProducts();
    }
  })
);

/**
 * Workshop: CRUD Feature Store — Topic 5 (40 min)
 */
@Component({
  selector: 'app-store-workshop',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [ProductCrudStore],
  template: `
    <div class="workshop-page">
      <h2>Workshop: Product CRUD Store <ui-badge variant="info">Block 5 — Topic 5</ui-badge></h2>

      <p class="note">
        End-to-end CRUD feature management using <strong>NgRx Signal Store</strong>,
        <strong>withEntities</strong>, custom features, and <strong>rxMethod</strong>
        for async data loading.
      </p>

      <!-- Store Architecture -->
      <ui-card title="Store Architecture" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeArchitecture }}</pre>
          <div class="explanation">
            <p>This store composes multiple features:</p>
            <ul>
              <li><strong>withEntities</strong> — normalized entity collection for products</li>
              <li><strong>withLoadingState</strong> — reusable loading/error tracking</li>
              <li><strong>withState</strong> — search, filter, edit state</li>
              <li><strong>withComputed</strong> — filtered products, counts, categories</li>
              <li><strong>rxMethod</strong> — async data loading via ProductService Observable</li>
              <li><strong>withHooks</strong> — auto-load on initialization</li>
            </ul>
          </div>
        </div>
      </ui-card>

      <!-- Dashboard -->
      <ui-card title="Product Dashboard" [elevated]="true">
        <div class="demo-section">
          <div class="stats-bar">
            <div class="stat">
              <span class="stat-value">{{ store.totalCount() }}</span>
              <span class="stat-label">Total</span>
            </div>
            <div class="stat">
              <span class="stat-value">{{ store.inStockCount() }}</span>
              <span class="stat-label">In Stock</span>
            </div>
            <div class="stat">
              <span class="stat-value">{{ store.outOfStockCount() }}</span>
              <span class="stat-label">Out of Stock</span>
            </div>
            <div class="stat">
              <span class="stat-value">{{ store.filteredProducts().length }}</span>
              <span class="stat-label">Showing</span>
            </div>
          </div>

          @if (store.isLoading()) {
            <div class="loading-bar">Loading products...</div>
          }
          @if (store.hasError()) {
            <div class="error-bar">
              Error: {{ store.error() }}
              <ui-button variant="ghost" size="sm" (clicked)="store.loadProducts()">Retry</ui-button>
            </div>
          }
        </div>
      </ui-card>

      <!-- Filters + Search -->
      <ui-card title="Search & Filter" [elevated]="true">
        <div class="demo-section">
          <div class="filter-bar">
            <input type="text" placeholder="Search products..." class="demo-input"
              [value]="store.searchTerm()"
              (input)="store.setSearch(getInputValue($event))" />
            <select class="demo-select" (change)="store.setCategory(getSelectValue($event))">
              @for (cat of store.categories(); track cat) {
                <option [value]="cat" [selected]="cat === store.selectedCategory()">{{ cat }}</option>
              }
            </select>
          </div>
        </div>
      </ui-card>

      <!-- Product List -->
      <ui-card title="Products" [elevated]="true">
        <div class="demo-section">
          <div class="product-list">
            @for (product of store.filteredProducts(); track product.id) {
              <div class="product-row">
                @if (isEditing(product.id)) {
                  <!-- Edit Mode -->
                  <div class="edit-form">
                    <input class="demo-input edit-input" [value]="store.editingProduct()?.name ?? ''"
                      (input)="store.updateEditField('name', getInputValue($event))" placeholder="Name" />
                    <input class="demo-input edit-input" type="number" [value]="store.editingProduct()?.price ?? 0"
                      (input)="store.updateEditField('price', getInputNumber($event))" placeholder="Price" />
                    <input class="demo-input edit-input" [value]="store.editingProduct()?.category ?? ''"
                      (input)="store.updateEditField('category', getInputValue($event))" placeholder="Category" />
                    <ui-button variant="primary" size="sm" (clicked)="store.saveEditing()">Save</ui-button>
                    <ui-button variant="ghost" size="sm" (clicked)="store.cancelEditing()">Cancel</ui-button>
                  </div>
                } @else {
                  <!-- View Mode -->
                  <div class="product-info">
                    <span class="product-name">{{ product.name }}</span>
                    <span class="product-category">{{ product.category }}</span>
                    <span class="product-price">\${{ product.price }}</span>
                    <ui-badge [variant]="product.inStock ? 'success' : 'danger'">
                      {{ product.inStock ? 'In Stock' : 'Out of Stock' }}
                    </ui-badge>
                  </div>
                  <div class="product-actions">
                    <ui-button variant="ghost" size="sm" (clicked)="store.startEditing(product)">Edit</ui-button>
                    <ui-button variant="ghost" size="sm" (clicked)="store.toggleStock(product.id)">Toggle Stock</ui-button>
                    <ui-button variant="danger" size="sm" (clicked)="store.deleteProduct(product.id)">Delete</ui-button>
                  </div>
                }
              </div>
            } @empty {
              <div class="empty-state">No products found.</div>
            }
          </div>
        </div>
      </ui-card>

      <!-- Create Product -->
      <ui-card title="Create Product" [elevated]="true">
        <div class="demo-section">
          <div class="create-form">
            <input class="demo-input" #nameInput placeholder="Name" />
            <input class="demo-input" #priceInput type="number" placeholder="Price" />
            <input class="demo-input" #categoryInput placeholder="Category" />
            <input class="demo-input" #descInput placeholder="Description" />
            <ui-button variant="primary" size="sm"
              (clicked)="createProduct(nameInput, priceInput, categoryInput, descInput)">
              Add Product
            </ui-button>
          </div>
        </div>
      </ui-card>

      <!-- rxMethod Code Example -->
      <ui-card title="Key Pattern: rxMethod for Async" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeRxMethod }}</pre>
          <div class="explanation">
            <p><code>rxMethod</code> bridges RxJS Observables into Signal Store methods.
            It creates a method that triggers an RxJS pipeline. Useful for async
            operations like HTTP calls.</p>
          </div>
        </div>
      </ui-card>

      <!-- Exercise -->
      <ui-card title="Exercise: Extend the CRUD Store" [elevated]="true">
        <div class="demo-section">
          <div class="exercise-tasks">
            <h4>Tasks for students:</h4>
            <ol>
              <li>Add a <code>sortBy</code> state field and implement <code>sortProducts()</code>
              computed that sorts by name or price</li>
              <li>Add <code>withPagination()</code> custom feature: page, pageSize,
              totalPages, nextPage(), prevPage()</li>
              <li>Create a <code>ProductDetailStore</code> that loads a single product
              by ID using <code>rxMethod</code></li>
              <li>Add a <code>withUndoRedo()</code> feature that keeps state history
              and allows undo/redo of entity changes</li>
            </ol>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .workshop-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-input { padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; }
    .demo-input:focus { outline: none; border-color: #42a5f5; }
    .demo-select { padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; background: #fff; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation ul { padding-left: 1.25rem; font-size: 0.85rem; color: #555; }
    .explanation li { margin: 0.3rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }

    .stats-bar { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 0.75rem; }
    .stat { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 0.75rem; text-align: center; }
    .stat-value { display: block; font-size: 1.5rem; font-weight: 700; color: #1976d2; }
    .stat-label { font-size: 0.78rem; color: #888; text-transform: uppercase; }
    .loading-bar { background: #fff3e0; padding: 0.5rem 0.75rem; border-radius: 8px; font-size: 0.88rem; color: #e65100; }
    .error-bar { background: #ffebee; padding: 0.5rem 0.75rem; border-radius: 8px; font-size: 0.88rem; color: #c62828; display: flex; align-items: center; gap: 0.5rem; }

    .filter-bar { display: flex; gap: 0.75rem; flex-wrap: wrap; }
    .filter-bar .demo-input { flex: 1; min-width: 200px; }

    .product-list { border: 1px solid #e0e0e0; border-radius: 8px; max-height: 400px; overflow-y: auto; }
    .product-row { border-bottom: 1px solid #eee; padding: 0.5rem 0.75rem; }
    .product-row:last-child { border-bottom: none; }
    .product-info { display: flex; align-items: center; gap: 0.75rem; font-size: 0.88rem; }
    .product-name { font-weight: 600; flex: 1; }
    .product-category { color: #888; font-size: 0.82rem; }
    .product-price { font-weight: 500; color: #2e7d32; }
    .product-actions { display: flex; gap: 0.25rem; margin-top: 0.25rem; }

    .edit-form { display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap; }
    .edit-input { flex: 1; min-width: 120px; }

    .create-form { display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap; }
    .create-form .demo-input { flex: 1; min-width: 120px; }

    .empty-state { padding: 1.5rem; text-align: center; color: #888; font-size: 0.9rem; }

    .exercise-tasks { background: #f3e5f5; border-radius: 12px; padding: 1rem; }
    .exercise-tasks h4 { margin: 0 0 0.5rem; }
    .exercise-tasks ol { padding-left: 1.25rem; font-size: 0.88rem; }
    .exercise-tasks li { margin: 0.5rem 0; }
    .exercise-tasks code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.82rem; }
  `]
})
export class StoreWorkshopComponent {
  protected store = inject(ProductCrudStore);

  codeArchitecture = `const ProductCrudStore = signalStore(
  withEntities(productConfig),        // entity collection
  withLoadingState(),                   // reusable loading feature
  withState({
    searchTerm: '',
    selectedCategory: 'all',
    editingProduct: null as Product | null,
    nextId: 100,
  }),
  withComputed(({ entities, searchTerm, selectedCategory }) => ({
    filteredProducts: computed(() => { ... }),
    totalCount: computed(() => entities().length),
    categories: computed(() => ['all', ...new Set(entities().map(p => p.category))]),
  })),
  withMethods((store, productService = inject(ProductService)) => ({
    loadProducts: rxMethod<void>(pipe(
      switchMap(() => productService.getProducts()),
      tap((products) => patchState(store, setAllEntities(products, productConfig)))
    )),
    createProduct(data) { patchState(store, addEntity(product, productConfig)); },
    updateProduct(id, changes) { patchState(store, updateEntity({ id, changes }, productConfig)); },
    deleteProduct(id) { patchState(store, removeEntity(id, productConfig)); },
  })),
  withHooks({ onInit: (store) => store.loadProducts() })
);`;

  codeRxMethod = `import { rxMethod } from '@ngrx/signals/rxjs-interop';
import { pipe, switchMap, tap } from 'rxjs';

// rxMethod creates a method that triggers an RxJS pipeline
loadProducts: rxMethod<void>(
  pipe(
    tap(() => store.setLoading()),          // 1. set loading state
    switchMap(() =>
      productService.getProducts().pipe(    // 2. call service (Observable)
        tap((products) => {
          patchState(store,                 // 3. update entities
            setAllEntities(products, productConfig)
          );
          store.setLoaded();                // 4. clear loading
        })
      )
    )
  )
),

// Can also accept a signal or observable as input:
loadById: rxMethod<number>(
  pipe(
    switchMap((id) => productService.getProductById(id))
  )
)`;

  isEditing(productId: number): boolean {
    return this.store.editingProduct()?.id === productId;
  }

  getInputValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  getInputNumber(event: Event): number {
    return parseFloat((event.target as HTMLInputElement).value) || 0;
  }

  getSelectValue(event: Event): string {
    return (event.target as HTMLSelectElement).value;
  }

  createProduct(
    nameInput: HTMLInputElement,
    priceInput: HTMLInputElement,
    categoryInput: HTMLInputElement,
    descInput: HTMLInputElement
  ): void {
    const name = nameInput.value.trim();
    if (!name) return;

    this.store.createProduct({
      name,
      price: parseFloat(priceInput.value) || 0,
      category: categoryInput.value.trim() || 'Uncategorized',
      description: descInput.value.trim() || '',
      inStock: true,
    });

    nameInput.value = '';
    priceInput.value = '';
    categoryInput.value = '';
    descInput.value = '';
  }
}
