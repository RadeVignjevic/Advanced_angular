import { Route } from '@angular/router';
import { StoreWorkshopComponent } from './store-workshop.component';

export const STORE_WORKSHOP_ROUTES: Route[] = [
  { path: '', component: StoreWorkshopComponent }
];
