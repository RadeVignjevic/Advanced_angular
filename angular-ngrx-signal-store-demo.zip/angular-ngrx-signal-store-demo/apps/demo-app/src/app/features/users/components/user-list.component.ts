import { Component, inject, signal, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { UserService, User } from '@angular-monorepo-demo/data-access';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';
import { DateAdapter } from '@angular-monorepo-demo/util';

@Component({
  selector: 'app-user-list',
  imports: [UiCardComponent, UiBadgeComponent],
  template: `
    <h2>Users <ui-badge variant="success">Standalone</ui-badge></h2>
    <div class="user-grid">
      @for (user of users(); track user.id) {
        <ui-card [title]="user.name" [elevated]="true">
          <p class="email">{{ user.email }}</p>
          <ui-badge [variant]="user.role === 'admin' ? 'danger' : user.role === 'editor' ? 'info' : 'neutral'">
            {{ user.role }}
          </ui-badge>
          <p class="login">Last login: {{ formatDate(user.lastLogin) }}</p>
        </ui-card>
      }
    </div>
  `,
  styles: [`
    .user-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; margin-top: 1rem; }
    .email { color: #666; font-size: 0.9rem; margin: 0.3rem 0; }
    .login { font-size: 0.8rem; color: #999; margin-top: 0.5rem; }
  `]
})
export class UserListComponent implements OnInit {
  private userService = inject(UserService);
  users = signal<User[]>([]);

  ngOnInit(): void {
    this.userService.getUsers().subscribe(u => this.users.set(u));
  }

  formatDate(date: Date): string {
    return DateAdapter.format(date);
  }
}
