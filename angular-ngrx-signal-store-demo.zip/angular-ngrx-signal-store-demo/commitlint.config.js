// Commitlint Configuration
// Enforces conventional commit format: type(scope): subject
// Examples:
//   feat(shared-ui): add dropdown component
//   fix(data-access): handle null response in ProductService
//   docs(util): update adapter pattern documentation
//   refactor(demo-app): extract dashboard widgets
//
// Types: feat, fix, docs, style, refactor, perf, test, build, ci, chore, revert

module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    // Enforce specific scopes matching our library structure
    'scope-enum': [
      2,
      'always',
      [
        'shared-ui',       // UI component library
        'data-access',     // Data access library
        'util',            // Utility library
        'demo-app',        // Demo application
        'workspace',       // Workspace-level changes (nx.json, tsconfig.base, etc.)
        'ci',              // CI/CD pipeline changes
        'release',         // Release-related changes
      ],
    ],
    'scope-empty': [1, 'never'],           // Warn if scope is missing
    'subject-case': [2, 'always', 'lower-case'],
    'header-max-length': [2, 'always', 100],
    'body-max-line-length': [2, 'always', 200],
  },
};
