/**
 * @angular-monorepo-demo/data-access
 *
 * PUBLIC API — Models, services, and injection tokens.
 * This library is a "data-access" boundary — it should only
 * be imported by feature libraries or applications, never by UI libs.
 */

// --- Models ---
export { type Product, type Customer, type User } from './lib/models';

// --- Tokens ---
export {
  APP_CONFIG, DEFAULT_APP_CONFIG, type AppConfig,
  LOGGER_CONFIG, DEV_LOGGER_CONFIG, type LoggerConfig
} from './lib/tokens';

// --- Services ---
export { ProductService } from './lib/services/product.service';
export { CustomerService } from './lib/services/customer.service';
export { UserService } from './lib/services/user.service';
export { LoggerService } from './lib/services/logger.service';
