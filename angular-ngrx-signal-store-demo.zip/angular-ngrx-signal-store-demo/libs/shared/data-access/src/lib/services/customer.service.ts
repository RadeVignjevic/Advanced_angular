import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { Customer } from '../models';

/** CustomerService — providedIn: 'root' (Block 1 migration already done) */
@Injectable({ providedIn: 'root' })
export class CustomerService {
  private customers: Customer[] = [
    { id: 1, firstName: 'Alice', lastName: 'Johnson', email: 'alice@example.com', phone: '555-0101', tier: 'platinum', totalOrders: 142 },
    { id: 2, firstName: 'Bob', lastName: 'Smith', email: 'bob@example.com', phone: '555-0102', tier: 'gold', totalOrders: 87 },
    { id: 3, firstName: 'Carol', lastName: 'Williams', email: 'carol@example.com', phone: '555-0103', tier: 'silver', totalOrders: 34 },
    { id: 4, firstName: 'David', lastName: 'Brown', email: 'david@example.com', phone: '555-0104', tier: 'bronze', totalOrders: 12 },
    { id: 5, firstName: 'Eva', lastName: 'Davis', email: 'eva@example.com', phone: '555-0105', tier: 'gold', totalOrders: 95 },
    { id: 6, firstName: 'Grace', lastName: 'Wilson', email: 'grace@example.com', phone: '555-0107', tier: 'platinum', totalOrders: 203 },
  ];

  getCustomers(): Observable<Customer[]> {
    return of(this.customers).pipe(delay(200));
  }

  getCustomerById(id: number): Observable<Customer | undefined> {
    return of(this.customers.find(c => c.id === id)).pipe(delay(100));
  }
}
