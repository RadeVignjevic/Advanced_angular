import { inject, Injectable } from '@angular/core';
import { LOGGER_CONFIG } from '../tokens';

@Injectable({ providedIn: 'root' })
export class LoggerService {
  private config = inject(LOGGER_CONFIG);

  debug(msg: string, ...args: unknown[]): void {
    if (this.shouldLog('debug') && this.config.enableConsole) console.debug(`[DEBUG] ${msg}`, ...args);
  }
  info(msg: string, ...args: unknown[]): void {
    if (this.shouldLog('info') && this.config.enableConsole) console.info(`[INFO] ${msg}`, ...args);
  }
  warn(msg: string, ...args: unknown[]): void {
    if (this.shouldLog('warn') && this.config.enableConsole) console.warn(`[WARN] ${msg}`, ...args);
  }
  error(msg: string, ...args: unknown[]): void {
    if (this.shouldLog('error') && this.config.enableConsole) console.error(`[ERROR] ${msg}`, ...args);
  }

  getLevel(): string { return this.config.level; }

  private shouldLog(level: string): boolean {
    const levels = ['debug', 'info', 'warn', 'error'];
    return levels.indexOf(level) >= levels.indexOf(this.config.level);
  }
}
