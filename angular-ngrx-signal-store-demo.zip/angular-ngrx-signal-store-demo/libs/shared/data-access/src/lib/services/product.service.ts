import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { Product } from '../models';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private products: Product[] = [
    { id: 1, name: 'Laptop Pro X', price: 1299.99, category: 'Electronics', description: 'High-performance laptop', inStock: true },
    { id: 2, name: 'Wireless Mouse', price: 49.99, category: 'Electronics', description: 'Ergonomic wireless mouse', inStock: true },
    { id: 3, name: 'Standing Desk', price: 599.99, category: 'Furniture', description: 'Adjustable height desk', inStock: false },
    { id: 4, name: 'Mechanical Keyboard', price: 159.99, category: 'Electronics', description: 'Cherry MX, RGB backlit', inStock: true },
    { id: 5, name: 'Monitor 27"', price: 449.99, category: 'Electronics', description: '4K UHD IPS display', inStock: true },
    { id: 6, name: 'Desk Chair', price: 399.99, category: 'Furniture', description: 'Ergonomic with lumbar support', inStock: true },
  ];

  getProducts(): Observable<Product[]> {
    return of(this.products).pipe(delay(200));
  }

  getProductById(id: number): Observable<Product | undefined> {
    return of(this.products.find(p => p.id === id)).pipe(delay(100));
  }

  getCategories(): string[] {
    return [...new Set(this.products.map(p => p.category))];
  }
}
