import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { User } from '../models';

@Injectable({ providedIn: 'root' })
export class UserService {
  private users: User[] = [
    { id: 1, name: 'Admin User', email: 'admin@example.com', role: 'admin', avatarUrl: 'https://i.pravatar.cc/150?u=admin', lastLogin: new Date('2026-04-19') },
    { id: 2, name: 'Jane Editor', email: 'jane@example.com', role: 'editor', avatarUrl: 'https://i.pravatar.cc/150?u=jane', lastLogin: new Date('2026-04-18') },
    { id: 3, name: 'John Viewer', email: 'john@example.com', role: 'viewer', avatarUrl: 'https://i.pravatar.cc/150?u=john', lastLogin: new Date('2026-04-15') },
    { id: 4, name: 'Sarah Editor', email: 'sarah@example.com', role: 'editor', avatarUrl: 'https://i.pravatar.cc/150?u=sarah', lastLogin: new Date('2026-04-20') },
  ];

  getUsers(): Observable<User[]> {
    return of(this.users).pipe(delay(200));
  }

  getUserById(id: number): Observable<User | undefined> {
    return of(this.users.find(u => u.id === id)).pipe(delay(100));
  }
}
