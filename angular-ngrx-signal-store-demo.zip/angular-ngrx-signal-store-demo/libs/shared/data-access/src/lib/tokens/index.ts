import { InjectionToken } from '@angular/core';

export interface AppConfig {
  apiUrl: string;
  appTitle: string;
  enableAnalytics: boolean;
  maxItemsPerPage: number;
}

export const APP_CONFIG = new InjectionToken<AppConfig>('app.config');

export const DEFAULT_APP_CONFIG: AppConfig = {
  apiUrl: 'https://api.example.com',
  appTitle: 'Monorepo Architecture Demo',
  enableAnalytics: false,
  maxItemsPerPage: 10
};

export interface LoggerConfig {
  level: 'debug' | 'info' | 'warn' | 'error';
  enableConsole: boolean;
}

export const LOGGER_CONFIG = new InjectionToken<LoggerConfig>('logger.config');

export const DEV_LOGGER_CONFIG: LoggerConfig = {
  level: 'debug',
  enableConsole: true
};
