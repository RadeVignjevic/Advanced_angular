/**
 * @angular-monorepo-demo/shared-ui
 *
 * PUBLIC API — This file defines the library's public surface.
 * Only symbols exported here are accessible to consumers.
 *
 * PUBLIC API DESIGN PRINCIPLES:
 * 1. Export only what consumers need (components, types, interfaces)
 * 2. Do NOT export internal helpers or implementation details
 * 3. Group exports by feature area
 * 4. Document breaking changes in CHANGELOG.md
 */

// --- Button ---
export { UiButtonComponent, type ButtonVariant, type ButtonSize } from './lib/button/button.component';

// --- Badge ---
export { UiBadgeComponent, type BadgeVariant } from './lib/badge/badge.component';

// --- Card ---
export { UiCardComponent } from './lib/card/card.component';

// --- Data Table ---
export { UiDataTableComponent, type TableColumn } from './lib/data-table/data-table.component';

// --- Layout ---
export { UiLayoutComponent } from './lib/layout/layout.component';
