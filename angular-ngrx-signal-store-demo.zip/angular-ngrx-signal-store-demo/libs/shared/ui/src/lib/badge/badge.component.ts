import { Component, input } from '@angular/core';

export type BadgeVariant = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

/**
 * UiBadgeComponent — Standalone badge/tag component.
 *
 * Demonstrates:
 * - Minimal public API surface
 * - Signal inputs with defaults
 */
@Component({
  selector: 'ui-badge',
  template: `
    <span [class]="'ui-badge ui-badge--' + variant()">
      <ng-content />
    </span>
  `,
  styles: [`
    .ui-badge {
      display: inline-flex; align-items: center;
      padding: 0.15rem 0.5rem; border-radius: 12px;
      font-size: 0.75rem; font-weight: 600;
    }
    .ui-badge--success { background: #d4edda; color: #155724; }
    .ui-badge--warning { background: #fff3cd; color: #856404; }
    .ui-badge--danger { background: #f8d7da; color: #721c24; }
    .ui-badge--info { background: #d1ecf1; color: #0c5460; }
    .ui-badge--neutral { background: #e2e3e5; color: #383d41; }
  `]
})
export class UiBadgeComponent {
  variant = input<BadgeVariant>('neutral');
}
