import type { Meta, StoryObj } from '@storybook/angular';
import { UiBadgeComponent } from './badge.component';

/**
 * # UiBadge
 *
 * A small status indicator badge component.
 * Uses signal inputs with pre-defined variant types.
 *
 * ## Usage
 * ```html
 * <ui-badge variant="success">Active</ui-badge>
 * <ui-badge variant="danger">Overdue</ui-badge>
 * ```
 */
const meta: Meta<UiBadgeComponent> = {
  title: 'Shared UI/Badge',
  component: UiBadgeComponent,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['success', 'warning', 'danger', 'info', 'neutral'],
      description: 'Visual variant of the badge',
    },
  },
  render: (args) => ({
    props: args,
    template: `<ui-badge [variant]="variant">Badge Text</ui-badge>`,
  }),
};

export default meta;
type Story = StoryObj<UiBadgeComponent>;

export const Success: Story = {
  args: { variant: 'success' },
  render: (args) => ({
    props: args,
    template: `<ui-badge [variant]="variant">Active</ui-badge>`,
  }),
};

export const Warning: Story = {
  args: { variant: 'warning' },
  render: (args) => ({
    props: args,
    template: `<ui-badge [variant]="variant">Pending</ui-badge>`,
  }),
};

export const Danger: Story = {
  args: { variant: 'danger' },
  render: (args) => ({
    props: args,
    template: `<ui-badge [variant]="variant">Overdue</ui-badge>`,
  }),
};

export const Info: Story = {
  args: { variant: 'info' },
  render: (args) => ({
    props: args,
    template: `<ui-badge [variant]="variant">New</ui-badge>`,
  }),
};

export const Neutral: Story = {
  args: { variant: 'neutral' },
  render: (args) => ({
    props: args,
    template: `<ui-badge [variant]="variant">Draft</ui-badge>`,
  }),
};

/** All badge variants displayed together for comparison */
export const AllVariants: Story = {
  render: () => ({
    template: `
      <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
        <ui-badge variant="success">Active</ui-badge>
        <ui-badge variant="warning">Pending</ui-badge>
        <ui-badge variant="danger">Overdue</ui-badge>
        <ui-badge variant="info">New</ui-badge>
        <ui-badge variant="neutral">Draft</ui-badge>
      </div>
    `,
  }),
};
