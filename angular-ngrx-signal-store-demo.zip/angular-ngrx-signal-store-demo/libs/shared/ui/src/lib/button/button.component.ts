import { Component, input, output } from '@angular/core';

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
export type ButtonSize = 'sm' | 'md' | 'lg';

/**
 * UiButtonComponent — Standalone reusable button.
 *
 * PUBLIC API DESIGN:
 * - Uses Angular signal inputs (input()) for type-safe props
 * - Exposes typed variants and sizes
 * - Part of @angular-monorepo-demo/shared-ui public API
 */
@Component({
  selector: 'ui-button',
  template: `
    <button
      [class]="'ui-btn ui-btn--' + variant() + ' ui-btn--' + size()"
      [disabled]="disabled()"
      (click)="handleClick()">
      <ng-content />
    </button>
  `,
  styles: [`
    .ui-btn {
      display: inline-flex; align-items: center; gap: 0.5rem;
      border: none; border-radius: 8px; cursor: pointer;
      font-weight: 600; transition: all 0.2s;
      font-family: inherit;
    }
    .ui-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .ui-btn--sm { padding: 0.3rem 0.75rem; font-size: 0.8rem; }
    .ui-btn--md { padding: 0.5rem 1.25rem; font-size: 0.9rem; }
    .ui-btn--lg { padding: 0.75rem 1.75rem; font-size: 1rem; }
    .ui-btn--primary { background: #3498db; color: white; }
    .ui-btn--primary:hover:not(:disabled) { background: #2980b9; }
    .ui-btn--secondary { background: #ecf0f1; color: #2c3e50; }
    .ui-btn--secondary:hover:not(:disabled) { background: #d5dbdb; }
    .ui-btn--danger { background: #e74c3c; color: white; }
    .ui-btn--danger:hover:not(:disabled) { background: #c0392b; }
    .ui-btn--ghost { background: transparent; color: #3498db; border: 1px solid #3498db; }
    .ui-btn--ghost:hover:not(:disabled) { background: #ebf5fb; }
  `]
})
export class UiButtonComponent {
  variant = input<ButtonVariant>('primary');
  size = input<ButtonSize>('md');
  disabled = input<boolean>(false);
  clicked = output<void>();

  handleClick(): void {
    if (!this.disabled()) {
      this.clicked.emit();
    }
  }
}
