import type { Meta, StoryObj } from '@storybook/angular';
import { UiButtonComponent } from './button.component';

/**
 * # UiButton
 *
 * A reusable button component with variant and size support.
 * Uses Angular signal inputs for type-safe props.
 *
 * ## Usage
 * ```html
 * <ui-button variant="primary" size="md" (clicked)="onAction()">
 *   Click Me
 * </ui-button>
 * ```
 */
const meta: Meta<UiButtonComponent> = {
  title: 'Shared UI/Button',
  component: UiButtonComponent,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary', 'secondary', 'danger', 'ghost'],
      description: 'Visual style variant of the button',
    },
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
      description: 'Size of the button',
    },
    disabled: {
      control: 'boolean',
      description: 'Whether the button is disabled',
    },
  },
  render: (args) => ({
    props: args,
    template: `<ui-button [variant]="variant" [size]="size" [disabled]="disabled">Button Text</ui-button>`,
  }),
};

export default meta;
type Story = StoryObj<UiButtonComponent>;

/** Default primary button */
export const Primary: Story = {
  args: {
    variant: 'primary',
    size: 'md',
    disabled: false,
  },
};

/** Secondary variant for less prominent actions */
export const Secondary: Story = {
  args: {
    variant: 'secondary',
    size: 'md',
    disabled: false,
  },
};

/** Danger variant for destructive actions */
export const Danger: Story = {
  args: {
    variant: 'danger',
    size: 'md',
    disabled: false,
  },
};

/** Ghost variant for minimal visual weight */
export const Ghost: Story = {
  args: {
    variant: 'ghost',
    size: 'md',
    disabled: false,
  },
};

/** Small button */
export const Small: Story = {
  args: {
    variant: 'primary',
    size: 'sm',
    disabled: false,
  },
};

/** Large button */
export const Large: Story = {
  args: {
    variant: 'primary',
    size: 'lg',
    disabled: false,
  },
};

/** Disabled state */
export const Disabled: Story = {
  args: {
    variant: 'primary',
    size: 'md',
    disabled: true,
  },
};

/** All variants together for comparison */
export const AllVariants: Story = {
  render: () => ({
    template: `
      <div style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
        <ui-button variant="primary">Primary</ui-button>
        <ui-button variant="secondary">Secondary</ui-button>
        <ui-button variant="danger">Danger</ui-button>
        <ui-button variant="ghost">Ghost</ui-button>
        <ui-button variant="primary" [disabled]="true">Disabled</ui-button>
      </div>
    `,
  }),
};
