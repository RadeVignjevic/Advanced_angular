import { Component, input } from '@angular/core';

/**
 * UiCardComponent — Standalone card container.
 *
 * Demonstrates ng-content projection with named slots
 * (header / body / footer) — a common library pattern.
 */
@Component({
  selector: 'ui-card',
  template: `
    <div class="ui-card" [class.ui-card--elevated]="elevated()">
      @if (title()) {
        <div class="ui-card__header">
          <h3>{{ title() }}</h3>
          <ng-content select="[card-actions]" />
        </div>
      }
      <div class="ui-card__body">
        <ng-content />
      </div>
      <div class="ui-card__footer">
        <ng-content select="[card-footer]" />
      </div>
    </div>
  `,
  styles: [`
    .ui-card {
      background: white; border: 1px solid #e0e0e0;
      border-radius: 12px; overflow: hidden;
    }
    .ui-card--elevated { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .ui-card__header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 1rem 1.25rem; border-bottom: 1px solid #f0f0f0;
    }
    .ui-card__header h3 { margin: 0; font-size: 1rem; }
    .ui-card__body { padding: 1.25rem; }
    .ui-card__footer:empty { display: none; }
    .ui-card__footer {
      padding: 0.75rem 1.25rem; border-top: 1px solid #f0f0f0;
      background: #fafafa;
    }
  `]
})
export class UiCardComponent {
  title = input<string>('');
  elevated = input<boolean>(false);
}
