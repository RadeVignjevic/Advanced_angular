import type { Meta, StoryObj } from '@storybook/angular';
import { UiCardComponent } from './card.component';

/**
 * # UiCard
 *
 * A container card with title, body, and content projection slots.
 * Supports optional elevation and named content slots.
 *
 * ## Usage
 * ```html
 * <ui-card title="Card Title" [elevated]="true">
 *   Main content goes here
 *   <div card-actions>
 *     <ui-button size="sm">Edit</ui-button>
 *   </div>
 *   <div card-footer>Footer content</div>
 * </ui-card>
 * ```
 */
const meta: Meta<UiCardComponent> = {
  title: 'Shared UI/Card',
  component: UiCardComponent,
  tags: ['autodocs'],
  argTypes: {
    title: {
      control: 'text',
      description: 'Title displayed in the card header',
    },
    elevated: {
      control: 'boolean',
      description: 'Whether to show an elevated shadow',
    },
  },
};

export default meta;
type Story = StoryObj<UiCardComponent>;

/** Basic card with title and content */
export const Default: Story = {
  render: (args) => ({
    props: args,
    template: `
      <ui-card title="Product Summary" [elevated]="false">
        <p>This is the card body content. It supports any HTML or Angular components.</p>
      </ui-card>
    `,
  }),
};

/** Elevated card with shadow for emphasis */
export const Elevated: Story = {
  render: () => ({
    template: `
      <ui-card title="Important Metric" [elevated]="true">
        <div style="text-align: center;">
          <span style="font-size: 2rem; font-weight: bold; color: #3498db;">42</span>
          <p style="color: #7f8c8d; margin: 0.5rem 0 0;">Active Users</p>
        </div>
      </ui-card>
    `,
  }),
};

/** Card with action buttons in the header */
export const WithActions: Story = {
  render: () => ({
    template: `
      <ui-card title="User Profile">
        <p>John Doe — john@example.com</p>
        <div card-actions>
          <button style="padding: 0.25rem 0.75rem; border: 1px solid #3498db; background: transparent; border-radius: 4px; color: #3498db; cursor: pointer;">
            Edit
          </button>
        </div>
        <div card-footer>
          Last updated: Jan 1, 2025
        </div>
      </ui-card>
    `,
  }),
};

/** Card without a title (body-only) */
export const NoTitle: Story = {
  render: () => ({
    template: `
      <ui-card>
        <p style="margin: 0;">A card without a title — the header is hidden.</p>
      </ui-card>
    `,
  }),
};

/** Multiple cards in a grid layout */
export const CardGrid: Story = {
  render: () => ({
    template: `
      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem;">
        <ui-card title="Products" [elevated]="true">
          <span style="font-size: 1.5rem; font-weight: bold;">128</span>
        </ui-card>
        <ui-card title="Customers" [elevated]="true">
          <span style="font-size: 1.5rem; font-weight: bold;">64</span>
        </ui-card>
        <ui-card title="Revenue" [elevated]="true">
          <span style="font-size: 1.5rem; font-weight: bold;">$12,340</span>
        </ui-card>
      </div>
    `,
  }),
};
