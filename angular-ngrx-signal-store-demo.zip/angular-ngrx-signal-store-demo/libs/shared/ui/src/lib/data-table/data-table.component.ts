import { Component, input, output, computed } from '@angular/core';

export interface TableColumn<T = unknown> {
  key: string;
  header: string;
  sortable?: boolean;
  width?: string;
  /** Optional transform function for cell rendering */
  transform?: (value: unknown, row: T) => string;
}

/**
 * UiDataTableComponent — Generic data table with column definitions.
 *
 * PUBLIC API DESIGN:
 * - Generic column config via TableColumn interface
 * - Signal inputs for data and columns
 * - Output for row selection
 *
 * This demonstrates designing a library component with a
 * well-defined, documented public API.
 */
@Component({
  selector: 'ui-data-table',
  template: `
    <div class="ui-table-wrapper">
      <table class="ui-table">
        <thead>
          <tr>
            @for (col of columns(); track col.key) {
              <th [style.width]="col.width ?? 'auto'">
                {{ col.header }}
              </th>
            }
          </tr>
        </thead>
        <tbody>
          @for (row of data(); track $index) {
            <tr (click)="rowClicked.emit(row)" class="ui-table__row">
              @for (col of columns(); track col.key) {
                <td>{{ getCellValue(row, col) }}</td>
              }
            </tr>
          } @empty {
            <tr>
              <td [attr.colspan]="columns().length" class="ui-table__empty">
                {{ emptyMessage() }}
              </td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .ui-table-wrapper { overflow-x: auto; }
    .ui-table {
      width: 100%; border-collapse: collapse;
      font-size: 0.9rem;
    }
    .ui-table th {
      background: #f8f9fa; padding: 0.75rem;
      text-align: left; border-bottom: 2px solid #dee2e6;
      font-weight: 600; color: #495057;
    }
    .ui-table td {
      padding: 0.75rem; border-bottom: 1px solid #e9ecef;
    }
    .ui-table__row { cursor: pointer; transition: background 0.15s; }
    .ui-table__row:hover { background: #f8f9fa; }
    .ui-table__empty {
      text-align: center; padding: 2rem;
      color: #6c757d; font-style: italic;
    }
  `]
})
export class UiDataTableComponent {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data = input<any[]>([]);
  columns = input<TableColumn[]>([]);
  emptyMessage = input<string>('No data available');
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  rowClicked = output<any>();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getCellValue(row: any, col: TableColumn): string {
    const value = row[col.key];
    if (col.transform) {
      return col.transform(value, row);
    }
    return value?.toString() ?? '';
  }
}
