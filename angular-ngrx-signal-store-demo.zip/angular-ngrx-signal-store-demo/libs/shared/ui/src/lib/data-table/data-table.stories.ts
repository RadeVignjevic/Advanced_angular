import type { Meta, StoryObj } from '@storybook/angular';
import { UiDataTableComponent, TableColumn } from './data-table.component';

const sampleProducts = [
  { name: 'Angular Handbook', category: 'Books', price: 49.99, stock: 120 },
  { name: 'TypeScript Course', category: 'Courses', price: 199, stock: 0 },
  { name: 'Nx Enterprise Guide', category: 'Books', price: 79.99, stock: 45 },
  { name: 'RxJS Masterclass', category: 'Courses', price: 149, stock: 30 },
  { name: 'Angular Stickers', category: 'Merch', price: 9.99, stock: 500 },
];

const productColumns: TableColumn[] = [
  { key: 'name', header: 'Product Name', width: '40%' },
  { key: 'category', header: 'Category' },
  {
    key: 'price',
    header: 'Price',
    transform: (value: unknown) => `$${(value as number).toFixed(2)}`,
  },
  {
    key: 'stock',
    header: 'In Stock',
    transform: (value: unknown) => (value as number) > 0 ? `${value}` : 'Out of stock',
  },
];

/**
 * # UiDataTable
 *
 * A generic data table driven by column definitions.
 * Supports custom cell transforms and row click events.
 *
 * ## Usage
 * ```typescript
 * const columns: TableColumn[] = [
 *   { key: 'name', header: 'Name' },
 *   { key: 'price', header: 'Price', transform: (v) => `$${v}` },
 * ];
 * ```
 * ```html
 * <ui-data-table [data]="products" [columns]="columns" (rowClicked)="onSelect($event)" />
 * ```
 */
const meta: Meta<UiDataTableComponent> = {
  title: 'Shared UI/DataTable',
  component: UiDataTableComponent,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<UiDataTableComponent>;

/** Table with product data and custom transforms */
export const Default: Story = {
  args: {
    data: sampleProducts,
    columns: productColumns,
    emptyMessage: 'No products found',
  },
};

/** Empty table with custom message */
export const Empty: Story = {
  args: {
    data: [],
    columns: productColumns,
    emptyMessage: 'No products match your search criteria.',
  },
};

/** Table with simple string columns (no transforms) */
export const SimpleColumns: Story = {
  args: {
    data: [
      { id: 1, name: 'Alice', email: 'alice@example.com', role: 'Admin' },
      { id: 2, name: 'Bob', email: 'bob@example.com', role: 'User' },
      { id: 3, name: 'Charlie', email: 'charlie@example.com', role: 'Editor' },
    ],
    columns: [
      { key: 'id', header: '#', width: '60px' },
      { key: 'name', header: 'Name' },
      { key: 'email', header: 'Email' },
      { key: 'role', header: 'Role' },
    ] as TableColumn[],
  },
};
