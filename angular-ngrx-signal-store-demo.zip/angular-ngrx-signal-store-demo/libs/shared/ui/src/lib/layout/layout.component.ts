import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/**
 * UiLayoutComponent — App shell with sidebar navigation.
 * Demonstrates content projection for menu items.
 */
@Component({
  selector: 'ui-layout',
  imports: [RouterOutlet],
  template: `
    <div class="ui-layout">
      <nav class="ui-sidebar">
        <div class="ui-sidebar__header">
          <ng-content select="[sidebar-header]" />
        </div>
        <div class="ui-sidebar__nav">
          <ng-content select="[sidebar-nav]" />
        </div>
      </nav>
      <main class="ui-main">
        <router-outlet />
      </main>
    </div>
  `,
  styles: [`
    .ui-layout { display: flex; min-height: 100vh; }
    .ui-sidebar {
      width: 260px; background: #1a1a2e; color: white;
      position: fixed; top: 0; left: 0; bottom: 0;
      display: flex; flex-direction: column; overflow-y: auto;
    }
    .ui-sidebar__header {
      padding: 1.5rem; background: #16213e;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .ui-sidebar__nav { padding: 0.5rem 0; flex: 1; }
    .ui-main {
      flex: 1; margin-left: 260px;
      padding: 1.5rem 2rem; background: #f5f7fa; min-height: 100vh;
    }
  `]
})
export class UiLayoutComponent {}
