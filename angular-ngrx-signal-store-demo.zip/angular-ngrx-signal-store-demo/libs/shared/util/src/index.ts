/**
 * @angular-monorepo-demo/util
 *
 * PUBLIC API — Adapters, wrappers, and helper utilities.
 *
 * LIBRARY BOUNDARY: "util" libraries should only contain
 * framework-agnostic code — no Angular imports, no components.
 * They can be used by any other library type.
 */

// --- Adapters (third-party isolation) ---
export { DateAdapter } from './lib/adapters/date.adapter';
export { StorageAdapter, createLocalStorageAdapter, createSessionStorageAdapter } from './lib/adapters/storage.adapter';

// --- Wrappers ---
export { HttpWrapper, type HttpResponse, STORAGE_ADAPTER, provideStorageAdapter } from './lib/wrappers/http.wrapper';

// --- Helpers ---
export { formatCurrency, generateId, deepClone, debounce } from './lib/helpers';
