/**
 * DateAdapter — Wrapper pattern for third-party date libraries.
 *
 * THIRD-PARTY DEPENDENCY MANAGEMENT:
 * ──────────────────────────────────
 * Instead of importing a date library (moment, date-fns, luxon)
 * directly throughout the application, we create an adapter
 * that wraps the library's API.
 *
 * Benefits:
 * 1. Single place to change if the library has breaking changes
 * 2. Swap implementations without touching consumers
 * 3. Test consumers with a mock adapter
 * 4. Reduce the surface area of the dependency
 *
 * Currently wraps native Date API. To swap to date-fns:
 *   import { format, parseISO, differenceInDays } from 'date-fns';
 *   Then update the method implementations.
 */
export class DateAdapter {
  /**
   * Format a date to a display string.
   * Wraps: native toLocaleDateString (swap to date-fns format())
   */
  static format(date: Date | string, locale = 'en-US'): string {
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleDateString(locale, {
      year: 'numeric', month: 'short', day: 'numeric'
    });
  }

  /**
   * Format with time.
   * Wraps: native toLocaleString (swap to date-fns format())
   */
  static formatDateTime(date: Date | string, locale = 'en-US'): string {
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleString(locale, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  }

  /**
   * Parse ISO string to Date.
   * Wraps: new Date() (swap to date-fns parseISO())
   */
  static parse(isoString: string): Date {
    return new Date(isoString);
  }

  /**
   * Get relative time (e.g., "3 days ago").
   * Wraps: manual calc (swap to date-fns formatDistanceToNow())
   */
  static relative(date: Date | string): string {
    const d = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'today';
    if (diffDays === 1) return 'yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return `${Math.floor(diffDays / 30)} months ago`;
  }
}
