/**
 * StorageAdapter — Wrapper pattern for browser storage APIs.
 *
 * ADAPTER PATTERN:
 * Wraps localStorage/sessionStorage behind a clean interface.
 * Enables:
 * - Easy swap to cookies, IndexedDB, or a server-side store
 * - Type-safe get/set with generics
 * - Testability (mock the adapter, not window.localStorage)
 * - SSR compatibility (check for window availability)
 */
export class StorageAdapter {
  constructor(private storage: Storage) {}

  /** Get a typed value from storage */
  get<T>(key: string): T | null {
    try {
      const raw = this.storage.getItem(key);
      return raw ? JSON.parse(raw) as T : null;
    } catch {
      return null;
    }
  }

  /** Set a typed value in storage */
  set<T>(key: string, value: T): void {
    try {
      this.storage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn(`StorageAdapter: Failed to set "${key}"`, e);
    }
  }

  /** Remove a key from storage */
  remove(key: string): void {
    this.storage.removeItem(key);
  }

  /** Clear all keys */
  clear(): void {
    this.storage.clear();
  }

  /** Check if a key exists */
  has(key: string): boolean {
    return this.storage.getItem(key) !== null;
  }
}

/**
 * Factory functions for creating storage adapters.
 * Use these in provider configurations.
 */
export function createLocalStorageAdapter(): StorageAdapter {
  return new StorageAdapter(window.localStorage);
}

export function createSessionStorageAdapter(): StorageAdapter {
  return new StorageAdapter(window.sessionStorage);
}
