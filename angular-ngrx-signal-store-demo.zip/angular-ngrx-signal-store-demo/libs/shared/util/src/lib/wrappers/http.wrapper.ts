import { InjectionToken, Provider } from '@angular/core';
import { StorageAdapter, createLocalStorageAdapter } from '../adapters/storage.adapter';

/**
 * HttpWrapper — Demonstrates the WRAPPER PATTERN.
 *
 * WRAPPER PATTERN vs ADAPTER PATTERN:
 * ───────────────────────────────────
 * - Adapter: Converts one interface to another (StorageAdapter converts
 *   localStorage to a typed API)
 * - Wrapper: Adds a layer around an existing interface without changing it
 *   (HttpWrapper adds logging/retry around fetch)
 *
 * This wrapper wraps the native fetch API so that:
 * 1. If fetch changes or we switch to axios, only this file changes
 * 2. We can add cross-cutting concerns (logging, auth headers, retries)
 * 3. Consumers import from @angular-monorepo-demo/util, not from 'axios'
 */

export interface HttpResponse<T = unknown> {
  data: T;
  status: number;
  ok: boolean;
}

export const STORAGE_ADAPTER = new InjectionToken<StorageAdapter>('storage.adapter');

/** Provider helper for StorageAdapter — use in app.config.ts */
export function provideStorageAdapter(): Provider {
  return { provide: STORAGE_ADAPTER, useFactory: createLocalStorageAdapter };
}

export class HttpWrapper {
  private baseUrl: string;

  constructor(baseUrl = '') {
    this.baseUrl = baseUrl;
  }

  async get<T>(url: string): Promise<HttpResponse<T>> {
    return this.request<T>('GET', url);
  }

  async post<T>(url: string, body: unknown): Promise<HttpResponse<T>> {
    return this.request<T>('POST', url, body);
  }

  async put<T>(url: string, body: unknown): Promise<HttpResponse<T>> {
    return this.request<T>('PUT', url, body);
  }

  async delete<T>(url: string): Promise<HttpResponse<T>> {
    return this.request<T>('DELETE', url);
  }

  private async request<T>(method: string, url: string, body?: unknown): Promise<HttpResponse<T>> {
    // All fetch usage concentrated here — easy to swap to axios
    const response = await fetch(`${this.baseUrl}${url}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    });

    const data = response.ok ? await response.json() as T : (undefined as unknown as T);

    return {
      data,
      status: response.status,
      ok: response.ok
    };
  }
}
