# Block 6 — RxJS to Signals Migration Methodology

## Instructor Guide

| Item | Detail |
|------|--------|
| **Duration** | 1 h 30 min |
| **Project** | `angular-rxjs-signals-migration-demo` |
| **Angular** | 19.0.7 (`resource`, `rxResource` available as developer preview) |
| **Prerequisites** | Blocks 2–5 complete |

---

## Agenda

| # | Topic | Route | Time | Component |
|---|-------|-------|------|-----------|
| 1 | Migration Strategy | `/migration-strategy` | 20 min | `MigrationStrategyComponent` |
| 2 | Async Data Fetching with Signals | `/async-data-signals` | 30 min | `AsyncDataSignalsComponent` |
| 3 | Signal-Based Forms (Experimental) | `/signal-forms` | 20 min | `SignalFormsComponent` |
| 4 | Workshop: Service Layer Migration | `/migration-workshop` | 20 min | `MigrationWorkshopComponent` |

---

## Topic 1 — Migration Strategy (20 min)

**Route:** `/migration-strategy`

### Teaching Points

1. **Why Migrate?** — Pain/gain comparison grid. RxJS pain points (leak-prone subscribes, steep learning curve, over-engineering simple state) vs Signal advantages (synchronous reads, auto cleanup, fine-grained CD).

2. **Risk Assessment Framework** — Table covering codebase size, RxJS complexity, test coverage, team experience, timeline. Use this to help students assess their own projects.

3. **Strategy Comparison** — Two approaches side by side:
   - **Incremental** (recommended): migrate one service at a time, RxJS + Signals coexist via interop
   - **Complete Replacement** (high risk): one big rewrite, all-or-nothing release

4. **Migration Phases** — Five-phase roadmap:
   1. Audit & inventory (classify RxJS usage by complexity)
   2. Add interop layer (`toSignal()` wrappers at consumption)
   3. Convert simple services (BehaviorSubject → signal)
   4. Adopt Signal Store for complex features
   5. Remove RxJS remnants (unused imports, AsyncPipe, subscription cleanup)

5. **When to Keep RxJS** — WebSockets, retry/polling, complex event coordination should stay RxJS. Simple state, HTTP GET → display, derived UI state should migrate.

### Instructor Notes
- Ask students: "How much RxJS is in your current project? How complex is it?"
- Emphasize: **the goal is NOT to eliminate RxJS** — it's to use the right tool per job
- The incremental approach is always safer — stress the "ship after each feature" benefit

---

## Topic 2 — Async Data Fetching with Signals (30 min)

**Route:** `/async-data-signals`

### Teaching Points

1. **`toSignal()`** — Observable→Signal bridge. One line replaces `subscribe + unsubscribe + OnDestroy`. Set `initialValue` to avoid `undefined`. Live demo loads products from `ProductService`.

2. **`resource()`** — Angular's built-in async primitive for signals:
   - `request` signal → when it changes, the loader re-runs automatically
   - `loader` returns a **Promise** (fits `fetch()` API, or `firstValueFrom()`)
   - Properties: `value()`, `status()`, `isLoading()`, `error()`, `reload()`
   - Live demo: category filter buttons that auto-refetch products
   - Import from `@angular/core`

3. **`rxResource()`** — Same API as `resource()` but loader returns an **Observable**:
   - Perfect for existing `HttpClient` services (they already return Observable)
   - Live demo: search input that auto-refetches products by term
   - Import from `@angular/core/rxjs-interop`

4. **Comparison Table** — When to use each:
   - `toSignal()` → wrapping existing Observable services (quick win, no refetch)
   - `resource()` → new code, `fetch()` API, Promise-based loaders
   - `rxResource()` → existing HttpClient services, need auto-refetch + status

5. **ResourceStatus** — Enum with Idle, Loading, Reloading, Resolved, Error, Local. Convenience getters: `isLoading()`, `error()`.

### Instructor Notes
- **This is the most important topic in Block 6.** Spend time on the live demos.
- Have students click the category buttons and search input — watch the resource status badge change.
- Key insight: `resource()`/`rxResource()` replace the common pattern of "service call + loading flag + error handling" with a single declarative primitive.
- Note: `resource()` and `rxResource()` are in **developer preview** in Angular 19. API may evolve but the concept is stable.

---

## Topic 3 — Signal-Based Forms (20 min)

**Route:** `/signal-forms`

### Teaching Points

1. **Current Status** — Three form APIs: Template-Driven (stable), Reactive Forms (stable), Signal Forms (experimental/RFC). Neither existing API is deprecated.

2. **Problems with Current Forms** — Both have friction: Reactive Forms are verbose with Observable-based `valueChanges`; Template-Driven are hard to test and weakly typed.

3. **Proposed Signal Forms API** — Show the RFC/proposed code:
   - `SignalFormControl` with `.value()` as a signal
   - `SignalFormGroup` with computed validity
   - Template binding via `[signalControl]` directive
   - **Do NOT adopt in production** — API will change

4. **Manual Signal Forms (Today)** — Live interactive demo:
   - Form fields as `signal()`: `formName`, `formEmail`, `formPrice`
   - Validation as `computed()`: `formNameError`, `formEmailError`, `formPriceError`
   - Form validity: `formValid = computed(() => !nameError() && !emailError() && ...)`
   - **This pattern works in Angular 19 right now with no experimental APIs**

5. **Adoption Readiness** — Table:
   - Reactive Forms → keep using for existing code
   - Manual signal pattern → great for new features today
   - Official Signal Forms → watch RFC, don't adopt yet

### Instructor Notes
- The live demo is the highlight — let students type in the form and watch validation update instantly
- Stress: the manual pattern is **production-ready today** and a great stepping stone
- If anyone asks "should I rewrite all my forms?": NO — keep Reactive Forms in existing code, use signal pattern for new features
- The proposed API shown is illustrative — actual syntax will differ

---

## Topic 4 — Workshop: Service Layer Migration (20 min)

**Route:** `/migration-workshop`

### Teaching Points

Walk through four migration steps, each building on the previous:

1. **Step 1 — The Before State**: Show `ProductService` (returns `Observable`) and a component with manual `subscribe/unsubscribe`. This is the code students already have from Block 2.

2. **Step 2 — `toSignal()` Quick Win**: Service stays exactly the same. Component replaces `subscribe` with one `toSignal()` call. Live demo shows products loading. **Effort: 2 minutes per component.**

3. **Step 3 — `rxResource()` for Parameterised Queries**: Replace `toSignal()` with `rxResource()` when you need auto-refetch on parameter change. Live demo: customer list with tier filter that auto-refetches. Show status tracking (Loading → Resolved), reload button.

4. **Step 4 — Signal-Native Service**: Convert the service itself to use `signal()` internally. `getProducts()` returns `Signal<Product[]>` not `Observable<Product[]>`. Component reads signal directly — zero bridging code. **Only worth doing for simple data services.**

5. **Migration Checklist**: Walk through the checklist items. First two are already checked (representing Steps 2–3).

6. **Student Exercises**: If time allows, assign one or more:
   - Add `searchProducts()` to `ProductService`, consume with `rxResource()`
   - Convert `UserService` calls to `toSignal()` in the Users page
   - Create `ProductSignalService` (signal-native version)
   - Build a product detail page with `resource()` + route param

### Instructor Notes
- This workshop is demonstration-heavy. Walk through each step, show the live result.
- The customer rxResource demo is the most impressive — clicking tier buttons triggers auto-refetch with status tracking.
- Key takeaway: migration doesn't have to be all-or-nothing. Each step delivers value independently.

---

## Key Imports Reference

```typescript
// Signal interop (bridge)
import { toSignal, toObservable } from '@angular/core/rxjs-interop';

// Resource API (Promise-based)
import { resource, ResourceStatus } from '@angular/core';

// rxResource (Observable-based)
import { rxResource } from '@angular/core/rxjs-interop';

// Core signals
import { signal, computed, effect } from '@angular/core';
```

---

## Build & Run

```bash
cd angular-rxjs-signals-migration-demo
npm install
npx nx serve demo-app
# Open http://localhost:4200
```

---

## Project Structure (Block 6 additions)

```
apps/demo-app/src/app/features/
├── migration-strategy/          # Topic 1: Incremental vs complete
│   ├── migration-strategy.component.ts
│   └── migration-strategy.routes.ts
├── async-data-signals/          # Topic 2: toSignal, resource, rxResource
│   ├── async-data-signals.component.ts
│   └── async-data-signals.routes.ts
├── signal-forms/                # Topic 3: Experimental forms + manual pattern
│   ├── signal-forms.component.ts
│   └── signal-forms.routes.ts
└── migration-workshop/          # Topic 4: Step-by-step service conversion
    ├── migration-workshop.component.ts
    └── migration-workshop.routes.ts
```

## Carried Over from Previous Blocks

- **Block 2**: Products, Customers, Users, Settings features + shared libraries
- **Block 3**: Signal Fundamentals, Signals vs RxJS, Signal Interop, RxJS Workshop
- **Block 4**: CD in Depth, Signal-Driven CD, CD Issues, Profiling Workshop
- **Block 5**: State Overview, Signal Store API, Store Patterns, Store Debugging, CRUD Workshop
