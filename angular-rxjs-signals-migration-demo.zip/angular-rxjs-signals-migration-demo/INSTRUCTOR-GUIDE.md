# Block 6 — RxJS to Signals Migration Methodology

## Instructor Guide — "For Dummies" Edition

**Duration:** 1 h 30 min  
**Prerequisites:** Blocks 2–5 complete (Architecture, Signals, CD, Signal Store)  
**Project:** `angular-rxjs-signals-migration-demo`  
**Angular:** 19.0.7 (`resource`, `rxResource` available as developer preview)

---

## How to Use This Guide

This guide tells you **exactly what to say, what to click, and what to draw on the whiteboard**. Every section follows this pattern:

1. **Whiteboard / Analogy** — draw or explain the concept in plain English first
2. **Show the Code** — scroll to the exact section in the running app
3. **Live Demo** — click buttons, watch the result, narrate what happens
4. **Student Checkpoint** — ask a question to verify understanding

> **Convention:** Text in "quotes like this" is **exactly what you say out loud** to the class.

---

## Schedule Overview

| # | Topic | Time | Route | What Students Learn |
|---|-------|------|-------|---------------------|
| 1 | Migration Strategy | 20 min | `/migration-strategy` | Why migrate, risk assessment, phased roadmap |
| 2 | Async Data Fetching with Signals | 30 min | `/async-data-signals` | toSignal(), resource(), rxResource() |
| 3 | Signal-Based Forms (Experimental) | 20 min | `/signal-forms` | Manual signal forms, validation patterns |
| 4 | Workshop: Service Layer Migration | 20 min | `/migration-workshop` | 4-step service conversion, live coding |

---

## Before Class — Setup (3 min)

```bash
cd angular-rxjs-signals-migration-demo
npm install
npx nx serve demo-app
```

Open **http://localhost:4200**. The dashboard shows Block 6 topic cards plus all previous blocks.

---

## Opening Talk (5 min)

### The Home Renovation Analogy

> "Imagine you live in a house with old copper plumbing. It works, but it leaks sometimes, it's hard to maintain, and new fixtures don't fit well.
>
> You have two choices:
> 1. **Rip out ALL the plumbing at once** — the house is unusable for weeks. High risk.
> 2. **Replace one room at a time** — the kitchen gets new pipes this week. The bathroom next month. The house stays liveable the entire time.
>
> Migrating from RxJS to Signals is option 2. You replace one service, one component at a time. RxJS and Signals coexist perfectly — Angular gives you bridge functions (`toSignal`, `toObservable`) so old plumbing and new plumbing can connect."

### Whiteboard — Draw This

```
┌──────────────────────────────────────────────┐
│           THE MIGRATION SPECTRUM              │
│                                               │
│  ┌─────────┐    ┌──────────────┐    ┌──────┐ │
│  │ 100%    │    │ HYBRID       │    │ 100% │ │
│  │ RxJS    │ →  │ RxJS+Signals │ →  │Signals│ │
│  │ (today) │    │ (transition) │    │(goal) │ │
│  └─────────┘    └──────────────┘    └──────┘ │
│                                               │
│  Bridge functions:                            │
│  toSignal()     — Observable → Signal         │
│  toObservable() — Signal → Observable         │
│  rxResource()   — Observable loader → resource│
└──────────────────────────────────────────────┘
```

> "The middle state is FINE. Many apps will live here for months or years. You don't need to eliminate every Observable. The goal is: use the right tool for each job."

---

## Topic 1: Migration Strategy (20 min)

**Navigate to:** `http://localhost:4200/migration-strategy`

### Section 1.1: Why Migrate? (5 min)

> "First — let's be clear about WHAT is changing and WHY."

Point to the comparison grid on screen:

> "Left column — RxJS pain points. Right column — Signal advantages.
>
> **Leak-prone subscriptions**: Every `subscribe()` needs a matching `unsubscribe`. Forget it and you have a memory leak. With signals — NO subscriptions to clean up.
>
> **Steep learning curve**: RxJS has 100+ operators. `mergeMap`, `switchMap`, `exhaustMap`, `concatMap` — your junior devs can't tell them apart. Signals are just `signal()`, `computed()`, `effect()`. Three things.
>
> **Over-engineering simple state**: I've seen codebases where a simple boolean toggle goes through an Action → Reducer → Selector → AsyncPipe pipeline. That's 4 files for `isOpen = true`. A signal is ONE LINE: `isOpen = signal(false)`.
>
> **Synchronous reads**: To read an Observable value, you pipe, subscribe, and wait. To read a signal: `count()`. Done. The value is there, right now, synchronously."

### Section 1.2: Risk Assessment (3 min)

Scroll to the Risk Assessment table.

> "Before you start migrating, assess your risk level. Five factors:"

Read each row:

> "**Codebase size**: Small is low risk. Large is high risk — more things to change.
>
> **RxJS complexity**: Simple BehaviorSubjects? Easy. Complex `combineLatest` chains with error recovery? Hard.
>
> **Test coverage**: High coverage = safety net. Low coverage = you're flying blind.
>
> **Team experience**: Has the team used signals before? If not, train first.
>
> **Timeline**: If you have 6 months, migrate incrementally. If you have 2 weeks, don't start."

### Section 1.3: Incremental vs Complete Replacement (4 min)

Scroll to the Strategy Comparison.

> "There are only two strategies. One is smart. One is suicidal."

Point to **Incremental (Recommended)**:

> "Migrate one service at a time. Ship after each conversion. RxJS and signals coexist. Time frame: weeks to months. Risk: LOW.
>
> This works because Angular gives us `toSignal()` and `toObservable()` — bridges between the two worlds."

Point to **Complete Replacement**:

> "Rewrite everything at once. All-or-nothing release. Risk: HIGH. Only works for tiny apps with zero users. For any real project — DON'T do this."

### Section 1.4: Five-Phase Migration Roadmap (5 min)

Scroll to the Migration Phases section.

> "Here's the playbook. Five phases:"

Read and point:

> "**Phase 1: Audit & Inventory** — Open every service file. Classify each Observable usage: 'simple state' (BehaviorSubject → easy to migrate), 'HTTP calls' (medium), 'complex streams' (keep RxJS).
>
> **Phase 2: Add Interop Layer** — Wrap existing Observables with `toSignal()` at the CONSUMPTION point. The service stays RxJS. The component reads a signal. Quick win.
>
> **Phase 3: Convert Simple Services** — Replace BehaviorSubjects with signals. Replace `.getValue()` with `signal()`. Replace `.pipe(map(...))` with `computed()`.
>
> **Phase 4: Adopt Signal Store** — Complex features with entities, loading states, CRUD operations → move to NgRx Signal Store (covered in Block 5).
>
> **Phase 5: Remove RxJS Remnants** — Delete unused imports, remove AsyncPipe, remove subscription cleanup code. Run `ng lint` to find dead RxJS code."

### Section 1.5: When to KEEP RxJS (3 min)

> "Not everything should migrate. RxJS is still the BEST tool for:
>
> - **WebSockets** — continuous bidirectional streams
> - **Retry/polling** — `retry()`, `interval()`, `repeatWhen()`
> - **Complex event coordination** — `merge()`, `race()`, `combineLatest()` with timing
> - **Debounce/throttle** — `debounceTime()`, `throttleTime()`
>
> Rule of thumb: if it's a STREAM of events over time, keep RxJS. If it's STATE that changes, use a signal."

#### Student Checkpoint

> "You have a service with a BehaviorSubject that holds the current user. Ten components subscribe to it. Which migration phase handles this?"

**Answer:** Phase 3 — Convert Simple Services. Replace the BehaviorSubject with `signal()`, replace subscriptions with direct signal reads.

---

## Topic 2: Async Data Fetching with Signals (30 min)

**Navigate to:** `http://localhost:4200/async-data-signals`

### Section 2.1: toSignal() — The Quick Bridge (8 min)

> "This is the EASIEST way to start migrating — and you can do it TODAY."

Scroll to **Section 1** ("toSignal()").

> "`toSignal()` takes any Observable and returns a Signal. One line replaces `subscribe()` + `unsubscribe()` + `ngOnDestroy`."

Point to the live demo: the product list loaded via `toSignal()`.

> "The products are loaded from `ProductService.getProducts()` — that returns an Observable. Instead of subscribing in `ngOnInit` and unsubscribing in `ngOnDestroy`, we just do:
>
> ```typescript
> products = toSignal(this.productService.getProducts(), { initialValue: [] });
> ```
>
> That's it. In the template: `@for (product of products(); track product.id)`. No async pipe. No subscription. Signal handles cleanup automatically."

> "Two important things:
>
> 1. **`initialValue`** — Without it, the type is `Product[] | undefined`. With `initialValue: []`, the type is `Product[]`. Always set an initial value unless you explicitly want to handle undefined.
>
> 2. **Auto-unsubscribe** — `toSignal()` subscribes when the injection context is created and unsubscribes when destroyed. No memory leaks."

### Section 2.2: resource() — Built-in Async Primitive (10 min)

Scroll to **Section 2** ("resource()").

> "This is Angular's NEW way to fetch async data. It was added in Angular 19."

#### Whiteboard — Draw This

```
┌──────────────────────────────────────────────┐
│              resource() Flow                  │
│                                               │
│  request signal ──→ changes? ──→ loader()     │
│  (e.g. category())     │        (returns      │
│                        │         Promise)      │
│                        ↓                       │
│                   ┌─────────┐                  │
│                   │ resource │                  │
│                   │ .value() │ ← the data      │
│                   │ .status()│ ← Loading/Done   │
│                   │ .error() │ ← any error      │
│                   │ .reload()│ ← force refresh   │
│                   └─────────┘                  │
│                                               │
│  KEY: when request signal changes,            │
│  loader() re-runs AUTOMATICALLY               │
└──────────────────────────────────────────────┘
```

**Live Demo:**

> "Look at the category buttons: All, Electronics, Clothing, Books."

**Click "Electronics":**

> "Watch the product list — it filters to only electronics. Under the hood: `selectedCategory` is a signal. When I click the button, the signal updates. `resource()` detects the change and re-runs the loader with the new category. No manual subscription, no switchMap, no takeUntil."

**Click "Books":**

> "Filtered again. Point to the status indicator — it shows 'Loading' briefly, then 'Resolved'. That's `ResourceStatus` doing the work."

Show the code:

```typescript
productsResource = resource({
  request: () => ({ category: this.selectedCategory() }),
  loader: async ({ request }) => {
    const response = await fetch(`/api/products?category=${request.category}`);
    return response.json();
  }
});
```

> "Three things to notice:
>
> 1. `request` is a function that returns any value. When that value CHANGES, the loader re-runs.
> 2. `loader` receives the request and returns a PROMISE. Not Observable — Promise.
> 3. The resource gives you `.value()`, `.status()`, `.isLoading()`, `.error()`, `.reload()` — all signals."

### Section 2.3: rxResource() — Observable-Friendly (7 min)

Scroll to **Section 3** ("rxResource()").

> "What if your existing services already return Observables? You don't want to convert every `HttpClient.get()` to a Promise. That's what `rxResource()` is for."

> "Same API as `resource()`, but the loader returns an Observable instead of a Promise."

**Live Demo:**

> "Type 'angular' in the search box."

Type and watch. Products filter by search term.

> "The loader calls `this.productService.searchProducts(term)` — that returns an Observable. `rxResource` handles subscribing, unsubscribing, and re-running when the search term signal changes."

```typescript
searchResults = rxResource({
  request: () => this.searchTerm(),
  loader: ({ request: term }) => this.productService.searchProducts(term)
});
```

> "Import from `@angular/core/rxjs-interop`. Use this when you have existing `HttpClient` services."

### Section 2.4: Comparison — When to Use What (5 min)

Scroll to the comparison table.

> "Three tools, three use cases:
>
> **toSignal()** → Quick bridge. Wrap an existing Observable. No auto-refetch. Use for: one-time loads, streams you want to read as signals.
>
> **resource()** → New code, Promise-based loaders. Auto-refetches when request signal changes. Use for: `fetch()` API, new services.
>
> **rxResource()** → Existing `HttpClient` services. Same auto-refetch behaviour. Use for: existing Angular services that return Observables."

#### Student Checkpoint

> "Your service has `getUsers(): Observable<User[]>` and you need the list to refresh when a department filter changes. Which do you use: toSignal, resource, or rxResource?"

**Answer:** `rxResource()` — because the service returns an Observable and you need auto-refetch when the filter signal changes.

---

## Topic 3: Signal-Based Forms (20 min)

**Navigate to:** `http://localhost:4200/signal-forms`

### The Forms Problem (3 min)

> "Angular's current Reactive Forms are built on Observables. `valueChanges`, `statusChanges` — all Observables. In a signal-based world, this creates a mismatch: you're using signals everywhere EXCEPT forms.
>
> Signal-based forms are still an RFC — not stable yet. But I want to show you the PATTERN so you know where Angular is headed. And you can use this pattern TODAY without waiting for the framework."

### Section 3.1: Manual Signal Form Pattern (10 min)

Scroll to the live form demo.

> "This is a signup form built entirely with signals. No FormControl, no FormGroup, no Observable."

Show the form fields: name, email, age.

**Type "John" in the name field:**

> "Watch the validation state update in real-time. Name is valid — it has 2+ characters."

**Type "j" in the email field:**

> "Email is invalid. The validation signal detects it's not a valid email format."

**Type "john@example.com":**

> "Email is now valid. The overall form validity updates — it's a computed signal that checks ALL field validations."

Show the code:

```typescript
// Each field is a signal
name = signal('');
email = signal('');
age = signal<number | null>(null);

// Validation is computed
nameValid = computed(() => this.name().length >= 2);
emailValid = computed(() => /^[^@]+@[^@]+\.[^@]+$/.test(this.email()));
ageValid = computed(() => {
  const a = this.age();
  return a !== null && a >= 18 && a <= 120;
});

// Overall form validity — computed from all fields
formValid = computed(() =>
  this.nameValid() && this.emailValid() && this.ageValid()
);
```

> "This is the pattern:
> 1. Each field = a signal
> 2. Each validation = a computed signal that reads the field
> 3. Form validity = a computed signal that reads all validations
>
> No subscriptions. No memory leaks. No `.pipe(takeUntil(this.destroy$))`. Just functions."

### Section 3.2: When to Use This (5 min)

> "Today, use this pattern for:
> - Simple forms (2-5 fields)
> - Dynamic forms where fields appear/disappear based on signals
> - Forms where you need instant, synchronous validation (no async pipe delay)
>
> For complex forms with 20+ fields, nested arrays, async validators — stick with Reactive Forms for now. The Angular team is working on a signal-based equivalent."

### Section 3.3: What's Coming (2 min)

> "The Angular team has an active RFC for signal-based forms. When it ships, you'll get:
> - `SignalFormControl` — `FormControl` powered by signals
> - `SignalFormGroup` — groups that compose signal controls
> - Instant access to values via `.value()` signal
> - No more `valueChanges.subscribe()` — just read the signal
>
> Your code today using manual signal forms will translate almost 1:1."

#### Student Checkpoint

> "In our manual signal form, what type of signal is `formValid`?"

**Answer:** A `computed` signal. It derives its value from `nameValid()`, `emailValid()`, and `ageValid()`. When any field changes, form validity recalculates automatically.

---

## Topic 4: Workshop — Service Layer Migration (20 min)

**Navigate to:** `http://localhost:4200/migration-workshop`

### The Workshop Structure

> "This is a 4-step migration exercise. We'll take a traditional RxJS service and convert it to signals, step by step."

### Step 1: The "Before" — Traditional RxJS (3 min)

Scroll to **Step 1** ("Before: Traditional RxJS Service").

> "Look at this service. It's what most Angular projects have today:"

```typescript
// Traditional RxJS service
@Injectable()
export class CustomerService {
  private customersSubject = new BehaviorSubject<Customer[]>([]);
  customers$ = this.customersSubject.asObservable();

  private selectedTierSubject = new BehaviorSubject<string>('all');

  filteredCustomers$ = combineLatest([
    this.customers$,
    this.selectedTierSubject
  ]).pipe(
    map(([customers, tier]) =>
      tier === 'all' ? customers : customers.filter(c => c.tier === tier)
    )
  );
}
```

> "BehaviorSubject, `.asObservable()`, `combineLatest`, `.pipe(map(...))`. It works, but it's verbose and every consumer needs `subscribe()` + cleanup."

### Step 2: Add toSignal() Interop (4 min)

Scroll to **Step 2**.

> "First — the quick win. Keep the service as-is. Convert at the consumption point."

```typescript
// Component — add toSignal at consumption
customers = toSignal(this.service.filteredCustomers$, { initialValue: [] });
```

> "The service is unchanged. Only the component changes. This is Phase 2 from our roadmap — the LOWEST risk migration step."

### Step 3: Replace with rxResource (6 min)

Scroll to **Step 3**.

> "Now we go deeper. Replace the HTTP call with rxResource for auto-refetch."

```typescript
selectedTier = signal('all');

customersResource = rxResource({
  request: () => this.selectedTier(),
  loader: ({ request: tier }) => this.http.get<Customer[]>(`/api/customers?tier=${tier}`)
});
```

> "When selectedTier changes, the resource re-fetches automatically. No combineLatest. No pipe. No subscription."

**Live Demo:**

> "Click the tier buttons: All, Gold, Silver, Bronze."

Click through each tier. Watch the customer list filter.

> "Each click updates the selectedTier signal. rxResource detects the change, calls the loader, and updates the result. The template reads `customersResource.value()` — a signal."

### Step 4: Full Signal-Native Service (5 min)

Scroll to **Step 4**.

> "Final form — the service itself uses signals. No RxJS at all."

```typescript
@Injectable()
export class CustomerSignalService {
  private customers = signal<Customer[]>([]);
  selectedTier = signal('all');

  filteredCustomers = computed(() => {
    const tier = this.selectedTier();
    const all = this.customers();
    return tier === 'all' ? all : all.filter(c => c.tier === tier);
  });

  totalCount = computed(() => this.customers().length);
  filteredCount = computed(() => this.filteredCustomers().length);
}
```

> "Look how simple this is. No BehaviorSubject, no combineLatest, no pipe, no subscribe, no unsubscribe. Just signals and computed. The service IS the state."

### Workshop Exercise (2 min)

> "If time allows, try this on your own project:
> 1. Pick one service with a BehaviorSubject
> 2. Apply Steps 2 → 3 → 4
> 3. Run your tests to verify nothing breaks"

#### Student Checkpoint

> "In Step 3, why do we use rxResource instead of resource?"

**Answer:** Because `HttpClient.get()` returns an Observable, and `rxResource` accepts Observable-returning loaders. `resource()` expects a Promise.

---

## Wrap-Up Talk (5 min)

### Key Takeaways — Say These Out Loud

> "Five things to remember from this block:
>
> 1. **Migrate incrementally** — one service at a time. Never rewrite everything.
> 2. **toSignal() is your quickest win** — wrap an existing Observable and you're done.
> 3. **resource()/rxResource() replace the subscribe pattern** — auto-refetch, auto-cleanup, built-in loading/error states.
> 4. **Keep RxJS for streams** — WebSockets, retry, debounce. Use signals for state.
> 5. **Signal forms are coming** — you can start with the manual pattern today."

---

## Common Student Questions

**Q: Does toSignal() subscribe eagerly or lazily?**
> "Eagerly. As soon as `toSignal()` is called, it subscribes to the Observable. The subscription lives until the injection context is destroyed."

**Q: What happens if the resource loader throws an error?**
> "The resource transitions to `ResourceStatus.Error`. You can read `resource.error()` to get the error object. The `@error` block in the template renders. Call `resource.reload()` to retry."

**Q: Can I use resource() with HttpClient?**
> "Yes, but you need to convert the Observable to a Promise: `loader: async () => firstValueFrom(this.http.get(...))`. Or just use `rxResource()` — it accepts Observables directly."

**Q: Is toSignal() tree-shakeable?**
> "Yes. If you don't import it, it's not in the bundle."

**Q: Can a resource depend on multiple signals?**
> "Yes. The `request` function can read multiple signals: `request: () => ({ category: this.cat(), search: this.term() })`. When ANY of them changes, the loader re-runs."

**Q: How does rxResource handle cancellation?**
> "Like `switchMap()` — if the request signal changes while a previous request is in-flight, the previous Observable is unsubscribed and a new one starts."

---

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| `toSignal() must be called in an injection context` | Called outside constructor/field init | Move to class field or use `inject()` context |
| `resource.value()` is undefined | Loader hasn't resolved yet | Set `initialValue` or check `resource.isLoading()` |
| `rxResource is not a function` | Wrong import | Import from `@angular/core/rxjs-interop`, not `@angular/core` |
| Resource loader fires twice on init | Request function reads a signal that changes during init | Use `untracked()` for initial reads or set a stable initial signal value |
| Form validation doesn't update | Forgot to read signal in computed | Use `this.name()` not `this.name` in computed |

---

## Project Structure

```
angular-rxjs-signals-migration-demo/
├── apps/demo-app/src/app/
│   ├── app.config.ts
│   ├── app.routes.ts
│   └── features/
│       ├── dashboard/              # Block 6 overview
│       ├── migration-strategy/     # Topic 1: Why/how to migrate
│       ├── async-data-signals/     # Topic 2: toSignal, resource, rxResource
│       ├── signal-forms/           # Topic 3: Manual signal forms
│       └── migration-workshop/     # Topic 4: 4-step conversion exercise
├── libs/shared/
│   ├── ui/                         # UiButton, UiBadge, UiCard
│   └── data-access/                # ProductService, Models
└── INSTRUCTOR-GUIDE.md
```

---

## Key Imports Reference

```typescript
// toSignal — Observable to Signal bridge
import { toSignal, toObservable } from '@angular/core/rxjs-interop';

// resource — Promise-based async data
import { resource, ResourceStatus } from '@angular/core';

// rxResource — Observable-based async data
import { rxResource } from '@angular/core/rxjs-interop';

// Signals (review)
import { signal, computed, effect } from '@angular/core';
```

---

## Nx Commands

```bash
npx nx serve demo-app          # Serve the demo app
npx nx build demo-app          # Build for production
npx nx lint demo-app           # Run linting
npx nx graph                   # Dependency graph
```
