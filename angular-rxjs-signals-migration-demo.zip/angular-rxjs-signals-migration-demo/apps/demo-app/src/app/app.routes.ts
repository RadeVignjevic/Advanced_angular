import { Route } from '@angular/router';
import { DashboardComponent } from './features/dashboard/dashboard.component';

export const appRoutes: Route[] = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },

  // Block 6: RxJS to Signals Migration Methodology
  { path: 'migration-strategy', loadChildren: () => import('./features/migration-strategy/migration-strategy.routes').then(m => m.MIGRATION_STRATEGY_ROUTES) },
  { path: 'async-data-signals', loadChildren: () => import('./features/async-data-signals/async-data-signals.routes').then(m => m.ASYNC_DATA_SIGNALS_ROUTES) },
  { path: 'signal-forms', loadChildren: () => import('./features/signal-forms/signal-forms.routes').then(m => m.SIGNAL_FORMS_ROUTES) },
  { path: 'migration-workshop', loadChildren: () => import('./features/migration-workshop/migration-workshop.routes').then(m => m.MIGRATION_WORKSHOP_ROUTES) },

  // Block 5: Signal Store (carried over)
  { path: 'state-overview', loadChildren: () => import('./features/state-overview/state-overview.routes').then(m => m.STATE_OVERVIEW_ROUTES) },
  { path: 'signal-store-api', loadChildren: () => import('./features/signal-store-api/signal-store-api.routes').then(m => m.SIGNAL_STORE_API_ROUTES) },
  { path: 'store-patterns', loadChildren: () => import('./features/store-patterns/store-patterns.routes').then(m => m.STORE_PATTERNS_ROUTES) },
  { path: 'store-debugging', loadChildren: () => import('./features/store-debugging/store-debugging.routes').then(m => m.STORE_DEBUGGING_ROUTES) },
  { path: 'store-workshop', loadChildren: () => import('./features/store-workshop/store-workshop.routes').then(m => m.STORE_WORKSHOP_ROUTES) },

  // Block 4: Change Detection (carried over)
  { path: 'cd-in-depth', loadChildren: () => import('./features/cd-in-depth/cd-in-depth.routes').then(m => m.CD_IN_DEPTH_ROUTES) },
  { path: 'signal-driven-cd', loadChildren: () => import('./features/signal-driven-cd/signal-driven-cd.routes').then(m => m.SIGNAL_DRIVEN_CD_ROUTES) },
  { path: 'cd-issues', loadChildren: () => import('./features/cd-issues/cd-issues.routes').then(m => m.CD_ISSUES_ROUTES) },
  { path: 'cd-workshop', loadChildren: () => import('./features/cd-workshop/cd-workshop.routes').then(m => m.CD_WORKSHOP_ROUTES) },

  // Block 3: Signals (carried over)
  { path: 'signal-fundamentals', loadChildren: () => import('./features/signal-fundamentals/signal-fundamentals.routes').then(m => m.SIGNAL_FUNDAMENTALS_ROUTES) },
  { path: 'signals-vs-rxjs', loadChildren: () => import('./features/signals-vs-rxjs/signals-vs-rxjs.routes').then(m => m.SIGNALS_VS_RXJS_ROUTES) },
  { path: 'signal-interop', loadChildren: () => import('./features/signal-interop/signal-interop.routes').then(m => m.SIGNAL_INTEROP_ROUTES) },
  { path: 'workshop', loadChildren: () => import('./features/rxjs-workshop/rxjs-workshop.routes').then(m => m.RXJS_WORKSHOP_ROUTES) },
  { path: 'workshop-solution', loadChildren: () => import('./features/rxjs-workshop/rxjs-workshop-solution.routes').then(m => m.RXJS_WORKSHOP_SOLUTION_ROUTES) },

  // Block 2: Architecture (carried over)
  { path: 'products', loadChildren: () => import('./features/products/products.routes').then(m => m.PRODUCT_ROUTES) },
  { path: 'customers', loadChildren: () => import('./features/customers/customers.routes').then(m => m.CUSTOMER_ROUTES) },
  { path: 'users', loadChildren: () => import('./features/users/users.routes').then(m => m.USER_ROUTES) },
  { path: 'settings', loadChildren: () => import('./features/settings/settings.routes').then(m => m.SETTINGS_ROUTES) },

  { path: '**', redirectTo: 'dashboard' }
];
