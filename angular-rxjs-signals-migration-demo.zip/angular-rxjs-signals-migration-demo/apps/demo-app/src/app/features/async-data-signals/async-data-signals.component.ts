import { Component, ChangeDetectionStrategy, inject, signal, computed, resource, ResourceStatus } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { rxResource } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';
import { ProductService } from '@angular-monorepo-demo/data-access';
import { Product } from '@angular-monorepo-demo/data-access';

/**
 * Asynchronous Data Fetching with Signals — Topic 2 (30 min)
 *
 * Covers: toSignal(), resource(), rxResource(), ResourceStatus
 */
@Component({
  selector: 'app-async-data-signals',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="async-page">
      <h2>Asynchronous Data Fetching with Signals
        <ui-badge variant="info">Block 6 — Topic 2</ui-badge>
      </h2>

      <p class="note">
        Three ways to replace <code>subscribe()</code> patterns:
        <strong>toSignal()</strong> (bridge), <strong>resource()</strong> (Promise-based),
        and <strong>rxResource()</strong> (Observable-based).
      </p>

      <!-- Pattern 1: toSignal() -->
      <ui-card title="1. toSignal() — Observable to Signal Bridge" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeToSignal }}</pre>

          <h4>Live Demo: toSignal(productService.getProducts())</h4>
          <div class="product-list">
            @for (product of productsViaToSignal(); track product.id) {
              <div class="product-row">
                <span class="product-name">{{ product.name }}</span>
                <span class="product-price">\${{ product.price }}</span>
                <ui-badge [variant]="product.inStock ? 'success' : 'danger'">
                  {{ product.inStock ? 'In Stock' : 'Out' }}
                </ui-badge>
              </div>
            } @empty {
              <div class="loading">Loading via toSignal()...</div>
            }
          </div>

          <div class="explanation">
            <p><code>toSignal()</code> subscribes to an Observable and exposes its values as a signal.
            It <strong>automatically unsubscribes</strong> when the component is destroyed.
            Set <code>initialValue</code> to avoid <code>undefined</code> before the first emission.</p>
          </div>
        </div>
      </ui-card>

      <!-- Pattern 2: resource() -->
      <ui-card title="2. resource() — Promise-Based Data Loading" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeResource }}</pre>

          <h4>Live Demo: resource() with category filter</h4>
          <div class="demo-row">
            <ui-button [variant]="selectedCategory() === 'all' ? 'primary' : 'ghost'" size="sm"
              (clicked)="selectedCategory.set('all')">All</ui-button>
            <ui-button [variant]="selectedCategory() === 'Electronics' ? 'primary' : 'ghost'" size="sm"
              (clicked)="selectedCategory.set('Electronics')">Electronics</ui-button>
            <ui-button [variant]="selectedCategory() === 'Furniture' ? 'primary' : 'ghost'" size="sm"
              (clicked)="selectedCategory.set('Furniture')">Furniture</ui-button>
          </div>

          <div class="resource-status">
            Status: <ui-badge [variant]="resourceStatusBadge()">{{ resourceStatusLabel() }}</ui-badge>
          </div>

          <div class="product-list">
            @if (productResource.isLoading()) {
              <div class="loading">Loading via resource()...</div>
            }
            @for (product of productResource.value() ?? []; track product.id) {
              <div class="product-row">
                <span class="product-name">{{ product.name }}</span>
                <span class="product-price">\${{ product.price }}</span>
                <ui-badge [variant]="product.inStock ? 'success' : 'danger'">
                  {{ product.inStock ? 'In Stock' : 'Out' }}
                </ui-badge>
              </div>
            }
          </div>

          <div class="demo-row">
            <ui-button variant="ghost" size="sm" (clicked)="productResource.reload()">Reload</ui-button>
          </div>

          <div class="explanation">
            <p><code>resource()</code> is Angular's built-in async primitive for Signals.
            It accepts a <code>request</code> signal and a <code>loader</code> function
            that returns a Promise. When the request signal changes, the resource
            <strong>automatically re-fetches</strong>.</p>
            <p>Properties: <code>value()</code>, <code>status()</code>,
            <code>isLoading()</code>, <code>error()</code>, <code>reload()</code>.</p>
          </div>
        </div>
      </ui-card>

      <!-- Pattern 3: rxResource() -->
      <ui-card title="3. rxResource() — Observable-Based Data Loading" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeRxResource }}</pre>

          <h4>Live Demo: rxResource() with search</h4>
          <div class="demo-row">
            <input type="text" class="demo-input" placeholder="Search products..."
              [value]="searchTerm()"
              (input)="searchTerm.set(getInputValue($event))" />
          </div>

          <div class="resource-status">
            Status: <ui-badge [variant]="rxResourceStatusBadge()">{{ rxResourceStatusLabel() }}</ui-badge>
          </div>

          <div class="product-list">
            @if (searchResource.isLoading()) {
              <div class="loading">Loading via rxResource()...</div>
            }
            @for (product of searchResource.value() ?? []; track product.id) {
              <div class="product-row">
                <span class="product-name">{{ product.name }}</span>
                <span class="product-price">\${{ product.price }}</span>
                <ui-badge [variant]="product.inStock ? 'success' : 'danger'">
                  {{ product.inStock ? 'In Stock' : 'Out' }}
                </ui-badge>
              </div>
            } @empty {
              @if (!searchResource.isLoading()) {
                <div class="empty">No products match "{{ searchTerm() }}"</div>
              }
            }
          </div>

          <div class="explanation">
            <p><code>rxResource()</code> is the same concept as <code>resource()</code>
            but the loader returns an <strong>Observable</strong> instead of a Promise.
            Ideal when your services already return Observables (e.g. <code>HttpClient</code>).</p>
            <p>Import from <code>&#64;angular/core/rxjs-interop</code>.</p>
          </div>
        </div>
      </ui-card>

      <!-- Comparison Table -->
      <ui-card title="4. Comparison: Which Pattern to Use?" [elevated]="true">
        <div class="demo-section">
          <table class="comparison-table">
            <thead>
              <tr>
                <th>Pattern</th>
                <th>Source</th>
                <th>Auto-refetch?</th>
                <th>Status tracking?</th>
                <th>Best for</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><code>toSignal()</code></td>
                <td>Observable</td>
                <td>No (one-shot bridge)</td>
                <td>No</td>
                <td>Wrapping existing Observable services</td>
              </tr>
              <tr>
                <td><code>resource()</code></td>
                <td>Promise (fetch)</td>
                <td>Yes (on request change)</td>
                <td>Yes</td>
                <td>New code, fetch API, simple loaders</td>
              </tr>
              <tr>
                <td><code>rxResource()</code></td>
                <td>Observable</td>
                <td>Yes (on request change)</td>
                <td>Yes</td>
                <td>Existing HttpClient services</td>
              </tr>
            </tbody>
          </table>
        </div>
      </ui-card>

      <!-- ResourceStatus -->
      <ui-card title="5. ResourceStatus Enum" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeResourceStatus }}</pre>

          <div class="explanation">
            <p><code>ResourceStatus</code> is an enum: <code>Idle</code>, <code>Loading</code>,
            <code>Reloading</code>, <code>Resolved</code>, <code>Error</code>, <code>Local</code>.
            Use <code>resource.status()</code> or the convenience getters
            <code>isLoading()</code>, <code>error()</code>.</p>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .async-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.75rem 0; flex-wrap: wrap; }
    .demo-input { padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; min-width: 250px; }
    .demo-input:focus { outline: none; border-color: #42a5f5; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .product-list { border: 1px solid #e0e0e0; border-radius: 8px; max-height: 220px; overflow-y: auto; margin: 0.5rem 0; }
    .product-row { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 0.75rem; border-bottom: 1px solid #eee; font-size: 0.85rem; }
    .product-row:last-child { border-bottom: none; }
    .product-name { flex: 1; font-weight: 500; }
    .product-price { color: #2e7d32; font-weight: 500; }
    .loading { padding: 1rem; text-align: center; color: #888; font-size: 0.88rem; }
    .empty { padding: 1rem; text-align: center; color: #888; font-size: 0.88rem; }
    .resource-status { margin: 0.5rem 0; font-size: 0.88rem; }

    .comparison-table { width: 100%; border-collapse: collapse; font-size: 0.82rem; }
    .comparison-table th { background: #f5f5f5; padding: 0.5rem; text-align: left; border-bottom: 2px solid #e0e0e0; }
    .comparison-table td { padding: 0.5rem; border-bottom: 1px solid #eee; }
    .comparison-table code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.78rem; }
  `]
})
export class AsyncDataSignalsComponent {
  private productService = inject(ProductService);

  // ═══════════ Pattern 1: toSignal() ═══════════
  productsViaToSignal = toSignal(this.productService.getProducts(), { initialValue: [] as Product[] });

  // ═══════════ Pattern 2: resource() ═══════════
  selectedCategory = signal<string>('all');

  productResource = resource({
    request: () => ({ category: this.selectedCategory() }),
    loader: async ({ request }) => {
      // Simulate fetch from ProductService (convert Observable to Promise)
      const products = await new Promise<Product[]>((resolve) => {
        this.productService.getProducts().subscribe(products => resolve(products));
      });
      if (request.category === 'all') return products;
      return products.filter(p => p.category === request.category);
    }
  });

  resourceStatusLabel = computed(() => {
    const s = this.productResource.status();
    if (s === ResourceStatus.Idle) return 'Idle';
    if (s === ResourceStatus.Loading) return 'Loading';
    if (s === ResourceStatus.Reloading) return 'Reloading';
    if (s === ResourceStatus.Resolved) return 'Resolved';
    if (s === ResourceStatus.Error) return 'Error';
    return 'Local';
  });

  resourceStatusBadge = computed(() => {
    const s = this.productResource.status();
    if (s === ResourceStatus.Resolved) return 'success' as const;
    if (s === ResourceStatus.Error) return 'danger' as const;
    if (s === ResourceStatus.Loading || s === ResourceStatus.Reloading) return 'warning' as const;
    return 'neutral' as const;
  });

  // ═══════════ Pattern 3: rxResource() ═══════════
  searchTerm = signal<string>('');

  searchResource = rxResource({
    request: () => ({ term: this.searchTerm() }),
    loader: ({ request }) => {
      return this.productService.getProducts().pipe(
        map(products => {
          const term = request.term.toLowerCase();
          if (!term) return products;
          return products.filter(p =>
            p.name.toLowerCase().includes(term) ||
            p.description.toLowerCase().includes(term)
          );
        })
      );
    }
  });

  rxResourceStatusLabel = computed(() => {
    const s = this.searchResource.status();
    if (s === ResourceStatus.Idle) return 'Idle';
    if (s === ResourceStatus.Loading) return 'Loading';
    if (s === ResourceStatus.Reloading) return 'Reloading';
    if (s === ResourceStatus.Resolved) return 'Resolved';
    if (s === ResourceStatus.Error) return 'Error';
    return 'Local';
  });

  rxResourceStatusBadge = computed(() => {
    const s = this.searchResource.status();
    if (s === ResourceStatus.Resolved) return 'success' as const;
    if (s === ResourceStatus.Error) return 'danger' as const;
    if (s === ResourceStatus.Loading || s === ResourceStatus.Reloading) return 'warning' as const;
    return 'neutral' as const;
  });

  // ═══════════ Code examples ═══════════
  codeToSignal = `// BEFORE: subscribe + AsyncPipe
@Component({ template: '<div *ngFor="let p of products$ | async">...' })
export class ListComponent {
  products$ = this.productService.getProducts();
}

// AFTER: toSignal — no subscribe, no async pipe
@Component({ template: '@for (p of products(); track p.id) {...}' })
export class ListComponent {
  private productService = inject(ProductService);
  products = toSignal(this.productService.getProducts(), {
    initialValue: []   // avoids undefined before first emit
  });
}`;

  codeResource = `import { resource, ResourceStatus } from '@angular/core';

selectedCategory = signal('all');

productResource = resource({
  // When this signal changes, the loader re-runs
  request: () => ({ category: this.selectedCategory() }),

  // Loader returns a Promise
  loader: async ({ request, abortSignal }) => {
    const res = await fetch(\`/api/products?cat=\${request.category}\`, {
      signal: abortSignal  // auto-cancellation on re-fetch
    });
    return await res.json();
  }
});

// In template:
// productResource.value()      → the loaded data
// productResource.isLoading()  → boolean
// productResource.status()     → ResourceStatus enum
// productResource.error()      → error if failed
// productResource.reload()     → force re-fetch`;

  codeRxResource = `import { rxResource } from '@angular/core/rxjs-interop';

searchTerm = signal('');

searchResource = rxResource({
  request: () => ({ term: this.searchTerm() }),

  // Loader returns an Observable (fits HttpClient perfectly)
  loader: ({ request }) => {
    return this.http.get<Product[]>('/api/products', {
      params: { search: request.term }
    });
  }
});

// Same API as resource():
// searchResource.value(), .isLoading(), .status(), .error(), .reload()`;

  codeResourceStatus = `import { ResourceStatus } from '@angular/core';

// ResourceStatus enum values:
// ResourceStatus.Idle      → 0  (not yet started)
// ResourceStatus.Error     → 1  (loader threw/rejected)
// ResourceStatus.Loading   → 2  (first load in progress)
// ResourceStatus.Reloading → 3  (subsequent load in progress)
// ResourceStatus.Resolved  → 4  (data available)
// ResourceStatus.Local     → 5  (value set locally via .set())

// Convenience getters on the resource:
resource.isLoading()  // true when Loading or Reloading
resource.error()      // the error object, or undefined
resource.value()      // the resolved data, or undefined
resource.status()     // ResourceStatus enum value
resource.reload()     // trigger re-fetch manually`;

  getInputValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }
}
