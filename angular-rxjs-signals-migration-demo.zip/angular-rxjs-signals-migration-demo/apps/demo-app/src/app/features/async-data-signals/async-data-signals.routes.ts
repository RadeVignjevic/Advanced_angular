import { Route } from '@angular/router';
import { AsyncDataSignalsComponent } from './async-data-signals.component';

export const ASYNC_DATA_SIGNALS_ROUTES: Route[] = [
  { path: '', component: AsyncDataSignalsComponent }
];
