import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Migration Strategy: Incremental vs Complete Replacement — Topic 1 (20 min)
 */
@Component({
  selector: 'app-migration-strategy',
  imports: [UiCardComponent, UiBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="strategy-page">
      <h2>Migration Strategy: Incremental vs Complete Replacement
        <ui-badge variant="info">Block 6 — Topic 1</ui-badge>
      </h2>

      <p class="note">
        Moving from RxJS to Signals is <strong>not</strong> an all-or-nothing decision.
        This topic covers how to assess, plan and execute a phased migration with minimal risk.
      </p>

      <!-- Why Migrate? -->
      <ui-card title="1. Why Migrate from RxJS to Signals?" [elevated]="true">
        <div class="demo-section">
          <div class="comparison-grid">
            <div class="comparison-card pain">
              <h4>RxJS Pain Points</h4>
              <ul>
                <li>Steep learning curve (operators, marble diagrams)</li>
                <li>Leak-prone: manual <code>subscribe/unsubscribe</code></li>
                <li>Over-engineering simple state with BehaviorSubject + pipe</li>
                <li>AsyncPipe adds template complexity</li>
                <li>Hard to debug (stack traces, operator chains)</li>
              </ul>
            </div>
            <div class="comparison-card gain">
              <h4>Signal Advantages</h4>
              <ul>
                <li>Synchronous reads — just call <code>mySignal()</code></li>
                <li>Automatic cleanup — no subscription management</li>
                <li>Fine-grained change detection (no Zone.js needed)</li>
                <li>Simple mental model: value + dependency graph</li>
                <li>Better DevTools integration</li>
              </ul>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Risk Assessment -->
      <ui-card title="2. Risk Assessment Framework" [elevated]="true">
        <div class="demo-section">
          <table class="assessment-table">
            <thead>
              <tr>
                <th>Factor</th>
                <th>Low Risk</th>
                <th>High Risk</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Codebase size</strong></td>
                <td>Small / medium app</td>
                <td>Enterprise monorepo with 100+ services</td>
              </tr>
              <tr>
                <td><strong>RxJS complexity</strong></td>
                <td>Basic subscribe, simple pipes</td>
                <td>Heavy multicasting, custom operators, shareReplay chains</td>
              </tr>
              <tr>
                <td><strong>Test coverage</strong></td>
                <td>Good coverage on services</td>
                <td>Low / no automated tests</td>
              </tr>
              <tr>
                <td><strong>Team experience</strong></td>
                <td>Team knows Signals well</td>
                <td>Team is new to Signals</td>
              </tr>
              <tr>
                <td><strong>Timeline</strong></td>
                <td>Flexible, can migrate over sprints</td>
                <td>Hard deadline, concurrent feature work</td>
              </tr>
            </tbody>
          </table>
        </div>
      </ui-card>

      <!-- Two Strategies -->
      <ui-card title="3. Strategy Comparison" [elevated]="true">
        <div class="demo-section">
          <div class="strategy-grid">
            <div class="strategy-card incremental">
              <div class="strategy-header">
                <h4>Incremental Migration</h4>
                <ui-badge variant="success">Recommended</ui-badge>
              </div>
              <p>Migrate one service/feature at a time. RxJS and Signals coexist via the interop layer.</p>
              <div class="pros-cons">
                <div>
                  <strong>Pros:</strong>
                  <ul>
                    <li>Low risk — ship after each feature</li>
                    <li>Team learns gradually</li>
                    <li>Rollback is scoped</li>
                    <li>No "big bang" release</li>
                  </ul>
                </div>
                <div>
                  <strong>Cons:</strong>
                  <ul>
                    <li>Longer total timeline</li>
                    <li>Two patterns coexist (temporary)</li>
                    <li>Interop glue code (toSignal / toObservable)</li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="strategy-card complete">
              <div class="strategy-header">
                <h4>Complete Replacement</h4>
                <ui-badge variant="danger">High Risk</ui-badge>
              </div>
              <p>Replace all RxJS usage in one pass. One large PR / release.</p>
              <div class="pros-cons">
                <div>
                  <strong>Pros:</strong>
                  <ul>
                    <li>No interop overhead</li>
                    <li>Clean codebase afterward</li>
                    <li>Consistent patterns across app</li>
                  </ul>
                </div>
                <div>
                  <strong>Cons:</strong>
                  <ul>
                    <li>High risk — everything changes at once</li>
                    <li>Long branch, merge conflicts</li>
                    <li>Hard to test thoroughly</li>
                    <li>ALL or nothing rollback</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Migration Phases -->
      <ui-card title="4. Incremental Migration Phases" [elevated]="true">
        <div class="demo-section">
          <div class="phases-timeline">
            <div class="phase">
              <div class="phase-number">1</div>
              <div class="phase-content">
                <h4>Audit &amp; Inventory</h4>
                <p>List all RxJS usage: services, pipes, operators. Classify by complexity.</p>
                <pre class="code-block">{{ codeAudit }}</pre>
              </div>
            </div>
            <div class="phase">
              <div class="phase-number">2</div>
              <div class="phase-content">
                <h4>Add Interop Layer</h4>
                <p>Wrap existing Observables with <code>toSignal()</code> at consumption points.
                Services keep returning Observable — components read signals.</p>
                <pre class="code-block">{{ codeInterop }}</pre>
              </div>
            </div>
            <div class="phase">
              <div class="phase-number">3</div>
              <div class="phase-content">
                <h4>Convert Simple Services</h4>
                <p>Replace BehaviorSubject services with <code>signal()</code> + <code>computed()</code>.
                Start with the easiest ones (counters, toggles, filters).</p>
                <pre class="code-block">{{ codeConvertSimple }}</pre>
              </div>
            </div>
            <div class="phase">
              <div class="phase-number">4</div>
              <div class="phase-content">
                <h4>Adopt Signal Store</h4>
                <p>Move complex feature state to <code>signalStore</code> with entities, rxMethod.
                Use <code>rxResource</code> / <code>resource</code> for async data.</p>
              </div>
            </div>
            <div class="phase">
              <div class="phase-number">5</div>
              <div class="phase-content">
                <h4>Remove RxJS Remnants</h4>
                <p>Delete unused imports, remove AsyncPipe, drop <code>toSignal</code> wrappers
                once the source is signal-native.</p>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Keep RxJS -->
      <ui-card title="5. When to Keep RxJS" [elevated]="true">
        <div class="demo-section">
          <div class="keep-grid">
            <div class="keep-item">
              <ui-badge variant="warning">Keep RxJS</ui-badge>
              <span>WebSocket / real-time streams</span>
            </div>
            <div class="keep-item">
              <ui-badge variant="warning">Keep RxJS</ui-badge>
              <span>Complex event coordination (race, merge, combineLatest of events)</span>
            </div>
            <div class="keep-item">
              <ui-badge variant="warning">Keep RxJS</ui-badge>
              <span>Retry / polling / backoff strategies</span>
            </div>
            <div class="keep-item">
              <ui-badge variant="warning">Keep RxJS</ui-badge>
              <span>Cancellation-heavy workflows (switchMap chains)</span>
            </div>
            <div class="keep-item">
              <ui-badge variant="success">Migrate to Signals</ui-badge>
              <span>BehaviorSubject as state holder</span>
            </div>
            <div class="keep-item">
              <ui-badge variant="success">Migrate to Signals</ui-badge>
              <span>Simple HTTP GET → display in template</span>
            </div>
            <div class="keep-item">
              <ui-badge variant="success">Migrate to Signals</ui-badge>
              <span>Derived / computed UI state</span>
            </div>
            <div class="keep-item">
              <ui-badge variant="success">Migrate to Signals</ui-badge>
              <span>Form field validation state</span>
            </div>
          </div>
          <div class="explanation">
            <p>Signals and RxJS are <strong>complementary</strong>. The goal is not to eliminate RxJS —
            it is to use the right tool for each job.</p>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .strategy-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .comparison-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .comparison-card { border-radius: 12px; padding: 1rem; }
    .comparison-card.pain { background: #fff3e0; border: 2px solid #ffe0b2; }
    .comparison-card.gain { background: #e8f5e9; border: 2px solid #c8e6c9; }
    .comparison-card h4 { margin: 0 0 0.5rem; font-size: 0.95rem; }
    .comparison-card ul { padding-left: 1.25rem; font-size: 0.85rem; margin: 0; }
    .comparison-card li { margin: 0.3rem 0; }
    .comparison-card code { background: rgba(0,0,0,0.06); padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.8rem; }

    .assessment-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
    .assessment-table th { background: #f5f5f5; padding: 0.5rem; text-align: left; border-bottom: 2px solid #e0e0e0; }
    .assessment-table td { padding: 0.5rem; border-bottom: 1px solid #eee; }
    .assessment-table tr:hover { background: #f8f9fa; }

    .strategy-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .strategy-card { border-radius: 12px; padding: 1rem; }
    .strategy-card.incremental { background: #e8f5e9; border: 2px solid #c8e6c9; }
    .strategy-card.complete { background: #ffebee; border: 2px solid #ffcdd2; }
    .strategy-header { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.5rem; }
    .strategy-header h4 { margin: 0; }
    .strategy-card p { font-size: 0.85rem; color: #555; margin: 0.25rem 0 0.5rem; }
    .pros-cons { display: flex; gap: 1rem; font-size: 0.82rem; }
    .pros-cons ul { padding-left: 1.25rem; margin: 0.25rem 0; }
    .pros-cons li { margin: 0.2rem 0; }

    .phases-timeline { display: flex; flex-direction: column; gap: 1rem; }
    .phase { display: flex; gap: 1rem; align-items: flex-start; }
    .phase-number { width: 36px; height: 36px; border-radius: 50%; background: #1976d2; color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; flex-shrink: 0; }
    .phase-content { flex: 1; }
    .phase-content h4 { margin: 0 0 0.25rem; font-size: 0.9rem; }
    .phase-content p { font-size: 0.85rem; color: #555; margin: 0.25rem 0; }
    .phase-content code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.8rem; }

    .keep-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin-bottom: 0.75rem; }
    .keep-item { display: flex; align-items: center; gap: 0.5rem; font-size: 0.85rem; padding: 0.4rem 0.6rem; background: #f8f9fa; border-radius: 8px; }
  `]
})
export class MigrationStrategyComponent {

  codeAudit = `// Phase 1: Audit RxJS usage
// Search your codebase:
//   subscribe(    → manual subscriptions (leak risk)
//   | async       → AsyncPipe usage
//   BehaviorSubject → state holders (prime migration targets)
//   switchMap, mergeMap, exhaustMap → complex operators
//   shareReplay   → multicasting (keep RxJS for these)

// Classify each file:
//   EASY   → BehaviorSubject as state, simple .subscribe()
//   MEDIUM → HTTP + pipe chain + template binding
//   HARD   → WebSocket, retry logic, complex multicasting`;

  codeInterop = `// Phase 2: Wrap with toSignal() at consumption
// BEFORE (component):
products$ = this.productService.getProducts();
// Template: *ngFor="let p of products$ | async"

// AFTER (component — service stays the same):
private productService = inject(ProductService);
products = toSignal(this.productService.getProducts(), {
  initialValue: []
});
// Template: @for (p of products(); track p.id) { ... }`;

  codeConvertSimple = `// Phase 3: Convert BehaviorSubject → signal()
// BEFORE:
@Injectable({ providedIn: 'root' })
export class ThemeService {
  private theme$ = new BehaviorSubject<'light' | 'dark'>('light');
  theme = this.theme$.asObservable();
  toggle() { this.theme$.next(this.theme$.value === 'light' ? 'dark' : 'light'); }
}

// AFTER:
@Injectable({ providedIn: 'root' })
export class ThemeService {
  theme = signal<'light' | 'dark'>('light');
  toggle() { this.theme.update(t => t === 'light' ? 'dark' : 'light'); }
}`;
}
