import { Route } from '@angular/router';
import { MigrationStrategyComponent } from './migration-strategy.component';

export const MIGRATION_STRATEGY_ROUTES: Route[] = [
  { path: '', component: MigrationStrategyComponent }
];
