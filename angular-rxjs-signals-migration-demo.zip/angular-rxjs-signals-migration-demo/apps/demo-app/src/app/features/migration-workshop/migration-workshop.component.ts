import { Component, ChangeDetectionStrategy, inject, signal, computed, resource, ResourceStatus } from '@angular/core';
import { toSignal, rxResource } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';
import { ProductService, CustomerService } from '@angular-monorepo-demo/data-access';
import { Product, Customer } from '@angular-monorepo-demo/data-access';

/**
 * Practical Workshop: Service Layer Migration — Topic 4 (20 min)
 *
 * Step-by-step conversion of data services from RxJS to signal-based patterns.
 */
@Component({
  selector: 'app-migration-workshop',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="workshop-page">
      <h2>Workshop: Service Layer Migration
        <ui-badge variant="info">Block 6 — Topic 4</ui-badge>
      </h2>

      <p class="note">
        In this workshop we migrate two real services (<code>ProductService</code> and
        <code>CustomerService</code>) from RxJS subscribe patterns to signal-based patterns
        <strong>step by step</strong>.
      </p>

      <!-- Step 1: Before -->
      <ui-card title="Step 1: The RxJS Service (Before)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeServiceBefore }}</pre>
          <pre class="code-block">{{ codeComponentBefore }}</pre>
          <div class="explanation">
            <p>This is the classic pattern: service returns <code>Observable</code>,
            component subscribes in <code>ngOnInit</code> or uses <code>AsyncPipe</code>.
            Works, but verbose and leak-prone without careful cleanup.</p>
          </div>
        </div>
      </ui-card>

      <!-- Step 2: toSignal wrapper -->
      <ui-card title="Step 2: Wrap with toSignal() (Quick Win)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeStep2 }}</pre>

          <h4>Live: Products via toSignal()</h4>
          <div class="data-list">
            @for (p of productsToSignal(); track p.id) {
              <div class="data-row">
                <span class="data-name">{{ p.name }}</span>
                <span class="data-detail">\${{ p.price }} · {{ p.category }}</span>
              </div>
            } @empty {
              <div class="loading">Loading products...</div>
            }
          </div>

          <div class="explanation">
            <p><strong>Effort: 2 minutes per component.</strong> The service stays unchanged.
            Only the component consumption changes. Great first step in migration.</p>
          </div>
        </div>
      </ui-card>

      <!-- Step 3: rxResource -->
      <ui-card title="Step 3: Upgrade to rxResource() (Full Status Tracking)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeStep3 }}</pre>

          <h4>Live: Customers via rxResource()</h4>
          <div class="demo-row">
            <span>Filter tier:</span>
            <ui-button [variant]="customerTier() === 'all' ? 'primary' : 'ghost'" size="sm"
              (clicked)="customerTier.set('all')">All</ui-button>
            <ui-button [variant]="customerTier() === 'gold' ? 'primary' : 'ghost'" size="sm"
              (clicked)="customerTier.set('gold')">Gold</ui-button>
            <ui-button [variant]="customerTier() === 'platinum' ? 'primary' : 'ghost'" size="sm"
              (clicked)="customerTier.set('platinum')">Platinum</ui-button>
            <ui-button [variant]="customerTier() === 'silver' ? 'primary' : 'ghost'" size="sm"
              (clicked)="customerTier.set('silver')">Silver</ui-button>
          </div>

          <div class="resource-info">
            Status:
            <ui-badge [variant]="customerStatusBadge()">{{ customerStatusLabel() }}</ui-badge>
            · Count: <strong>{{ (customerResource.value() ?? []).length }}</strong>
          </div>

          <div class="data-list">
            @if (customerResource.isLoading()) {
              <div class="loading">Loading customers...</div>
            }
            @for (c of customerResource.value() ?? []; track c.id) {
              <div class="data-row">
                <span class="data-name">{{ c.firstName }} {{ c.lastName }}</span>
                <span class="data-detail">{{ c.email }}</span>
                <ui-badge [variant]="tierBadge(c.tier)">{{ c.tier }}</ui-badge>
              </div>
            } @empty {
              @if (!customerResource.isLoading()) {
                <div class="empty">No customers in "{{ customerTier() }}" tier</div>
              }
            }
          </div>

          <div class="demo-row">
            <ui-button variant="ghost" size="sm" (clicked)="customerResource.reload()">Reload</ui-button>
          </div>

          <div class="explanation">
            <p><strong>Benefit:</strong> Auto-refetch when the tier filter changes.
            Built-in <code>isLoading()</code>, <code>error()</code>, and <code>reload()</code>.
            No manual subscribe, no cleanup.</p>
          </div>
        </div>
      </ui-card>

      <!-- Step 4: Signal-native service -->
      <ui-card title="Step 4: Convert the Service Itself (Full Migration)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeStep4Service }}</pre>
          <pre class="code-block">{{ codeStep4Component }}</pre>

          <div class="explanation">
            <p>In the final step, the service itself becomes signal-native.
            <code>getProducts()</code> returns a signal, not an Observable. The component
            just reads the signal — <strong>zero bridging code</strong>.</p>
            <p>This is only worth doing for simple data services. Keep RxJS for
            WebSocket streams, polling, and retry logic.</p>
          </div>
        </div>
      </ui-card>

      <!-- Migration Checklist -->
      <ui-card title="Step 5: Migration Checklist" [elevated]="true">
        <div class="demo-section">
          <div class="checklist">
            <div class="check-item">
              <input type="checkbox" checked disabled />
              <span>Identify all <code>.subscribe()</code> calls in components</span>
            </div>
            <div class="check-item">
              <input type="checkbox" checked disabled />
              <span>Replace with <code>toSignal()</code> (quick win, keep service as-is)</span>
            </div>
            <div class="check-item">
              <input type="checkbox" checked disabled />
              <span>For parameterised queries, upgrade to <code>rxResource()</code></span>
            </div>
            <div class="check-item">
              <input type="checkbox" disabled />
              <span>Convert simple BehaviorSubject services to <code>signal()</code></span>
            </div>
            <div class="check-item">
              <input type="checkbox" disabled />
              <span>Remove unused <code>AsyncPipe</code> imports</span>
            </div>
            <div class="check-item">
              <input type="checkbox" disabled />
              <span>Remove <code>OnDestroy</code> / subscription cleanup</span>
            </div>
            <div class="check-item">
              <input type="checkbox" disabled />
              <span>Run tests after each service migration</span>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Exercises -->
      <ui-card title="Student Exercises" [elevated]="true">
        <div class="demo-section">
          <div class="exercise-tasks">
            <h4>Hands-on tasks:</h4>
            <ol>
              <li>Open <code>ProductService</code> and add a <code>searchProducts(term: string)</code>
              method that returns an Observable. Then consume it with <code>rxResource()</code>
              in a new component.</li>
              <li>Convert <code>UserService.getUsers()</code> calls to use <code>toSignal()</code>
              in the Users feature page.</li>
              <li>Create a new <code>ProductSignalService</code> that uses <code>signal()</code>
              internally instead of Observables. Compare the API surface.</li>
              <li>Build a product detail page that loads a single product by ID using
              <code>resource()</code> with a route param signal.</li>
            </ol>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .workshop-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.75rem 0; flex-wrap: wrap; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .data-list { border: 1px solid #e0e0e0; border-radius: 8px; max-height: 220px; overflow-y: auto; margin: 0.5rem 0; }
    .data-row { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 0.75rem; border-bottom: 1px solid #eee; font-size: 0.85rem; }
    .data-row:last-child { border-bottom: none; }
    .data-name { font-weight: 500; flex: 1; }
    .data-detail { color: #666; font-size: 0.82rem; }
    .loading { padding: 1rem; text-align: center; color: #888; font-size: 0.88rem; }
    .empty { padding: 1rem; text-align: center; color: #888; font-size: 0.88rem; }
    .resource-info { font-size: 0.88rem; margin: 0.25rem 0; }

    .checklist { display: flex; flex-direction: column; gap: 0.4rem; }
    .check-item { display: flex; align-items: center; gap: 0.5rem; font-size: 0.88rem; }
    .check-item code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.82rem; }

    .exercise-tasks { background: #f3e5f5; border-radius: 12px; padding: 1rem; }
    .exercise-tasks h4 { margin: 0 0 0.5rem; }
    .exercise-tasks ol { padding-left: 1.25rem; font-size: 0.88rem; }
    .exercise-tasks li { margin: 0.5rem 0; }
    .exercise-tasks code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.82rem; }
  `]
})
export class MigrationWorkshopComponent {
  private productService = inject(ProductService);
  private customerService = inject(CustomerService);

  // ═══════════ Step 2: toSignal() quick win ═══════════
  productsToSignal = toSignal(this.productService.getProducts(), { initialValue: [] as Product[] });

  // ═══════════ Step 3: rxResource() with parameterised query ═══════════
  customerTier = signal<string>('all');

  customerResource = rxResource({
    request: () => ({ tier: this.customerTier() }),
    loader: ({ request }) => {
      return this.customerService.getCustomers().pipe(
        map(customers => {
          if (request.tier === 'all') return customers;
          return customers.filter(c => c.tier === request.tier);
        })
      );
    }
  });

  customerStatusLabel = computed(() => {
    const s = this.customerResource.status();
    if (s === ResourceStatus.Loading) return 'Loading';
    if (s === ResourceStatus.Reloading) return 'Reloading';
    if (s === ResourceStatus.Resolved) return 'Resolved';
    if (s === ResourceStatus.Error) return 'Error';
    return 'Idle';
  });

  customerStatusBadge = computed(() => {
    const s = this.customerResource.status();
    if (s === ResourceStatus.Resolved) return 'success' as const;
    if (s === ResourceStatus.Error) return 'danger' as const;
    if (s === ResourceStatus.Loading || s === ResourceStatus.Reloading) return 'warning' as const;
    return 'neutral' as const;
  });

  tierBadge(tier: string): 'success' | 'warning' | 'info' | 'danger' | 'neutral' {
    switch (tier) {
      case 'platinum': return 'success';
      case 'gold': return 'warning';
      case 'silver': return 'info';
      default: return 'neutral';
    }
  }

  // ═══════════ Code examples ═══════════
  codeServiceBefore = `// BEFORE: Classic RxJS Service
@Injectable({ providedIn: 'root' })
export class ProductService {
  private products: Product[] = [ /* ... */ ];

  getProducts(): Observable<Product[]> {
    return of(this.products).pipe(delay(200));
  }

  getProductById(id: number): Observable<Product | undefined> {
    return of(this.products.find(p => p.id === id)).pipe(delay(100));
  }
}`;

  codeComponentBefore = `// BEFORE: Component with subscribe
export class ProductListComponent implements OnInit, OnDestroy {
  products: Product[] = [];
  private sub!: Subscription;

  ngOnInit() {
    this.sub = this.productService.getProducts()
      .subscribe(products => this.products = products);
  }
  ngOnDestroy() { this.sub.unsubscribe(); }
}

// OR with AsyncPipe:
// products$ = this.productService.getProducts();
// <div *ngFor="let p of products$ | async">...`;

  codeStep2 = `// STEP 2: Wrap with toSignal() — service stays the same!
export class ProductListComponent {
  private productService = inject(ProductService);

  // One line replaces subscribe + unsubscribe + OnDestroy
  products = toSignal(this.productService.getProducts(), {
    initialValue: []
  });
}

// Template: @for (p of products(); track p.id) { ... }
// No subscribe. No unsubscribe. No async pipe.`;

  codeStep3 = `// STEP 3: rxResource() for parameterised queries
customerTier = signal('all');

customerResource = rxResource({
  request: () => ({ tier: this.customerTier() }),
  loader: ({ request }) =>
    this.customerService.getCustomers().pipe(
      map(customers =>
        request.tier === 'all'
          ? customers
          : customers.filter(c => c.tier === request.tier)
      )
    )
});

// Auto-refetches when customerTier changes!
// customerResource.value()       → Customer[]
// customerResource.isLoading()   → boolean
// customerResource.reload()      → manual refresh`;

  codeStep4Service = `// STEP 4: Signal-native service (full migration)
@Injectable({ providedIn: 'root' })
export class ProductSignalService {
  // Internal state
  private _products = signal<Product[]>([
    { id: 1, name: 'Laptop Pro X', price: 1299.99, ... },
    // ...
  ]);

  // Public read-only signal
  products = this._products.asReadonly();

  // Derived state
  categories = computed(() =>
    [...new Set(this._products().map(p => p.category))]
  );

  // Mutations
  addProduct(product: Product) {
    this._products.update(list => [...list, product]);
  }

  removeProduct(id: number) {
    this._products.update(list => list.filter(p => p.id !== id));
  }
}`;

  codeStep4Component = `// STEP 4: Component using signal-native service
export class ProductListComponent {
  private productService = inject(ProductSignalService);

  // Direct signal access — no bridging needed
  products = this.productService.products;
  categories = this.productService.categories;

  // Template: @for (p of products(); track p.id) { ... }
}`;
}
