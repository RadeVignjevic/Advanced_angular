import { Route } from '@angular/router';
import { MigrationWorkshopComponent } from './migration-workshop.component';

export const MIGRATION_WORKSHOP_ROUTES: Route[] = [
  { path: '', component: MigrationWorkshopComponent }
];
