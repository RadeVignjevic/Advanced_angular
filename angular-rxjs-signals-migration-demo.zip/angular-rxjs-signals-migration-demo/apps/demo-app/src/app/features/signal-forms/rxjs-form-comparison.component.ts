import { Component, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BehaviorSubject, combineLatest, map } from 'rxjs';

/**
 * RxJS BehaviorSubject-based form — for comparison with signal-based form.
 *
 * Key differences vs signals:
 *  - Needs BehaviorSubject + .pipe() + map() for each validation
 *  - Needs combineLatest to derive overall form validity
 *  - Template must use {{ ... | async }} everywhere
 *  - Must manually complete subjects in ngOnDestroy
 */
@Component({
  selector: 'app-rxjs-form-comparison',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="form-container">
      <h3>RxJS BehaviorSubject Form</h3>

      <div class="form-row">
        <label>Name:</label>
        <input [value]="(name | async) ?? ''"
               (input)="setName(getValue($event))"
               [class.invalid]="(nameValid$ | async) === false" />
        @if ((nameValid$ | async) === false) {
          <span class="error">Min 2 characters</span>
        }
      </div>

      <div class="form-row">
        <label>Email:</label>
        <input [value]="(email | async) ?? ''"
               (input)="setEmail(getValue($event))"
               [class.invalid]="(emailValid$ | async) === false" />
        @if ((emailValid$ | async) === false) {
          <span class="error">Invalid email</span>
        }
      </div>

      <div class="form-row">
        <label>Age:</label>
        <input type="number"
               [value]="(age | async) ?? ''"
               (input)="setAge(getNumber($event))"
               [class.invalid]="(ageValid$ | async) === false" />
        @if ((ageValid$ | async) === false) {
          <span class="error">Must be 18–120</span>
        }
      </div>

      <div class="form-status">
        <span>Form valid: <strong>{{ formValid$ | async }}</strong></span>
      </div>

      <button [disabled]="(formValid$ | async) === false" (click)="onSubmit()">
        Submit
      </button>
    </div>
  `,
  styles: [`
    .form-container { padding: 1rem; background: #fff3e0; border: 2px solid #ffe0b2; border-radius: 12px; }
    h3 { margin: 0 0 1rem; }
    .form-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.5rem 0; }
    .form-row label { min-width: 60px; font-weight: 600; font-size: 0.88rem; }
    .form-row input { padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; min-width: 200px; }
    .form-row input:focus { outline: none; border-color: #42a5f5; }
    .form-row input.invalid { border-color: #e53935; background: #fff5f5; }
    .error { color: #e53935; font-size: 0.78rem; }
    .form-status { font-family: monospace; font-size: 0.85rem; margin: 0.75rem 0; }
    button { padding: 0.5rem 1.25rem; border: none; border-radius: 8px; background: #1976d2; color: #fff; cursor: pointer; font-size: 0.88rem; }
    button:disabled { background: #bdbdbd; cursor: not-allowed; }
  `]
})
export class RxjsFormComparisonComponent implements OnDestroy {

  // ── State: BehaviorSubjects ──────────────────────────
  private name$ = new BehaviorSubject('');
  private email$ = new BehaviorSubject('');
  private age$ = new BehaviorSubject<number | null>(null);

  // Expose as observables for the template (async pipe)
  // We reuse the private subjects directly since BehaviorSubject IS an Observable
  name = this.name$.asObservable();
  email = this.email$.asObservable();
  age = this.age$.asObservable();

  // ── Derived streams ──────────────────────────────────
  nameValid$ = this.name$.pipe(map(n => n.trim().length >= 2));
  emailValid$ = this.email$.pipe(map(e => /^[^@]+@[^@]+\.[^@]+$/.test(e)));
  ageValid$ = this.age$.pipe(map(a => a !== null && a >= 18 && a <= 120));

  formValid$ = combineLatest([
    this.nameValid$,
    this.emailValid$,
    this.ageValid$
  ]).pipe(
    map(([n, e, a]) => n && e && a)
  );

  // ── Setters ──────────────────────────────────────────
  setName(v: string) { this.name$.next(v); }
  setEmail(v: string) { this.email$.next(v); }
  setAge(v: number | null) { this.age$.next(v); }

  // ── Cleanup (REQUIRED — unlike signals) ──────────────
  ngOnDestroy() {
    this.name$.complete();
    this.email$.complete();
    this.age$.complete();
  }

  // ── Helpers ──────────────────────────────────────────
  getValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  getNumber(event: Event): number | null {
    const v = (event.target as HTMLInputElement).value;
    const n = parseFloat(v);
    return isNaN(n) ? null : n;
  }

  onSubmit(): void {
    console.log('Submitted:', {
      name: this.name$.value,
      email: this.email$.value,
      age: this.age$.value,
    });
  }
}
