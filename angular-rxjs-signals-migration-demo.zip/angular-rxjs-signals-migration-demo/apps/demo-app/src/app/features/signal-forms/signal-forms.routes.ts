import { Route } from '@angular/router';
import { SignalFormsComponent } from './signal-forms.component';

export const SIGNAL_FORMS_ROUTES: Route[] = [
  { path: '', component: SignalFormsComponent }
];
