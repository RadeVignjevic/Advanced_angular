# Block 3 — Signals as a Reactive Primitive

## Instructor Guide (For Dummies Edition)

**Duration:** 2 hours (120 min)
**Prerequisites:** Blocks 1 & 2 complete (Standalone migration + Monorepo architecture)
**Angular Version:** 19.x (Signals stable since v17)
**Project:** `angular-signals-demo` (Nx monorepo, carried over from Block 2)

---

## Before You Start — What Are Signals in Plain English?

Imagine a spreadsheet cell. Cell A1 has the value `5`. Cell B1 has a formula `=A1 * 2` which shows `10`. When you change A1 to `7`, B1 automatically updates to `14`. You don't have to press a button or refresh anything.

**That's exactly what Angular Signals do:**
- `signal(5)` = cell A1 (a value you can change)
- `computed(() => count() * 2)` = cell B1 (a formula that auto-updates)
- `effect(() => console.log(count()))` = a macro that runs every time A1 changes

**Why do we need them?** Before signals, Angular used RxJS Observables for reactivity. Observables are powerful but complex — like using a Formula 1 race car to go grocery shopping. Signals are the everyday car: simple, efficient, and get the job done for most UI state.

---

## Schedule Overview

| # | Topic | Time | Route | Component | What Students Will Learn |
|---|-------|------|-------|-----------|--------------------------|
| 1 | Signal Fundamentals | 30 min | `/signal-fundamentals` | `signal-fundamentals.component.ts` | How to create, read, update, and derive reactive values |
| 2 | Signals vs RxJS | 30 min | `/signals-vs-rxjs` | `signals-vs-rxjs.component.ts` | When to use signals vs when to use observables |
| 3 | toSignal / toObservable Interop | 20 min | `/signal-interop` | `signal-interop.component.ts` | How to bridge between the two reactive worlds |
| 4 | Workshop: RxJS to Signals Refactoring | 40 min | `/workshop` + `/workshop-solution` | `rxjs-workshop.component.ts` + `rxjs-workshop-solution.component.ts` | Hands-on practice converting real code |

All feature components are in `apps/demo-app/src/app/features/`.

---

## Starting the App

```bash
cd angular-signals-demo
npm install          # if first time
npx nx serve demo-app
```

Open http://localhost:4200. The dashboard shows all Block 3 topics as clickable cards. Block 2 features (Products, Customers, Users, Settings) are still accessible under "Block 2: Features (Done)" in the sidebar.

---

---

## Topic 1: Signal Fundamentals (30 min)

**Route:** `/signal-fundamentals`
**File:** `apps/demo-app/src/app/features/signal-fundamentals/signal-fundamentals.component.ts`

### What You Are Teaching

Students will learn the 3 core building blocks of Angular Signals:
1. `signal()` — a container that holds a value (like a variable that notifies when it changes)
2. `computed()` — a derived value that auto-updates (like a spreadsheet formula)
3. `effect()` — code that runs automatically when a signal changes (like a watcher)

### Before You Open the Demo: Explain This on the Whiteboard (3 min)

Draw this on the whiteboard or share screen with a diagram:

```
┌─────────────┐       ┌──────────────┐       ┌─────────────┐
│  signal(0)  │──────>│ computed(    │──────>│  effect(    │
│  count      │       │   count()*2) │       │   log it)   │
│             │       │  doubled     │       │             │
│  YOU change │       │  AUTO-updates│       │  AUTO-runs  │
│  this       │       │  (read-only) │       │  (side-fx)  │
└─────────────┘       └──────────────┘       └─────────────┘
     ▲                                              │
     │              YOU set/update                  │
     └──────────────────────────────────────────────┘
                    (via user clicks)
```

> **Say this:** "A signal is like a box with a value inside. You can read what's in the box by calling it like a function: `count()`. You can put a new value in the box with `set()` or `update()`. When the value changes, anything that depends on it — computed values, effects, the template — automatically knows."

### Now Open the Demo App — Section by Section

Navigate to http://localhost:4200/signal-fundamentals

---

#### Section 1: `signal()` — Writable Reactive Value (8 min)

**What to show:** The first card on the page with the counter and three buttons.

**What to say:**

> "Let's look at the simplest possible signal. In the component code we have:"
> ```typescript
> count = signal(0);
> ```
> "This creates a signal with an initial value of 0. That's it. One line."

**Live demo — click the buttons:**

1. Click **`set(count + 1)`** button a few times
   - Watch the count go up: 1, 2, 3...
   - > "set() replaces the entire value. We're saying: set the count to its current value plus 1."

2. Click **`update(v + 5)`** button
   - Watch it jump by 5
   - > "update() gives you the current value as a parameter. Think of it like setState in React if anyone knows React. You receive the old value and return the new one."
   - Show the code: `count.update(v => v + 5)` — v is the current value

3. Click **`set(0) — Reset`**
   - Back to 0
   - > "set(0) just directly puts 0 in the box. Simple."

**Key point to hammer home:**
> "The crucial thing is how you READ a signal: `count()` — with parentheses. It looks like a function call. That's intentional. When Angular sees `count()` in the template, it KNOWS this component depends on that signal. If the signal changes, Angular will re-render ONLY this component. This is how Angular can be smart about change detection."

**Common student question:** "Why parentheses? Why not just `count`?"
> "Because `count` without parentheses is just a reference to the signal object. `count()` actually reads the current value AND registers the component as a listener. The parentheses are the magic."

---

#### Section 2: `computed()` — Derived Read-Only Signal (8 min)

**What to show:** The second card showing the dependency chain: count → doubled → quadrupled → label.

**What to say:**

> "Now watch this. In the code we have:"
> ```typescript
> doubled = computed(() => this.count() * 2);
> quadrupled = computed(() => this.doubled() * 2);
> label = computed(() => {
>   const c = this.count();
>   return c === 0 ? 'Zero' : c > 10 ? 'High' : 'Low';
> });
> ```

**Live demo — click the +1 button and watch the chain update:**

- Count: 0 → Doubled: 0 → Quadrupled: 0 → Label: "Zero"
- Count: 1 → Doubled: 2 → Quadrupled: 4 → Label: "Low"
- Count: 5 → Doubled: 10 → Quadrupled: 20 → Label: "Low"
- Count: 11 → Doubled: 22 → Quadrupled: 44 → Label: "High"

> "See how EVERY computed value updated automatically? We never had to manually recalculate. That's the spreadsheet model. Change one cell, everything downstream updates."

**Three key points to make:**

1. **Lazy:** "computed() only recalculates when you actually read it AND a dependency changed. If nobody reads `quadrupled()`, it won't recalculate — saving work."

2. **Cached:** "If you read `doubled()` ten times without changing `count`, it returns the cached value. It doesn't recalculate 10 times."

3. **Read-only:** "You cannot do `doubled.set(100)`. It's derived. You can only change `count` (the source signal), and doubled updates automatically. This prevents bugs."

**Analogy to drive it home:**
> "Think of it like tax calculation. Your `salary` is a signal. Your `taxAmount` is a computed signal. You don't set your tax — it's derived from your salary. If your salary changes, your tax automatically changes."

---

#### Section 3: Signals with Objects and Arrays (5 min)

**What to show:** The third card with items list and user object.

**What to say:**

> "Signals work with any type — not just numbers. Here we have an array signal and an object signal:"
> ```typescript
> items = signal<string[]>(['Angular', 'Signals']);
> user = signal({ name: 'Alice', age: 30 });
> ```

**Live demo:**

1. Click **"Add Item"** — watch the items list grow
2. Click **"Increment Age"** — watch Alice get older
3. Click **"Reset"** — back to defaults

**THE TRAP TO TEACH (this is important):**

> "Here's where beginners get bitten. Signals check if the value changed using `Object.is()` — which does REFERENCE comparison for objects. Watch:"
> ```typescript
> // ❌ WRONG — this mutates the same array, signal doesn't see a change!
> items().push('New Item');
>
> // ✅ RIGHT — spread creates a new array, signal sees a new reference
> items.update(list => [...list, 'New Item']);
> ```

> "Same for objects:"
> ```typescript
> // ❌ WRONG — same object reference
> user().name = 'Bob';
>
> // ✅ RIGHT — spread creates a new object
> user.update(u => ({ ...u, name: 'Bob' }));
> ```

> "This is the same immutability rule from React and NgRx. If you've used either, it's the same concept. Always create NEW references."

---

#### Section 4: `effect()` — Reactive Side Effects (5 min)

**What to show:** The fourth card with the green log output.

**What to say:**

> "Sometimes you need to DO something when a signal changes. Not derive a value, but perform an action — like logging, saving to localStorage, or calling an analytics API. That's what effect() is for."
> ```typescript
> effect(() => {
>   const current = this.count();
>   console.log('Count changed to:', current);
> });
> ```

**Live demo:**

1. Click **"Trigger Effect"** (the +1 button) several times
2. Watch log entries appear in the green console area:
   ```
   [14:23:05] count changed to 1
   [14:23:06] count changed to 2
   [14:23:07] count changed to 3
   ```

**Key points:**

> "Three things about effects:"
> 1. **Auto-tracking:** "Angular sees that we read `count()` inside the effect. So it automatically re-runs the effect whenever count changes. You don't have to tell it 'watch count' — it figures it out."
> 2. **Runs at least once:** "Even if nothing changes, the effect runs once on initialization."
> 3. **Auto-cleanup:** "When the component is destroyed (user navigates away), the effect stops. No manual cleanup needed."

**The `untracked()` escape hatch:**

> "What if you want to READ a signal inside an effect but NOT re-run when that signal changes? Use `untracked()`:"
> ```typescript
> effect(() => {
>   const c = this.count();               // tracked — re-runs when count changes
>   const other = untracked(() => this.other()); // NOT tracked
> });
> ```

**Warning to students:**
> "Avoid writing to signals inside effects. If you find yourself doing `effect(() => { someSignal.set(...) })`, ask yourself: can I use `computed()` instead? 90% of the time, `computed()` is the right choice. Effects are for EXTERNAL side-effects — logging, saving to storage, API calls."

---

#### Section 5: Mental Model Visualization (4 min)

**What to show:** The last card with the visual flow diagram.

**Draw this on whiteboard for emphasis:**

```
signal()  ──feeds──>  computed()  ──triggers──>  effect()
(input)               (derived)                  (output/side-effect)

Examples:
count     ──feeds──>  doubled     ──triggers──>  log to console
username  ──feeds──>  greeting    ──triggers──>  save to localStorage
cart      ──feeds──>  total       ──triggers──>  update page title
```

**Final summary for Topic 1:**
> "Remember the spreadsheet analogy. `signal()` = cells you can edit. `computed()` = cells with formulas. `effect()` = macros that run when cells change. That's the entire signal model."

### Quick Reference Card for Topic 1

| API | What It Does | When to Use |
|-----|-------------|-------------|
| `signal(0)` | Creates a writable reactive value | Any component state: counters, toggles, form values, lists |
| `signal.set(5)` | Replaces the value | When you know the exact new value |
| `signal.update(v => v + 1)` | Derives new value from old | When the new value depends on the current value |
| `computed(() => sig() * 2)` | Creates a derived, read-only signal | Any calculated/derived value: totals, filtered lists, labels |
| `effect(() => console.log(sig()))` | Runs code when signals change | Logging, analytics, saving to storage, DOM manipulation |
| `untracked(() => sig())` | Reads a signal without creating a dependency | When you need a value inside an effect but don't want to re-run on its change |

---

---

## Topic 2: Signals vs RxJS (30 min)

**Route:** `/signals-vs-rxjs`
**File:** `apps/demo-app/src/app/features/signals-vs-rxjs/signals-vs-rxjs.component.ts`

### What You Are Teaching

Students already know RxJS from working with Angular. Now they're confused: "Should I use signals or observables?" This topic gives them a clear decision framework.

### Before You Open the Demo: Frame the Discussion (3 min)

> **Say this to the class:** "Signals and RxJS are NOT competing. They're different tools for different jobs. Signals are for SYNCHRONOUS state — values that always exist and change over time. Observables are for ASYNCHRONOUS streams — HTTP responses, WebSocket events, keyboard events with debounce. Most real apps use BOTH."

**Analogy:**
> "Signals are like a whiteboard in your office — you write a value, anyone who walks in can immediately read it. Observables are like a TV news channel — you have to tune in (subscribe), wait for the broadcast, and the program might have ad breaks and reruns. Both are useful, for different things."

### Now Open the Demo App

Navigate to http://localhost:4200/signals-vs-rxjs

---

#### Section 1: Decision Framework Card (5 min)

**What to show:** The decision grid at the top of the page.

**Walk through the left column (Signals):**

> "Use Signals when..."
> - "You need the current value RIGHT NOW, synchronously — `count()` gives it immediately"
> - "You're managing simple UI state — a toggle, a counter, a selected item"
> - "You want to derive values — `computed()` replaces most `combineLatest + map`"
> - "Your state always has a value — signals can't be 'empty' like observables can"

**Walk through the right column (Observables):**

> "Use Observables when..."
> - "You're dealing with HTTP calls — `HttpClient.get()` returns an Observable"
> - "You need operators like `debounceTime`, `switchMap`, `retry` — signals don't have these"
> - "You're composing multiple event streams — `merge`, `race`, `combineLatest`"
> - "You need error handling in a pipeline — `catchError`, `retry(3)`"

**Give them the one-liner rule:**
> "Signals for STATE. Observables for STREAMS. When in doubt, ask: 'Does this value always exist, or do I need to wait for it?' If it always exists → signal. If you wait → observable."

---

#### Section 2: Pattern 1 — Counter Comparison (8 min)

**What to show:** The counter comparison card with Signal and RxJS side by side.

**Walk through the Signal side:**

> "With Signals, a counter is 3 lines of code:"
> ```typescript
> count = signal(0);
> doubled = computed(() => count() * 2);
> // Template: {{ count() }}
> ```
> "That's it. Click the button, the count updates, the template re-renders."

Click the Signal +1 button a few times.

**Now walk through the RxJS side:**

> "With RxJS, the same counter needs:"
> ```typescript
> count$ = new BehaviorSubject(0);
> doubled$ = count$.pipe(map(v => v * 2));
> // Template: {{ count$ | async }}
> ```
> "You need a BehaviorSubject, the pipe operator, map operator, AND the async pipe in the template. Four concepts for a simple counter."

Click the RxJS +1 button a few times.

> "Both do the same thing. But the Signal version is simpler. For UI state like this, Signals win."

**Ask the class:** "Can anyone think of a case where you'd use BehaviorSubject for a counter instead of a signal?" (Answer: very rarely — only if you need to feed it into a larger RxJS pipeline)

---

#### Section 3: Pattern 2 — Filtering Data (8 min)

**What to show:** The filtering comparison card.

**Signal side — type in the search box:**

> "With signals, filtering a list is just computed():"
> ```typescript
> searchTerm = signal('');
> filtered = computed(() =>
>   products().filter(p =>
>     p.name.toLowerCase().includes(searchTerm().toLowerCase())
>   )
> );
> ```
> "Type 'A' in the box — the list filters instantly. Type 'An' — it narrows more. No debounce needed because it's synchronous."

Type slowly in the Signal search box to show filtering.

**RxJS side:**

> "The RxJS version needs combineLatest + map + startWith:"
> ```typescript
> filtered$ = combineLatest([
>   products$,
>   searchTerm$.pipe(startWith(''))
> ]).pipe(
>   map(([p, term]) => p.filter(...))
> );
> ```
> "Same result, but more code. The RxJS version is overkill for local filtering."

Type in the RxJS search box.

**Key insight:**
> "Computed() replaces most combineLatest + map patterns. Whenever you have 'combine multiple values and derive a result', reach for computed() first."

---

#### Section 4: Pattern 3 — Async Loading (5 min)

**What to show:** The async data loading card.

> "Here's where Observables still shine. HTTP calls are inherently asynchronous:"
> ```typescript
> products$ = this.http.get<Product[]>('/api/products').pipe(
>   retry(3),                        // retry on failure
>   catchError(err => {              // handle errors
>     this.errorSignal.set(err.message);
>     return EMPTY;
>   })
> );
> ```
> "You can't do retry(3) or catchError with pure signals. These are RxJS superpowers."

> "But once the data arrives, convert to signal for the template:"
> ```typescript
> products = toSignal(this.products$, { initialValue: [] });
> ```
> "This gives you the best of both worlds — RxJS for the async pipeline, signals for the template."

**This is the bridge to Topic 3.** Tell students: "We'll explore this toSignal() bridge in detail next."

---

#### Section 5: Cheat Sheet Table (4 min)

**What to show:** The comparison table at the bottom.

Walk through each row:

| Aspect | Signal | Observable | What to tell students |
|--------|--------|-----------|----------------------|
| Value availability | Always has value | May not have emitted | "A signal ALWAYS has a value. Observables can be empty — HTTP hasn't responded yet." |
| Synchronous read | `signal()` | Not possible | "You can call `count()` anywhere and get the value instantly. With Observables, you have to subscribe and wait." |
| Operators | `computed()` only | 200+ operators | "Signals have ONE operator: computed(). That's all you need for 80% of cases. But if you need debounce, switchMap, retry — you need RxJS." |
| Cleanup | Auto (DI context) | Manual unsubscribe | "Signals clean up automatically. Observables need takeUntil/destroy$ or will leak memory." |
| Change detection | Granular (zoneless) | Zone-based / OnPush | "Signals enable Angular's new zoneless change detection — faster, more precise." |

### Student Discussion Points

Prepare answers for these common questions:

**Q: "If signals are simpler, will RxJS go away?"**
> "No. Angular's HttpClient, Router, and Forms all return Observables and the Angular team has no plans to change that. Signals complement RxJS — they don't replace it."

**Q: "Can I use both in the same component?"**
> "Yes! That's the expected pattern. Use signals for component state, observables for HTTP/streams, and bridge with toSignal(). We'll do exactly this in Topic 3."

**Q: "What about NgRx?"**
> "NgRx has released @ngrx/signals (SignalStore). It's a signal-based state management solution. Same principles from this block apply directly."

---

---

## Topic 3: toSignal / toObservable Interop (20 min)

**Route:** `/signal-interop`
**File:** `apps/demo-app/src/app/features/signal-interop/signal-interop.component.ts`

### What You Are Teaching

Now students know signals AND observables. This topic teaches the BRIDGES between them:
- `toSignal()` — converts an Observable into a Signal (most common)
- `toObservable()` — converts a Signal into an Observable (when you need RxJS operators)

### Before You Open the Demo: Draw This Diagram (2 min)

```
 ┌─────────────────┐                        ┌─────────────────┐
 │                 │    toSignal()           │                 │
 │   Observable    │ ──────────────────────> │     Signal      │
 │   World         │                        │     World       │
 │                 │ <────────────────────── │                 │
 │  (RxJS)         │    toObservable()       │  (Templates)    │
 └─────────────────┘                        └─────────────────┘

 Use for:                                    Use for:
 - HTTP calls                                - Template binding
 - debounce/switchMap                         - computed() derivation
 - retry/catchError                           - Synchronous reads
```

> **Say this:** "These two functions are your translators. They let data flow between the Observable world and the Signal world. Most of the time you'll use toSignal() — taking an HTTP response and making it available in your template."

### Now Open the Demo App

Navigate to http://localhost:4200/signal-interop

---

#### Section 1: `toSignal()` — Observable to Signal (8 min)

**What to show:** The first card "toSignal() — Observable to Signal".

**Walk through the code:**

```typescript
// In the component class:
private products$ = this.productService.getProducts();    // Observable
products = toSignal(this.products$, { initialValue: [] }); // Signal
```

> "This is the MOST COMMON bridge. The service returns an Observable (like HttpClient does). We convert it to a Signal so we can use it in the template without `| async`."

**Show the template difference:**

> "Before (Observable):"
> ```html
> <div *ngFor="let p of products$ | async">{{ p.name }}</div>
> ```
>
> "After (Signal via toSignal):"
> ```html
> @for (p of products(); track p.id) { {{ p.name }} }
> ```
> "No async pipe. No null checks. Just `products()`. Clean."

**Point out the product badges in the demo** — they're rendering from toSignal data.

**IMPORTANT: Explain `initialValue`:**

> "Why do we need `{ initialValue: [] }`? Because the HTTP call hasn't returned yet when the component first renders. Signals MUST always have a value — they can't be `undefined`. So we give it an empty array as the initial value. Once the HTTP response arrives, the signal updates automatically."

**When NOT to use initialValue:**

> "If your Observable emits synchronously — like `of([1,2,3])` or a `BehaviorSubject` — you can use `{ requireSync: true }` instead. But for HTTP calls, you always need `initialValue`."

---

#### Section 2: `toSignal()` with Live Stream (4 min)

**What to show:** The second card with the live timer.

**Watch the timer counting up in real-time:**

```typescript
tick = toSignal(interval(1000), { initialValue: 0 });
formattedTick = computed(() => {
  const t = this.tick();
  const min = Math.floor(t / 60);
  const sec = t % 60;
  return `${min}:${sec.toString().padStart(2, '0')}`;
});
isEvenTick = computed(() => this.tick() % 2 === 0);
```

> "Look at this. The interval Observable emits a number every second. toSignal() converts it to a signal. Then we derive TWO computed signals from it — a formatted time and an even/odd check. Zero subscriptions. Zero cleanup."

**Key insight to emphasize:**
> "The toSignal() subscribes when the component is created and automatically unsubscribes when the component is destroyed. No more `takeUntil(this.destroy$)` or `ngOnDestroy()` boilerplate!"

**Ask the class:** "How many lines of code would the RxJS equivalent need?" (Answer: you'd need subscribe, takeUntil, a destroy$ Subject, ngOnDestroy, and BehaviorSubjects for each derived value)

---

#### Section 3: `toObservable()` — Signal to Observable (8 min)

**What to show:** The third card with the search box.

**THIS IS THE MOST IMPORTANT PATTERN IN THE TOPIC. Take your time here.**

> "Here's the scenario: the user types in a search box. We want to:"
> 1. "Wait 300ms after they stop typing (debounce)"
> 2. "Only search if the text actually changed"
> 3. "Cancel the previous search if they type again (switchMap)"
> 4. "Show the results in the template"
>
> "Steps 1-3 are RxJS superpowers. Step 4 is signal territory. So we need BOTH worlds."

**Walk through the code line by line:**

```typescript
// Step 1: Signal for user input (signal world)
searchQuery = signal('');

// Step 2: Convert to Observable (enter RxJS world)
searchQuery$ = toObservable(this.searchQuery);

// Step 3: RxJS pipeline (debounce, distinct, switchMap)
results$ = this.searchQuery$.pipe(
  debounceTime(300),
  distinctUntilChanged(),
  switchMap(query => this.searchProducts(query))
);

// Step 4: Convert back to Signal (return to signal world)
searchResults = toSignal(this.results$, { initialValue: [] });
```

**Live demo — type in the search box:**

1. Type "A" — wait 300ms — see results
2. Type "Ang" — previous search cancelled, new results appear
3. Clear the box — results reset

> "This is THE recommended pattern for Angular. Memorize this flow:"
> ```
> Signal (input) → toObservable() → RxJS pipeline → toSignal() → Signal (output)
>       ↑                                                              ↓
>    user types                                                   template reads
> ```

**Why not just use RxJS for everything?**
> "You could. But then your template needs async pipes everywhere, you need to manage subscriptions, and Angular can't do granular change detection. The signal-based approach is cleaner and future-proof."

---

#### Section 4: Bridge Pattern Summary (quick review)

**What to show:** The last card with the flow diagram and API table.

**Quick recap:**

| Function | Direction | When To Use |
|----------|-----------|-------------|
| `toSignal(obs$, {initialValue})` | Observable → Signal | You have an HTTP call or stream and want to use the result in a template |
| `toObservable(signal)` | Signal → Observable | You have a signal (like user input) and need RxJS operators (debounce, switchMap) |

> "90% of the time you'll use `toSignal()`. You'll use `toObservable()` when user input needs to be debounced or when you need complex async composition."

---

---

## Topic 4: Workshop — RxJS to Signals Refactoring (40 min)

### What You Are Teaching

This is a HANDS-ON exercise. Students take a real component that uses heavy RxJS (BehaviorSubjects, combineLatest, async pipe, manual subscriptions) and refactor it to use Signals. This is the most important topic because it gives them practical experience.

### Workshop Structure — Stick to This Timeline

| Phase | Time | What Happens |
|-------|------|-------------|
| 1. Explain the "Before" code | 5 min | You walk through the RxJS component on screen |
| 2. Students refactor | 25 min | They code — you walk around and help |
| 3. Compare with solution | 5 min | Open the solution route, compare side by side |
| 4. Discussion | 5 min | Q&A, gotchas, best practices |

---

### Phase 1: Explain the "Before" Code (5 min)

**Route:** `/workshop`
**File:** `apps/demo-app/src/app/features/rxjs-workshop/rxjs-workshop.component.ts`

Open the file and show students what they're dealing with. Point out these pain points:

> "This is a product dashboard. It works perfectly. But look at how much RxJS boilerplate it has:"

**Pain Point 1 — Five BehaviorSubjects for simple state:**
```typescript
searchTerm$ = new BehaviorSubject<string>('');
selectedCategory$ = new BehaviorSubject<string | null>(null);
showInStockOnly$ = new BehaviorSubject<boolean>(false);
selectedProduct$ = new BehaviorSubject<Product | null>(null);
products$ = new BehaviorSubject<Product[]>([]);
```
> "Five BehaviorSubjects! These are just holding simple values — a string, a boolean, a selected item. Signals are made for this."

**Pain Point 2 — combineLatest + map for filtering:**
```typescript
filteredProducts$ = combineLatest([
  this.products$,
  this.searchTerm$.pipe(debounceTime(200), distinctUntilChanged()),
  this.selectedCategory$,
  this.showInStockOnly$
]).pipe(
  map(([products, search, category, inStockOnly]) => { ... })
);
```
> "combineLatest combines 4 observables. This could be one computed() signal."

**Pain Point 3 — Manual cleanup:**
```typescript
private destroy$ = new Subject<void>();
ngOnDestroy() {
  this.destroy$.next();
  this.destroy$.complete();
}
```
> "Every subscription needs takeUntil(this.destroy$). Forget one, you get a memory leak. Signals clean up automatically."

**Pain Point 4 — AsyncPipe everywhere in the template:**
```html
{{ totalCount$ | async }}
{{ (filteredProducts$ | async) ?? [] }}
{{ (showInStockOnly$ | async) ? 'primary' : 'ghost' }}
```
> "Every template binding needs `| async` and null-safety `?? []`. Verbose and error-prone."

---

### Phase 2: Students Refactor (25 min)

Tell students to open `rxjs-workshop.component.ts` and refactor it. Give them the 6 steps below as a checklist. Walk around the room and help.

**If students are struggling**, do Step 1 together on screen and let them do steps 2-6 independently.

**If students are fast**, challenge them: "Can you also add `toObservable()` for the debounced search instead of just using computed?"

---

#### Step 1: Replace BehaviorSubjects with signal() (5 min)

**Tell students:**
> "Find every `new BehaviorSubject(...)` and replace it with `signal(...)`. The initial value stays the same."

```typescript
// BEFORE:
searchTerm$ = new BehaviorSubject<string>('');
selectedCategory$ = new BehaviorSubject<string | null>(null);
showInStockOnly$ = new BehaviorSubject<boolean>(false);
selectedProduct$ = new BehaviorSubject<Product | null>(null);

// AFTER:
searchTerm = signal('');
selectedCategory = signal<string | null>(null);
showInStockOnly = signal(false);
selectedProduct = signal<Product | null>(null);
```

**Common mistake to watch for:** Students might forget to remove the `$` suffix from the name. Convention: signals don't need `$`.

---

#### Step 2: Replace combineLatest + map with computed() (8 min)

**Tell students:**
> "The big combineLatest+map block becomes one computed() signal. Instead of subscribing to multiple observables, just call the signals directly inside computed()."

```typescript
// BEFORE:
filteredProducts$ = combineLatest([
  this.products$,
  this.searchTerm$.pipe(debounceTime(200), distinctUntilChanged()),
  this.selectedCategory$,
  this.showInStockOnly$
]).pipe(
  map(([products, search, category, inStockOnly]) => {
    let filtered = products;
    if (search) filtered = filtered.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
    if (category) filtered = filtered.filter(p => p.category === category);
    if (inStockOnly) filtered = filtered.filter(p => p.inStock);
    return filtered;
  })
);

// AFTER:
filteredProducts = computed(() => {
  let filtered = this.products();
  const search = this.searchTerm().toLowerCase();
  if (search) filtered = filtered.filter(p => p.name.toLowerCase().includes(search));
  const cat = this.selectedCategory();
  if (cat) filtered = filtered.filter(p => p.category === cat);
  if (this.showInStockOnly()) filtered = filtered.filter(p => p.inStock);
  return filtered;
});
```

> "See the difference? No combineLatest, no pipe, no map. Just read the signals and do the logic. Angular figures out the dependencies automatically."

**Also convert the derived stats:**

```typescript
// BEFORE:
totalCount$ = this.products$.pipe(map(p => p.length));
inStockCount$ = this.products$.pipe(map(p => p.filter(x => x.inStock).length));
filteredCount$ = this.filteredProducts$.pipe(map(p => p.length));
totalValue$ = this.filteredProducts$.pipe(map(p => ...));

// AFTER:
totalCount = computed(() => this.products().length);
inStockCount = computed(() => this.products().filter(p => p.inStock).length);
filteredCount = computed(() => this.filteredProducts().length);
totalValue = computed(() => formatCurrency(this.filteredProducts().reduce((sum, p) => sum + p.price, 0)));
```

---

#### Step 3: Replace manual subscription with toSignal() (3 min)

**Tell students:**
> "The products are loaded from a service via HTTP. Replace the subscribe-in-ngOnInit pattern with toSignal()."

```typescript
// BEFORE:
private products$ = new BehaviorSubject<Product[]>([]);
ngOnInit() {
  this.productService.getProducts()
    .pipe(takeUntil(this.destroy$))
    .subscribe(products => this.products$.next(products));
}

// AFTER:
private products = toSignal(this.productService.getProducts(), { initialValue: [] as Product[] });
// No ngOnInit needed!
```

> "One line replaces five. No subscription, no cleanup, no lifecycle hook."

**Remind students:** "Import `toSignal` from `@angular/core/rxjs-interop`."

---

#### Step 4: Remove AsyncPipe from template (5 min)

**Tell students:**
> "Find every `| async` in the template and remove it. Replace with the signal getter syntax `()`."

```html
<!-- BEFORE: -->
<div>{{ totalCount$ | async }}</div>
<div [data]="(filteredProducts$ | async) ?? []"></div>
<ui-button [variant]="(showInStockOnly$ | async) ? 'primary' : 'ghost'">

<!-- AFTER: -->
<div>{{ totalCount() }}</div>
<div [data]="filteredProducts()"></div>
<ui-button [variant]="showInStockOnly() ? 'primary' : 'ghost'">
```

> "No more `| async`, no more null coalescing `?? []`. Signals always have a value."

**Also remove `AsyncPipe` from the component's imports array.**

---

#### Step 5: Remove cleanup boilerplate (2 min)

**Tell students:**
> "Delete the destroy$ Subject, ngOnDestroy, and all takeUntil calls. Signals handle cleanup automatically."

```typescript
// DELETE ALL OF THIS:
private destroy$ = new Subject<void>();

ngOnDestroy() {
  this.destroy$.next();
  this.destroy$.complete();
}
```

> "If the component also implements OnDestroy, remove that from the class declaration."

---

#### Step 6: Update event handlers (2 min)

**Tell students:**
> "Replace `.next()` calls with `.set()` calls."

```typescript
// BEFORE:
onSearchInput(event: Event) {
  this.searchTerm$.next((event.target as HTMLInputElement).value);
}
selectCategory(cat: string) {
  this.selectedCategory$.next(cat);
}
toggleInStock() {
  this.showInStockOnly$.next(!this.showInStockOnly$.value);
}

// AFTER:
// In template: (input)="searchTerm.set(getInputValue($event))"
selectCategory(cat: string) {
  this.selectedCategory.set(cat);
}
toggleInStock() {
  this.showInStockOnly.update(v => !v);
}
```

---

### Phase 3: Compare with Solution (5 min)

**Route:** `/workshop-solution`
**File:** `apps/demo-app/src/app/features/rxjs-workshop/rxjs-workshop-solution.component.ts`

Open the solution route next to the workshop route. The solution page shows a diff summary card:

**Removed:**
- BehaviorSubject × 5
- combineLatest
- AsyncPipe
- takeUntil / destroy$
- ngOnInit / ngOnDestroy
- Subject import

**Added:**
- signal() × 4
- computed() × 5
- toSignal() × 1
- toObservable() × 1

**Impact:**
- ~40% less code
- No manual cleanup
- No async pipe
- Synchronous reads

> "The app works EXACTLY the same. Same features, same UI. But the code is simpler, safer, and easier to understand."

---

### Phase 4: Discussion (5 min)

**Questions to ask the class:**

1. "Was anything harder than expected?" — Usually students struggle with computed() replacing combineLatest
2. "Where would you NOT want to use signals?" — Answer: complex async pipelines with retry, error handling
3. "How would you handle the debounced search with signals?" — Answer: toObservable() → RxJS pipeline → toSignal() (the bridge pattern from Topic 3)

---

---

## Project Structure

```
angular-signals-demo/
+-- apps/demo-app/src/app/
|   +-- app.routes.ts            # All routes (Block 3 + Block 2)
|   +-- app.component.html       # Navigation sidebar
|   +-- features/
|       +-- dashboard/           # Block 3 overview dashboard
|       +-- signal-fundamentals/ # Topic 1: signal, computed, effect
|       +-- signals-vs-rxjs/     # Topic 2: comparison with live demos
|       +-- signal-interop/      # Topic 3: toSignal, toObservable
|       +-- rxjs-workshop/       # Topic 4: before + solution
|       +-- products/            # Block 2 (carried over)
|       +-- customers/           # Block 2 (carried over)
|       +-- users/               # Block 2 (carried over)
|       +-- settings/            # Block 2 (carried over)
+-- libs/shared/
|   +-- ui/                      # UiButton, UiBadge, UiCard, UiDataTable, UiLayout
|   +-- data-access/             # Models, Services, Tokens
|   +-- util/                    # Adapters, helpers
+-- INSTRUCTOR-GUIDE.md          # This file
```

---

## Key Takeaways (Wrap-up Slide — Read These Out)

1. **signal()** = a box with a value. Read it with `count()`. Change it with `set()` or `update()`.
2. **computed()** = a formula that auto-updates. Replaces most `combineLatest + map` patterns.
3. **effect()** = code that runs when signals change. For logging, saving, analytics — NOT for deriving values.
4. **Signals + RxJS = Complementary** — Signals for state, Observables for streams. Use BOTH.
5. **toSignal()** = bring Observable data into Signal world (HTTP → template).
6. **toObservable()** = send Signal data into RxJS world (input → debounce → search).
7. **Workshop result:** ~40% less code, zero manual cleanup, zero AsyncPipe, synchronous reads.

---

## Common Student Questions — Full Answers

**Q: Do signals replace RxJS entirely?**
No. Angular's HttpClient, Router, and Forms still use Observables. The Angular team has explicitly said RxJS is NOT going away. Signals are for synchronous UI state. Use toSignal() to bridge HTTP responses into your templates.

**Q: When should I NOT use signals?**
When you need async operators (debounceTime, switchMap, retry, catchError) or complex event composition (merge, race, withLatestFrom). For these, use the bridge pattern: toObservable → RxJS pipeline → toSignal.

**Q: What about NgRx?**
NgRx now has `@ngrx/signals` (SignalStore) which is a signal-based state management solution. It follows the same principles taught in this block. We cover it in Block 6.

**Q: Is effect() like subscribe()?**
Similar concept, but effect() auto-tracks dependencies (no need to list them) and auto-cleans up with the component's DestroyRef. It is more like MobX autoruns or Vue watchEffect().

**Q: Can I write to signals inside computed()?**
No — computed() is a pure derivation (no side-effects allowed). Use effect() for side-effects that need to write to signals, though prefer restructuring to avoid that pattern.

**Q: What is the `equal` option on signal()?**
`signal(value, { equal: customEqualFn })` lets you provide a custom equality function instead of `Object.is`. Useful for comparing objects by their contents instead of by reference. Example:
```typescript
user = signal({ name: 'Alice', age: 30 }, {
  equal: (a, b) => a.name === b.name && a.age === b.age
});
```

**Q: What if I forget to use `initialValue` with toSignal()?**
The compiler will complain. The signal type becomes `Signal<T | undefined>` and you'll get TypeScript errors wherever you use it. Always provide `initialValue` for HTTP observables.

**Q: Can I use signals in services?**
Yes! Signals work great in `@Injectable({ providedIn: 'root' })` services. The signal persists as long as the service does. This is the basis for signal-based state management (covered in Block 6).

**Q: Are signals faster than Observables?**
For synchronous state, yes — signals skip the Observable machinery (subscribe, pipe, operators) and directly notify Angular's change detection system. This enables Angular's new "zoneless" mode where change detection is triggered precisely by signal changes, not by Zone.js patching every async operation.

---

## Nx Commands Reference

```bash
# Serve the demo app
npx nx serve demo-app

# Build for production
npx nx build demo-app

# Run linting
npx nx lint demo-app

# Generate Storybook (Block 2 UI library)
npx nx storybook shared-ui

# Generate documentation (Block 2)
npx nx run demo-app:compodoc

# Dependency graph
npx nx graph
```
