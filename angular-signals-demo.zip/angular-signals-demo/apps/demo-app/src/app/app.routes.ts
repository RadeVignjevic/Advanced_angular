import { Route } from '@angular/router';
import { DashboardComponent } from './features/dashboard/dashboard.component';

export const appRoutes: Route[] = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },

  // Block 3: Signals as a Reactive Primitive
  { path: 'signal-fundamentals', loadChildren: () => import('./features/signal-fundamentals/signal-fundamentals.routes').then(m => m.SIGNAL_FUNDAMENTALS_ROUTES) },
  { path: 'signals-vs-rxjs', loadChildren: () => import('./features/signals-vs-rxjs/signals-vs-rxjs.routes').then(m => m.SIGNALS_VS_RXJS_ROUTES) },
  { path: 'signal-interop', loadChildren: () => import('./features/signal-interop/signal-interop.routes').then(m => m.SIGNAL_INTEROP_ROUTES) },
  { path: 'workshop', loadChildren: () => import('./features/rxjs-workshop/rxjs-workshop.routes').then(m => m.RXJS_WORKSHOP_ROUTES) },
  { path: 'workshop-solution', loadChildren: () => import('./features/rxjs-workshop/rxjs-workshop-solution.routes').then(m => m.RXJS_WORKSHOP_SOLUTION_ROUTES) },

  // Block 2: Architecture (carried over)
  { path: 'products', loadChildren: () => import('./features/products/products.routes').then(m => m.PRODUCT_ROUTES) },
  { path: 'customers', loadChildren: () => import('./features/customers/customers.routes').then(m => m.CUSTOMER_ROUTES) },
  { path: 'users', loadChildren: () => import('./features/users/users.routes').then(m => m.USER_ROUTES) },
  { path: 'settings', loadChildren: () => import('./features/settings/settings.routes').then(m => m.SETTINGS_ROUTES) },

  { path: '**', redirectTo: 'dashboard' }
];
