# Block 8: Upgrade Strategies and Course Conclusion — Instructor Guide

**Duration:** 2 hours  
**Prerequisites:** Blocks 1–7 (CLI, Nx, Signals, CD, Signal Store, Migration, Performance)  
**Project:** `angular-upgrade-strategies-demo` (builds on Block 7 codebase)

---

## Overview

This final block addresses the practical considerations of Angular version upgrades, helps participants stay current with Angular development, and consolidates all learning outcomes from the 16-hour course. It includes a capstone peer review exercise where participants present their project architectures for structured group evaluation.

---

## Setup

```bash
cd angular-upgrade-strategies-demo
npm install
npx nx serve demo-app
```

Navigate to `http://localhost:4200`. The sidebar shows Block 8 topics at the top; all Blocks 2–7 remain accessible.

---

## Topic 1: Angular Upgrade Methodology (30 min)

**Route:** `/upgrade-methodology`  
**Component:** `apps/demo-app/src/app/features/upgrade-methodology/upgrade-methodology.component.ts`

### Teaching Points

1. **Release Cadence** (5 min)
   - Angular's 6-month major release cycle with semantic versioning
   - Visual timeline: Major (breaking changes possible), Minor (new features), Patch (bug fixes)
   - Version table showing v15–v19 with key features and status (Current, LTS, End of Life)

2. **The ng update Command** (10 min)
   - 4-step flow: analyse → run schematics → update deps → report results
   - Code examples: `ng update @angular/cli @angular/core`, `npx nx migrate latest`
   - **Critical:** Always commit before running ng update (schematics modify source code)
   - Show: `ng update --dry-run` for preview

3. **Identifying Breaking Changes** (8 min)
   - Angular Update Guide at update.angular.dev
   - 4 categories: API removals, behaviour changes, dependency updates, tooling changes
   - Deprecation lifecycle: deprecated → removed 2 major versions later

4. **Automating Upgrades** (7 min)
   - Renovate / Dependabot configuration for Angular packages
   - CI pipeline that auto-tests upgrade PRs
   - Nx migrate workflow for monorepos
   - Canary branch strategy

5. **Interactive Upgrade Checklist** — 10-item checklist with progress bar. Participants can click items to track progress (read blog, check update guide, commit, run ng update, test, deploy).

### Key Takeaway
> Upgrades are safest when automated, tested, and done within 1 month of each release. The longer you wait, the harder it gets.

---

## Topic 2: Staying Current with Angular Development (15 min)

**Route:** `/staying-current`  
**Component:** `apps/demo-app/src/app/features/staying-current/staying-current.component.ts`

### Teaching Points

1. **The Angular RFC Process** (5 min)
   - 4-step flow: RFC created → community feedback → design finalised → implementation
   - Examples: Signal-Based Components (shipped), Built-in Control Flow (shipped), Signal Forms (in progress), Zoneless (in progress)

2. **Roadmap Monitoring** (5 min)
   - Three columns: In Progress, Future, Recently Completed
   - Show angular.dev/roadmap as the source of truth

3. **Community Engagement** (3 min)
   - 6 resources: Angular Blog, YouTube, Discord/SO, GitHub Discussions, Newsletter, Conferences

4. **Practical Tips for Teams** (2 min)
   - Upgrade within 1 month of major release
   - Follow deprecation warnings immediately
   - Use `--dry-run` first
   - Assign an "Angular Champion" on the team
   - Maintain good test coverage (80%+ target)

### Key Takeaway
> Staying current is a team habit. Assign someone to monitor releases and RFCs. Deprecation warnings are your early warning system.

---

## Topic 3: Capstone Exercise — Architectural Peer Review (45 min)

**Route:** `/capstone-review`  
**Component:** `apps/demo-app/src/app/features/capstone-review/capstone-review.component.ts`

### Exercise Structure

- **Groups of 3–4 participants**
- **Per presenter:** 5 min presentation + 7 min group review + 3 min action items = 15 min
- **3 presenters × 15 min = 45 min**

### Presentation Template (5 sections)
1. Project Overview (app purpose, team size, Angular version)
2. Module Structure (features, shared libs, routing, lazy loading)
3. State Management (services vs stores, signal adoption, server state)
4. Performance & CD (OnPush adoption, bundle size, bottlenecks)
5. Pain Points (biggest challenge, what would you change, bug clusters)

### Interactive Scoring Rubric (7 categories)
- Module Architecture, State Management, Change Detection, Performance, Code Organisation, Testability, Upgrade Readiness
- Each rated 1–5 stars with running total and dynamic label (Excellent / Good / Needs Work / Significant Gaps)

### Structured Feedback Framework
- **Strengths** (green): What's working well
- **Improvements** (orange): What could be better
- **Questions** (blue): What needs clarification

### Course Concepts Checklist
- 15 key concepts from Blocks 2–8 for participants to check against the presented architecture

### Instructor Tips
- Encourage specific, actionable feedback (not "it's good")
- Use the scoring rubric to keep reviews structured
- The presenter should note their top 3 action items
- If groups finish early, discuss one architecture across the full room

### Key Takeaway
> The best architecture decisions are informed by peer review. Use structured frameworks to give and receive feedback.

---

## Topic 4: Open Discussion and Questions (20 min)

**Route:** `/open-discussion`  
**Component:** `apps/demo-app/src/app/features/open-discussion/open-discussion.component.ts`

### Facilitation Guide

1. **Discussion Prompts** (10 min)
   - 6 clickable topics: Architecture Decisions, Signals Adoption, State Management, Migration Strategy, Performance Quick Wins, Testing
   - Each expands to 5 discussion points
   - Let participants vote on which topic to discuss first

2. **FAQ Section** (5 min)
   - 6 expandable FAQs covering the most common questions:
     - "Should we migrate all RxJS to signals?"
     - "Is Signal Store production-ready?"
     - "When will zoneless be stable?"
     - "How to handle different skill levels?"
     - "Best folder structure for large apps?"
     - "How often should we upgrade?"

3. **Real-World Scenarios** (5 min)
   - Scenario A: Legacy migration (AngularJS → Angular 19)
   - Scenario B: Greenfield architecture design
   - Scenario C: Performance crisis (Lighthouse score 35)

4. **Parking Lot** — Topics for post-course follow-up:
   - To Research: SSR/hydration, micro-frontends, Angular Elements
   - To Try: Convert a service, add @defer, add Lighthouse CI
   - To Discuss with Team: Signal adoption timeline, upgrade schedule, shared lib strategy

### Key Takeaway
> Real learning happens when you connect course material to your actual projects. Take the parking lot items back to your team.

---

## Topic 5: Summary and Recommended Resources (10 min)

**Route:** `/summary-resources`  
**Component:** `apps/demo-app/src/app/features/summary-resources/summary-resources.component.ts`

### Teaching Points

1. **Course Recap — 8 Blocks** (3 min)
   - Visual timeline of all 8 blocks with key takeaways from each
   - Colour-coded cards showing Block 1 (CLI) through Block 8 (Upgrade & Conclusion)

2. **Key Learning Outcomes** (2 min)
   - 6 outcome cards: Architecture, Signals, Change Detection, State Management, Migration, Performance

3. **Reference Materials** (3 min)
   - **Official:** angular.dev, update.angular.dev, angular.dev/roadmap, GitHub Discussions, blog.angular.dev
   - **Tools:** nx.dev, ngrx.io/guide/signals, Angular CDK, Angular DevTools, source-map-explorer
   - **Learning:** Angular University, Angular In Depth, ng-conf YouTube, Enterprise Angular book

4. **Next Steps** (2 min)
   - This Week: Run ng update, add OnPush to 5 components, install DevTools
   - This Month: Convert one service to signals, implement Signal Store feature, add lazy loading
   - This Quarter: Evaluate Nx, set up Lighthouse CI, create shared libraries
   - Long Term: Complete migration, prepare for zoneless, maintain upgrade cadence

5. **Thank You Banner** — Course statistics: 8 blocks, 16 hours, 30+ topics, 8 workshops

### Key Takeaway
> Knowledge without action fades. Pick 3 things from the "Next Steps" and start this week.

---

## Component Dependencies

| Component | Shared UI | CDK | Signals | Interactive Features |
|-----------|-----------|-----|---------|---------------------|
| Upgrade Methodology | Card, Badge | — | signal | Clickable checklist with progress bar |
| Staying Current | Card, Badge | — | — | RFC flow, roadmap columns |
| Capstone Review | Card, Badge | — | signal, computed | Star rating rubric, score calculation |
| Open Discussion | Card, Badge | — | signal, computed | Expandable prompts, FAQ accordion, scenarios |
| Summary Resources | Card, Badge | — | — | Block timeline, next steps timeline |

---

## Build Output Summary

- **Initial:** ~324 KB (main + polyfills + runtime + styles)
- **Lazy chunks:** 5 new Block 8 chunks (~11–15 KB each), plus all previous block chunks
- **Zero warnings, zero errors** after cleanup of unused imports
- All Block 8 routes are lazy-loaded

---

## Timing Guide

| Segment | Duration | Route |
|---------|----------|-------|
| Angular Upgrade Methodology | 30 min | `/upgrade-methodology` |
| Staying Current with Angular | 15 min | `/staying-current` |
| Capstone: Architectural Peer Review | 45 min | `/capstone-review` |
| Open Discussion and Questions | 20 min | `/open-discussion` |
| Summary and Recommended Resources | 10 min | `/summary-resources` |
| **Total** | **2 hours** | |

---

## Full Course Summary

| Block | Title | Duration | Key Technologies |
|-------|-------|----------|-----------------|
| 1 | Angular CLI Foundations | 2h | Angular CLI, workspace config |
| 2 | Nx Monorepo Architecture | 2h | Nx, shared libs, DI tokens |
| 3 | Angular Signals | 2h | signal(), computed(), effect(), toSignal |
| 4 | Change Detection | 2h | OnPush, signal-driven CD, profiling |
| 5 | NgRx Signal Store | 2h | signalStore(), withEntities(), custom features |
| 6 | RxJS → Signals Migration | 1.5h | Migration strategy, resource(), rxResource() |
| 7 | Performance Optimisation | 2h | Bundle analysis, virtual scroll, zoneless, Lighthouse |
| 8 | Upgrade Strategies & Conclusion | 2h | ng update, RFC process, peer review, resources |
| **Total** | | **15.5 hours** | |

---

## Reference Materials (for distribution)

- **Angular Update Guide (Interactive):** https://update.angular.dev
- **Angular Roadmap:** https://angular.dev/roadmap
- **Angular RFCs on GitHub:** https://github.com/angular/angular/discussions
- **Angular Blog:** https://blog.angular.dev
- **Nx Documentation:** https://nx.dev
- **NgRx Signal Store:** https://ngrx.io/guide/signals
