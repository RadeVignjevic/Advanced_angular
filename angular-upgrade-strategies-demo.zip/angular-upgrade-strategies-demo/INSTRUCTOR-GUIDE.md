# Block 8 — Upgrade Strategies and Course Conclusion

## Instructor Guide — "For Dummies" Edition

**Duration:** 2 h 00 min  
**Prerequisites:** Blocks 1–7 complete  
**Project:** `angular-upgrade-strategies-demo`

---

## How to Use This Guide

This guide tells you **exactly what to say, what to click, and what to draw on the whiteboard**. Every section follows this pattern:

1. **Whiteboard / Analogy** — draw or explain the concept in plain English first
2. **Show the Code** — scroll to the exact section in the running app
3. **Live Demo** — click buttons, watch the result, narrate what happens
4. **Student Checkpoint** — ask a question to verify understanding

> **Convention:** Text in "quotes like this" is **exactly what you say out loud** to the class.

---

## Schedule Overview

| # | Topic | Time | Route | What Students Learn |
|---|-------|------|-------|---------------------|
| 1 | Angular Upgrade Methodology | 30 min | `/upgrade-methodology` | ng update, semver, breaking changes, automation |
| 2 | Staying Current with Angular | 15 min | `/staying-current` | RFC process, roadmap, community resources |
| 3 | Capstone: Architectural Peer Review | 45 min | `/capstone-review` | Structured peer review exercise |
| 4 | Open Discussion & Questions | 20 min | `/open-discussion` | Facilitated Q&A, real-world scenarios |
| 5 | Summary & Resources | 10 min | `/summary-resources` | Course recap, next steps, reference materials |

---

## Before Class — Setup (3 min)

```bash
cd angular-upgrade-strategies-demo
npm install
npx nx serve demo-app
```

Open **http://localhost:4200**. The sidebar shows Block 8 topics at the top; all Blocks 2–7 remain accessible.

---

## Opening Talk (3 min)

### The Car Maintenance Analogy

> "You just spent 7 blocks learning how to build a high-performance sports car — the architecture, the engine (signals), the transmission (change detection), the fuel system (state management), the aerodynamics (performance), and the pit stops (migration).
>
> But even the best car needs regular maintenance. Today is about:
> 1. How to MAINTAIN your Angular app over time — upgrades, staying current.
> 2. How to REVIEW your architecture — the capstone exercise.
> 3. What to do NEXT — after this course."

---

## Topic 1: Angular Upgrade Methodology (30 min)

**Navigate to:** `http://localhost:4200/upgrade-methodology`

### Section 1.1: Release Cadence (5 min)

> "Angular releases a new MAJOR version every 6 months. Like clockwork. This is the most predictable release cycle in frontend."

Point to the timeline visual:

> "Three types of releases:
>
> **Major (vX.0.0)** — Every 6 months. Red dot. May contain BREAKING CHANGES. You need to review and test before upgrading.
>
> **Minor (vX.Y.0)** — 1 to 3 per major cycle. Blue dot. NEW FEATURES but no breaking changes. Safe to upgrade.
>
> **Patch (vX.Y.Z)** — Weekly. Green dot. Bug fixes only. Always safe."

Scroll to the version table:

> "Here's the recent history:
>
> **v19** (current): Standalone default, linkedSignal, resource()
> **v18** (LTS): Zoneless preview, Material 3, @let syntax
> **v17** (LTS): @for/@if/@switch, esbuild default, @defer
> **v16** (End of Life): Signals dev preview, standalone APIs
> **v15** (End of Life): Standalone components stable"

> "Notice: v16 and v15 are End of Life. No more security patches. If you're on these versions — upgrade NOW."

### Section 1.2: The ng update Command (10 min)

Scroll to **Section 2** ("The ng update Command").

> "This is the command you'll run every 6 months:"

Show the code example:

```bash
# Step 1: Check what needs updating
ng update

# Step 2: Update Angular core
ng update @angular/cli @angular/core

# Step 3: Update Angular Material (if used)
ng update @angular/material

# For Nx workspaces:
npx nx migrate latest
npx nx migrate --run-migrations
```

Point to the 4-step flow diagram:

> "Step 1: `ng update` ANALYSES your package.json — what version are you on, what's available.
>
> Step 2: It RUNS SCHEMATICS — these are automated code transformations. If an API was renamed from v18 to v19, the schematic renames it in YOUR code automatically.
>
> Step 3: It UPDATES DEPENDENCIES — modifies package.json and runs npm install.
>
> Step 4: It REPORTS — tells you what was migrated and what needs manual attention."

Point to the warning box:

> "**CRITICAL: Always commit before running ng update!** The schematics will modify your source files. If something goes wrong, you need a clean git state to revert."

> "Pro tip: run `ng update --dry-run` first. It shows you what WOULD change without actually changing anything."

### Section 1.3: Breaking Changes (8 min)

Scroll to **Section 3** ("Identifying Breaking Changes").

> "Before upgrading, always check the Angular Update Guide at **update.angular.dev**."

Show the four breaking change categories:

> "**API Removals** — Deprecated APIs get removed 2 major versions later. If something was deprecated in v17, it's removed in v19.
>
> **Behaviour Changes** — Same API name, different default. Example: `standalone: true` became the default in v19. Your code still works, but new components behave differently.
>
> **Dependency Updates** — Angular 19 requires TypeScript 5.5+. If you're on TypeScript 5.3, you need to upgrade TypeScript FIRST.
>
> **Tooling Changes** — esbuild replaced webpack as the default builder. Your build config might need updates."

> "The update guide at update.angular.dev generates a PERSONALISED checklist. Select your current version, your target version, and your complexity level. It tells you exactly what to do."

### Section 1.4: Automation (7 min)

Scroll to **Section 4** ("Automating Upgrades").

> "The best upgrade is one you don't have to think about. Automate it."

Show the four automation cards:

> "**Dependabot / Renovate** — Configure these to auto-create Pull Requests when new Angular versions are published. The PR runs your CI pipeline. If tests pass, review and merge.
>
> **CI Pipeline** — Your PR builds and tests the entire app automatically. If the upgrade breaks something, the PR is blocked.
>
> **Nx migrate** — For Nx workspaces, `npx nx migrate latest` generates a `migrations.json` file. Run `npx nx migrate --run-migrations` to apply them.
>
> **Canary Branch** — For very large apps, maintain a long-lived branch where you test upgrades before merging to main."

Show the Renovate config example:

```json
{
  "extends": ["config:base"],
  "packageRules": [{
    "matchPackagePatterns": ["@angular/*"],
    "groupName": "Angular",
    "schedule": ["after 1pm on Monday"]
  }]
}
```

> "This groups all Angular packages into one PR, scheduled for Monday afternoon. Your team reviews it weekly."

### Section 1.5: Interactive Checklist (3 min)

Scroll to **Section 5** ("Upgrade Checklist").

> "Let's walk through the checklist together."

**Click each item as you read it:**

1. Read release blog post and changelog
2. Check Angular Update Guide
3. Ensure clean git state
4. Run `ng update @angular/cli @angular/core`
5. Review automatic code migrations
6. Update third-party dependencies
7. Run full test suite
8. Test critical user flows manually
9. Review bundle size for regressions
10. Deploy to staging and smoke test

> "10 items. Do them in order. Skip none. The progress bar should hit 100% before you merge to main."

Watch the progress bar fill as you click.

#### Student Checkpoint

> "You want to upgrade from Angular 17 to 19. Should you go 17→18→19 or jump straight to 17→19?"

**Answer:** Either works. `ng update` supports multi-version jumps. But if you're skipping more than one major version, go step-by-step (17→18 then 18→19) — it's safer because each step runs its own schematics.

---

## Topic 2: Staying Current with Angular (15 min)

**Navigate to:** `http://localhost:4200/staying-current`

### Section 2.1: The RFC Process (5 min)

Scroll to **Section 1** ("The Angular RFC Process").

Point to the 4-step flow:

> "RFC stands for Request for Comments. The Angular team uses this for major features.
>
> Step 1: The team publishes an RFC document on GitHub.
> Step 2: The community (that's YOU) provides feedback — comments, concerns, suggestions.
> Step 3: The team incorporates feedback and finalises the design.
> Step 4: Implementation begins — feature lands in a dev preview, then stable."

Show the notable RFCs grid:

> "**Shipped**: Signal-Based Components — the signals you've been using all course. Built-in Control Flow — @for, @if, @switch.
>
> **In Progress**: Signal-Based Forms — replacing Reactive Forms with signals. Zoneless Angular — removing Zone.js completely.
>
> These are features you've already learned about! By following RFCs, you knew they were coming months before release."

> "Pro tip: go to GitHub → angular/angular → Watch → Custom → Discussions. You'll get notified when new RFCs are posted."

### Section 2.2: Roadmap Monitoring (5 min)

Scroll to **Section 2** ("Angular Roadmap Monitoring").

Point to the three columns:

> "**In Progress**: Zoneless stable, signal-based forms, improved SSR/hydration, signal-based queries/inputs. These are being built RIGHT NOW.
>
> **Future**: Full signal-based component model, improved tooling, partial hydration. On the horizon — likely 2025/2026.
>
> **Recently Completed**: Built-in control flow (v17), @defer (v17), esbuild (v17), standalone default (v19). These are what we covered in this course."

> "Bookmark **angular.dev/roadmap** — it's updated every quarter."

### Section 2.3: Community Engagement (3 min)

Scroll to **Section 3** ("Community Engagement").

Quickly point to the six resource cards:

> "**Angular Blog** (blog.angular.dev) — official announcements.
> **Angular YouTube** — ng-conf talks, release overviews.
> **Discord** — community Q&A, real-time help.
> **GitHub Discussions** — RFCs, feature requests.
> **Newsletter** — weekly digest.
> **Conferences** — ng-conf, NG-DE, NG-BE."

### Section 2.4: Practical Tips (2 min)

Scroll to **Section 4** ("Practical Tips").

> "Five rules for your team:
> 1. Upgrade within 1 month of a major release.
> 2. Fix deprecation warnings immediately — deprecated APIs die 2 versions later.
> 3. Run `ng update --dry-run` before the actual update.
> 4. Assign an 'Angular Champion' on your team — one person who monitors releases.
> 5. Maintain 80%+ test coverage — upgrades are safe when tests catch regressions."

#### Student Checkpoint

> "An API was deprecated in Angular 17. In which version will it be removed?"

**Answer:** Angular 19. Deprecated APIs are removed 2 major versions later.

---

## Topic 3: Capstone — Architectural Peer Review (45 min)

**Navigate to:** `http://localhost:4200/capstone-review`

> "This is the most important exercise of the course. You'll present your REAL project architecture and get structured feedback from peers."

### Section 3.1: Exercise Setup (5 min)

Scroll to **Section 1** ("Exercise Structure").

> "Here's how it works:
>
> 1. Form groups of 3–4 people. Ideally, people from different teams.
> 2. Each person gets 15 minutes:
>    - **5 min** — present your architecture using the template
>    - **7 min** — group reviews using the scoring rubric
>    - **3 min** — note your top 3 action items
> 3. Rotate until everyone has presented.
> 4. Total time: ~45 min for 3 presenters."

> "If someone doesn't have a current Angular project, they can review the demo app architecture from this course."

### Section 3.2: Presentation Template (3 min)

Scroll to **Section 2** ("Presentation Template").

> "When presenting, cover these five areas:"

Point to each card:

> "1. **Project Overview** — what does the app do, how many devs, what Angular version.
> 2. **Module Structure** — how are features organised, any shared libraries, lazy loading?
> 3. **State Management** — services vs stores, local vs global, signals usage.
> 4. **Performance & CD** — OnPush adoption, bundle size, known bottlenecks.
> 5. **Pain Points** — biggest challenges, what would you change, where do bugs cluster."

### Section 3.3: Scoring Rubric — Live Demo (5 min)

Scroll to **Section 3** ("Evaluation Rubric").

> "We'll score each presentation on 7 criteria. Let me show you how it works."

**Click the stars** to demonstrate scoring:

> "Module Architecture — click 4 stars.
> State Management — click 3 stars.
> Change Detection — click 5 stars.
>
> Watch the total score and badge update in real-time. This IS a Signal Store pattern! The scores are signals, the total is computed, the badge variant is computed from the total."

> "Scoring guide:
> - **5 = Excellent** — follows all best practices we covered
> - **4 = Good** — mostly there, minor improvements possible
> - **3 = Adequate** — works but could benefit from modernisation
> - **2 = Needs Work** — significant gaps to address
> - **1 = Critical** — major architectural issues"

### Section 3.4: Feedback Framework (2 min)

Scroll to **Section 4** ("Structured Feedback Framework").

> "When giving feedback, use these three categories:
>
> **Strengths (green)** — what they're doing well. 'Good separation of feature modules.' 'Effective use of OnPush.'
>
> **Improvements (orange)** — what could be better. 'Consider lazy loading the admin module.' 'Replace BehaviorSubjects with signals.'
>
> **Questions (blue)** — what needs clarification. 'How are auth tokens refreshed?' 'Is there a caching strategy?'
>
> Be specific. 'Your architecture is good' is useless. 'Your shared library pattern allows independent feature development' is helpful."

### Section 3.5: Course Concepts Map (1 min)

Scroll to **Section 5** ("Review Against Course Concepts").

> "As you review, check which course concepts are (or should be) applied. This grid maps every concept we covered — from B2 through B8 — to your architecture."

### Section 3.6: Run the Exercise (30 min)

> "Alright — form your groups! You have 15 minutes per presenter. GO!"

**During the exercise:**
- Walk between groups, listen, answer questions
- If a group finishes early, ask them to discuss: "What ONE improvement would have the most impact?"
- At the 15-minute mark, announce "Switch presenter!"

**After all presentations:**

> "Raise your hand if you identified at least TWO improvements for your project."

(Most hands should go up.)

> "THAT is the value of peer review. Fresh eyes catch what you've been blind to."

---

## Topic 4: Open Discussion & Questions (20 min)

**Navigate to:** `http://localhost:4200/open-discussion`

### Section 4.1: Discussion Prompts (8 min)

Scroll to **Section 1** ("Discussion Prompts").

> "Pick a topic that's most relevant to your team."

**Click "Signals Adoption":**

> "Let's discuss: Can you mix signals and RxJS? When should new features use signals? When is RxJS still better?"

Facilitate discussion. Let 2-3 students share their perspective. Then add:

> "My recommendation: new features → signals from day one. Existing features → migrate incrementally using the Phase 1-5 roadmap from Block 6. Keep RxJS for complex streams."

**Click "Performance":**

> "What's the biggest performance WIN for the least effort?"

Let students answer. Then:

> "My top 3 quick wins: 1. OnPush on every component. 2. Lazy load all feature routes. 3. Run Lighthouse once and fix the top 3 recommendations."

### Section 4.2: FAQ (5 min)

Scroll to **Section 2** ("Frequently Asked Questions").

Click through 3-4 FAQs that haven't been covered:

**Click "Should we migrate all RxJS to signals right now?":**

> "No. Migrate incrementally. Start with template-bound state. Keep RxJS for complex async streams."

**Click "When will zoneless Angular be stable?":**

> "Experimental in v19. The team aims for stable in v20 or v21. Prepare NOW by using OnPush + signals everywhere."

**Click "What is the best folder structure for a large Angular app?":**

> "Feature-based with shared libraries: `apps/my-app` (thin shell), `libs/shared/ui`, `libs/shared/data-access`, `libs/feature-x`. Enforced with Nx module boundaries."

### Section 4.3: Real-World Scenarios (5 min)

Scroll to **Section 3** ("Real-World Scenarios").

Pick one or two scenarios based on the class's background:

**Scenario B — Greenfield Architecture:**

> "You're starting a brand new enterprise Angular app today. Using everything from this course, how would you set it up?"

Let students brainstorm. Then summarise:

> "My answer: Nx monorepo, shared libs for UI and data-access, standalone components everywhere, OnPush on everything, NgRx Signal Store for complex features, plain signals for simple state, lazy loading for all feature routes, Angular 19, ready for zoneless."

### Section 4.4: Parking Lot (2 min)

Scroll to **Section 4** ("Parking Lot").

> "These are topics that came up during the course but need more time. Capture them for your post-course learning:
>
> **To Research**: SSR/hydration, micro-frontends, Angular Elements.
> **To Try**: Convert a service to Signal Store, add @defer to your heaviest component, run Lighthouse CI.
> **To Discuss with Team**: Signal adoption timeline, upgrade schedule, shared library strategy."

---

## Topic 5: Summary & Resources (10 min)

**Navigate to:** `http://localhost:4200/summary-resources`

### Section 5.1: Course Recap (4 min)

Scroll to **Section 1** ("Course Recap — 8 Blocks").

Point to each block card:

> "Let's speed-run everything we covered:
>
> **Block 1** — Angular CLI foundations. How to scaffold, build, and serve. (2h)
>
> **Block 2** — Nx Monorepo architecture. Shared libraries, smart/dumb components, dependency injection. (2h)
>
> **Block 3** — Angular Signals. `signal()`, `computed()`, `effect()`, `toSignal()`, `toObservable()`. (2h)
>
> **Block 4** — Change Detection. OnPush, signal-driven CD, profiling, common pitfalls. (2h)
>
> **Block 5** — NgRx Signal Store. `signalStore()`, `withEntities()`, `withMethods()`, custom features, `rxMethod`. (2h)
>
> **Block 6** — RxJS → Signals migration. `resource()`, `rxResource()`, signal forms, incremental migration. (1.5h)
>
> **Block 7** — Performance. Bundle analysis, virtual scrolling, `@defer`, zoneless prep, Lighthouse profiling. (2h)
>
> **Block 8** — Upgrade strategies, peer review, and this summary. (2h)
>
> That's 8 blocks, 16 hours, and 30+ topics. You are now DANGEROUS."

### Section 5.2: Key Learning Outcomes (2 min)

Scroll to **Section 2** ("Key Learning Outcomes").

Point to the 6 outcome cards:

> "You can now: Design scalable architecture. Use signals for reactive state. Understand and optimise change detection. Implement Signal Stores. Migrate from RxJS. Profile and improve performance."

### Section 5.3: Reference Materials (2 min)

Scroll to **Section 3** ("Reference Materials").

> "Bookmark these:
> - **angular.dev** — official documentation
> - **update.angular.dev** — interactive upgrade guide
> - **angular.dev/roadmap** — what's coming next
> - **ngrx.io/guide/signals** — Signal Store docs
> - **nx.dev** — Nx monorepo tools
>
> All of these are in the reference panel on screen."

### Section 5.4: Next Steps Timeline (2 min)

Scroll to **Section 4** ("Your Next Steps").

> "Homework. Seriously:
>
> **This Week:**
> - Run `ng update` on your project
> - Add OnPush to 5 components
> - Install Angular DevTools and profile one page
>
> **This Month:**
> - Convert one BehaviorSubject service to signals
> - Implement one feature with NgRx Signal Store
> - Add lazy loading to your largest feature module
>
> **This Quarter:**
> - Evaluate Nx for your team
> - Set up Lighthouse CI
> - Create shared UI/data-access libraries
>
> **Long Term:**
> - Complete RxJS-to-signals migration for template state
> - Prepare for zoneless Angular
> - Maintain a regular upgrade cadence"

### Closing (2 min)

> "Look at the course stats: 8 blocks, 16 hours, 30+ topics, 8 workshops.
>
> You now know modern Angular architecture better than 95% of Angular developers. The key is to actually USE it. Start small — one component, one service, one store. Build momentum.
>
> If you have questions after the course, remember the resources: Angular blog, Discord, GitHub discussions. And you have the demo apps from this course — they're your reference implementations.
>
> Thank you for your attention and your energy. Good luck with your Angular projects!"

---

## Common Student Questions

**Q: We're still on Angular 14. Is it too late to modernize?**
> "No, but start now. Angular 14→19 is a big jump. Go one major version at a time: 14→15→16→17→18→19. Each step has automated schematics. Budget 1-2 weeks per major version jump for a medium-sized app."

**Q: Should we switch to Nx if we already have a working Angular CLI project?**
> "If you have a single app, Nx is optional. If you have (or plan) multiple apps sharing code, Nx is a massive productivity gain. You can add Nx to an existing workspace: `npx nx@latest init`."

**Q: How do we convince management to invest in upgrades and modernisation?**
> "Frame it in business terms: faster development velocity (signals are simpler than RxJS), fewer bugs (OnPush catches mutation issues), better performance (smaller bundles, faster load times), talent retention (developers want to work with modern tools)."

**Q: What about micro-frontends with Angular?**
> "Module Federation is the main approach. It works well but adds complexity. Only use it if you have multiple teams that need to deploy independently. For most projects, a monorepo with shared libraries is simpler and better."

**Q: When should we start using zoneless?**
> "Prepare now (signals + OnPush everywhere). Adopt when stable (v20-21). The preparation work is valuable regardless — signals and OnPush improve performance even with Zone.js."

---

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| `ng update` fails mid-migration | Conflicting package versions | Commit, revert, upgrade one package at a time |
| Schematics don't find all instances | Code in unusual patterns | Search for deprecated API names manually after migration |
| `ERESOLVE` errors during npm install | Conflicting peer dependencies | Use `--legacy-peer-deps` or resolve version conflicts |
| Capstone groups too quiet | Students unsure how to give feedback | Use the structured framework: Strengths → Improvements → Questions |
| "We don't have time for upgrades" | Team deprioritises maintenance | Show the cost of delayed upgrades: accumulated breaking changes, security risk, lost LTS support |

---

## Project Structure

```
angular-upgrade-strategies-demo/
├── apps/demo-app/src/app/
│   ├── app.config.ts
│   ├── app.routes.ts
│   └── features/
│       ├── dashboard/              # Block 8 overview
│       ├── upgrade-methodology/    # Topic 1: ng update, semver, automation
│       ├── staying-current/        # Topic 2: RFCs, roadmap, community
│       ├── capstone-review/        # Topic 3: Peer review exercise
│       ├── open-discussion/        # Topic 4: Q&A, scenarios
│       └── summary-resources/      # Topic 5: Recap, next steps
│       # + All Blocks 2-7 features accessible
├── libs/shared/
│   ├── ui/                         # UiButton, UiBadge, UiCard
│   └── data-access/                # ProductService, Models
└── INSTRUCTOR-GUIDE.md
```

---

## Nx Commands

```bash
npx nx serve demo-app          # Serve the demo app
npx nx build demo-app          # Build for production
npx nx lint demo-app           # Run linting
npx nx graph                   # Dependency graph
```
