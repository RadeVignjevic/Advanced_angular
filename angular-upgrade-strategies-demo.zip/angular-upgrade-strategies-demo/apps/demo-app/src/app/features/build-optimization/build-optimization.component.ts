import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Build and Bundle Optimisation — Topic 1 (30 min)
 *
 * Covers: tree-shaking, lazy loading, defer blocks, bundle analysis
 */
@Component({
  selector: 'app-build-optimization',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="build-page">
      <h2>Build &amp; Bundle Optimisation
        <ui-badge variant="info">Block 7 — Topic 1</ui-badge>
      </h2>

      <p class="note">
        Large-scale Angular apps need aggressive bundle optimisation. This topic covers
        <strong>tree-shaking</strong>, <strong>lazy loading</strong>, <strong>&#64;defer blocks</strong>,
        and how to analyse what ends up in your bundles.
      </p>

      <!-- Tree Shaking -->
      <ui-card title="1. Tree-Shaking: Dead Code Elimination" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeTreeShaking }}</pre>

          <div class="key-points">
            <div class="point">
              <ui-badge variant="success">Do</ui-badge>
              <span>Use <code>providedIn: 'root'</code> — services are tree-shakeable if unused</span>
            </div>
            <div class="point">
              <ui-badge variant="success">Do</ui-badge>
              <span>Use standalone components — no NgModule side-effect imports</span>
            </div>
            <div class="point">
              <ui-badge variant="success">Do</ui-badge>
              <span>Prefer named imports: <code>import {{ '{' }} map {{ '}' }} from 'rxjs'</code></span>
            </div>
            <div class="point">
              <ui-badge variant="danger">Don't</ui-badge>
              <span>Import entire libraries: <code>import * as _ from 'lodash'</code></span>
            </div>
            <div class="point">
              <ui-badge variant="danger">Don't</ui-badge>
              <span>Register services in NgModule <code>providers</code> array (not tree-shakeable)</span>
            </div>
          </div>

          <div class="explanation">
            <p>Tree-shaking removes unused code during production builds. The Angular compiler
            + esbuild/webpack work together to eliminate dead code. Standalone components and
            <code>providedIn: 'root'</code> services are <strong>tree-shakeable by default</strong>.</p>
          </div>
        </div>
      </ui-card>

      <!-- Lazy Loading -->
      <ui-card title="2. Lazy Loading: Route-Level Code Splitting" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeLazyRoutes }}</pre>

          <div class="bundle-visual">
            <div class="bundle main-bundle">
              <span class="bundle-label">main.js</span>
              <span class="bundle-desc">Core framework + shared UI</span>
              <span class="bundle-size">~280 KB</span>
            </div>
            <div class="lazy-bundles">
              @for (chunk of lazyChunks; track chunk.name) {
                <div class="bundle lazy-bundle">
                  <span class="bundle-label">{{ chunk.name }}</span>
                  <span class="bundle-size">{{ chunk.size }}</span>
                </div>
              }
            </div>
          </div>

          <div class="explanation">
            <p>Every <code>loadChildren</code> route creates a <strong>separate JS chunk</strong>
            that is only downloaded when the user navigates to that route. This keeps the initial
            bundle small and improves First Contentful Paint (FCP).</p>
            <p>This demo app already uses lazy loading — each "Block" topic loads on demand.</p>
          </div>
        </div>
      </ui-card>

      <!-- Defer Blocks -->
      <ui-card title="3. &#64;defer Blocks: Template-Level Lazy Loading" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeDeferBasic }}</pre>

          <h4>Live Demo: &#64;defer with trigger</h4>
          <div class="defer-demo-area">
            <p>The heavy component below only loads when you click the button or it enters the viewport:</p>

            <ui-button variant="primary" size="sm" (clicked)="showDeferred.set(true)">
              Load Deferred Content
            </ui-button>

            @if (showDeferred()) {
              <div class="deferred-content">
                <div class="heavy-widget">
                  <h4>Deferred Widget Loaded!</h4>
                  <p>This content was lazy-loaded at template level using &#64;defer.
                  In a real app, this could be a chart library, map, or complex component
                  that you don't want in the initial bundle.</p>
                  <div class="widget-stats">
                    @for (i of deferredItems; track i) {
                      <div class="stat-bar" [style.width.%]="i * 10">{{ i * 10 }}%</div>
                    }
                  </div>
                </div>
              </div>
            }
          </div>

          <pre class="code-block">{{ codeDeferTriggers }}</pre>

          <div class="explanation">
            <p><code>&#64;defer</code> blocks lazy-load <strong>template sections</strong> and their
            dependencies. Unlike route-based lazy loading, this works within a single component.
            Triggers: <code>on viewport</code>, <code>on interaction</code>,
            <code>on idle</code>, <code>on timer(ms)</code>, <code>when condition</code>.</p>
          </div>
        </div>
      </ui-card>

      <!-- Preloading Strategies -->
      <ui-card title="4. Preloading Strategies" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codePreloading }}</pre>

          <table class="strategy-table">
            <thead>
              <tr>
                <th>Strategy</th>
                <th>Behaviour</th>
                <th>Use Case</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><code>NoPreloading</code></td>
                <td>Load only on navigation</td>
                <td>Large apps, metered connections</td>
              </tr>
              <tr>
                <td><code>PreloadAllModules</code></td>
                <td>Preload all lazy routes after initial load</td>
                <td>Small-medium apps, fast connections</td>
              </tr>
              <tr>
                <td><strong>Custom</strong></td>
                <td>Selective preloading based on route data</td>
                <td>Production apps with mixed priorities</td>
              </tr>
            </tbody>
          </table>

          <div class="explanation">
            <p>Preloading strategies let you balance initial load time with navigation speed.
            A custom strategy can preload high-priority routes immediately and defer
            rarely-visited routes.</p>
          </div>
        </div>
      </ui-card>

      <!-- Bundle Analysis -->
      <ui-card title="5. Bundle Analysis Tools" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeBundleAnalysis }}</pre>

          <div class="tools-grid">
            <div class="tool-card">
              <h4>source-map-explorer</h4>
              <p>Visualise what npm packages and files contribute to your bundle size.
              Best for production builds.</p>
            </div>
            <div class="tool-card">
              <h4>webpack-bundle-analyzer</h4>
              <p>Interactive treemap showing module sizes. Works with Angular CLI
              custom webpack config.</p>
            </div>
            <div class="tool-card">
              <h4>nx build --stats-json</h4>
              <p>Generate <code>stats.json</code> file for detailed analysis.
              Feed into bundle analyzer tools.</p>
            </div>
            <div class="tool-card">
              <h4>Angular CLI budget</h4>
              <p>Set maximum bundle size budgets in <code>angular.json</code>.
              Build fails if exceeded.</p>
            </div>
          </div>

          <pre class="code-block">{{ codeBudgets }}</pre>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .build-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .key-points { display: flex; flex-direction: column; gap: 0.4rem; margin: 0.75rem 0; }
    .point { display: flex; align-items: center; gap: 0.75rem; font-size: 0.85rem; }
    .point code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.8rem; }

    .bundle-visual { margin: 0.75rem 0; }
    .bundle { border-radius: 8px; padding: 0.5rem 0.75rem; margin: 0.25rem 0; display: flex; align-items: center; gap: 0.75rem; font-size: 0.82rem; }
    .main-bundle { background: #1565c0; color: white; }
    .lazy-bundles { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 0.25rem; margin-top: 0.5rem; }
    .lazy-bundle { background: #e3f2fd; color: #1565c0; border: 1px solid #bbdefb; font-size: 0.75rem; }
    .bundle-label { font-weight: 600; }
    .bundle-size { margin-left: auto; font-family: monospace; }
    .bundle-desc { opacity: 0.9; }

    .defer-demo-area { background: #f8f9fa; border: 2px dashed #e0e0e0; border-radius: 12px; padding: 1rem; margin: 0.75rem 0; }
    .deferred-content { margin-top: 0.75rem; animation: fadeIn 0.3s ease-in; }
    .heavy-widget { background: white; border: 2px solid #c8e6c9; border-radius: 12px; padding: 1rem; }
    .heavy-widget h4 { margin: 0 0 0.5rem; color: #2e7d32; }
    .heavy-widget p { font-size: 0.85rem; color: #555; }
    .widget-stats { display: flex; flex-direction: column; gap: 0.25rem; margin-top: 0.5rem; }
    .stat-bar { background: linear-gradient(90deg, #42a5f5, #1565c0); color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 600; transition: width 0.5s; }

    .strategy-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; margin: 0.75rem 0; }
    .strategy-table th { background: #f5f5f5; padding: 0.5rem; text-align: left; border-bottom: 2px solid #e0e0e0; }
    .strategy-table td { padding: 0.5rem; border-bottom: 1px solid #eee; }
    .strategy-table code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.8rem; }

    .tools-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin: 0.75rem 0; }
    .tool-card { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 0.75rem; }
    .tool-card h4 { margin: 0 0 0.25rem; font-size: 0.88rem; color: #1565c0; }
    .tool-card p { margin: 0; font-size: 0.82rem; color: #666; }
    .tool-card code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.78rem; }

    @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
  `]
})
export class BuildOptimizationComponent {
  showDeferred = signal(false);
  deferredItems = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  lazyChunks = [
    { name: 'build-optimization', size: '~15 KB' },
    { name: 'runtime-perf', size: '~17 KB' },
    { name: 'zoneless', size: '~12 KB' },
    { name: 'perf-workshop', size: '~14 KB' },
    { name: 'signal-store', size: '~18 KB' },
    { name: 'migration', size: '~15 KB' },
  ];

  codeTreeShaking = `// Tree-shakeable service (Angular default)
@Injectable({ providedIn: 'root' })  // <-- removed if never injected
export class AnalyticsService { ... }

// Tree-shakeable standalone component
@Component({
  standalone: true,  // default in Angular 19
  imports: [CommonModule],  // only imports what template uses
})
export class MyComponent { }

// NOT tree-shakeable (avoid):
@NgModule({
  providers: [AnalyticsService],  // always included in bundle
})`;

  codeLazyRoutes = `// Route-level code splitting via lazy loading
export const appRoutes: Route[] = [
  { path: 'dashboard', component: DashboardComponent },  // eager

  // Each loadChildren creates a separate JS chunk
  { path: 'products',
    loadChildren: () => import('./features/products/products.routes')
      .then(m => m.PRODUCT_ROUTES)
  },
  { path: 'analytics',
    loadChildren: () => import('./features/analytics/analytics.routes')
      .then(m => m.ANALYTICS_ROUTES)
  },
];

// Result: main.js (core) + products.chunk.js + analytics.chunk.js
// Only main.js is downloaded on initial load!`;

  codeDeferBasic = `// @defer — template-level lazy loading (Angular 17+)
@Component({
  template: \`
    <!-- Load heavy chart component only when visible -->
    @defer (on viewport) {
      <app-heavy-chart [data]="chartData()" />
    } @placeholder {
      <div class="placeholder">Chart loading area</div>
    } @loading (minimum 200ms) {
      <div class="spinner">Loading chart...</div>
    } @error {
      <div class="error">Failed to load chart</div>
    }
  \`
})`;

  codeDeferTriggers = `// @defer trigger options:
@defer (on viewport)       // when element enters viewport
@defer (on interaction)    // on click/focus/input
@defer (on idle)           // when browser is idle
@defer (on timer(2000ms))  // after 2 seconds
@defer (on hover)          // on mouse hover
@defer (when isReady())    // when a signal/expression is true
@defer (prefetch on idle)  // prefetch JS on idle, render on trigger`;

  codePreloading = `// Configure preloading in app config
import { PreloadAllModules } from '@angular/router';

export const appConfig = {
  providers: [
    provideRouter(appRoutes,
      withPreloading(PreloadAllModules)  // preload all lazy routes
    ),
  ]
};

// Custom preloading strategy:
@Injectable({ providedIn: 'root' })
export class SelectivePreload implements PreloadingStrategy {
  preload(route: Route, load: () => Observable<any>) {
    return route.data?.['preload'] ? load() : of(null);
  }
}

// Route config:
{ path: 'dashboard', data: { preload: true }, loadChildren: ... }`;

  codeBundleAnalysis = `# Analyse your bundle
npx source-map-explorer dist/apps/demo-app/browser/*.js

# Generate stats for webpack-bundle-analyzer
npx nx build demo-app --stats-json
npx webpack-bundle-analyzer dist/apps/demo-app/stats.json

# In CI: check bundle size automatically
npx nx build demo-app --configuration=production`;

  codeBudgets = `// angular.json (or project.json) — bundle budgets
"budgets": [
  {
    "type": "initial",
    "maximumWarning": "500kb",     // warn if initial > 500 KB
    "maximumError": "1mb"          // fail if initial > 1 MB
  },
  {
    "type": "anyComponentStyle",
    "maximumWarning": "4kb",
    "maximumError": "8kb"
  }
]`;
}
