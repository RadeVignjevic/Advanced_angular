import { Route } from '@angular/router';
import { BuildOptimizationComponent } from './build-optimization.component';

export const BUILD_OPTIMIZATION_ROUTES: Route[] = [
  { path: '', component: BuildOptimizationComponent }
];
