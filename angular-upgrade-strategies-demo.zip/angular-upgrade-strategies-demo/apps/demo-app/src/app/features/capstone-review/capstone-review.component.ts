import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Capstone Exercise: Architectural Peer Review — Topic 3 (45 min)
 *
 * Covers: structured peer review framework, evaluation criteria,
 *         feedback templates, group exercise
 */
@Component({
  selector: 'app-capstone-review',
  imports: [UiCardComponent, UiBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="capstone-page">
      <h2>Capstone Exercise: Architectural Peer Review
        <ui-badge variant="info">Block 8 — Topic 3</ui-badge>
        <ui-badge variant="neutral">45 min</ui-badge>
      </h2>

      <p class="note">
        Participants present their current project architecture for <strong>structured group
        evaluation and feedback</strong>. This exercise consolidates everything learned across
        Blocks 1–7.
      </p>

      <!-- Exercise Structure -->
      <ui-card title="1. Exercise Structure" [elevated]="true">
        <div class="demo-section">
          <div class="structure-timeline">
            <div class="struct-item">
              <span class="struct-time">5 min</span>
              <div class="struct-content">
                <h4>Setup</h4>
                <p>Form groups of 3–4. Each person picks one project/module to present.</p>
              </div>
            </div>
            <div class="struct-item">
              <span class="struct-time">5 min</span>
              <div class="struct-content">
                <h4>Presentation</h4>
                <p>Each presenter describes their architecture using the template below.</p>
              </div>
            </div>
            <div class="struct-item">
              <span class="struct-time">7 min</span>
              <div class="struct-content">
                <h4>Group Review</h4>
                <p>Group evaluates using the scoring rubric. Structured feedback, not free-form.</p>
              </div>
            </div>
            <div class="struct-item">
              <span class="struct-time">3 min</span>
              <div class="struct-content">
                <h4>Action Items</h4>
                <p>Presenter notes top 3 improvements. Group moves to next presenter.</p>
              </div>
            </div>
          </div>
          <div class="struct-note">
            <strong>Total per person:</strong> ~15 min &times; 3 presenters = 45 min
          </div>
        </div>
      </ui-card>

      <!-- Presentation Template -->
      <ui-card title="2. Presentation Template" [elevated]="true">
        <div class="demo-section">
          <p class="template-intro">Use this structure when presenting your architecture:</p>
          <div class="template-sections">
            <div class="template-card">
              <span class="template-num">1</span>
              <h4>Project Overview</h4>
              <ul>
                <li>What does the application do?</li>
                <li>How many developers work on it?</li>
                <li>Angular version and key dependencies</li>
                <li>Deployment target (web, mobile, hybrid)</li>
              </ul>
            </div>
            <div class="template-card">
              <span class="template-num">2</span>
              <h4>Module Structure</h4>
              <ul>
                <li>How are features organised? (modules, standalone, libs)</li>
                <li>Is there a shared/core library?</li>
                <li>How is routing structured?</li>
                <li>Is there lazy loading?</li>
              </ul>
            </div>
            <div class="template-card">
              <span class="template-num">3</span>
              <h4>State Management</h4>
              <ul>
                <li>What pattern is used? (services, NgRx, Signal Store)</li>
                <li>Where does state live? (local vs global)</li>
                <li>How is server state handled?</li>
                <li>Are signals used? Where?</li>
              </ul>
            </div>
            <div class="template-card">
              <span class="template-num">4</span>
              <h4>Performance &amp; CD</h4>
              <ul>
                <li>Change detection strategy (Default vs OnPush)</li>
                <li>Bundle size and lazy loading coverage</li>
                <li>Any performance bottlenecks known?</li>
                <li>Zoneless readiness?</li>
              </ul>
            </div>
            <div class="template-card">
              <span class="template-num">5</span>
              <h4>Pain Points</h4>
              <ul>
                <li>What is the biggest architectural challenge?</li>
                <li>What would you change if starting fresh?</li>
                <li>Where do bugs cluster?</li>
                <li>What slows development velocity?</li>
              </ul>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Scoring Rubric -->
      <ui-card title="3. Evaluation Rubric" [elevated]="true">
        <div class="demo-section">
          <h4>Interactive Scoring Tool</h4>
          <p class="rubric-intro">Rate each category 1–5. Click to set the score.</p>

          <div class="rubric">
            @for (cat of categories; track cat.id) {
              <div class="rubric-row">
                <div class="rubric-label">
                  <h5>{{ cat.name }}</h5>
                  <p>{{ cat.description }}</p>
                </div>
                <div class="rubric-stars">
                  @for (star of [1, 2, 3, 4, 5]; track star) {
                    <span
                      class="star"
                      [class.active]="star <= cat.score()"
                      (click)="setScore(cat.id, star)">
                      &#x2605;
                    </span>
                  }
                  <span class="score-label">{{ cat.score() }}/5</span>
                </div>
              </div>
            }
          </div>

          <div class="total-score">
            <strong>Total Score: {{ totalScore() }} / {{ categories.length * 5 }}</strong>
            <ui-badge [variant]="scoreVariant()">{{ scoreLabel() }}</ui-badge>
          </div>
        </div>
      </ui-card>

      <!-- Feedback Framework -->
      <ui-card title="4. Structured Feedback Framework" [elevated]="true">
        <div class="demo-section">
          <div class="feedback-framework">
            <div class="feedback-col positive">
              <h4>&#x2705; Strengths</h4>
              <p>What is this architecture doing well?</p>
              <div class="feedback-examples">
                <span>"Good separation of feature modules"</span>
                <span>"Effective use of OnPush throughout"</span>
                <span>"Signal Store patterns are clean"</span>
              </div>
            </div>
            <div class="feedback-col improvement">
              <h4>&#x1F527; Improvements</h4>
              <p>What could be better?</p>
              <div class="feedback-examples">
                <span>"Consider lazy loading the admin module"</span>
                <span>"Move shared logic to a library"</span>
                <span>"Replace BehaviorSubjects with signals"</span>
              </div>
            </div>
            <div class="feedback-col question">
              <h4>&#x2753; Questions</h4>
              <p>What needs clarification?</p>
              <div class="feedback-examples">
                <span>"How are auth tokens refreshed?"</span>
                <span>"Is there a caching strategy?"</span>
                <span>"How is error handling centralised?"</span>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Course Concepts Map -->
      <ui-card title="5. Review Against Course Concepts" [elevated]="true">
        <div class="demo-section">
          <p class="map-intro">Check which course concepts apply to the presented architecture:</p>
          <div class="concepts-grid">
            @for (concept of courseConcepts; track concept) {
              <div class="concept-item">
                <span class="concept-block">{{ concept.block }}</span>
                <span class="concept-name">{{ concept.name }}</span>
              </div>
            }
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .capstone-page { padding: 0.5rem; }
    .note { background: #f3e5f5; border: 1px solid #ce93d8; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .demo-section { padding: 0.5rem 0; }

    /* Structure timeline */
    .structure-timeline { display: flex; flex-direction: column; gap: 0.5rem; margin: 0.75rem 0; }
    .struct-item { display: flex; gap: 0.75rem; align-items: flex-start; }
    .struct-time { background: #1565c0; color: white; padding: 0.3rem 0.5rem; border-radius: 6px; font-weight: 700; font-size: 0.78rem; white-space: nowrap; min-width: 50px; text-align: center; }
    .struct-content h4 { margin: 0; font-size: 0.85rem; }
    .struct-content p { margin: 0.1rem 0 0; font-size: 0.78rem; color: #666; }
    .struct-note { background: #e3f2fd; border-radius: 6px; padding: 0.5rem; font-size: 0.82rem; margin-top: 0.5rem; }

    /* Template */
    .template-intro { font-size: 0.85rem; color: #555; margin: 0 0 0.5rem; }
    .template-sections { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 0.5rem; }
    .template-card { background: #f8f9fa; border: 2px solid #e9ecef; border-radius: 8px; padding: 0.6rem; }
    .template-num { background: #1565c0; color: white; width: 24px; height: 24px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.78rem; }
    .template-card h4 { margin: 0.25rem 0; font-size: 0.82rem; }
    .template-card ul { padding-left: 1rem; margin: 0; font-size: 0.78rem; }
    .template-card li { margin: 0.15rem 0; color: #555; }

    /* Rubric */
    .rubric-intro { font-size: 0.85rem; color: #555; margin: 0 0 0.5rem; }
    .rubric { display: flex; flex-direction: column; gap: 0.35rem; margin: 0.5rem 0; }
    .rubric-row { display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; background: #f8f9fa; border-radius: 8px; }
    .rubric-label h5 { margin: 0; font-size: 0.85rem; }
    .rubric-label p { margin: 0; font-size: 0.72rem; color: #999; }
    .rubric-stars { display: flex; align-items: center; gap: 0.15rem; }
    .star { font-size: 1.3rem; color: #e0e0e0; cursor: pointer; transition: color 0.15s; }
    .star.active { color: #ffc107; }
    .star:hover { color: #ffb300; }
    .score-label { font-size: 0.78rem; color: #666; margin-left: 0.5rem; min-width: 30px; }
    .total-score { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem; background: #e3f2fd; border-radius: 8px; margin-top: 0.5rem; font-size: 0.9rem; }

    /* Feedback */
    .feedback-framework { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; }
    .feedback-col { border-radius: 8px; padding: 0.6rem; }
    .feedback-col h4 { margin: 0 0 0.25rem; font-size: 0.85rem; }
    .feedback-col p { font-size: 0.78rem; color: #666; margin: 0 0 0.5rem; }
    .positive { background: #e8f5e9; border: 1px solid #c8e6c9; }
    .improvement { background: #fff3e0; border: 1px solid #ffe0b2; }
    .question { background: #e3f2fd; border: 1px solid #bbdefb; }
    .feedback-examples { display: flex; flex-direction: column; gap: 0.25rem; }
    .feedback-examples span { font-size: 0.75rem; color: #555; font-style: italic; padding: 0.2rem 0.4rem; background: rgba(255,255,255,0.6); border-radius: 4px; }

    /* Concepts grid */
    .map-intro { font-size: 0.85rem; color: #555; margin: 0 0 0.5rem; }
    .concepts-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 0.35rem; }
    .concept-item { display: flex; align-items: center; gap: 0.5rem; padding: 0.35rem 0.5rem; background: #f8f9fa; border-radius: 6px; font-size: 0.82rem; }
    .concept-block { background: #1565c0; color: white; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.7rem; font-weight: 600; white-space: nowrap; }
  `]
})
export class CapstoneReviewComponent {
  // ═══════════ Scoring rubric ═══════════
  categories = [
    { id: 1, name: 'Module Architecture', description: 'Feature organisation, shared libs, standalone usage', score: signal(0) },
    { id: 2, name: 'State Management', description: 'Signal usage, store patterns, data flow clarity', score: signal(0) },
    { id: 3, name: 'Change Detection', description: 'OnPush adoption, signal-driven updates', score: signal(0) },
    { id: 4, name: 'Performance', description: 'Lazy loading, bundle size, virtual scrolling', score: signal(0) },
    { id: 5, name: 'Code Organisation', description: 'Naming, folder structure, barrel exports', score: signal(0) },
    { id: 6, name: 'Testability', description: 'Dependency injection, separation of concerns', score: signal(0) },
    { id: 7, name: 'Upgrade Readiness', description: 'Deprecation handling, Angular version currency', score: signal(0) },
  ];

  totalScore = computed(() => this.categories.reduce((sum, c) => sum + c.score(), 0));

  scoreVariant = computed((): 'success' | 'warning' | 'danger' | 'info' => {
    const pct = this.totalScore() / (this.categories.length * 5);
    if (pct >= 0.8) return 'success';
    if (pct >= 0.6) return 'info';
    if (pct >= 0.4) return 'warning';
    return 'danger';
  });

  scoreLabel = computed(() => {
    const pct = this.totalScore() / (this.categories.length * 5);
    if (pct >= 0.8) return 'Excellent';
    if (pct >= 0.6) return 'Good';
    if (pct >= 0.4) return 'Needs Work';
    return 'Significant Gaps';
  });

  setScore(categoryId: number, score: number): void {
    const cat = this.categories.find(c => c.id === categoryId);
    if (cat) cat.score.set(score);
  }

  // ═══════════ Course concepts ═══════════
  courseConcepts = [
    { block: 'B2', name: 'Nx monorepo with shared libraries' },
    { block: 'B2', name: 'Smart/dumb component pattern' },
    { block: 'B2', name: 'Dependency injection & tokens' },
    { block: 'B3', name: 'Signal fundamentals (signal, computed, effect)' },
    { block: 'B3', name: 'toSignal / toObservable interop' },
    { block: 'B4', name: 'OnPush change detection strategy' },
    { block: 'B4', name: 'Signal-driven change detection' },
    { block: 'B5', name: 'NgRx Signal Store for state' },
    { block: 'B5', name: 'Custom store features (withMethods, withComputed)' },
    { block: 'B6', name: 'RxJS to signals migration patterns' },
    { block: 'B6', name: 'resource() / rxResource() for data fetching' },
    { block: 'B7', name: 'Lazy loading & @defer blocks' },
    { block: 'B7', name: 'Virtual scrolling for large lists' },
    { block: 'B7', name: 'Zoneless readiness' },
    { block: 'B8', name: 'Upgrade strategy & version currency' },
  ];
}
