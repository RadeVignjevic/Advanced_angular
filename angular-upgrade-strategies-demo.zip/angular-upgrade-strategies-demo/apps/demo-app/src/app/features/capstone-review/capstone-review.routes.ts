import { Route } from '@angular/router';
import { CapstoneReviewComponent } from './capstone-review.component';

export const CAPSTONE_REVIEW_ROUTES: Route[] = [
  { path: '', component: CapstoneReviewComponent }
];
