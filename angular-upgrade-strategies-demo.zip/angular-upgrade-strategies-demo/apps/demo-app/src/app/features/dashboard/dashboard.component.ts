import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProductService, UserService, APP_CONFIG } from '@angular-monorepo-demo/data-access';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';
import { Product, User } from '@angular-monorepo-demo/data-access';

@Component({
  selector: 'app-dashboard',
  imports: [RouterLink, UiCardComponent, UiBadgeComponent],
  template: `
    <div class="dashboard">
      <h2>Block 8: Upgrade Strategies &amp; Course Conclusion <ui-badge variant="info">2 hours</ui-badge></h2>
      <p class="note">
        Blocks 1–7 are complete. This final block addresses Angular version <strong>upgrade
        strategies</strong>, staying current with the ecosystem, a <strong>capstone peer review</strong>
        exercise, and consolidates all course learning outcomes.
      </p>

      <h3>Topics</h3>
      <div class="topics-grid">
        <a routerLink="/upgrade-methodology" class="topic-card">
          <span class="topic-icon">🔄</span>
          <h4>Upgrade Methodology</h4>
          <p>ng update, breaking changes, automation</p>
          <ui-badge variant="info">30 min</ui-badge>
        </a>
        <a routerLink="/staying-current" class="topic-card">
          <span class="topic-icon">📡</span>
          <h4>Staying Current</h4>
          <p>RFC process, roadmap, community engagement</p>
          <ui-badge variant="info">15 min</ui-badge>
        </a>
        <a routerLink="/capstone-review" class="topic-card">
          <span class="topic-icon">🏆</span>
          <h4>Capstone Peer Review</h4>
          <p>Architecture presentation and evaluation</p>
          <ui-badge variant="warning">45 min</ui-badge>
        </a>
        <a routerLink="/open-discussion" class="topic-card">
          <span class="topic-icon">💬</span>
          <h4>Open Discussion</h4>
          <p>Q&amp;A, real-world scenarios, parking lot</p>
          <ui-badge variant="neutral">20 min</ui-badge>
        </a>
        <a routerLink="/summary-resources" class="topic-card">
          <span class="topic-icon">📚</span>
          <h4>Summary &amp; Resources</h4>
          <p>Course recap, reference materials, next steps</p>
          <ui-badge variant="success">10 min</ui-badge>
        </a>
      </div>

      <h3>Previous Blocks (Done)</h3>
      <div class="stats-grid">
        <ui-card title="Products" [elevated]="true">
          <div class="stat-number">{{ totalProducts() }}</div>
          <a routerLink="/products" card-footer>View All</a>
        </ui-card>
        <ui-card title="In Stock" [elevated]="true">
          <div class="stat-number">{{ inStockCount() }}</div>
        </ui-card>
        <ui-card title="Users" [elevated]="true">
          <div class="stat-number">{{ totalUsers() }}</div>
          <a routerLink="/users" card-footer>View All</a>
        </ui-card>
        <ui-card title="Config" [elevated]="true">
          <div class="stat-number">{{ appConfig.maxItemsPerPage }}</div>
          <span card-footer>Items/Page</span>
        </ui-card>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    h3 { margin: 1.5rem 0 0.75rem; color: #2c3e50; }
    .topics-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
    .topic-card {
      display: block; padding: 1.25rem; background: #f8f9fa; border: 2px solid #e9ecef;
      border-radius: 12px; text-decoration: none; color: inherit; transition: all 0.2s;
    }
    .topic-card:hover { border-color: #42a5f5; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .topic-icon { font-size: 2rem; }
    .topic-card h4 { margin: 0.5rem 0 0.25rem; color: #1565c0; }
    .topic-card p { margin: 0.25rem 0 0.5rem; font-size: 0.85rem; color: #666; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin: 1rem 0; }
    .stat-number { font-size: 2.5rem; font-weight: 700; color: #2c3e50; text-align: center; }
  `]
})
export class DashboardComponent implements OnInit {
  private productService = inject(ProductService);
  private userService = inject(UserService);
  protected appConfig = inject(APP_CONFIG);

  products = signal<Product[]>([]);
  users = signal<User[]>([]);
  totalProducts = computed(() => this.products().length);
  inStockCount = computed(() => this.products().filter(p => p.inStock).length);
  totalUsers = computed(() => this.users().length);

  ngOnInit(): void {
    this.productService.getProducts().subscribe(p => this.products.set(p));
    this.userService.getUsers().subscribe(u => this.users.set(u));
  }
}
