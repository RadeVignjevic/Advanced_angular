import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Open Discussion and Questions — Topic 4 (20 min)
 *
 * Covers: facilitated Q&A, common questions, discussion prompts,
 *         real-world scenario discussions
 */
@Component({
  selector: 'app-open-discussion',
  imports: [UiCardComponent, UiBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="discussion-page">
      <h2>Open Discussion and Questions
        <ui-badge variant="info">Block 8 — Topic 4</ui-badge>
        <ui-badge variant="neutral">20 min</ui-badge>
      </h2>

      <p class="note">
        Facilitated session to address outstanding questions, discuss real-world scenarios,
        and share experiences from the course.
      </p>

      <!-- Discussion Prompts -->
      <ui-card title="1. Discussion Prompts" [elevated]="true">
        <div class="demo-section">
          <p class="prompt-intro">Select a topic to discuss as a group:</p>
          <div class="prompt-grid">
            @for (prompt of prompts; track prompt.id) {
              <div class="prompt-card"
                [class.selected]="selectedPrompt() === prompt.id"
                (click)="selectPrompt(prompt.id)">
                <span class="prompt-icon">{{ prompt.icon }}</span>
                <h4>{{ prompt.title }}</h4>
                <p>{{ prompt.description }}</p>
              </div>
            }
          </div>

          @if (currentPromptDetail(); as detail) {
            <div class="prompt-detail">
              <h4>{{ detail.title }}</h4>
              <div class="discussion-points">
                @for (point of detail.points; track point) {
                  <div class="point">
                    <span class="bullet">&#x25CF;</span>
                    <span>{{ point }}</span>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </ui-card>

      <!-- FAQ -->
      <ui-card title="2. Frequently Asked Questions" [elevated]="true">
        <div class="demo-section">
          <div class="faq-list">
            @for (faq of faqs; track faq.q) {
              <div class="faq-item">
                <div class="faq-question" (click)="toggleFaq(faq.q)">
                  <span class="faq-toggle">{{ expandedFaq() === faq.q ? '&#x25BC;' : '&#x25B6;' }}</span>
                  <strong>{{ faq.q }}</strong>
                </div>
                @if (expandedFaq() === faq.q) {
                  <div class="faq-answer">
                    <p>{{ faq.a }}</p>
                  </div>
                }
              </div>
            }
          </div>
        </div>
      </ui-card>

      <!-- Real-World Scenarios -->
      <ui-card title="3. Real-World Scenarios" [elevated]="true">
        <div class="demo-section">
          <div class="scenarios">
            <div class="scenario-card">
              <ui-badge variant="warning">Scenario A</ui-badge>
              <h4>Legacy Migration</h4>
              <p>Your team has a large AngularJS app (v1.x) alongside an Angular 14 app.
              How would you plan a migration path to Angular 19 with signals?</p>
              <div class="scenario-consider">
                <strong>Consider:</strong> Team capacity, feature parity, incremental vs big-bang, testing strategy
              </div>
            </div>
            <div class="scenario-card">
              <ui-badge variant="warning">Scenario B</ui-badge>
              <h4>Greenfield Architecture</h4>
              <p>You are starting a new enterprise Angular application today.
              How would you structure it using what you learned in this course?</p>
              <div class="scenario-consider">
                <strong>Consider:</strong> Nx monorepo, signal stores, OnPush everywhere, lazy loading strategy
              </div>
            </div>
            <div class="scenario-card">
              <ui-badge variant="warning">Scenario C</ui-badge>
              <h4>Performance Crisis</h4>
              <p>Your production app has a Lighthouse score of 35. Users report 3+ second
              load times. Where do you start?</p>
              <div class="scenario-consider">
                <strong>Consider:</strong> Bundle analysis, lazy loading audit, CD profiling, network optimisation
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Parking Lot -->
      <ui-card title="4. Parking Lot" [elevated]="true">
        <div class="demo-section">
          <p class="parking-intro">
            Topics that came up during the course but need more time. Capture them here
            for follow-up after the session.
          </p>
          <div class="parking-categories">
            <div class="parking-col">
              <h4>&#x1F4CB; To Research</h4>
              <div class="parking-items">
                <div class="parking-item">Angular SSR / hydration deep-dive</div>
                <div class="parking-item">Micro-frontends with Module Federation</div>
                <div class="parking-item">Angular Elements (web components)</div>
              </div>
            </div>
            <div class="parking-col">
              <h4>&#x1F6E0; To Try</h4>
              <div class="parking-items">
                <div class="parking-item">Convert a service to Signal Store</div>
                <div class="parking-item">Add &#64;defer to heaviest components</div>
                <div class="parking-item">Run Lighthouse CI in pipeline</div>
              </div>
            </div>
            <div class="parking-col">
              <h4>&#x1F4AC; To Discuss with Team</h4>
              <div class="parking-items">
                <div class="parking-item">Signal adoption timeline</div>
                <div class="parking-item">Angular upgrade schedule</div>
                <div class="parking-item">Shared library strategy</div>
              </div>
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .discussion-page { padding: 0.5rem; }
    .note { background: #fff3e0; border: 1px solid #ffe0b2; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .demo-section { padding: 0.5rem 0; }

    /* Prompts */
    .prompt-intro { font-size: 0.85rem; color: #555; margin: 0 0 0.5rem; }
    .prompt-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 0.5rem; margin: 0.5rem 0; }
    .prompt-card { background: #f8f9fa; border: 2px solid #e9ecef; border-radius: 8px; padding: 0.6rem; cursor: pointer; transition: all 0.2s; }
    .prompt-card:hover { border-color: #42a5f5; }
    .prompt-card.selected { border-color: #1565c0; background: #e3f2fd; }
    .prompt-icon { font-size: 1.5rem; }
    .prompt-card h4 { margin: 0.25rem 0 0.15rem; font-size: 0.82rem; }
    .prompt-card p { font-size: 0.72rem; color: #666; margin: 0; }
    .prompt-detail { background: #e3f2fd; border: 2px solid #90caf9; border-radius: 8px; padding: 0.75rem; margin: 0.75rem 0; animation: slideIn 0.2s ease; }
    .prompt-detail h4 { margin: 0 0 0.5rem; color: #1565c0; font-size: 0.88rem; }
    .discussion-points { display: flex; flex-direction: column; gap: 0.25rem; }
    .point { display: flex; gap: 0.4rem; font-size: 0.82rem; }
    .bullet { color: #1565c0; }
    @keyframes slideIn { from { opacity: 0; transform: translateY(-5px); } to { opacity: 1; transform: translateY(0); } }

    /* FAQ */
    .faq-list { display: flex; flex-direction: column; gap: 0.25rem; }
    .faq-item { border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; }
    .faq-question { display: flex; align-items: center; gap: 0.5rem; padding: 0.5rem 0.6rem; cursor: pointer; font-size: 0.85rem; background: #fafafa; }
    .faq-question:hover { background: #f0f0f0; }
    .faq-toggle { font-size: 0.7rem; color: #666; }
    .faq-answer { padding: 0.5rem 0.6rem 0.5rem 1.5rem; font-size: 0.82rem; color: #555; border-top: 1px solid #e0e0e0; animation: slideIn 0.2s ease; }
    .faq-answer p { margin: 0; line-height: 1.5; }

    /* Scenarios */
    .scenarios { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; }
    .scenario-card { background: #f8f9fa; border: 2px solid #e9ecef; border-radius: 8px; padding: 0.6rem; }
    .scenario-card h4 { margin: 0.35rem 0 0.25rem; font-size: 0.85rem; }
    .scenario-card p { font-size: 0.78rem; color: #555; margin: 0 0 0.5rem; line-height: 1.4; }
    .scenario-consider { font-size: 0.75rem; color: #666; background: #fff3e0; padding: 0.35rem 0.5rem; border-radius: 6px; }

    /* Parking lot */
    .parking-intro { font-size: 0.85rem; color: #555; margin: 0 0 0.5rem; }
    .parking-categories { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; }
    .parking-col h4 { margin: 0 0 0.5rem; font-size: 0.85rem; }
    .parking-items { display: flex; flex-direction: column; gap: 0.25rem; }
    .parking-item { font-size: 0.82rem; padding: 0.35rem 0.5rem; background: #fafafa; border-radius: 6px; border-left: 3px solid #1565c0; }
  `]
})
export class OpenDiscussionComponent {
  selectedPrompt = signal<number | null>(null);
  expandedFaq = signal<string | null>(null);

  prompts = [
    { id: 1, icon: '🏗️', title: 'Architecture Decisions', description: 'Monorepo vs polyrepo, libs structure' },
    { id: 2, icon: '⚡', title: 'Signals Adoption', description: 'When and how to start with signals' },
    { id: 3, icon: '📦', title: 'State Management', description: 'Signal Store vs NgRx vs services' },
    { id: 4, icon: '🔄', title: 'Migration Strategy', description: 'Incremental vs complete rewrite' },
    { id: 5, icon: '🚀', title: 'Performance', description: 'Biggest wins for least effort' },
    { id: 6, icon: '🧪', title: 'Testing', description: 'Strategies for signal-based code' },
  ];

  private promptDetails: Record<number, { title: string; points: string[] }> = {
    1: {
      title: 'Architecture Decisions',
      points: [
        'When does a monorepo make sense vs separate repos?',
        'How do you decide between shared libraries vs copy-paste?',
        'What is the ideal team size for a monorepo?',
        'How do you handle versioning in a monorepo?',
        'When should you extract a feature into its own library?',
      ]
    },
    2: {
      title: 'Signals Adoption',
      points: [
        'Can you mix signals and RxJS in the same component?',
        'Should new features use signals from day one?',
        'What is the minimum Angular version for signals?',
        'How do signals affect unit testing patterns?',
        'When is RxJS still the better choice? (streams, debounce, merge)',
      ]
    },
    3: {
      title: 'State Management',
      points: [
        'When is a simple service with signals enough?',
        'What triggers the move to NgRx Signal Store?',
        'How do you decide between local and global state?',
        'What about caching and invalidation patterns?',
        'How does state management change with SSR?',
      ]
    },
    4: {
      title: 'Migration Strategy',
      points: [
        'How do you convince management to invest in migration?',
        'What metrics show migration is working? (bundle size, performance, velocity)',
        'How do you handle feature development during migration?',
        'What is the risk of a long-lived migration branch?',
        'How do you prioritise which modules to migrate first?',
      ]
    },
    5: {
      title: 'Performance Quick Wins',
      points: [
        'OnPush on every component — what breaks? How to fix?',
        'Lazy loading: what is the 80/20 rule for routes?',
        'Image optimisation: NgOptimizedImage directive',
        'Bundle analysis: how often should you check?',
        'Network: caching headers, CDN, service workers',
      ]
    },
    6: {
      title: 'Testing Signal-Based Code',
      points: [
        'How do you test a signal() value in a unit test?',
        'How do you test computed() derivations?',
        'How do you test effect() side effects?',
        'What changes with Signal Store testing?',
        'Integration testing with signals: what patterns work?',
      ]
    }
  };

  currentPromptDetail = computed(() => {
    const id = this.selectedPrompt();
    return id ? this.promptDetails[id] : null;
  });

  selectPrompt(id: number): void {
    this.selectedPrompt.set(this.selectedPrompt() === id ? null : id);
  }

  toggleFaq(question: string): void {
    this.expandedFaq.set(this.expandedFaq() === question ? null : question);
  }

  faqs = [
    { q: 'Should we migrate all RxJS to signals right now?', a: 'No. Migrate incrementally. Start with template-bound state (BehaviorSubjects → signals). Keep RxJS for complex async streams (debounce, merge, switchMap). The two work well together via toSignal/toObservable.' },
    { q: 'Is NgRx Signal Store production-ready?', a: 'Yes, since @ngrx/signals v17. It is the recommended NgRx approach for new projects. The traditional NgRx Store is still supported but Signal Store is the future direction.' },
    { q: 'When will zoneless Angular be stable?', a: 'It is experimental in Angular 19. The Angular team aims for stable in a future release (likely v20 or v21). You can prepare now by using OnPush + signals everywhere.' },
    { q: 'How do we handle teams at different Angular skill levels?', a: 'Use shared libraries with well-defined APIs. Junior developers work within feature modules using established patterns. Senior developers maintain the shared architecture layer. Code reviews enforce consistency.' },
    { q: 'What is the best folder structure for a large Angular app?', a: 'Feature-based with shared libraries: apps/my-app (thin shell), libs/shared/ui (components), libs/shared/data-access (services/stores), libs/feature-x (domain-specific). Enforced with Nx boundaries.' },
    { q: 'How often should we upgrade Angular?', a: 'Within 1 month of each major release. Angular provides 18 months of LTS, but waiting accumulates technical debt and makes each upgrade harder. Automate with Renovate/Dependabot.' },
  ];
}
