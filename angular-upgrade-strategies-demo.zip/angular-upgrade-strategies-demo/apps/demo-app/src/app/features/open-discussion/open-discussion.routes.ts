import { Route } from '@angular/router';
import { OpenDiscussionComponent } from './open-discussion.component';

export const OPEN_DISCUSSION_ROUTES: Route[] = [
  { path: '', component: OpenDiscussionComponent }
];
