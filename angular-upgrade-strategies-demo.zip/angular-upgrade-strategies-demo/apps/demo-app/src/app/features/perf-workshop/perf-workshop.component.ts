import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Practical Workshop: Application Performance Profiling — Topic 4 (40 min)
 *
 * Covers: Lighthouse, Angular DevTools, Chrome Performance tab, bundle analysis,
 *         bottleneck identification, hands-on profiling exercises
 */
@Component({
  selector: 'app-perf-workshop',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="workshop-page">
      <h2>Practical Workshop: Performance Profiling
        <ui-badge variant="info">Block 7 — Topic 4</ui-badge>
        <ui-badge variant="neutral">40 min</ui-badge>
      </h2>

      <p class="note">
        Hands-on profiling workshop. You will use <strong>Lighthouse</strong>,
        <strong>Angular DevTools</strong>, and the <strong>Chrome Performance tab</strong>
        to identify and resolve performance bottlenecks in a live Angular application.
      </p>

      <!-- Tool 1: Lighthouse -->
      <ui-card title="1. Lighthouse Performance Audit" [elevated]="true">
        <div class="demo-section">
          <div class="tool-overview">
            <div class="tool-header">
              <h4>What it measures</h4>
              <ui-badge variant="success">Built into Chrome DevTools</ui-badge>
            </div>
            <div class="metrics-grid">
              <div class="metric-card">
                <span class="metric-name">FCP</span>
                <span class="metric-full">First Contentful Paint</span>
                <span class="metric-desc">When the first content appears</span>
                <span class="metric-target good">&#60; 1.8s</span>
              </div>
              <div class="metric-card">
                <span class="metric-name">LCP</span>
                <span class="metric-full">Largest Contentful Paint</span>
                <span class="metric-desc">When the largest element renders</span>
                <span class="metric-target good">&#60; 2.5s</span>
              </div>
              <div class="metric-card">
                <span class="metric-name">TBT</span>
                <span class="metric-full">Total Blocking Time</span>
                <span class="metric-desc">Time the main thread is blocked</span>
                <span class="metric-target good">&#60; 200ms</span>
              </div>
              <div class="metric-card">
                <span class="metric-name">CLS</span>
                <span class="metric-full">Cumulative Layout Shift</span>
                <span class="metric-desc">Visual stability score</span>
                <span class="metric-target good">&#60; 0.1</span>
              </div>
              <div class="metric-card">
                <span class="metric-name">SI</span>
                <span class="metric-full">Speed Index</span>
                <span class="metric-desc">How quickly content fills viewport</span>
                <span class="metric-target good">&#60; 3.4s</span>
              </div>
              <div class="metric-card">
                <span class="metric-name">INP</span>
                <span class="metric-full">Interaction to Next Paint</span>
                <span class="metric-desc">Responsiveness to user input</span>
                <span class="metric-target good">&#60; 200ms</span>
              </div>
            </div>
          </div>

          <pre class="code-block">{{ codeLighthouse }}</pre>

          <div class="exercise-box">
            <h4>Exercise 1: Run a Lighthouse Audit</h4>
            <ol>
              <li>Open app in Chrome Incognito (no extensions)</li>
              <li>Open DevTools &#x2192; Lighthouse tab</li>
              <li>Select "Performance" category only</li>
              <li>Choose "Mobile" device</li>
              <li>Click "Analyze page load"</li>
              <li>Record the scores and identify top recommendations</li>
            </ol>
          </div>
        </div>
      </ui-card>

      <!-- Tool 2: Angular DevTools -->
      <ui-card title="2. Angular DevTools Profiler" [elevated]="true">
        <div class="demo-section">
          <div class="tool-header">
            <h4>Chrome Extension for Angular</h4>
            <ui-badge variant="success">Component Inspector + Profiler</ui-badge>
          </div>

          <div class="devtools-features">
            <div class="feature-card">
              <h5>Component Explorer</h5>
              <ul>
                <li>View component tree hierarchy</li>
                <li>Inspect signal values in real time</li>
                <li>See input/output bindings</li>
                <li>Highlight components on hover</li>
              </ul>
            </div>
            <div class="feature-card">
              <h5>Profiler</h5>
              <ul>
                <li>Record change detection cycles</li>
                <li>See which components were checked</li>
                <li>Identify unnecessary re-renders</li>
                <li>Measure cycle duration</li>
              </ul>
            </div>
            <div class="feature-card">
              <h5>Dependency Injection</h5>
              <ul>
                <li>View injector hierarchy</li>
                <li>See provided services</li>
                <li>Track injection resolution path</li>
                <li>Identify singleton vs scoped services</li>
              </ul>
            </div>
          </div>

          <div class="exercise-box">
            <h4>Exercise 2: Profile Change Detection</h4>
            <ol>
              <li>Install Angular DevTools from Chrome Web Store</li>
              <li>Open DevTools &#x2192; Angular tab &#x2192; Profiler</li>
              <li>Start recording, interact with the app</li>
              <li>Stop recording and examine the flame chart</li>
              <li>Identify which components run CD most frequently</li>
              <li>Compare a Default CD component vs OnPush component</li>
            </ol>
          </div>
        </div>
      </ui-card>

      <!-- Tool 3: Chrome Performance Tab -->
      <ui-card title="3. Chrome Performance Tab" [elevated]="true">
        <div class="demo-section">
          <div class="tool-header">
            <h4>Low-Level Runtime Analysis</h4>
            <ui-badge variant="warning">Advanced</ui-badge>
          </div>

          <pre class="code-block">{{ codePerformanceApi }}</pre>

          <div class="perf-sections">
            <div class="perf-section">
              <h5>What to Look For</h5>
              <div class="look-for-grid">
                <div class="look-item red">
                  <strong>Long Tasks</strong>
                  <p>Red bars &#62; 50ms — blocks main thread</p>
                </div>
                <div class="look-item yellow">
                  <strong>Layout Thrashing</strong>
                  <p>Purple "Layout" blocks in rapid sequence</p>
                </div>
                <div class="look-item red">
                  <strong>Forced Reflow</strong>
                  <p>Reading layout after writing (offsetHeight after style change)</p>
                </div>
                <div class="look-item yellow">
                  <strong>Excessive Scripting</strong>
                  <p>Yellow blocks dominate — too much JS execution</p>
                </div>
              </div>
            </div>
          </div>

          <div class="exercise-box">
            <h4>Exercise 3: Record a Performance Trace</h4>
            <ol>
              <li>Open DevTools &#x2192; Performance tab</li>
              <li>Click Record, interact with the app for 5 seconds, Stop</li>
              <li>Find the "Main" thread in the flame chart</li>
              <li>Look for long tasks (&#62; 50ms, marked in red)</li>
              <li>Click on tasks to see the call stack</li>
              <li>Identify Angular-specific functions (e.g., detectChanges, refreshView)</li>
            </ol>
          </div>
        </div>
      </ui-card>

      <!-- Tool 4: Bundle Analysis -->
      <ui-card title="4. Bundle Analysis Workshop" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeBundleAnalysis }}</pre>

          <div class="bundle-tips">
            <h4>What to Look For in Bundle Reports</h4>
            <div class="tip-grid">
              <div class="tip-card">
                <ui-badge variant="danger">Large modules</ui-badge>
                <p>Single files over 50 KB — candidate for lazy loading</p>
              </div>
              <div class="tip-card">
                <ui-badge variant="warning">Duplicates</ui-badge>
                <p>Same library bundled twice — check imports and peer deps</p>
              </div>
              <div class="tip-card">
                <ui-badge variant="danger">Unused exports</ui-badge>
                <p>Barrel files importing entire modules — use direct imports</p>
              </div>
              <div class="tip-card">
                <ui-badge variant="warning">Polyfills</ui-badge>
                <p>Large polyfill bundles — check browser targets in .browserslistrc</p>
              </div>
            </div>
          </div>

          <div class="exercise-box">
            <h4>Exercise 4: Analyze the Bundle</h4>
            <ol>
              <li>Build with stats: <code>npx nx build demo-app --stats-json</code></li>
              <li>Run: <code>npx source-map-explorer dist/**/*.js</code></li>
              <li>Identify the 3 largest modules</li>
              <li>Check if any can be lazy loaded or replaced</li>
              <li>Look for tree-shaking failures (unused code still present)</li>
            </ol>
          </div>
        </div>
      </ui-card>

      <!-- Interactive bottleneck finder -->
      <ui-card title="5. Performance Bottleneck Finder" [elevated]="true">
        <div class="demo-section">
          <h4>Interactive Diagnostic</h4>
          <p class="explanation-text">Click symptoms below to see likely root causes and fixes.</p>

          <div class="symptom-buttons">
            @for (symptom of symptoms; track symptom.id) {
              <ui-button
                [variant]="selectedSymptom() === symptom.id ? 'primary' : 'ghost'"
                size="sm"
                (clicked)="selectSymptom(symptom.id)">
                {{ symptom.label }}
              </ui-button>
            }
          </div>

          @if (currentDiagnosis(); as diag) {
            <div class="diagnosis-panel">
              <h4>{{ diag.title }}</h4>
              <div class="diagnosis-content">
                <div class="cause-section">
                  <h5>Likely Causes</h5>
                  <ul>
                    @for (cause of diag.causes; track cause) {
                      <li>{{ cause }}</li>
                    }
                  </ul>
                </div>
                <div class="fix-section">
                  <h5>Recommended Fixes</h5>
                  <ul>
                    @for (fix of diag.fixes; track fix) {
                      <li>{{ fix }}</li>
                    }
                  </ul>
                </div>
              </div>
            </div>
          }
        </div>
      </ui-card>

      <!-- Checklist -->
      <ui-card title="6. Performance Optimisation Checklist" [elevated]="true">
        <div class="demo-section">
          <div class="checklist-categories">
            <div class="checklist-category">
              <h4>Build Time</h4>
              <div class="checklist-items">
                @for (item of buildChecklist; track item) {
                  <div class="checklist-row">
                    <span class="check-icon">&#x2610;</span>
                    <span>{{ item }}</span>
                  </div>
                }
              </div>
            </div>
            <div class="checklist-category">
              <h4>Runtime</h4>
              <div class="checklist-items">
                @for (item of runtimeChecklist; track item) {
                  <div class="checklist-row">
                    <span class="check-icon">&#x2610;</span>
                    <span>{{ item }}</span>
                  </div>
                }
              </div>
            </div>
            <div class="checklist-category">
              <h4>Network</h4>
              <div class="checklist-items">
                @for (item of networkChecklist; track item) {
                  <div class="checklist-row">
                    <span class="check-icon">&#x2610;</span>
                    <span>{{ item }}</span>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .workshop-page { padding: 0.5rem; }
    .note { background: #e8f5e9; border: 1px solid #c8e6c9; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .explanation-text { font-size: 0.88rem; color: #555; margin: 0.5rem 0; }
    .explanation-text code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }
    .tool-header { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.5rem; }
    .tool-header h4 { margin: 0; }

    /* Metrics grid */
    .metrics-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; margin: 0.75rem 0; }
    .metric-card { background: #f5f5f5; border-radius: 8px; padding: 0.6rem; text-align: center; }
    .metric-name { display: block; font-size: 1.2rem; font-weight: 700; color: #1565c0; }
    .metric-full { display: block; font-size: 0.72rem; color: #666; }
    .metric-desc { display: block; font-size: 0.72rem; color: #999; margin: 0.15rem 0; }
    .metric-target { display: inline-block; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.72rem; font-weight: 600; margin-top: 0.15rem; }
    .good { background: #e8f5e9; color: #2e7d32; }

    /* Exercise boxes */
    .exercise-box { background: #fffde7; border: 2px solid #fff176; border-radius: 8px; padding: 0.75rem; margin: 0.75rem 0; }
    .exercise-box h4 { margin: 0 0 0.5rem; color: #f57f17; font-size: 0.88rem; }
    .exercise-box ol { padding-left: 1.25rem; font-size: 0.82rem; margin: 0; }
    .exercise-box li { margin: 0.2rem 0; }
    .exercise-box code { background: #fff8e1; padding: 0.1rem 0.35rem; border-radius: 4px; font-size: 0.78rem; }

    /* DevTools features */
    .devtools-features { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; margin: 0.75rem 0; }
    .feature-card { background: #f5f5f5; border-radius: 8px; padding: 0.6rem; }
    .feature-card h5 { margin: 0 0 0.35rem; font-size: 0.85rem; }
    .feature-card ul { padding-left: 1rem; font-size: 0.78rem; margin: 0; }
    .feature-card li { margin: 0.15rem 0; }

    /* Performance look-for */
    .look-for-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin: 0.5rem 0; }
    .look-item { padding: 0.5rem; border-radius: 8px; }
    .look-item strong { font-size: 0.82rem; display: block; }
    .look-item p { font-size: 0.78rem; margin: 0.15rem 0 0; }
    .look-item.red { background: #ffebee; border: 1px solid #ffcdd2; }
    .look-item.yellow { background: #fff8e1; border: 1px solid #ffe082; }

    /* Bundle tips */
    .tip-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; margin: 0.5rem 0; }
    .tip-card { background: #fafafa; border-radius: 8px; padding: 0.5rem; }
    .tip-card p { font-size: 0.78rem; margin: 0.25rem 0 0; color: #666; }

    /* Symptoms / diagnosis */
    .symptom-buttons { display: flex; flex-wrap: wrap; gap: 0.35rem; margin: 0.5rem 0; }
    .diagnosis-panel { background: #e3f2fd; border: 2px solid #90caf9; border-radius: 8px; padding: 0.75rem; margin: 0.75rem 0; animation: fadeIn 0.3s ease; }
    .diagnosis-panel h4 { margin: 0 0 0.5rem; color: #1565c0; }
    .diagnosis-content { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .diagnosis-content h5 { margin: 0 0 0.35rem; }
    .diagnosis-content ul { padding-left: 1.25rem; font-size: 0.82rem; margin: 0; }
    .diagnosis-content li { margin: 0.2rem 0; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(-5px); } to { opacity: 1; transform: translateY(0); } }

    /* Checklist */
    .checklist-categories { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; }
    .checklist-category h4 { margin: 0 0 0.5rem; font-size: 0.88rem; padding-bottom: 0.25rem; border-bottom: 2px solid #1565c0; }
    .checklist-items { display: flex; flex-direction: column; gap: 0.15rem; }
    .checklist-row { display: flex; align-items: center; gap: 0.4rem; font-size: 0.8rem; padding: 0.2rem 0; }
    .check-icon { font-size: 1rem; color: #999; }
  `]
})
export class PerfWorkshopComponent {
  // ═══════════ Symptom diagnosis ═══════════
  selectedSymptom = signal<string | null>(null);

  symptoms = [
    { id: 'slow-load', label: 'Slow Initial Load' },
    { id: 'janky-scroll', label: 'Janky Scrolling' },
    { id: 'slow-nav', label: 'Slow Navigation' },
    { id: 'memory-leak', label: 'Memory Leak' },
    { id: 'ui-freeze', label: 'UI Freezes' }
  ];

  private diagnoses: Record<string, { title: string; causes: string[]; fixes: string[] }> = {
    'slow-load': {
      title: 'Slow Initial Load',
      causes: [
        'Large initial bundle (>500 KB)',
        'No lazy loading — everything in main chunk',
        'Heavy third-party libs loaded eagerly',
        'No preconnect/preload hints',
      ],
      fixes: [
        'Implement route-level lazy loading',
        'Use @defer for below-the-fold content',
        'Split large libs into separate chunks',
        'Add <link rel="preconnect"> for API domains',
        'Set Angular budgets to catch regressions',
      ]
    },
    'janky-scroll': {
      title: 'Janky Scrolling',
      causes: [
        'Rendering too many DOM nodes',
        'Complex CSS (box-shadow, filter, blur)',
        'Layout thrashing from JS reads/writes',
        'Default change detection on scroll events',
      ],
      fixes: [
        'Use cdk-virtual-scroll-viewport for long lists',
        'Use will-change: transform on animated elements',
        'Batch DOM reads before DOM writes',
        'Use OnPush + signals to skip unnecessary CD',
      ]
    },
    'slow-nav': {
      title: 'Slow Route Navigation',
      causes: [
        'Large lazy chunk for target route',
        'Heavy component initialisation in ngOnInit',
        'Route resolvers fetching too much data',
        'No preloading strategy configured',
      ],
      fixes: [
        'Use PreloadAllModules or custom strategy',
        'Defer non-critical init work',
        'Paginate resolver data, load on demand',
        'Show loading skeleton instantly, load data async',
      ]
    },
    'memory-leak': {
      title: 'Memory Leak',
      causes: [
        'Unsubscribed RxJS subscriptions',
        'Event listeners not cleaned up on destroy',
        'Detached DOM nodes held in closures',
        'Growing arrays/maps never pruned',
      ],
      fixes: [
        'Use takeUntilDestroyed() or async pipe',
        'Prefer toSignal() (auto-unsubscribes)',
        'Use DestroyRef.onDestroy() for cleanup',
        'Use Chrome DevTools Memory tab heap snapshots',
      ]
    },
    'ui-freeze': {
      title: 'UI Freezes',
      causes: [
        'Long synchronous computation on main thread',
        'Blocking the event loop (large JSON parse)',
        'Recursive or deeply nested change detection',
        'Heavy DOM manipulation in one frame',
      ],
      fixes: [
        'Move computation to Web Worker',
        'Break work into chunks with requestAnimationFrame',
        'Use OnPush to limit CD scope',
        'Virtualise or paginate large data sets',
      ]
    }
  };

  currentDiagnosis = computed(() => {
    const id = this.selectedSymptom();
    return id ? this.diagnoses[id] : null;
  });

  selectSymptom(id: string): void {
    this.selectedSymptom.set(id);
  }

  // ═══════════ Checklists ═══════════
  buildChecklist = [
    'Lazy load all feature routes',
    'Use @defer for heavy below-fold content',
    'Set Angular budget warnings and errors',
    'Enable production optimisations (ng build)',
    'Analyse bundle with source-map-explorer',
    'Remove unused dependencies',
    'Use direct imports, avoid large barrel files',
  ];

  runtimeChecklist = [
    'All components use OnPush',
    'All template state uses signals/computed',
    'track expression on every @for loop',
    'Virtual scroll for lists > 100 items',
    'No function calls in templates (use computed)',
    'Detach CD for special-case heavy views',
    'Use @if instead of [hidden] for heavy content',
  ];

  networkChecklist = [
    'HTTP caching headers configured',
    'Images lazy loaded (loading="lazy")',
    'Preconnect to API domains',
    'Use CDN for static assets',
    'Enable gzip/brotli compression',
    'Implement service worker for offline',
    'Paginate API responses',
  ];

  // ═══════════ Code examples ═══════════
  codeLighthouse = `# Run Lighthouse from CLI (CI-friendly)
npx lighthouse http://localhost:4200 \\
  --output=html \\
  --output-path=./lighthouse-report.html \\
  --only-categories=performance \\
  --chrome-flags="--headless"

# Key scores to track:
# Performance Score: 90+ (green)
# FCP: < 1.8s | LCP: < 2.5s | TBT: < 200ms | CLS: < 0.1`;

  codePerformanceApi = `// Use the Performance API for custom measurements
// Place in your component or service code

// Mark start of an operation
performance.mark('data-load-start');

await this.loadData();

// Mark end
performance.mark('data-load-end');

// Measure duration
performance.measure('Data Load', 'data-load-start', 'data-load-end');

// Read the measurement
const entries = performance.getEntriesByName('Data Load');
console.log('Load time:', entries[0].duration, 'ms');

// View in Chrome DevTools > Performance > Timings track`;

  codeBundleAnalysis = `# Step 1: Build with stats
npx nx build demo-app --stats-json

# Step 2: Analyse with source-map-explorer
npx source-map-explorer dist/apps/demo-app/browser/*.js

# Step 3: Or use webpack-bundle-analyzer
npx webpack-bundle-analyzer dist/apps/demo-app/browser/stats.json

# Angular budget configuration (project.json):
{
  "budgets": [
    {
      "type": "initial",
      "maximumWarning": "500kB",
      "maximumError": "1MB"
    },
    {
      "type": "anyComponentStyle",
      "maximumWarning": "4kB",
      "maximumError": "8kB"
    }
  ]
}`;
}
