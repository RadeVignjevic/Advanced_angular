import { Route } from '@angular/router';
import { PerfWorkshopComponent } from './perf-workshop.component';

export const PERF_WORKSHOP_ROUTES: Route[] = [
  { path: '', component: PerfWorkshopComponent }
];
