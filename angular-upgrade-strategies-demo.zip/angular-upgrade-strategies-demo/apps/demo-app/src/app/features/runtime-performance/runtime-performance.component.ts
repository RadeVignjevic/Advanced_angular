import { Component, ChangeDetectionStrategy, signal, computed, inject } from '@angular/core';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Runtime Performance Patterns — Topic 2 (30 min)
 *
 * Covers: track expressions, virtual scrolling, OnPush + signals
 */
@Component({
  selector: 'app-runtime-performance',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent, ScrollingModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="runtime-page">
      <h2>Runtime Performance Patterns
        <ui-badge variant="info">Block 7 — Topic 2</ui-badge>
      </h2>

      <p class="note">
        Build-time optimisation reduces what gets shipped; <strong>runtime patterns</strong>
        control what the browser does with it. Focus on <strong>track expressions</strong>,
        <strong>virtual scrolling</strong>, and the <strong>OnPush + signals</strong> strategy.
      </p>

      <!-- Track Expressions -->
      <ui-card title="1. Track Expressions in &#64;for" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeTrack }}</pre>

          <h4>Live Demo: track by id vs track by index</h4>
          <div class="demo-row">
            <ui-button variant="primary" size="sm" (clicked)="shuffleItems()">Shuffle Items</ui-button>
            <ui-button variant="ghost" size="sm" (clicked)="addItem()">Add Item</ui-button>
            <ui-button variant="danger" size="sm" (clicked)="removeLastItem()">Remove Last</ui-button>
            <span class="counter">Renders: <strong>{{ renderCount() }}</strong></span>
          </div>

          <div class="items-grid">
            @for (item of items(); track item.id) {
              <div class="item-card" [style.background]="item.color">
                <span class="item-id">#{{ item.id }}</span>
                <span class="item-name">{{ item.name }}</span>
              </div>
            }
          </div>

          <div class="explanation">
            <p>The <code>track</code> expression tells Angular how to identify items across
            re-renders. With <code>track item.id</code>, Angular reuses DOM nodes when items
            are reordered — only moves them. With <code>track $index</code>, every position
            change causes a full re-render of that slot.</p>
            <p><strong>Rule:</strong> Always track by a unique, stable identifier (usually <code>id</code>).</p>
          </div>
        </div>
      </ui-card>

      <!-- Virtual Scrolling -->
      <ui-card title="2. Virtual Scrolling (CDK)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeVirtualScroll }}</pre>

          <h4>Live Demo: 10,000 items — Virtual vs Non-Virtual</h4>
          <div class="scroll-comparison">
            <div class="scroll-panel">
              <h5>Virtual Scroll (50px items)</h5>
              <cdk-virtual-scroll-viewport itemSize="50" class="virtual-viewport">
                <div *cdkVirtualFor="let item of largeList" class="virtual-item">
                  <span class="v-id">#{{ item.id }}</span>
                  <span class="v-name">{{ item.name }}</span>
                  <span class="v-value">{{ item.value }}</span>
                </div>
              </cdk-virtual-scroll-viewport>
              <div class="scroll-info">
                <ui-badge variant="success">~20 DOM nodes</ui-badge>
              </div>
            </div>
            <div class="scroll-panel">
              <h5>Regular List (first 100 only)</h5>
              <div class="regular-viewport">
                @for (item of first100(); track item.id) {
                  <div class="virtual-item">
                    <span class="v-id">#{{ item.id }}</span>
                    <span class="v-name">{{ item.name }}</span>
                    <span class="v-value">{{ item.value }}</span>
                  </div>
                }
              </div>
              <div class="scroll-info">
                <ui-badge variant="danger">100 DOM nodes (would be 10,000)</ui-badge>
              </div>
            </div>
          </div>

          <div class="explanation">
            <p><code>cdk-virtual-scroll-viewport</code> renders only the visible items plus
            a small buffer. For 10,000 items, it maintains ~20 DOM nodes instead of 10,000.
            Import from <code>&#64;angular/cdk/scrolling</code>.</p>
          </div>
        </div>
      </ui-card>

      <!-- OnPush + Signals -->
      <ui-card title="3. OnPush + Signals Strategy" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeOnPushSignals }}</pre>

          <div class="strategy-comparison">
            <div class="strategy-card default-cd">
              <h4>Default CD</h4>
              <ul>
                <li>All components checked on every event</li>
                <li>Zone.js patches every async API</li>
                <li>O(n) checks per tick (n = components)</li>
              </ul>
              <ui-badge variant="danger">Expensive</ui-badge>
            </div>
            <div class="strategy-card onpush-cd">
              <h4>OnPush</h4>
              <ul>
                <li>Only checked when inputs change (reference)</li>
                <li>Or when events fire inside the component</li>
                <li>Skips entire subtrees</li>
              </ul>
              <ui-badge variant="warning">Better</ui-badge>
            </div>
            <div class="strategy-card signal-cd">
              <h4>OnPush + Signals</h4>
              <ul>
                <li>Signals mark exactly which components need update</li>
                <li>Computed values are memoised</li>
                <li>No unnecessary change detection runs</li>
              </ul>
              <ui-badge variant="success">Best</ui-badge>
            </div>
          </div>

          <div class="explanation">
            <p>Combining <code>OnPush</code> with signals gives you <strong>surgical precision</strong>
            in change detection. Signals notify Angular exactly when a value changes, and OnPush
            ensures the component tree is skipped when nothing changed. This is the recommended
            strategy for all new components.</p>
          </div>
        </div>
      </ui-card>

      <!-- Additional Patterns -->
      <ui-card title="4. Additional Runtime Patterns" [elevated]="true">
        <div class="demo-section">
          <div class="patterns-list">
            <div class="pattern-item">
              <h4>Avoid function calls in templates</h4>
              <pre class="code-block">{{ codeAvoidFunctions }}</pre>
            </div>

            <div class="pattern-item">
              <h4>Use &#64;if instead of [hidden]</h4>
              <pre class="code-block">{{ codeIfVsHidden }}</pre>
            </div>

            <div class="pattern-item">
              <h4>Detach change detection for heavy views</h4>
              <pre class="code-block">{{ codeDetachCd }}</pre>
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .runtime-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.75rem 0; flex-wrap: wrap; }
    .counter { font-family: monospace; font-size: 0.88rem; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }

    .items-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 0.5rem; margin: 0.5rem 0; }
    .item-card { border-radius: 8px; padding: 0.5rem; text-align: center; color: white; font-size: 0.82rem; transition: transform 0.2s; }
    .item-id { font-weight: 700; display: block; }
    .item-name { font-size: 0.75rem; }

    .scroll-comparison { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 0.75rem 0; }
    .scroll-panel h5 { margin: 0 0 0.5rem; font-size: 0.88rem; }
    .virtual-viewport { height: 250px; border: 2px solid #e0e0e0; border-radius: 8px; }
    .regular-viewport { height: 250px; overflow-y: auto; border: 2px solid #e0e0e0; border-radius: 8px; }
    .virtual-item { display: flex; align-items: center; gap: 0.75rem; padding: 0 0.75rem; height: 50px; border-bottom: 1px solid #eee; font-size: 0.82rem; }
    .v-id { font-weight: 600; min-width: 50px; }
    .v-name { flex: 1; }
    .v-value { color: #666; font-family: monospace; }
    .scroll-info { margin-top: 0.25rem; }

    .strategy-comparison { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0.75rem; margin: 0.75rem 0; }
    .strategy-card { border-radius: 12px; padding: 0.75rem; }
    .strategy-card h4 { margin: 0 0 0.5rem; font-size: 0.88rem; }
    .strategy-card ul { padding-left: 1.25rem; font-size: 0.8rem; margin: 0 0 0.5rem; }
    .strategy-card li { margin: 0.2rem 0; }
    .default-cd { background: #ffebee; border: 2px solid #ffcdd2; }
    .onpush-cd { background: #fff8e1; border: 2px solid #ffe082; }
    .signal-cd { background: #e8f5e9; border: 2px solid #c8e6c9; }

    .patterns-list { display: flex; flex-direction: column; gap: 0.5rem; }
    .pattern-item h4 { margin: 0; font-size: 0.88rem; color: #333; }
  `]
})
export class RuntimePerformanceComponent {
  // ═══════════ Track demo ═══════════
  private nextId = 11;
  renderCount = signal(0);

  items = signal(
    Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      name: `Item ${i + 1}`,
      color: this.randomColor(),
    }))
  );

  shuffleItems(): void {
    this.items.update(list => [...list].sort(() => Math.random() - 0.5));
    this.renderCount.update(c => c + 1);
  }

  addItem(): void {
    const id = this.nextId++;
    this.items.update(list => [...list, { id, name: `Item ${id}`, color: this.randomColor() }]);
    this.renderCount.update(c => c + 1);
  }

  removeLastItem(): void {
    this.items.update(list => list.slice(0, -1));
    this.renderCount.update(c => c + 1);
  }

  private randomColor(): string {
    const colors = ['#e53935', '#1e88e5', '#43a047', '#fb8c00', '#8e24aa', '#00acc1', '#5e35b1', '#d81b60'];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  // ═══════════ Virtual scroll demo ═══════════
  largeList = Array.from({ length: 10000 }, (_, i) => ({
    id: i + 1,
    name: `Product #${i + 1}`,
    value: `$${(Math.random() * 1000).toFixed(2)}`,
  }));

  first100 = computed(() => this.largeList.slice(0, 100));

  // ═══════════ Code examples ═══════════
  codeTrack = `// @for with track expression (Angular 17+)
// GOOD — track by unique ID (DOM reuse on reorder)
@for (item of items(); track item.id) {
  <div>{{ item.name }}</div>
}

// BAD — track by index (every reorder re-creates DOM)
@for (item of items(); track $index) {
  <div>{{ item.name }}</div>
}

// OLD NgFor equivalent:
// *ngFor="let item of items; trackBy: trackById"
// trackById(index: number, item: Item) { return item.id; }`;

  codeVirtualScroll = `// Virtual scrolling via @angular/cdk/scrolling
import { ScrollingModule } from '@angular/cdk/scrolling';

@Component({
  imports: [ScrollingModule],
  template: \`
    <cdk-virtual-scroll-viewport itemSize="50" class="viewport">
      <div *cdkVirtualFor="let item of items" class="row">
        {{ item.name }}
      </div>
    </cdk-virtual-scroll-viewport>
  \`,
  styles: [\`.viewport { height: 400px; }\`]
})

// itemSize = height in px of each row
// Only renders visible items + buffer (~20 DOM nodes for 10,000 items)`;

  codeOnPushSignals = `// The recommended performance strategy
@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,  // skip if no changes
  template: \`
    <h2>{{ title() }}</h2>         <!-- signal read -->
    <p>Count: {{ count() }}</p>    <!-- signal read -->
    <p>Double: {{ doubled() }}</p> <!-- computed, memoised -->
  \`
})
export class MyComponent {
  title = signal('Hello');
  count = signal(0);
  doubled = computed(() => this.count() * 2);  // only recalculates when count changes

  increment() {
    this.count.update(c => c + 1);
    // Angular knows EXACTLY which component(s) need re-checking
  }
}`;

  codeAvoidFunctions = `// BAD — function called on every CD cycle
<div>{{ getFullName() }}</div>

// GOOD — use a computed signal (memoised)
fullName = computed(() => this.firstName() + ' ' + this.lastName());
<div>{{ fullName() }}</div>`;

  codeIfVsHidden = `// @if removes from DOM (saves memory, no CD for hidden content)
@if (showPanel()) {
  <app-heavy-panel />
}

// [hidden] keeps in DOM (still runs CD, uses memory)
<app-heavy-panel [hidden]="!showPanel()" />

// Use @if for heavy components, [hidden] for toggles that flip frequently`;

  codeDetachCd = `// Detach CD for components that update on their own schedule
export class LiveChartComponent {
  private cdRef = inject(ChangeDetectorRef);

  ngOnInit() {
    this.cdRef.detach();  // stop automatic checking

    // Manually check on data update
    this.dataService.data$.subscribe(data => {
      this.data = data;
      this.cdRef.detectChanges();  // manual check
    });
  }
}`;
}
