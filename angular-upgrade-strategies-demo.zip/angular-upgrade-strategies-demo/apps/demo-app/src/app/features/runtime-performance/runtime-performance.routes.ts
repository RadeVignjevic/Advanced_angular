import { Route } from '@angular/router';
import { RuntimePerformanceComponent } from './runtime-performance.component';

export const RUNTIME_PERFORMANCE_ROUTES: Route[] = [
  { path: '', component: RuntimePerformanceComponent }
];
