import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Signal-Based Forms (Experimental) — Topic 3 (20 min)
 *
 * Covers: current development status, proposed API, adoption readiness
 */
@Component({
  selector: 'app-signal-forms',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="forms-page">
      <h2>Signal-Based Forms
        <ui-badge variant="warning">Experimental</ui-badge>
        <ui-badge variant="info">Block 6 — Topic 3</ui-badge>
      </h2>

      <p class="note">
        The Angular team is developing a <strong>signal-based forms API</strong> to replace
        Reactive Forms and Template-Driven Forms. It is currently in <strong>experimental / RFC stage</strong>.
        This topic covers the vision, proposed API, and adoption readiness.
      </p>

      <!-- Current Status -->
      <ui-card title="1. Current Status" [elevated]="true">
        <div class="demo-section">
          <div class="status-grid">
            <div class="status-item">
              <ui-badge variant="success">Stable</ui-badge>
              <span>Template-Driven Forms (<code>ngModel</code>)</span>
            </div>
            <div class="status-item">
              <ui-badge variant="success">Stable</ui-badge>
              <span>Reactive Forms (<code>FormControl</code>, <code>FormGroup</code>)</span>
            </div>
            <div class="status-item">
              <ui-badge variant="warning">Experimental</ui-badge>
              <span>Signal Forms — RFC / early prototype phase</span>
            </div>
          </div>

          <div class="explanation">
            <p>Angular forms have remained largely unchanged since Angular 2. Both APIs rely on
            RxJS Observables (<code>valueChanges</code>, <code>statusChanges</code>). The signal
            forms initiative aims to build forms on top of signals for a simpler, synchronous API.</p>
          </div>
        </div>
      </ui-card>

      <!-- Problems with Current Forms -->
      <ui-card title="2. Why Signal Forms?" [elevated]="true">
        <div class="demo-section">
          <div class="problems-grid">
            <div class="problem-card">
              <h4>Reactive Forms Pain Points</h4>
              <ul>
                <li>Verbose setup: <code>FormGroup</code>, <code>FormControl</code>, validators</li>
                <li>Weak typing — <code>value: any</code> by default (improved in v14)</li>
                <li><code>valueChanges</code> is Observable → needs subscribe / async</li>
                <li>Two-way binding requires custom wiring</li>
                <li>Dynamic forms are complex</li>
              </ul>
            </div>
            <div class="problem-card">
              <h4>Template-Driven Pain Points</h4>
              <ul>
                <li>Hard to test (template-dependent)</li>
                <li>Limited programmatic control</li>
                <li>Implicit model binding</li>
                <li>Difficult to compose validators</li>
                <li>No strong typing at all</li>
              </ul>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Proposed API -->
      <ui-card title="3. Proposed Signal Forms API" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeProposedApi }}</pre>

          <div class="explanation">
            <p>The proposed API replaces <code>FormControl</code> with a signal-based control
            that exposes <code>.value()</code> as a signal. Validation is synchronous via
            <code>computed()</code>. No more <code>valueChanges</code> Observables.</p>
          </div>

          <pre class="code-block">{{ codeProposedGroup }}</pre>

          <div class="explanation">
            <p><code>FormGroup</code> would become a record of signal controls. The entire form's
            validity is a <code>computed()</code> signal derived from each field's validity.</p>
          </div>
        </div>
      </ui-card>

      <!-- Manual Signal Forms (Today) -->
      <ui-card title="4. Building Signal Forms Today (Manual Pattern)" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeManualSignalForm }}</pre>

          <h4>Live Demo: Manual Signal Form</h4>
          <div class="form-demo">
            <div class="form-row">
              <label>Name:</label>
              <input class="demo-input" [value]="formName()"
                (input)="formName.set(getInputValue($event))"
                [class.invalid]="formNameError()" />
              @if (formNameError()) {
                <span class="error-text">{{ formNameError() }}</span>
              }
            </div>
            <div class="form-row">
              <label>Email:</label>
              <input class="demo-input" [value]="formEmail()"
                (input)="formEmail.set(getInputValue($event))"
                [class.invalid]="formEmailError()" />
              @if (formEmailError()) {
                <span class="error-text">{{ formEmailError() }}</span>
              }
            </div>
            <div class="form-row">
              <label>Price:</label>
              <input class="demo-input" type="number" [value]="formPrice()"
                (input)="formPrice.set(getInputNumber($event))"
                [class.invalid]="formPriceError()" />
              @if (formPriceError()) {
                <span class="error-text">{{ formPriceError() }}</span>
              }
            </div>

            <div class="form-status">
              <span>Valid: <strong>{{ formValid() }}</strong></span>
              <span>Dirty: <strong>{{ formDirty() }}</strong></span>
            </div>

            <div class="demo-row">
              <ui-button variant="primary" size="sm" [disabled]="!formValid()"
                (clicked)="submitForm()">Submit</ui-button>
              <ui-button variant="ghost" size="sm" (clicked)="resetForm()">Reset</ui-button>
            </div>

            @if (formSubmitted()) {
              <div class="submit-result">
                Submitted: {{ formSubmittedData() }}
              </div>
            }
          </div>

          <div class="explanation">
            <p>This pattern uses plain <code>signal()</code> + <code>computed()</code> for
            validation. It works <strong>today</strong> in Angular 19 without any experimental APIs.
            This is how teams can start building signal-based forms right now.</p>
          </div>
        </div>
      </ui-card>

      <!-- Adoption Readiness -->
      <ui-card title="5. Adoption Readiness Assessment" [elevated]="true">
        <div class="demo-section">
          <table class="readiness-table">
            <thead>
              <tr>
                <th>Approach</th>
                <th>Status</th>
                <th>Recommendation</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Reactive Forms</td>
                <td><ui-badge variant="success">Stable</ui-badge></td>
                <td>Keep using for existing apps. Not deprecated.</td>
              </tr>
              <tr>
                <td>Template-Driven Forms</td>
                <td><ui-badge variant="success">Stable</ui-badge></td>
                <td>Fine for simple forms. Not deprecated.</td>
              </tr>
              <tr>
                <td>Manual signal forms (signal + computed)</td>
                <td><ui-badge variant="info">Works Today</ui-badge></td>
                <td>Great for new features. No dependency on experimental APIs.</td>
              </tr>
              <tr>
                <td>Official Signal Forms API</td>
                <td><ui-badge variant="warning">Experimental</ui-badge></td>
                <td>Watch the RFC. Don't adopt in production yet.</td>
              </tr>
            </tbody>
          </table>

          <div class="explanation">
            <p><strong>Bottom line:</strong> Use Reactive Forms for existing code. For new features,
            the manual signal pattern (signal + computed + validation) is production-ready today.
            Wait for the official API to stabilize before migrating existing forms wholesale.</p>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .forms-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .note code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .demo-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.75rem 0; flex-wrap: wrap; }
    .demo-input { padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 0.9rem; min-width: 200px; }
    .demo-input:focus { outline: none; border-color: #42a5f5; }
    .demo-input.invalid { border-color: #e53935; background: #fff5f5; }
    .explanation p { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.5rem 0; }
    .explanation code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }

    .status-grid { display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 0.75rem; }
    .status-item { display: flex; align-items: center; gap: 0.75rem; font-size: 0.88rem; padding: 0.4rem 0; }
    .status-item code { background: #e8eaf6; padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.82rem; }

    .problems-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .problem-card { background: #fff3e0; border: 2px solid #ffe0b2; border-radius: 12px; padding: 1rem; }
    .problem-card h4 { margin: 0 0 0.5rem; font-size: 0.9rem; }
    .problem-card ul { padding-left: 1.25rem; font-size: 0.82rem; margin: 0; }
    .problem-card li { margin: 0.3rem 0; }
    .problem-card code { background: rgba(0,0,0,0.06); padding: 0.1rem 0.3rem; border-radius: 4px; font-size: 0.78rem; }

    .form-demo { background: #f8f9fa; border: 2px solid #e0e0e0; border-radius: 12px; padding: 1rem; margin: 0.75rem 0; }
    .form-row { display: flex; align-items: center; gap: 0.75rem; margin: 0.5rem 0; }
    .form-row label { min-width: 60px; font-weight: 600; font-size: 0.88rem; }
    .error-text { color: #e53935; font-size: 0.78rem; }
    .form-status { display: flex; gap: 1.5rem; font-family: monospace; font-size: 0.82rem; background: #fff; padding: 0.5rem 0.75rem; border-radius: 8px; margin: 0.5rem 0; }
    .submit-result { background: #e8f5e9; border: 1px solid #c8e6c9; padding: 0.5rem 0.75rem; border-radius: 8px; font-family: monospace; font-size: 0.82rem; margin-top: 0.5rem; }

    .readiness-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
    .readiness-table th { background: #f5f5f5; padding: 0.5rem; text-align: left; border-bottom: 2px solid #e0e0e0; }
    .readiness-table td { padding: 0.5rem; border-bottom: 1px solid #eee; vertical-align: middle; }
  `]
})
export class SignalFormsComponent {

  // ═══════════ Live manual signal form demo ═══════════
  formName = signal('');
  formEmail = signal('');
  formPrice = signal(0);
  formSubmitted = signal(false);

  formNameError = computed(() => {
    const v = this.formName();
    if (!v) return 'Name is required';
    if (v.length < 2) return 'Min 2 characters';
    return '';
  });

  formEmailError = computed(() => {
    const v = this.formEmail();
    if (!v) return 'Email is required';
    if (!v.includes('@')) return 'Must contain @';
    return '';
  });

  formPriceError = computed(() => {
    const v = this.formPrice();
    if (v <= 0) return 'Price must be positive';
    if (v > 10000) return 'Max price is 10,000';
    return '';
  });

  formValid = computed(() =>
    !this.formNameError() && !this.formEmailError() && !this.formPriceError()
  );

  formDirty = computed(() =>
    this.formName() !== '' || this.formEmail() !== '' || this.formPrice() !== 0
  );

  formSubmittedData = computed(() =>
    JSON.stringify({ name: this.formName(), email: this.formEmail(), price: this.formPrice() })
  );

  submitForm(): void {
    if (this.formValid()) {
      this.formSubmitted.set(true);
    }
  }

  resetForm(): void {
    this.formName.set('');
    this.formEmail.set('');
    this.formPrice.set(0);
    this.formSubmitted.set(false);
  }

  getInputValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  getInputNumber(event: Event): number {
    return parseFloat((event.target as HTMLInputElement).value) || 0;
  }

  // ═══════════ Code examples ═══════════
  codeProposedApi = `// PROPOSED Signal Forms API (Experimental / RFC)
// Note: this API may change before release

import { SignalFormControl } from '@angular/forms'; // future

// A form control backed by a signal
const name = new SignalFormControl('', {
  validators: [Validators.required, Validators.minLength(2)]
});

// Read value as a signal (synchronous!)
console.log(name.value());       // ''
console.log(name.valid());       // false
console.log(name.errors());      // { required: true }

// Set value
name.setValue('Alice');
console.log(name.value());       // 'Alice'
console.log(name.valid());       // true

// In template: just call the signal
// {{ name.value() }}
// @if (!name.valid()) { <span>{{ name.errors() }}</span> }`;

  codeProposedGroup = `// PROPOSED FormGroup equivalent
const form = new SignalFormGroup({
  name: new SignalFormControl('', [Validators.required]),
  email: new SignalFormControl('', [Validators.email]),
  price: new SignalFormControl(0, [Validators.min(1)]),
});

// Derived validity — automatic via computed
// form.valid()    → computed from all controls
// form.value()    → { name: string, email: string, price: number }
// form.dirty()    → true if any control changed

// In template:
// <input [signalControl]="form.controls.name" />
// @if (!form.valid()) { <button disabled>Submit</button> }`;

  codeManualSignalForm = `// Manual signal-based form pattern (works TODAY in Angular 19)
// No experimental APIs needed!

// State
name = signal('');
email = signal('');

// Validation — computed signals
nameError = computed(() => {
  const v = this.name();
  if (!v) return 'Required';
  if (v.length < 2) return 'Min 2 chars';
  return '';
});

emailError = computed(() => {
  const v = this.email();
  if (!v) return 'Required';
  if (!v.includes('@')) return 'Invalid email';
  return '';
});

// Form-level validity
formValid = computed(() => !this.nameError() && !this.emailError());

// Template:
// <input [value]="name()" (input)="name.set($event.target.value)" />
// @if (nameError()) { <span class="error">{{ nameError() }}</span> }`;
}
