import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Staying Current with Angular Development — Topic 2 (15 min)
 *
 * Covers: RFC process, roadmap monitoring, community engagement, Angular blog
 */
@Component({
  selector: 'app-staying-current',
  imports: [UiCardComponent, UiBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="staying-page">
      <h2>Staying Current with Angular Development
        <ui-badge variant="info">Block 8 — Topic 2</ui-badge>
      </h2>

      <p class="note">
        Angular evolves rapidly. Staying informed about upcoming features, breaking changes,
        and community best practices is essential for long-term project health.
      </p>

      <!-- RFC Process -->
      <ui-card title="1. The Angular RFC Process" [elevated]="true">
        <div class="demo-section">
          <div class="rfc-flow">
            <div class="rfc-step">
              <span class="rfc-num">1</span>
              <h4>RFC Created</h4>
              <p>Angular team publishes a Request for Comments on GitHub</p>
            </div>
            <div class="rfc-arrow">&#x2192;</div>
            <div class="rfc-step">
              <span class="rfc-num">2</span>
              <h4>Community Feedback</h4>
              <p>Developers comment, suggest changes, vote</p>
            </div>
            <div class="rfc-arrow">&#x2192;</div>
            <div class="rfc-step">
              <span class="rfc-num">3</span>
              <h4>Design Finalised</h4>
              <p>Team incorporates feedback, finalises design</p>
            </div>
            <div class="rfc-arrow">&#x2192;</div>
            <div class="rfc-step">
              <span class="rfc-num">4</span>
              <h4>Implementation</h4>
              <p>Feature lands in a dev preview or stable release</p>
            </div>
          </div>

          <div class="rfc-examples">
            <h4>Notable RFCs</h4>
            <div class="rfc-grid">
              <div class="rfc-card">
                <ui-badge variant="success">Shipped</ui-badge>
                <h5>Signal-Based Components</h5>
                <p>Reactive primitives replacing Zone.js-driven CD</p>
              </div>
              <div class="rfc-card">
                <ui-badge variant="success">Shipped</ui-badge>
                <h5>Built-in Control Flow</h5>
                <p>&#64;for, &#64;if, &#64;switch replacing *ngFor, *ngIf</p>
              </div>
              <div class="rfc-card">
                <ui-badge variant="warning">In Progress</ui-badge>
                <h5>Signal-Based Forms</h5>
                <p>Reactive forms built on signals instead of Observables</p>
              </div>
              <div class="rfc-card">
                <ui-badge variant="warning">In Progress</ui-badge>
                <h5>Zoneless Angular</h5>
                <p>Complete removal of Zone.js dependency</p>
              </div>
            </div>
          </div>

          <pre class="code-block">{{ codeRfc }}</pre>
        </div>
      </ui-card>

      <!-- Roadmap -->
      <ui-card title="2. Angular Roadmap Monitoring" [elevated]="true">
        <div class="demo-section">
          <div class="roadmap-categories">
            <div class="roadmap-col">
              <h4 class="roadmap-header active-header">In Progress</h4>
              <div class="roadmap-items">
                <div class="roadmap-item">Zoneless change detection (stable)</div>
                <div class="roadmap-item">Signal-based forms</div>
                <div class="roadmap-item">Improved SSR/hydration</div>
                <div class="roadmap-item">Signal-based queries/inputs</div>
              </div>
            </div>
            <div class="roadmap-col">
              <h4 class="roadmap-header future-header">Future</h4>
              <div class="roadmap-items">
                <div class="roadmap-item">Full signal-based component model</div>
                <div class="roadmap-item">Improved developer tooling</div>
                <div class="roadmap-item">Partial hydration</div>
                <div class="roadmap-item">Build performance improvements</div>
              </div>
            </div>
            <div class="roadmap-col">
              <h4 class="roadmap-header done-header">Recently Completed</h4>
              <div class="roadmap-items">
                <div class="roadmap-item">Built-in control flow (v17)</div>
                <div class="roadmap-item">Deferrable views (v17)</div>
                <div class="roadmap-item">esbuild as default builder (v17)</div>
                <div class="roadmap-item">Standalone components default (v19)</div>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Community Resources -->
      <ui-card title="3. Community Engagement" [elevated]="true">
        <div class="demo-section">
          <div class="resources-grid">
            <div class="resource-card">
              <span class="resource-icon">&#x1F4DD;</span>
              <h5>Angular Blog</h5>
              <p>Official announcements, release posts, deep-dives</p>
              <span class="resource-url">blog.angular.dev</span>
            </div>
            <div class="resource-card">
              <span class="resource-icon">&#x1F4E2;</span>
              <h5>Angular YouTube</h5>
              <p>ng-conf talks, release overviews, tutorials</p>
              <span class="resource-url">youtube.com/&#64;Angular</span>
            </div>
            <div class="resource-card">
              <span class="resource-icon">&#x1F4AC;</span>
              <h5>Discord / Stack Overflow</h5>
              <p>Community Q&amp;A, troubleshooting, best practices</p>
              <span class="resource-url">discord.gg/angular</span>
            </div>
            <div class="resource-card">
              <span class="resource-icon">&#x1F310;</span>
              <h5>GitHub Discussions</h5>
              <p>RFCs, feature requests, issue tracking</p>
              <span class="resource-url">github.com/angular/angular</span>
            </div>
            <div class="resource-card">
              <span class="resource-icon">&#x1F4E7;</span>
              <h5>Angular Newsletter</h5>
              <p>Weekly digest of Angular news and articles</p>
              <span class="resource-url">newsletter.angular.dev</span>
            </div>
            <div class="resource-card">
              <span class="resource-icon">&#x1F3A4;</span>
              <h5>ng-conf / NG-DE / NG-BE</h5>
              <p>Annual conferences with workshops and talks</p>
              <span class="resource-url">ng-conf.org</span>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Practical Tips -->
      <ui-card title="4. Practical Tips for Teams" [elevated]="true">
        <div class="demo-section">
          <div class="tips-list">
            <div class="tip">
              <span class="tip-icon">&#x2705;</span>
              <div>
                <strong>Upgrade within 1 month of a new major release</strong>
                <p>The longer you wait, the more breaking changes accumulate. LTS support
                lasts 18 months — don't rely on it as an excuse to skip upgrades.</p>
              </div>
            </div>
            <div class="tip">
              <span class="tip-icon">&#x2705;</span>
              <div>
                <strong>Follow deprecation warnings immediately</strong>
                <p>When you see a deprecation warning, schedule time to migrate. Deprecated
                APIs are removed 2 major versions later.</p>
              </div>
            </div>
            <div class="tip">
              <span class="tip-icon">&#x2705;</span>
              <div>
                <strong>Run ng update --dry-run first</strong>
                <p>See what changes will be made without actually applying them.</p>
              </div>
            </div>
            <div class="tip">
              <span class="tip-icon">&#x2705;</span>
              <div>
                <strong>Assign an "Angular Champion" on your team</strong>
                <p>One person monitors releases, RFCs, and blog posts, then briefs the team.</p>
              </div>
            </div>
            <div class="tip">
              <span class="tip-icon">&#x2705;</span>
              <div>
                <strong>Maintain good test coverage</strong>
                <p>Upgrades are safe when you have tests that catch regressions.
                Target 80%+ code coverage for confidence.</p>
              </div>
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .staying-page { padding: 0.5rem; }
    .note { background: #e8f5e9; border: 1px solid #c8e6c9; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }

    /* RFC flow */
    .rfc-flow { display: flex; align-items: flex-start; gap: 0.5rem; margin: 0.75rem 0; flex-wrap: wrap; }
    .rfc-step { background: #f5f5f5; border-radius: 8px; padding: 0.6rem; flex: 1; min-width: 140px; }
    .rfc-num { background: #1565c0; color: white; width: 24px; height: 24px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.78rem; }
    .rfc-step h4 { margin: 0.35rem 0 0.15rem; font-size: 0.82rem; }
    .rfc-step p { font-size: 0.75rem; color: #666; margin: 0; }
    .rfc-arrow { font-size: 1.5rem; color: #999; align-self: center; }

    /* RFC grid */
    .rfc-examples h4 { margin: 0.75rem 0 0.5rem; }
    .rfc-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; }
    .rfc-card { background: #fafafa; border: 1px solid #e0e0e0; border-radius: 8px; padding: 0.5rem; }
    .rfc-card h5 { margin: 0.25rem 0 0.1rem; font-size: 0.82rem; }
    .rfc-card p { font-size: 0.75rem; color: #666; margin: 0; }

    /* Roadmap */
    .roadmap-categories { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; }
    .roadmap-header { margin: 0 0 0.5rem; font-size: 0.88rem; padding: 0.35rem 0.5rem; border-radius: 6px; }
    .active-header { background: #e3f2fd; color: #1565c0; }
    .future-header { background: #fff3e0; color: #e65100; }
    .done-header { background: #e8f5e9; color: #2e7d32; }
    .roadmap-items { display: flex; flex-direction: column; gap: 0.25rem; }
    .roadmap-item { font-size: 0.82rem; padding: 0.35rem 0.5rem; background: #fafafa; border-radius: 6px; border-left: 3px solid #e0e0e0; }

    /* Resources */
    .resources-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; }
    .resource-card { background: #f5f5f5; border-radius: 8px; padding: 0.6rem; text-align: center; }
    .resource-icon { font-size: 1.5rem; }
    .resource-card h5 { margin: 0.25rem 0 0.1rem; font-size: 0.82rem; }
    .resource-card p { font-size: 0.72rem; color: #666; margin: 0 0 0.25rem; }
    .resource-url { font-size: 0.7rem; color: #1565c0; font-family: monospace; }

    /* Tips */
    .tips-list { display: flex; flex-direction: column; gap: 0.5rem; }
    .tip { display: flex; gap: 0.5rem; padding: 0.5rem; background: #f8f9fa; border-radius: 8px; }
    .tip-icon { font-size: 1.1rem; flex-shrink: 0; }
    .tip strong { font-size: 0.85rem; }
    .tip p { font-size: 0.78rem; color: #666; margin: 0.15rem 0 0; }
  `]
})
export class StayingCurrentComponent {
  codeRfc = `# How to participate in Angular RFCs
# 1. Watch the angular/angular repository on GitHub
# 2. Filter issues by "RFC" label
# 3. Read the RFC document and provide constructive feedback
# 4. Vote with thumbs up/down reactions

# Current RFC repository: github.com/angular/angular/discussions
# Categories: Feature Requests, RFCs, Q&A

# Tip: Subscribe to RFC notifications
# GitHub → angular/angular → Watch → Custom → Discussions`;
}
