import { Route } from '@angular/router';
import { StayingCurrentComponent } from './staying-current.component';

export const STAYING_CURRENT_ROUTES: Route[] = [
  { path: '', component: StayingCurrentComponent }
];
