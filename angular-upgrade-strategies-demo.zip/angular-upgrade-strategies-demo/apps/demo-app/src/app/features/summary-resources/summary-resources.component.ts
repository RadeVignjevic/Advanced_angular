import { Component, ChangeDetectionStrategy } from '@angular/core';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Summary and Recommended Resources — Topic 5 (10 min)
 *
 * Covers: course recap, key learning outcomes, reference materials,
 *         next steps for continued learning
 */
@Component({
  selector: 'app-summary-resources',
  imports: [UiCardComponent, UiBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="summary-page">
      <h2>Summary and Recommended Resources
        <ui-badge variant="info">Block 8 — Topic 5</ui-badge>
        <ui-badge variant="success">Course Finale</ui-badge>
      </h2>

      <p class="note">
        Consolidation of key learning outcomes from all 8 blocks and distribution
        of reference materials for continued learning.
      </p>

      <!-- Course Recap -->
      <ui-card title="1. Course Recap — 8 Blocks" [elevated]="true">
        <div class="demo-section">
          <div class="blocks-recap">
            @for (block of blocks; track block.num) {
              <div class="block-card" [style.border-left-color]="block.color">
                <div class="block-header">
                  <span class="block-num" [style.background]="block.color">B{{ block.num }}</span>
                  <h4>{{ block.title }}</h4>
                  <ui-badge variant="neutral">{{ block.duration }}</ui-badge>
                </div>
                <div class="block-takeaways">
                  @for (takeaway of block.takeaways; track takeaway) {
                    <span class="takeaway">{{ takeaway }}</span>
                  }
                </div>
              </div>
            }
          </div>
        </div>
      </ui-card>

      <!-- Key Outcomes -->
      <ui-card title="2. Key Learning Outcomes" [elevated]="true">
        <div class="demo-section">
          <div class="outcomes-grid">
            <div class="outcome-card">
              <span class="outcome-icon">&#x1F3D7;</span>
              <h4>Architecture</h4>
              <p>Design scalable apps with Nx monorepo, shared libraries, and standalone components</p>
            </div>
            <div class="outcome-card">
              <span class="outcome-icon">&#x26A1;</span>
              <h4>Signals</h4>
              <p>Use signal(), computed(), effect(), and signal-based inputs/queries for reactive state</p>
            </div>
            <div class="outcome-card">
              <span class="outcome-icon">&#x1F50D;</span>
              <h4>Change Detection</h4>
              <p>Understand and optimise CD with OnPush, signals, and zone-aware patterns</p>
            </div>
            <div class="outcome-card">
              <span class="outcome-icon">&#x1F4E6;</span>
              <h4>State Management</h4>
              <p>Implement NgRx Signal Store with custom features, entities, and computed slices</p>
            </div>
            <div class="outcome-card">
              <span class="outcome-icon">&#x1F504;</span>
              <h4>Migration</h4>
              <p>Incrementally migrate RxJS-based code to signals with toSignal/toObservable</p>
            </div>
            <div class="outcome-card">
              <span class="outcome-icon">&#x1F680;</span>
              <h4>Performance</h4>
              <p>Profile and optimise with Lighthouse, DevTools, virtual scrolling, and &#64;defer</p>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Reference Materials -->
      <ui-card title="3. Reference Materials" [elevated]="true">
        <div class="demo-section">
          <div class="ref-categories">
            <div class="ref-category">
              <h4>&#x1F4D6; Official Documentation</h4>
              <div class="ref-list">
                <div class="ref-item">
                  <strong>Angular Documentation</strong>
                  <span class="ref-url">angular.dev</span>
                </div>
                <div class="ref-item">
                  <strong>Angular Update Guide (Interactive)</strong>
                  <span class="ref-url">update.angular.dev</span>
                </div>
                <div class="ref-item">
                  <strong>Angular Roadmap</strong>
                  <span class="ref-url">angular.dev/roadmap</span>
                </div>
                <div class="ref-item">
                  <strong>Angular RFCs on GitHub</strong>
                  <span class="ref-url">github.com/angular/angular/discussions</span>
                </div>
                <div class="ref-item">
                  <strong>Angular Blog</strong>
                  <span class="ref-url">blog.angular.dev</span>
                </div>
              </div>
            </div>
            <div class="ref-category">
              <h4>&#x1F9F0; Tools &amp; Libraries</h4>
              <div class="ref-list">
                <div class="ref-item">
                  <strong>Nx Dev Tools</strong>
                  <span class="ref-url">nx.dev</span>
                </div>
                <div class="ref-item">
                  <strong>NgRx Signal Store</strong>
                  <span class="ref-url">ngrx.io/guide/signals</span>
                </div>
                <div class="ref-item">
                  <strong>Angular CDK</strong>
                  <span class="ref-url">material.angular.io/cdk</span>
                </div>
                <div class="ref-item">
                  <strong>Angular DevTools (Chrome)</strong>
                  <span class="ref-url">chrome.google.com/webstore</span>
                </div>
                <div class="ref-item">
                  <strong>Source Map Explorer</strong>
                  <span class="ref-url">npmjs.com/package/source-map-explorer</span>
                </div>
              </div>
            </div>
            <div class="ref-category">
              <h4>&#x1F4DA; Further Learning</h4>
              <div class="ref-list">
                <div class="ref-item">
                  <strong>Angular University (courses)</strong>
                  <span class="ref-url">angular-university.io</span>
                </div>
                <div class="ref-item">
                  <strong>Angular In Depth (articles)</strong>
                  <span class="ref-url">angularindepth.com</span>
                </div>
                <div class="ref-item">
                  <strong>ng-conf YouTube</strong>
                  <span class="ref-url">youtube.com/ng-conf</span>
                </div>
                <div class="ref-item">
                  <strong>Architecture Patterns (book)</strong>
                  <span class="ref-url">Enterprise Angular by Manfred Steyer</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Next Steps -->
      <ui-card title="4. Your Next Steps" [elevated]="true">
        <div class="demo-section">
          <div class="next-steps">
            <div class="next-timeline">
              <div class="next-item">
                <span class="next-when">This Week</span>
                <div class="next-actions">
                  <span>Run ng update on your project to latest Angular</span>
                  <span>Add OnPush to 5 components as a warm-up</span>
                  <span>Install Angular DevTools and profile one page</span>
                </div>
              </div>
              <div class="next-item">
                <span class="next-when">This Month</span>
                <div class="next-actions">
                  <span>Convert one BehaviorSubject service to signals</span>
                  <span>Implement one feature with NgRx Signal Store</span>
                  <span>Add lazy loading to your largest feature module</span>
                </div>
              </div>
              <div class="next-item">
                <span class="next-when">This Quarter</span>
                <div class="next-actions">
                  <span>Evaluate Nx for your team/organisation</span>
                  <span>Set up Lighthouse CI in your build pipeline</span>
                  <span>Create shared UI/data-access libraries</span>
                </div>
              </div>
              <div class="next-item">
                <span class="next-when">Long Term</span>
                <div class="next-actions">
                  <span>Complete RxJS-to-signals migration for template state</span>
                  <span>Prepare for zoneless Angular (all signals, all OnPush)</span>
                  <span>Maintain a regular Angular upgrade cadence</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Thank You -->
      <div class="thank-you">
        <h3>Thank you for completing the course!</h3>
        <p>Modern Angular Architecture and Reactive Primitives</p>
        <div class="course-stats">
          <div class="stat">
            <span class="stat-num">8</span>
            <span class="stat-label">Blocks</span>
          </div>
          <div class="stat">
            <span class="stat-num">16</span>
            <span class="stat-label">Hours</span>
          </div>
          <div class="stat">
            <span class="stat-num">30+</span>
            <span class="stat-label">Topics</span>
          </div>
          <div class="stat">
            <span class="stat-num">8</span>
            <span class="stat-label">Workshops</span>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .summary-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .demo-section { padding: 0.5rem 0; }

    /* Blocks recap */
    .blocks-recap { display: flex; flex-direction: column; gap: 0.5rem; }
    .block-card { border-left: 4px solid; background: #f8f9fa; border-radius: 0 8px 8px 0; padding: 0.5rem 0.6rem; }
    .block-header { display: flex; align-items: center; gap: 0.5rem; }
    .block-num { color: white; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.72rem; font-weight: 700; }
    .block-card h4 { margin: 0; font-size: 0.82rem; flex: 1; }
    .block-takeaways { display: flex; flex-wrap: wrap; gap: 0.25rem; margin-top: 0.35rem; }
    .takeaway { font-size: 0.72rem; background: white; padding: 0.15rem 0.4rem; border-radius: 4px; border: 1px solid #e0e0e0; color: #555; }

    /* Outcomes */
    .outcomes-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; }
    .outcome-card { background: #f8f9fa; border: 2px solid #e9ecef; border-radius: 8px; padding: 0.6rem; text-align: center; }
    .outcome-icon { font-size: 1.5rem; }
    .outcome-card h4 { margin: 0.25rem 0; font-size: 0.85rem; }
    .outcome-card p { font-size: 0.75rem; color: #666; margin: 0; }

    /* References */
    .ref-categories { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; }
    .ref-category h4 { margin: 0 0 0.5rem; font-size: 0.85rem; }
    .ref-list { display: flex; flex-direction: column; gap: 0.25rem; }
    .ref-item { padding: 0.35rem 0.5rem; background: #f8f9fa; border-radius: 6px; }
    .ref-item strong { font-size: 0.82rem; display: block; }
    .ref-url { font-size: 0.72rem; color: #1565c0; font-family: monospace; }

    /* Next steps */
    .next-timeline { display: flex; flex-direction: column; gap: 0.75rem; }
    .next-item { display: flex; gap: 0.75rem; }
    .next-when { background: #1565c0; color: white; padding: 0.3rem 0.5rem; border-radius: 6px; font-weight: 700; font-size: 0.78rem; white-space: nowrap; min-width: 90px; text-align: center; height: fit-content; }
    .next-actions { display: flex; flex-direction: column; gap: 0.2rem; }
    .next-actions span { font-size: 0.82rem; padding: 0.2rem 0.4rem; background: #f8f9fa; border-radius: 4px; border-left: 3px solid #1565c0; }

    /* Thank you */
    .thank-you { text-align: center; padding: 1.5rem; margin: 1rem 0; background: linear-gradient(135deg, #1565c0 0%, #7b1fa2 100%); border-radius: 16px; color: white; }
    .thank-you h3 { margin: 0; font-size: 1.3rem; }
    .thank-you p { margin: 0.25rem 0 1rem; opacity: 0.9; font-size: 0.88rem; }
    .course-stats { display: flex; justify-content: center; gap: 2rem; }
    .stat { text-align: center; }
    .stat-num { display: block; font-size: 1.8rem; font-weight: 700; }
    .stat-label { font-size: 0.78rem; opacity: 0.8; }
  `]
})
export class SummaryResourcesComponent {
  blocks = [
    { num: 1, title: 'Angular CLI Foundations', duration: '2h', color: '#e53935',
      takeaways: ['CLI scaffolding', 'Workspace config', 'Build & serve'] },
    { num: 2, title: 'Nx Monorepo Architecture', duration: '2h', color: '#fb8c00',
      takeaways: ['Nx workspace', 'Shared libraries', 'Smart/dumb components', 'DI tokens'] },
    { num: 3, title: 'Angular Signals', duration: '2h', color: '#43a047',
      takeaways: ['signal()', 'computed()', 'effect()', 'toSignal/toObservable'] },
    { num: 4, title: 'Change Detection', duration: '2h', color: '#1e88e5',
      takeaways: ['OnPush strategy', 'Signal-driven CD', 'Profiling', 'Common pitfalls'] },
    { num: 5, title: 'NgRx Signal Store', duration: '2h', color: '#8e24aa',
      takeaways: ['signalStore()', 'withEntities()', 'withMethods()', 'Custom features'] },
    { num: 6, title: 'RxJS → Signals Migration', duration: '1.5h', color: '#00acc1',
      takeaways: ['Migration strategy', 'resource()/rxResource()', 'Signal forms', 'Service conversion'] },
    { num: 7, title: 'Performance Optimisation', duration: '2h', color: '#d81b60',
      takeaways: ['Bundle analysis', 'Virtual scrolling', 'Zoneless prep', 'Lighthouse profiling'] },
    { num: 8, title: 'Upgrade Strategies & Conclusion', duration: '2h', color: '#5e35b1',
      takeaways: ['ng update workflow', 'RFC process', 'Peer review', 'Next steps'] },
  ];
}
