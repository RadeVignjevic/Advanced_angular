import { Route } from '@angular/router';
import { SummaryResourcesComponent } from './summary-resources.component';

export const SUMMARY_RESOURCES_ROUTES: Route[] = [
  { path: '', component: SummaryResourcesComponent }
];
