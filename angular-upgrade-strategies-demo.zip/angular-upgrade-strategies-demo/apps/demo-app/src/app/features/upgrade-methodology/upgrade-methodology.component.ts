import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { UiCardComponent, UiBadgeComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Angular Upgrade Methodology — Topic 1 (30 min)
 *
 * Covers: ng update, semver, breaking changes, automation, update guide
 */
@Component({
  selector: 'app-upgrade-methodology',
  imports: [UiCardComponent, UiBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="upgrade-page">
      <h2>Angular Upgrade Methodology
        <ui-badge variant="info">Block 8 — Topic 1</ui-badge>
      </h2>

      <p class="note">
        Angular follows a <strong>predictable 6-month release cycle</strong> with semantic
        versioning. This topic covers how to plan, execute, and automate Angular version
        upgrades safely.
      </p>

      <!-- Release Cycle -->
      <ui-card title="1. Angular Release Cadence" [elevated]="true">
        <div class="demo-section">
          <div class="timeline">
            <div class="timeline-item major">
              <div class="timeline-marker"></div>
              <div class="timeline-content">
                <h4>Major (vX.0.0)</h4>
                <p>Every 6 months. May contain breaking changes.</p>
                <ui-badge variant="danger">Breaking Changes Possible</ui-badge>
              </div>
            </div>
            <div class="timeline-item minor">
              <div class="timeline-marker"></div>
              <div class="timeline-content">
                <h4>Minor (vX.Y.0)</h4>
                <p>1–3 per major. New features, no breaking changes.</p>
                <ui-badge variant="info">New Features</ui-badge>
              </div>
            </div>
            <div class="timeline-item patch">
              <div class="timeline-marker"></div>
              <div class="timeline-content">
                <h4>Patch (vX.Y.Z)</h4>
                <p>Weekly. Bug fixes only.</p>
                <ui-badge variant="success">Bug Fixes</ui-badge>
              </div>
            </div>
          </div>

          <div class="version-table">
            <h4>Recent Angular Versions</h4>
            <div class="vtable-header">
              <span>Version</span>
              <span>Key Features</span>
              <span>Status</span>
            </div>
            @for (v of versions; track v.version) {
              <div class="vtable-row">
                <span class="v-num">{{ v.version }}</span>
                <span>{{ v.features }}</span>
                <ui-badge [variant]="v.badge">{{ v.status }}</ui-badge>
              </div>
            }
          </div>
        </div>
      </ui-card>

      <!-- ng update -->
      <ui-card title="2. The ng update Command" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeNgUpdate }}</pre>

          <h4>How ng update Works</h4>
          <div class="steps-flow">
            <div class="flow-step">
              <span class="step-num">1</span>
              <div>
                <strong>Analyses package.json</strong>
                <p>Reads current versions and determines target</p>
              </div>
            </div>
            <div class="flow-step">
              <span class="step-num">2</span>
              <div>
                <strong>Runs schematics</strong>
                <p>Executes code-migration schematics (automatic code transforms)</p>
              </div>
            </div>
            <div class="flow-step">
              <span class="step-num">3</span>
              <div>
                <strong>Updates dependencies</strong>
                <p>Modifies package.json and runs npm install</p>
              </div>
            </div>
            <div class="flow-step">
              <span class="step-num">4</span>
              <div>
                <strong>Reports results</strong>
                <p>Shows what was migrated and what requires manual attention</p>
              </div>
            </div>
          </div>

          <div class="warning-box">
            <strong>&#x26a0; Always commit before running ng update!</strong>
            <p>The schematics modify your source code. Having a clean git state lets you
            review and revert changes if needed.</p>
          </div>
        </div>
      </ui-card>

      <!-- Breaking Changes -->
      <ui-card title="3. Identifying Breaking Changes" [elevated]="true">
        <div class="demo-section">
          <div class="tool-header">
            <h4>Angular Update Guide</h4>
            <ui-badge variant="success">update.angular.io</ui-badge>
          </div>

          <pre class="code-block">{{ codeUpdateGuide }}</pre>

          <div class="breaking-categories">
            <div class="bc-card">
              <h5>API Removals</h5>
              <p>Deprecated APIs removed after 2 major versions</p>
              <span class="bc-example">e.g., ViewEngine APIs removed in v17</span>
            </div>
            <div class="bc-card">
              <h5>Behaviour Changes</h5>
              <p>Same API, different default behaviour</p>
              <span class="bc-example">e.g., standalone: true default in v19</span>
            </div>
            <div class="bc-card">
              <h5>Dependency Updates</h5>
              <p>TypeScript, RxJS, zone.js version requirements</p>
              <span class="bc-example">e.g., Angular 19 requires TypeScript 5.5+</span>
            </div>
            <div class="bc-card">
              <h5>Tooling Changes</h5>
              <p>Build system, CLI config format changes</p>
              <span class="bc-example">e.g., esbuild replacing webpack as default</span>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Automation -->
      <ui-card title="4. Automating Upgrades" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeAutomation }}</pre>

          <h4>Automation Strategy</h4>
          <div class="automation-grid">
            <div class="auto-card">
              <ui-badge variant="info">Dependabot / Renovate</ui-badge>
              <p>Auto-create PRs for dependency updates</p>
            </div>
            <div class="auto-card">
              <ui-badge variant="info">CI Pipeline</ui-badge>
              <p>Auto-build + test on upgrade PRs</p>
            </div>
            <div class="auto-card">
              <ui-badge variant="info">Nx migrate</ui-badge>
              <p>For Nx workspaces — generates migrations.json</p>
            </div>
            <div class="auto-card">
              <ui-badge variant="info">Canary Branch</ui-badge>
              <p>Test upgrades on a long-lived branch before merging</p>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Upgrade Checklist -->
      <ui-card title="5. Upgrade Checklist" [elevated]="true">
        <div class="demo-section">
          <h4>Interactive Checklist</h4>
          <div class="checklist">
            @for (item of checklist; track item.id) {
              <div class="checklist-item" (click)="toggleCheck(item.id)"
                [class.checked]="item.checked()">
                <span class="check-box">{{ item.checked() ? '&#x2611;' : '&#x2610;' }}</span>
                <span class="check-text">{{ item.text }}</span>
              </div>
            }
          </div>
          <div class="progress-bar">
            <div class="progress-fill" [style.width.%]="checklistProgress()"></div>
          </div>
          <span class="progress-text">{{ checklistProgress() }}% complete</span>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .upgrade-page { padding: 0.5rem; }
    .note { background: #e3f2fd; border: 1px solid #bbdefb; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .tool-header { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.5rem; }
    .tool-header h4 { margin: 0; }

    /* Timeline */
    .timeline { position: relative; padding-left: 2rem; margin: 0.75rem 0; }
    .timeline::before { content: ''; position: absolute; left: 0.6rem; top: 0; bottom: 0; width: 3px; background: #e0e0e0; }
    .timeline-item { position: relative; margin-bottom: 1rem; }
    .timeline-marker { position: absolute; left: -1.65rem; top: 0.2rem; width: 14px; height: 14px; border-radius: 50%; border: 3px solid; }
    .major .timeline-marker { border-color: #e53935; background: #ffcdd2; }
    .minor .timeline-marker { border-color: #1e88e5; background: #bbdefb; }
    .patch .timeline-marker { border-color: #43a047; background: #c8e6c9; }
    .timeline-content h4 { margin: 0; font-size: 0.88rem; }
    .timeline-content p { margin: 0.15rem 0 0.35rem; font-size: 0.82rem; color: #666; }

    /* Version table */
    .version-table { margin: 0.75rem 0; }
    .version-table h4 { margin: 0 0 0.5rem; }
    .vtable-header { display: grid; grid-template-columns: 80px 1fr 100px; background: #1565c0; color: white; font-weight: 600; font-size: 0.82rem; border-radius: 8px 8px 0 0; }
    .vtable-header span { padding: 0.5rem 0.6rem; }
    .vtable-row { display: grid; grid-template-columns: 80px 1fr 100px; font-size: 0.8rem; border: 1px solid #e0e0e0; border-top: none; align-items: center; }
    .vtable-row span { padding: 0.4rem 0.6rem; }
    .v-num { font-weight: 700; color: #1565c0; }

    /* Steps flow */
    .steps-flow { display: flex; flex-direction: column; gap: 0.75rem; margin: 0.75rem 0; }
    .flow-step { display: flex; gap: 0.75rem; align-items: flex-start; }
    .step-num { background: #1565c0; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.82rem; flex-shrink: 0; }
    .flow-step p { font-size: 0.82rem; color: #666; margin: 0.2rem 0 0; }

    /* Warning */
    .warning-box { background: #fff3e0; border: 2px solid #ff9800; border-radius: 8px; padding: 0.75rem; margin: 0.75rem 0; }
    .warning-box p { font-size: 0.82rem; margin: 0.25rem 0 0; color: #666; }

    /* Breaking categories */
    .breaking-categories { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; margin: 0.75rem 0; }
    .bc-card { background: #fafafa; border: 1px solid #e0e0e0; border-radius: 8px; padding: 0.6rem; }
    .bc-card h5 { margin: 0 0 0.2rem; font-size: 0.85rem; }
    .bc-card p { font-size: 0.78rem; color: #666; margin: 0; }
    .bc-example { font-size: 0.72rem; color: #999; font-style: italic; }

    /* Automation */
    .automation-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; margin: 0.75rem 0; }
    .auto-card { background: #f5f5f5; border-radius: 8px; padding: 0.5rem; }
    .auto-card p { font-size: 0.78rem; margin: 0.25rem 0 0; color: #666; }

    /* Checklist */
    .checklist { display: flex; flex-direction: column; gap: 0.15rem; margin: 0.5rem 0; }
    .checklist-item { display: flex; align-items: center; gap: 0.5rem; padding: 0.4rem 0.5rem; cursor: pointer; border-radius: 6px; transition: background 0.15s; font-size: 0.85rem; }
    .checklist-item:hover { background: #f5f5f5; }
    .checklist-item.checked .check-text { text-decoration: line-through; color: #999; }
    .check-box { font-size: 1.1rem; }
    .progress-bar { height: 8px; background: #e0e0e0; border-radius: 4px; margin: 0.5rem 0 0.25rem; overflow: hidden; }
    .progress-fill { height: 100%; background: #43a047; border-radius: 4px; transition: width 0.3s; }
    .progress-text { font-size: 0.78rem; color: #666; }
  `]
})
export class UpgradeMethodologyComponent {
  // ═══════════ Version table data ═══════════
  versions: { version: string; features: string; status: string; badge: 'success' | 'warning' | 'danger' | 'info' | 'neutral' }[] = [
    { version: 'v19', features: 'Standalone default, linkedSignal, resource()', status: 'Current', badge: 'success' },
    { version: 'v18', features: 'Zoneless preview, Material 3, @let syntax', status: 'LTS', badge: 'info' },
    { version: 'v17', features: '@for/@if/@switch, esbuild default, @defer', status: 'LTS', badge: 'info' },
    { version: 'v16', features: 'Signals (dev preview), standalone APIs', status: 'End of Life', badge: 'danger' },
    { version: 'v15', features: 'Standalone components stable, directive composition', status: 'End of Life', badge: 'danger' },
  ];

  // ═══════════ Interactive checklist ═══════════
  checklist = [
    { id: 1, text: 'Read release blog post and changelog', checked: signal(false) },
    { id: 2, text: 'Check Angular Update Guide (update.angular.io)', checked: signal(false) },
    { id: 3, text: 'Ensure clean git state (commit or stash)', checked: signal(false) },
    { id: 4, text: 'Run ng update @angular/cli @angular/core', checked: signal(false) },
    { id: 5, text: 'Review and test automatic code migrations', checked: signal(false) },
    { id: 6, text: 'Update third-party dependencies', checked: signal(false) },
    { id: 7, text: 'Run full test suite', checked: signal(false) },
    { id: 8, text: 'Test critical user flows manually', checked: signal(false) },
    { id: 9, text: 'Review bundle size for regressions', checked: signal(false) },
    { id: 10, text: 'Deploy to staging and smoke test', checked: signal(false) },
  ];

  toggleCheck(id: number): void {
    const item = this.checklist.find(c => c.id === id);
    if (item) item.checked.update(v => !v);
  }

  checklistProgress(): number {
    const total = this.checklist.length;
    const done = this.checklist.filter(c => c.checked()).length;
    return Math.round((done / total) * 100);
  }

  // ═══════════ Code examples ═══════════
  codeNgUpdate = `# Standard Angular upgrade workflow
# Step 1: Check what needs updating
ng update

# Step 2: Update Angular core packages
ng update @angular/cli @angular/core

# Step 3: Update Angular Material (if used)
ng update @angular/material

# Step 4: Update other Angular packages
ng update @angular/cdk @ngrx/store @ngrx/signals

# Step 5: Check for typescript version and other peer dependencies
npm install -D typescript@latest

# For Nx workspaces:
npx nx migrate 18.2.4
npx nx migrate latest
npx nx migrate --run-migrations

# Skip specific migration:
ng update @angular/core --migrate-only --from=18 --to=19`;

  codeUpdateGuide = `# Angular Update Guide: update.angular.dev
# 1. Select your current and target versions
# 2. Choose complexity level (Basic / Medium / Advanced)
# 3. Get a personalised checklist of changes

# Common breaking change patterns:
# - Deprecated API removed after 2 major versions
# - TypeScript version requirement bumped
# - RxJS minimum version increased
# - Default behaviour changed (opt-in → opt-out)
# - Build tooling changes (Webpack → esbuild)

# Pro tip: Subscribe to angular/angular releases on GitHub
# to get notified of new versions immediately`;

  codeAutomation = `# Renovate config for Angular (renovate.json)
{
  "extends": ["config:base"],
  "packageRules": [
    {
      "matchPackagePatterns": ["@angular/*"],
      "groupName": "Angular",
      "automerge": false,
      "schedule": ["after 1pm on Monday"]
    },
    {
      "matchPackagePatterns": ["@ngrx/*"],
      "groupName": "NgRx",
      "automerge": false
    }
  ]
}

# GitHub Actions — test on upgrade PR
# .github/workflows/upgrade-test.yml
# on: pull_request
# jobs:
#   test:
#     runs-on: ubuntu-latest
#     steps:
#       - uses: actions/checkout@v4
#       - run: npm ci
#       - run: npx nx run-many --target=build --all
#       - run: npx nx run-many --target=test --all`;
}
