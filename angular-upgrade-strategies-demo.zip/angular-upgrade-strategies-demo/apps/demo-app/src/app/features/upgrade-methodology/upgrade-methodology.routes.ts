import { Route } from '@angular/router';
import { UpgradeMethodologyComponent } from './upgrade-methodology.component';

export const UPGRADE_METHODOLOGY_ROUTES: Route[] = [
  { path: '', component: UpgradeMethodologyComponent }
];
