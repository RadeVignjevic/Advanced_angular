import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { UiCardComponent, UiBadgeComponent, UiButtonComponent } from '@angular-monorepo-demo/shared-ui';

/**
 * Zoneless Angular — Topic 3 (20 min)
 *
 * Covers: experimental zoneless CD, removing zone.js, signal-driven rendering,
 *         library compatibility, migration path
 */
@Component({
  selector: 'app-zoneless-angular',
  imports: [UiCardComponent, UiBadgeComponent, UiButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="zoneless-page">
      <h2>Zoneless Angular
        <ui-badge variant="info">Block 7 — Topic 3</ui-badge>
        <ui-badge variant="warning">Experimental</ui-badge>
      </h2>

      <p class="note">
        Angular has relied on <strong>Zone.js</strong> to trigger change detection since v2.
        With Angular 19, an <strong>experimental zoneless mode</strong> lets signals drive
        change detection directly — smaller bundles, simpler mental model, better performance.
      </p>

      <!-- What is Zone.js -->
      <ui-card title="1. What Zone.js Does (and Why We Want to Remove It)" [elevated]="true">
        <div class="demo-section">
          <div class="zone-flow">
            <div class="flow-step zone-step">
              <h4>With Zone.js</h4>
              <div class="flow-diagram">
                <span class="flow-box">User Click</span>
                <span class="flow-arrow">&#x2192;</span>
                <span class="flow-box zone-highlight">Zone.js intercepts</span>
                <span class="flow-arrow">&#x2192;</span>
                <span class="flow-box">Handler runs</span>
                <span class="flow-arrow">&#x2192;</span>
                <span class="flow-box zone-highlight">Zone triggers CD</span>
                <span class="flow-arrow">&#x2192;</span>
                <span class="flow-box">All components checked</span>
              </div>
            </div>
            <div class="flow-step zoneless-step">
              <h4>Without Zone.js (Signals)</h4>
              <div class="flow-diagram">
                <span class="flow-box">User Click</span>
                <span class="flow-arrow">&#x2192;</span>
                <span class="flow-box">Handler updates signal</span>
                <span class="flow-arrow">&#x2192;</span>
                <span class="flow-box signal-highlight">Signal notifies Angular</span>
                <span class="flow-arrow">&#x2192;</span>
                <span class="flow-box signal-highlight">Only affected views update</span>
              </div>
            </div>
          </div>

          <div class="zone-problems">
            <h4>Why Remove Zone.js?</h4>
            <div class="problem-grid">
              <div class="problem-card">
                <ui-badge variant="danger">~100 KB</ui-badge>
                <p>Added to every bundle</p>
              </div>
              <div class="problem-card">
                <ui-badge variant="danger">Monkey-patches</ui-badge>
                <p>setTimeout, Promise, fetch, addEventListener…</p>
              </div>
              <div class="problem-card">
                <ui-badge variant="danger">Over-triggers</ui-badge>
                <p>CD runs even for irrelevant async events</p>
              </div>
              <div class="problem-card">
                <ui-badge variant="danger">Debugging</ui-badge>
                <p>Long stack traces through zone frames</p>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Enabling Zoneless -->
      <ui-card title="2. Enabling Zoneless Mode" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeEnableZoneless }}</pre>

          <h4>Steps to Go Zoneless</h4>
          <div class="steps-list">
            <div class="step">
              <span class="step-num">1</span>
              <div>
                <strong>Add the provider</strong>
                <p>Use <code>provideExperimentalZonelessChangeDetection()</code> in your app config.</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">2</span>
              <div>
                <strong>Remove zone.js from polyfills</strong>
                <p>Delete <code>zone.js</code> from <code>angular.json</code> polyfills array.</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">3</span>
              <div>
                <strong>Uninstall zone.js</strong>
                <p>Run <code>npm uninstall zone.js</code> to drop ~100 KB from the bundle.</p>
              </div>
            </div>
            <div class="step">
              <span class="step-num">4</span>
              <div>
                <strong>Ensure all state uses signals</strong>
                <p>Without Zone.js, only signal changes trigger updates.</p>
              </div>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- What Changes -->
      <ui-card title="3. What Changes Without Zone.js" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeZonelessComponent }}</pre>

          <div class="change-table">
            <div class="change-header">
              <span>Pattern</span>
              <span>With Zone.js</span>
              <span>Without Zone.js</span>
            </div>
            <div class="change-row">
              <span>Template binding</span>
              <span class="works">interpolation works</span>
              <span class="signal">Must use signal() reads</span>
            </div>
            <div class="change-row">
              <span>setTimeout callback</span>
              <span class="works">Auto-triggers CD</span>
              <span class="signal">No CD unless signal updated</span>
            </div>
            <div class="change-row">
              <span>HTTP response</span>
              <span class="works">Auto-triggers CD</span>
              <span class="signal">Use toSignal() or update a signal</span>
            </div>
            <div class="change-row">
              <span>&#64;Input changes</span>
              <span class="works">Triggers CD on parent check</span>
              <span class="signal">Use input() signal function</span>
            </div>
            <div class="change-row">
              <span>Manual markForCheck</span>
              <span class="works">Schedules CD</span>
              <span class="signal">Not needed — signals handle it</span>
            </div>
          </div>
        </div>
      </ui-card>

      <!-- Live Demo -->
      <ui-card title="4. Live Demo: Signal-Driven Rendering" [elevated]="true">
        <div class="demo-section">
          <h4>This component uses OnPush + Signals (zoneless-compatible)</h4>
          <div class="live-demo">
            <div class="demo-controls">
              <ui-button variant="primary" size="sm" (clicked)="increment()">Increment</ui-button>
              <ui-button variant="secondary" size="sm" (clicked)="decrement()">Decrement</ui-button>
              <ui-button variant="ghost" size="sm" (clicked)="reset()">Reset</ui-button>
            </div>

            <div class="demo-values">
              <div class="value-card">
                <span class="label">Count</span>
                <span class="value">{{ count() }}</span>
              </div>
              <div class="value-card">
                <span class="label">Doubled</span>
                <span class="value">{{ doubled() }}</span>
              </div>
              <div class="value-card">
                <span class="label">Is Even?</span>
                <span class="value">{{ isEven() ? 'Yes' : 'No' }}</span>
              </div>
              <div class="value-card">
                <span class="label">Category</span>
                <span class="value">{{ category() }}</span>
              </div>
            </div>

            <p class="explanation-text">
              All four values derive from a single <code>count</code> signal.
              <code>doubled</code>, <code>isEven</code>, and <code>category</code> are computed signals
              that automatically re-evaluate only when <code>count</code> changes.
              No Zone.js required.
            </p>
          </div>
        </div>
      </ui-card>

      <!-- Migration Path -->
      <ui-card title="5. Migration Path" [elevated]="true">
        <div class="demo-section">
          <pre class="code-block">{{ codeMigration }}</pre>

          <div class="migration-checklist">
            <h4>Zoneless Readiness Checklist</h4>
            <div class="checklist-item">
              <span class="check">&#x2713;</span>
              All components use <code>ChangeDetectionStrategy.OnPush</code>
            </div>
            <div class="checklist-item">
              <span class="check">&#x2713;</span>
              All template state uses signals or computed
            </div>
            <div class="checklist-item">
              <span class="check">&#x2713;</span>
              No reliance on Zone.js auto-triggering (setTimeout, setInterval)
            </div>
            <div class="checklist-item">
              <span class="check">&#x2713;</span>
              Third-party libraries tested for zoneless compat
            </div>
            <div class="checklist-item">
              <span class="check">&#x2713;</span>
              No manual <code>ChangeDetectorRef.detectChanges()</code> hacks
            </div>
            <div class="checklist-item">
              <span class="check">&#x2713;</span>
              All RxJS streams converted to signals where used in templates
            </div>
          </div>
        </div>
      </ui-card>
    </div>
  `,
  styles: [`
    .zoneless-page { padding: 0.5rem; }
    .note { background: #fff3e0; border: 1px solid #ffe0b2; padding: 0.75rem; border-radius: 8px; margin: 1rem 0; font-size: 0.9rem; }
    .code-block { background: #1e1e2e; color: #cdd6f4; padding: 1rem; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 0.82rem; overflow-x: auto; white-space: pre; margin: 0.75rem 0; }
    .demo-section { padding: 0.5rem 0; }
    .explanation-text { font-size: 0.88rem; color: #555; line-height: 1.5; margin: 0.75rem 0 0; }
    .explanation-text code { background: #e8eaf6; padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.82rem; }

    /* Flow diagrams */
    .zone-flow { display: flex; flex-direction: column; gap: 1rem; margin: 0.75rem 0; }
    .flow-step h4 { margin: 0 0 0.5rem; font-size: 0.88rem; }
    .flow-diagram { display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap; }
    .flow-box { background: #f5f5f5; border: 2px solid #e0e0e0; padding: 0.4rem 0.6rem; border-radius: 8px; font-size: 0.78rem; }
    .flow-arrow { color: #999; font-size: 1.2rem; }
    .zone-highlight { background: #ffebee; border-color: #ef5350; color: #b71c1c; font-weight: 600; }
    .signal-highlight { background: #e8f5e9; border-color: #66bb6a; color: #1b5e20; font-weight: 600; }
    .zoneless-step .flow-diagram .flow-box:not(.signal-highlight) { border-color: #81c784; }

    /* Problem grid */
    .zone-problems h4 { margin: 0.75rem 0 0.5rem; }
    .problem-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.5rem; }
    .problem-card { text-align: center; padding: 0.5rem; background: #fafafa; border-radius: 8px; }
    .problem-card p { font-size: 0.78rem; margin: 0.25rem 0 0; color: #666; }

    /* Steps */
    .steps-list { display: flex; flex-direction: column; gap: 0.75rem; margin: 0.75rem 0; }
    .step { display: flex; gap: 0.75rem; align-items: flex-start; }
    .step-num { background: #1565c0; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.82rem; flex-shrink: 0; }
    .step p { font-size: 0.82rem; color: #666; margin: 0.2rem 0 0; }
    .step code { background: #e8eaf6; padding: 0.1rem 0.35rem; border-radius: 4px; font-size: 0.78rem; }

    /* Change table */
    .change-table { border: 2px solid #e0e0e0; border-radius: 8px; overflow: hidden; margin: 0.75rem 0; }
    .change-header { display: grid; grid-template-columns: 1fr 1fr 1fr; background: #1565c0; color: white; font-weight: 600; font-size: 0.82rem; }
    .change-header span { padding: 0.5rem 0.6rem; }
    .change-row { display: grid; grid-template-columns: 1fr 1fr 1fr; font-size: 0.8rem; border-top: 1px solid #e0e0e0; }
    .change-row span { padding: 0.4rem 0.6rem; }
    .change-row:nth-child(even) { background: #fafafa; }
    .works { color: #2e7d32; }
    .signal { color: #1565c0; font-weight: 500; }

    /* Live demo */
    .live-demo { background: #f5f5f5; border: 2px solid #e0e0e0; border-radius: 12px; padding: 1rem; margin: 0.75rem 0; }
    .demo-controls { display: flex; gap: 0.5rem; margin-bottom: 0.75rem; }
    .demo-values { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.5rem; }
    .value-card { background: white; border-radius: 8px; padding: 0.6rem; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .value-card .label { display: block; font-size: 0.72rem; text-transform: uppercase; color: #999; letter-spacing: 0.5px; }
    .value-card .value { display: block; font-size: 1.3rem; font-weight: 700; color: #1565c0; margin-top: 0.15rem; }

    /* Migration checklist */
    .migration-checklist { margin: 0.75rem 0; }
    .migration-checklist h4 { margin: 0 0 0.5rem; }
    .checklist-item { display: flex; align-items: center; gap: 0.5rem; padding: 0.35rem 0; font-size: 0.85rem; }
    .checklist-item code { background: #e8eaf6; padding: 0.1rem 0.35rem; border-radius: 4px; font-size: 0.78rem; }
    .check { color: #43a047; font-weight: 700; font-size: 1.1rem; }
  `]
})
export class ZonelessAngularComponent {
  // ═══════════ Live demo signals ═══════════
  count = signal(0);
  doubled = computed(() => this.count() * 2);
  isEven = computed(() => this.count() % 2 === 0);
  category = computed(() => {
    const c = this.count();
    if (c < 0) return 'Negative';
    if (c === 0) return 'Zero';
    if (c < 10) return 'Low';
    if (c < 50) return 'Medium';
    return 'High';
  });

  increment(): void { this.count.update(c => c + 1); }
  decrement(): void { this.count.update(c => c - 1); }
  reset(): void { this.count.set(0); }

  // ═══════════ Code examples ═══════════
  codeEnableZoneless = `// app.config.ts — enable zoneless change detection
import { provideExperimentalZonelessChangeDetection } from '@angular/core';

export const appConfig: ApplicationConfig = {
  providers: [
    provideExperimentalZonelessChangeDetection(),
    provideRouter(routes),
    provideHttpClient(),
  ]
};

// angular.json / project.json — REMOVE zone.js
{
  "polyfills": [
    // "zone.js"  ← DELETE this line
  ]
}

// Then uninstall: npm uninstall zone.js`;

  codeZonelessComponent = `// Zoneless-compatible component pattern
@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: \`
    <h2>{{ title() }}</h2>
    <p>Items: {{ items().length }}</p>

    @for (item of items(); track item.id) {
      <app-item [data]="item" />
    }
  \`
})
export class MyComponent {
  // All state as signals — the ONLY way to trigger updates without Zone.js
  title = signal('Products');
  items = signal<Item[]>([]);

  private http = inject(HttpClient);

  loadItems() {
    // Convert Observable to signal
    toSignal(this.http.get<Item[]>('/api/items'));

    // OR manually update signal
    this.http.get<Item[]>('/api/items').subscribe(data => {
      this.items.set(data);  // signal update triggers CD automatically
    });
  }
}`;

  codeMigration = `// Step-by-step migration from Zone.js to Zoneless

// 1. Start with hybrid mode (keep zone.js, add signals)
//    This approach lets you migrate incrementally.

// 2. Replace component state:
// BEFORE (Zone.js dependent)
export class OldComponent {
  title = 'Hello';              // plain property
  items: Item[] = [];           // plain array
  get total() { return ...; }   // getter (re-runs every CD)
}

// AFTER (Zoneless-ready)
export class NewComponent {
  title = signal('Hello');                // signal
  items = signal<Item[]>([]);             // signal
  total = computed(() => ...);            // computed (memoised)
}

// 3. Replace async patterns:
// BEFORE: setTimeout(() => this.data = newData, 1000);
// AFTER:  setTimeout(() => this.data.set(newData), 1000);

// 4. Test with provideExperimentalZonelessChangeDetection()
// 5. Remove zone.js from polyfills
// 6. npm uninstall zone.js`;
}
