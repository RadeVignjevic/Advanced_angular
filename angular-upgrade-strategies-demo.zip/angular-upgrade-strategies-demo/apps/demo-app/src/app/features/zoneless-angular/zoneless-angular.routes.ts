import { Route } from '@angular/router';
import { ZonelessAngularComponent } from './zoneless-angular.component';

export const ZONELESS_ANGULAR_ROUTES: Route[] = [
  { path: '', component: ZonelessAngularComponent }
];
